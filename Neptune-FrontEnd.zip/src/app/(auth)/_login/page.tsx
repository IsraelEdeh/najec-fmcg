/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import Link from "next/link";
import React, { useState } from "react";
import CustomButton from "@/components/Elements/CustomButton";

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

import CustomInput from "@/components/dashboard/CustomInput";
import Image from "next/image";
import { useMutation } from "@tanstack/react-query";
import { useDispatch } from "react-redux";
import { registerUserAsync } from "@/components/widgets/Features/UserSlice";
import { useRouter } from "next/navigation";
import { fetchUserAsync } from "@/components/widgets/Features/GetUserSlice";
import { toast } from "react-toastify";
import { TbLoader3 } from "react-icons/tb";

const schema = yup
  .object({
    // email: yup.string().email("[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,}$"),
    email: yup.string().email("Invalid email address"),
    password: yup
      .string()
      .matches(
        /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/,
        "Password must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
      )
  })
  .required();

const SignIn = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const [loading, setLoading] = useState<boolean>(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm({ resolver: yupResolver(schema) });

  const handleLogin = async (data: any) => {
    try {
      setLoading(true);

      const registerResult = await dispatch(registerUserAsync(data) as any);
      // console.log("registerResult::", registerResult);

      if (!registerResult?.payload?.status) {
        return;
      }
      // console.log("checkin");

      const fetchResult = await dispatch(fetchUserAsync() as any);
      // console.log("fetchResult::", fetchResult);

      if (fetchResult.payload.error) {
        toast.error(fetchResult.payload.error);
        return;
      }

      if (fetchResult?.payload?.userOrganizations?.length > 1) {
        return router.push("/company-select");
      }

      return router.push("/dashboard");
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error logging in.";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const mutation = useMutation({
    mutationFn: handleLogin,
    onSuccess: async () => {},
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onHandlerSubmit = (data: any) => {
    mutation.mutateAsync(data);
    mutation.reset();
    reset();
  };

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <Link href="/">
        <Image
          src="/auth/SignIn.png"
          width={160}
          height={29}
          alt="logo-icon"
          className="ml-[144px] pt-[32px] relative z-20"
        />
      </Link>
      <div className="pt-[190.5px] pr-[96px] flex justify-center items-center h-screen relative z-20">
        <section className="flex w-full justify-end">
          <div className="p-[40px] bg-[#F4F6F9] rounded-[16px] w-[480px] shadow-lg ">
            <header className="mb-10">
              <h1 className="text-[40px] font-semibold">Sign In</h1>
              <p className="text-sm text-[#757575]">
                Enter your email and password to sign in!
              </p>
            </header>

            <div>
              <form onSubmit={handleSubmit(onHandlerSubmit)}>
                <div>
                  <div className="grid grid-cols-1 space-y-8">
                    <div className="col-span-2">
                      <CustomInput
                        type="email"
                        label="Work Email"
                        placeholder="johndoe@gmail.com"
                        {...register("email")}
                      />

                      <p
                        className="text-red-400 mt-1 text-xs lg:text-sm"
                        role="alert"
                      >
                        {errors.email?.message}
                      </p>
                    </div>

                    <div className="col-span-2">
                      <div className="relative">
                        <CustomInput
                          type="password"
                          {...register("password")}
                          label="Password"
                          placeholder="********"
                        />
                        <div className="flex justify-end">
                          <Link
                            href="/forgot-password"
                            className="block cursor-pointer hover:underline underline-offset-4 text-xs text-red-600 mt-2"
                          >
                            forgot password?
                          </Link>
                        </div>
                      </div>

                      <p
                        className="text-red-400 mt-1 text-xs lg:text-sm"
                        role="alert"
                      >
                        {errors.password?.message}
                      </p>
                    </div>

                    <div className="col-span-2">
                      <CustomButton
                        type="submit"
                        classType="primary"
                        disabled={loading}
                        className="disabled:bg-secondary disabled:bg-opacity-50 w-full py-[9px] bg-primary text-white rounded-[4px]"
                      >
                        {loading ? (
                          <div className="flex items-center justify-center">
                            <div className="flex items-center space-x-2">
                              <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                              <span>Loading . . .</span>
                            </div>
                          </div>
                        ) : (
                          "Login"
                        )}
                      </CustomButton>
                    </div>
                  </div>
                </div>
              </form>
            </div>

            <div className="mt-10">
              <div className="hidden items-center justify-center mb-10">
                <hr className="w-1/4 border-gray-300" />
                <div className="bg-[#F4F5F7] p-2">
                  <p className="text-[#999da3] text-center text-sm">
                    {"or Sign in with"}
                  </p>
                </div>
                <hr className="w-1/4 border-gray-300" />
              </div>

              <button className="bg-[#E4E7EB] hidden p-3 rounded-lg mb-2  justify-center w-full cursor-pointer hover:scale-105 duration-300 ease-in">
                <div className="flex items-center space-x-2">
                  <Image
                    src="/auth/google-icon.png"
                    alt="google"
                    width={24}
                    height={24}
                  />
                  <p className="text-center text-[#4B5768]">
                    Continue with Google
                  </p>
                </div>
              </button>

              <button className="bg-[#E4E7EB] hidden p-3 rounded-lg  justify-center w-full cursor-pointer hover:scale-105 duration-300 ease-in">
                <div className="flex items-center space-x-2">
                  <Image
                    src="/auth/microsoft-icon.png"
                    alt="microsoft"
                    width={20}
                    height={20}
                  />
                  <p className="text-center text-[#4B5768]">
                    Continue with Microsoft
                  </p>
                </div>
              </button>

              <div>
                <Link
                  href="/sign-up"
                  className="block mt-10 text-center text-[#1E1E1E] text-sm underline hover:no-underline duration-150"
                >
                  <span>Create an account</span>
                </Link>
              </div>

              <p className="text-center text-sm mt-20 pb-10">
                © 2025 Deloitte Inc. All Rights Reserved
              </p>
            </div>
          </div>
        </section>
      </div>

      <div>
        <Image
          src="/auth/Rectangle2-black.png"
          height={897.59}
          width={897.59}
          alt="rectangle-icon"
          className="absolute top-[-200px] left-[-300px] z-10"
        />
      </div>

      <div>
        <Image
          src="/auth/Rectangle2Sky.png"
          height={750.94}
          width={750.94}
          alt="rectangle-icon"
          className="absolute top-[-100px] right-[-500px] z-10"
        />
      </div>

      <div>
        <Image
          src="/auth/Rectangle2Green.png"
          height={457.55}
          width={457.55}
          alt="rectangle-icon"
          className="absolute top-[750px] right-[200px] z-10"
        />
      </div>
    </div>
  );
};

export default SignIn;
