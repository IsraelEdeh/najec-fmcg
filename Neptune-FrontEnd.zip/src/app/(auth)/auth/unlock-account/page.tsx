/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import React, { useEffect, useState } from "react";
import CustomButton from "@/components/Elements/CustomButton";

import Image from "next/image";
import { useRouter, useSearchParams } from "next/navigation";
import { toast } from "react-toastify";
import { useMutation } from "@tanstack/react-query";
import ApiFetcher from "@/components/Utils/api";
import { TbLoader3 } from "react-icons/tb";

const Page = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const code = searchParams.get("code");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // console.log("id", id);

  const handleEmailVerification = async () => {
    try {
      setLoading(true);
      const response = await ApiFetcher.post(`/auth/unlock-admin/${code}`);
      setError("");
      toast.success(response.data.message);
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error unlocking account";
      console.log(errorMessage);
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    handleEmailVerification();
  }, [code]);

  return (
    <section className="relative">
      <Image
        src="/auth/CompanyLogo.png"
        height={29}
        width={140}
        alt="logo"
        className="absolute top-6 left-12 cursor-pointer"
      />

      <div className="h-screen flex justify-center items-center">
        {loading ? (
          <TbLoader3 className="text-primary animate-spin w-6 h-6" />
        ) : error ? (
          <p>{error}</p>
        ) : (
          <div>
            <div className="bg-[#F4F6F9] shadow-sm shadow-[#1E1E1E33] rounded-[16px] w-[478px] p-10">
              <header>
                <h1 className="text-[40px] text-primary font-semibold">
                  Account Unlocked
                </h1>
                <p className="mt-[8px] text-sm text-[#757575] leading-[22px] ">
                  Unlocked! Your account is now ready to use. Proceed to login
                  to continue.
                </p>
              </header>

              <div className="mt-10">
                <div className="">
                  <div>
                    <div className="grid grid-cols-1 space-y-8">
                      <div className="col-span-2">
                        <CustomButton
                          type="submit"
                          classType="primary"
                          className="disabled:bg-opacity-65 disabled:bg-secondary rounded-[4px] text-sm w-full py-[9px] bg-primary hover:bg-secondary text-white transition-all ease-linear delay-75"
                        >
                          Go to login
                        </CustomButton>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="absolute bottom-[0%] left-[50%] -translate-x-1/2 mt-10">
                <p className="text-center text-sm mt-20 pb-10">
                  © {new Date().getFullYear()} Deloitte Inc. All Rights Reserved
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="">
        <Image
          className="fixed top-[82px] right-0"
          src="/auth/green-1.svg"
          alt="blob"
          width={111}
          height={111}
        />
        <Image
          className="fixed top-[282px] right-0"
          src="/auth/black-1.svg"
          alt="blob"
          width={111}
          height={111}
        />
        <Image
          className="fixed top-[180px] right-6"
          src="/auth/dots-1.svg"
          alt="blob"
          width={136}
          height={84}
        />
      </div>
    </section>
  );
};

export default Page;
