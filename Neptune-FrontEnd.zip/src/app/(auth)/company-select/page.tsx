"use client";

import Link from "next/link";
import React, { useState } from "react";
import Image from "next/image";
import { FaUserCircle } from "react-icons/fa";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { HiMiniChevronRight, HiOutlineArrowRight } from "react-icons/hi2";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@/app/store";
import ApiFetcher from "@/components/Utils/api";
import { toast } from "react-toastify";
import { useMutation, useQuery } from "@tanstack/react-query";
import { fetchUserAsync } from "@/components/widgets/Features/GetUserSlice";
import { useRouter } from "next/navigation";
import { TbLoader3 } from "react-icons/tb";

const Page = () => {
  const user: any = useSelector((state: RootState) => state?.getUser?.user);
  const [loadingOrgId, setLoadingOrgId] = useState<string | number | null>(
    null
  );

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const getUserOrganization = async () => {
    try {
      const response = await ApiFetcher.get(`/auth/loggedin-user`);
      await dispatch(fetchUserAsync() as any);
      // console.log("fetch response::", await dispatch(fetchUserAsync() as any));

      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching users";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const { data, isPending, isLoading, error } = useQuery({
    queryKey: ["fetchUserOrganizations"],
    queryFn: getUserOrganization
  });

  // console.log("data", data);

  const router = useRouter();
  const dispatch = useDispatch();

  const handleSwitchOrganization = async (organizationId: any) => {
    setLoadingOrgId(organizationId);
    try {
      const payload = {
        userId: user?.userId,
        organizationId: organizationId
      };

      const response = await ApiFetcher.post(`/auth/switch/${organizationId}`, payload);
      // console.log("success::", response);
      if (response) {
        document.cookie = `jwt=${response.data.data.token}; path=/; Secure`;
        // fetchUserAsync();
      } else {
        toast.error("Login failed. Please check your credentials.");
      }

      const fetchResult = await dispatch(fetchUserAsync() as any);
      // console.log("fetchResult::", fetchResult);

      if (fetchResult?.payload?.error) {
        toast.error(fetchResult.payload.error);
        setLoadingOrgId(null);
        return;
      }
      router.push("/dashboard");
      toast.success(response?.data?.data?.message);
      setLoadingOrgId(null);

      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error switching organization";
      console.log("Error switching:", error);
      console.log(errorMessage);
      toast.error(errorMessage);
      setLoadingOrgId(null);
    }
  };

  const mutation = useMutation({
    mutationFn: handleSwitchOrganization,
    onSuccess: async () => {},
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onHandlerSubmit = (id: any) => {
    mutation.mutateAsync(id);
  };

  return (
    <div className="relative">
      <Link href="/">
        <Image
          src="/auth/CompanyLogo.png"
          height={29}
          width={160}
          alt="logo"
          className="ml-[132px] mt-[32px]"
        />
      </Link>
      <div className="relative flex w-full h-screen justify-center items-center">
        <section className="flex justify-center items-center bg-[#F4F6F9] rounded-[16px] w-[560px] shadow-lg py-[40px] z-20">
          <div className="">
            <div className="pb-1 rounded-[4px] ">
              <div className=" px-[40px] text-primary py-6 space-y-6">
                <p className="text-primary font-semibold text-[40px] text-center ">
                  Select Company
                </p>
                <div className="flex justify-center">
                  <div className="flex items-center space-x-2">
                    <FaUserCircle className="w-5 h-5" />

                    {user?.loading ? (
                      "Fetching User "
                    ) : (
                      <p>{user?.email || "N/A"} </p>
                    )}
                  </div>
                </div>

                <p className="text-center text-[sm]">
                  Choose a company below to continue:
                </p>
              </div>
            </div>

            <div className="rounded-t-[4px] mx-1 my-6 bg-[#F4F6F9] overflow-x-hidden max-h-[200px]">
              <ul className="space-y-6">
                {data?.userOrganizations?.map((org: any) => (
                  <li
                    key={org.organizationId}
                    onClick={() => onHandlerSubmit(org?.organizationId)}
                    className="group cursor-pointer flex justify-between items-center"
                  >
                    <p>
                      <span className="block">{org.organizationName}</span>
                    </p>

                    {loadingOrgId === org.organizationId ? (
                      <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                    ) : (
                      <HiMiniChevronRight className="text-xl group-hover:translate-x-1" />
                    )}
                  </li>
                ))}
              </ul>
            </div>

            <hr className="text-[#D9D9D9]" />

            {activeRole?.includes("Admin") && (
              <Link href="/create-company" className="block mt-[40px]">
                <p className="text-center text-[13px] text-[#1E1E1E]  underline hover:no-underline underline-offset-4 transition-all ease-in duration-200">
                  Create a new organisation
                </p>
              </Link>
            )}
          </div>
        </section>
      </div>

      <div>
        <Image
          src="/auth/Company-Black.png"
          width={923.68}
          height={923.68}
          alt="Rectangle-icon"
          className="absolute bottom-[-50px] left-[-80px]"
        />
      </div>

      <div>
        <Image
          src="/auth/Company-Green.png"
          width={365.44}
          height={365.44}
          alt="Rectangle-icon"
          className="absolute bottom-[-50px] right-[90px]"
        />
      </div>
    </div>
  );
};

export default Page;
