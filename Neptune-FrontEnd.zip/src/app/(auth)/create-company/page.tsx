"use client";

import Link from "next/link";
import React, { useState } from "react";
import Image from "next/image";
import { FaArrowLeft } from "react-icons/fa";
import { useRouter } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@/app/store";
import { Button } from "@/components/ui/button";
import CustomInput from "@/components/dashboard/CustomInput";
import { toast } from "react-toastify";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import ApiFetcher from "@/components/Utils/api";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { TbLoader3 } from "react-icons/tb";
import { fetchUserAsync } from "@/components/widgets/Features/GetUserSlice";
import CustomButton from "@/components/Elements/CustomButton";

type PayloadProps = {
  userId?: string;
  organizationName?: string | any;
};

const schema = yup
  .object({
    organizationName: yup
      .string()
      .min(3, "Organization name should be 3 characters or more")
      .matches(
        /^[A-Za-z\s]+$/,
        "Organization name can only contain letters and spaces"
      )
      .required("Organization name is required")
  })
  .required();

const Page = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const user: any = useSelector((state: RootState) => state?.getUser?.user);
  const router = useRouter();
  const dispatch = useDispatch();

  const queryClient = useQueryClient();

  // console.log("user::", user);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm({ resolver: yupResolver(schema), mode: "onChange" });

  const handleLogin = async (data: PayloadProps) => {
    try {
      const payload: any = {
        userId: user.userId,
        organizationName: data?.organizationName
      };

      setLoading(true);

      const response = await ApiFetcher.post(
        "/organization/create-new-organization",
        payload
      );

      // console.log("sjak::", response);

      if (response) {
        console.log("inside success::", response);
        document.cookie = `jwt=${response?.data?.data?.token}; path=/; Secure`;
        const fetchResult = await dispatch(fetchUserAsync() as any);
        // console.log("fetchResult::", fetchResult);
        console.log("outside success::", fetchResult);
      } else {
        return toast.error("Login failed. Please check your credentials.");
      }

      toast.success(response?.data?.data?.message);

      await dispatch(fetchUserAsync() as any);
      router.push("/dashboard");
      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error creating organisation";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const mutation = useMutation({
    mutationFn: handleLogin,
    onSuccess: () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onHandlerSubmit = (data: any) => {
    mutation.mutateAsync(data);
    mutation.reset();
    reset();
  };

  return (
    <div className="relative">
      <Link href="/">
        <Image
          src="/auth/CompanyLogo.png"
          height={29}
          width={160}
          alt="logo"
          className="ml-[132px] mt-[32px] cursor-pointer"
        />
      </Link>
      <div className="relative flex w-full h-screen overflow-x-hidden justify-center items-center">
        <section className="flex justify-center items-center bg-[#F4F6F9]  rounded-[16px] shadow-lg p-[40px] z-20">
          <div>
            <div className="flex justify-end mb-4">
              <button
                onClick={() => router.back()}
                className="w-fit flex items-center space-x-2 cursor-pointer"
              >
                <FaArrowLeft />
                <span className="block text-xs">back</span>
              </button>
            </div>
            <h1 className="text-2xl font-bold mb-4">Create Organization</h1>
            <form onSubmit={handleSubmit(onHandlerSubmit)}>
              <div>
                <div className="grid grid-cols-1 space-y-8">
                  <div className="col-span-2">
                    <input
                      type="text"
                      {...register("organizationName")}
                      placeholder="Your Awesome Organization"
                      className="w-[482px] text-base py-[7px] px-4 rounded-[4px] border border-[#D0D0CE] text-gray-900 placeholder:text-gray-500"
                    />
                    <p
                      className="text-red-400 mt-1 text-xs lg:text-sm"
                      role="alert"
                    >
                      {errors.organizationName?.message}
                    </p>
                  </div>

                  <div>
                    <CustomButton
                      type="submit"
                      disabled={loading}
                      className={`${
                        loading &&
                        "disabled:bg-secondary disabled:bg-opacity-70"
                      } w-full bg-primary text-white py-1.5`}
                    >
                      {loading ? (
                        <div className="flex justify-center items-center">
                          <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                        </div>
                      ) : (
                        "Create Organization"
                      )}
                    </CustomButton>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </section>
      </div>

      <div>
        <Image
          src="/auth/Company-Black.png"
          width={923.68}
          height={923.68}
          alt="Rectangle-icon"
          className="absolute bottom-[-50px] left-[-80px]"
        />
      </div>
    </div>
  );
};

export default Page;
