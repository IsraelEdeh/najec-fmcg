"use client";

import Link from "next/link";
import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import CustomInput from "@/components/dashboard/CustomInput";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useMutation, useQuery } from "@tanstack/react-query";
import axios from "axios";
import { TbLoader3 } from "react-icons/tb";
import { toast } from "react-toastify";
import { useMsal } from "@azure/msal-react";
import { InteractionRequiredAuthError } from "@azure/msal-browser";
import ApiFetcher from "@/components/Utils/api";
import { useDispatch } from "react-redux";
import { fetchUserAsync } from "@/components/widgets/Features/GetUserSlice";

export interface IFormInput {
  firstName: string;
  lastName: string;
  organizationName: string;
  phoneNumber: string;
  email: string;
  password: string;
}

const schema = yup
  .object({
    organizationName: yup
      .string()
      .min(3, "Company name should be 3 characters or more")
      .matches(
        /^[A-Za-z\s]+$/,
        "Organization name can only contain letters and spaces"
      )
      .required("Organization name is required")
  })
  .required();

const SignUp = () => {
  const router = useRouter();
  const { instance } = useMsal();
  const dispatch = useDispatch();
  const activeAccount = instance.getActiveAccount();
  const getIDToken = instance.getTokenCache();

  // console.log("check new active account in user", activeAccount);
  // console.log("tokens cache: ", getIDToken);
  const [isLoading, setIsLoading] = useState(false);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(schema),
    mode: "onChange"
  });

  const handleRegister = async (data: any) => {
    try {
      setIsLoading(true);
      // console.log("Form data submitted:", data);
      if (!activeAccount) return;

      const [lastName = "", firstName = ""] =
        activeAccount?.name?.split(",").map((name: any) => name.trim()) || [];

      const payload = {
        firstName: firstName,
        lastName: lastName,
        organizationName: data.organizationName,
        email: activeAccount.username,
        countryId: 1
      };

      // console.log("payload", payload);

      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_BASE_URL}/organization/create-organization`,
        payload
      );

      if (response) {
        if (!activeAccount.idToken) {
          return;
        }
        document.cookie = `jwt=${activeAccount.idToken}; path=/; Secure`;
        const res = await ApiFetcher.post(`/auth/exchange-token`);

        if (res?.data?.data?.token) {
          document.cookie = `jwt=${res.data.data.token}; path=/; Secure`;
          const fetchResult = await dispatch(fetchUserAsync() as any);

          // console.log("fetchResult::", "check here");
          if (fetchResult.payload.error) {
            toast.error(fetchResult.payload.error);
            return;
          }

          // console.log("fetchResult::", "didnt get here, check here again");
          toast.success("Organization created successfully");
          return router.push("/create-organisation/success");
        }
      }
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error signing up.";
      console.log(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const mutation = useMutation({
    mutationFn: handleRegister,
    onSuccess: () => {
      reset();
    }
  });

  const onHandlerSubmit = (data: any) => {
    mutation.mutate(data);
  };

  const getNeptuneBusinessCountries = async () => {
    try {
      const response = await axios.get(
        `${process.env.NEXT_PUBLIC_BASE_URL}/auth/countries`
      );

      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching countries data";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  // const {
  //   error: countryFetchError,
  //   data: countryData,
  //   isError
  // } = useQuery({
  //   queryKey: ["countryData"],
  //   queryFn: getNeptuneBusinessCountries
  // });

  if (isLoading) {
    <div className="glass-nav h-screen flex justify-center items-center">
      <div>
        <TbLoader3 className="text-primary animate-spin w-6 h-6" />
      </div>
    </div>;
  }

  return (
    <div className=" relative h-screen overflow-x-hidden overflow-y-hidden">
      <section className="px-[130px] relative z-20">
        <div className="">
          <Link href="/">
            <Image
              src="/auth/Logo.png"
              height={29}
              width={160}
              alt="Logo-icon"
              className="mt-[32px] z-40"
            />
          </Link>
          <section className="flex w-[480px] p-[40px] mt-[91px] bg-[#F4F6F9] rounded-[16px] shadow-lg z-20">
            <div className="w-full">
              <header className="mb-10">
                <h1 className="text-[24px] leading-[32px] text-[#000000] font-bold">
                  Create an Organization
                </h1>
                <p className="text-sm text-[#757575]">
                  Complete the form below to create organisation
                </p>
              </header>

              <div>
                <form onSubmit={handleSubmit(onHandlerSubmit)}>
                  <div>
                    <div className="grid grid-cols-1 space-y-8">
                      <div className="col-span-2">
                        <label className="flex items-center space-x-1 text-sm w-full max-w-[280px] font-bold text-[#1E1E1E]">
                          Organization Name
                        </label>
                        <input
                          type="text"
                          {...register("organizationName")}
                          placeholder="Your Awesome Company"
                          className="w-full text-base py-[7px] px-4 rounded-[4px] border border-[#D0D0CE] text-gray-900 placeholder:text-gray-500"
                        />

                        <p
                          className="text-red-400 mt-1 text-xs lg:text-sm"
                          role="alert"
                        >
                          {errors.organizationName?.message}
                        </p>
                      </div>

                      <div>
                        <Button
                          type="submit"
                          disabled={mutation.isPending}
                          className="disabled:bg-secondary disabled:bg-opacity-50 w-full bg-primary text-white rounded-[8px]"
                        >
                          {mutation.isPending ? (
                            <div className="flex items-center justify-center">
                              <div className="flex items-center space-x-2">
                                <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                                <span>Creating . . .</span>
                              </div>
                            </div>
                          ) : (
                            "Create account"
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </section>
        </div>
      </section>

      <div>
        <Image
          src="/auth/RectangleSky.png"
          height={750.94}
          width={750.94}
          alt="rectangle-icon"
          className="absolute top-[-40px] left-[0px] z-10"
        />
      </div>

      <div>
        <Image
          src="/auth/RectangleBlack.png"
          height={897.59}
          width={897.59}
          alt="rectangle-icon"
          className="absolute top-[-100px] right-[-300px] z-10"
        />
      </div>

      <div>
        <Image
          src="/auth/RectangleGreen.png"
          height={457.55}
          width={457.55}
          alt="rectangle-icon"
          className="absolute top-[800px] left-[150px] z-10"
        />
      </div>
    </div>
  );
};

export default SignUp;
