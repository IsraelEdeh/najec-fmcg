/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import React from "react";
import CustomButton from "@/components/Elements/CustomButton";

import Image from "next/image";
import { IoMdCheckmarkCircleOutline } from "react-icons/io";
import Link from "next/link";

const Page = () => {
  return (
    <section className="relative">
      <Link href="/">
        <Image
          src="/auth/CompanyLogo.png"
          height={29}
          width={140}
          alt="logo"
          className="absolute top-6 left-12 cursor-pointer"
        />
      </Link>

      <div className="h-screen flex justify-center items-center">
        <div>
          <div className="bg-[#F4F6F9] shadow-sm shadow-[#1E1E1E33] rounded-[16px] w-[478px] p-10">
            <div>
              <div className="flex justify-center">
                <IoMdCheckmarkCircleOutline className="text-7xl text-secondary" />
              </div>

              <h1 className="font-semibold text-center mt-2 text-2xl">
                Signed in successfully!
              </h1>
              {/* <p className="text-center mt-1 text-base">
                Verification email sent to you.
              </p> */}
              <div className="flex mt-4 justify-center">
                <Link href="/dashboard">
                  <CustomButton
                    type="submit"
                    classType="primary"
                    className="disabled:bg-secondary px-10 disabled:bg-opacity-50 w-full py-[9px] bg-primary text-white rounded-[4px]"
                  >
                    Proceed to dashboard
                  </CustomButton>
                </Link>
              </div>
            </div>

            <div className="absolute bottom-[0%] left-[50%] -translate-x-1/2 mt-10">
              <p className="text-center text-sm mt-20 pb-10">
                © {new Date().getFullYear()} Deloitte Inc. All Rights Reserved
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="">
        <Image
          className="fixed top-[82px] right-0"
          src="/auth/green-1.svg"
          alt="blob"
          width={111}
          height={111}
        />
        <Image
          className="fixed top-[282px] right-0"
          src="/auth/black-1.svg"
          alt="blob"
          width={111}
          height={111}
        />
        <Image
          className="fixed top-[180px] right-6"
          src="/auth/dots-1.svg"
          alt="blob"
          width={136}
          height={84}
        />
      </div>
    </section>
  );
};

export default Page;
