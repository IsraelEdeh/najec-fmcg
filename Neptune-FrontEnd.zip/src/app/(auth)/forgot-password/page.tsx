/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import Link from "next/link";
import React, { useState } from "react";
import CustomButton from "@/components/Elements/CustomButton";

import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

import CustomInput from "@/components/dashboard/CustomInput";
import Image from "next/image";
import { useMutation } from "@tanstack/react-query";
import { useDispatch } from "react-redux";
import { registerUserAsync } from "@/components/widgets/Features/UserSlice";
import { useRouter } from "next/navigation";

const schema = yup
  .object({
    email: yup.string().email("[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,}$"),
    password: yup
      .string()
      .matches(
        /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/,
        "Password must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
      ),
  })
  .required();

const Page = () => {
  return (
    <div className="relative">
      <section>
        <div className="relative">
          <section className="flex relative justify-center items-center h-screen z-20">
            <div className="relative w-[514px] pt-[45px] px-[57px] bg-[#F4F6F9] rounded-[16px] shadow-lg">
              <header className="mb-10">
                <h1 className="text-[40px] font-semibold">Forgot Password</h1>
                <p className="text-sm text-[#757575]">
                  No worries, we will send you reset instructions.
                </p>
              </header>

              <div>
                <form>
                  <div>
                    <div className="grid grid-cols-1 space-y-8">
                      <div className="col-span-2">
                        <CustomInput
                          type="email"
                          label="Work Email"
                          placeholder="johndoe@gmail.com"
                          //   {...register("email")}
                        />
                        {/* {touchedFields.email && <p>{errors.email?.message}</p>} */}
                      </div>

                      <div className="col-span-2">
                        <CustomButton
                          type="submit"
                          classType="primary"
                          //   disabled={loading}
                          className="w-full py-[9px] bg-primary text-white rounded-[8px]"
                        >
                          Reset password
                          {/* {loading ? "Logging in ..." : "Login"} */}
                        </CustomButton>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
              <Link
                href="/login"
                className="flex justify-center text-sm text-[#1E1E1E] underline my-[40px]"
              >
                Back to login
              </Link>
              {/* <div className="mt-10">
                <p className="text-center text-sm mt-20 pb-10">
                  © 2024 Deloitte Inc. All Rights Reserved
                </p>
              </div> */}
            </div>
          </section>
        </div>
      </section>

      <div>
        <Image
          src="/auth/Rectangle3Black.png"
          width={897.59}
          height={897.59}
          alt="Rectangle-icon"
          className="absolute top-[150px] left-[-110px]"
        />
      </div>

      <div>
        <Image
          src="/auth/Rectangle3Green.png"
          width={457.55}
          height={457.55}
          alt="Rectangle-icon"
          className="absolute top-[40px] right-[0px]"
        />
      </div>
    </div>
  );
};

export default Page;
