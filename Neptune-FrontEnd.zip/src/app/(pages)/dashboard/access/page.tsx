"use client";

import { RootState } from "@/app/store";
import ApiFetcher from "@/components/Utils/api";
import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import React, { useState } from "react";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import CustomButton from "@/components/Elements/CustomButton";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import {
  MdInfoOutline,
  MdOutlineArrowDropDown,
  MdOutlineFileDownload
} from "react-icons/md";
import { TbLoader3 } from "react-icons/tb";
import EmptyRecord from "@/components/dashboard/EmptyRecord";
import {
  RiArrowLeftSFill,
  RiArrowRightSFill,
  RiDeleteBin5Line
} from "react-icons/ri";
import {
  Dialog,
  DialogHeader,
  DialogContent,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { IoMdMore } from "react-icons/io";
import { FaEdit } from "react-icons/fa";
import AccessUserForm from "@/components/dashboard/access/AccessUserForm";
import ChangeStatusForm from "@/components/dashboard/access/ChangeStatusForm";
import { DialogClose, DialogDescription } from "@radix-ui/react-dialog";
import { Button } from "@/components/ui/button";
import { useMsal } from "@azure/msal-react";
import { log } from "console";
import { sanitizeFilename } from "@/lib/helpers";

const Access = () => {
  const queryClient = useQueryClient();

  const [loading, setLoading] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [openUserActivateDialog, setOpenUserActivateDialog] =
    useState<boolean>();
  const [selectedUserDetails, setSelectedUserDetails] = useState<any>(null);
  const [openUserDialog, setOpenUserDialog] = useState<boolean>();
  const [selectedUserId, setSelectedUserId] = useState<any>(null);
  const user: any = useSelector((state: RootState) => state?.getUser.user);
  const { instance } = useMsal();

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const isAdmin = user.roles.some(
    (roleObject: any) => roleObject.role === "Admin"
  );

  const activeEmail = user;
  console.log("activeEmail::", activeEmail);

  const organizationId = user?.userOrganizations?.find(
    (item: any) => item.isCurrentLoggedInOrganization
  )?.organizationId;
  const handleOpenEditDialog = (userId: any) => {
    setSelectedUserId(userId);
    setOpenUserActivateDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenUserActivateDialog(false);
    setSelectedUserId(null);
  };

  const handleCloseUserDialog = () => {
    setSelectedUserDetails(null);
  };

  const handleOpenUserDialog = (user: any) => {
    setSelectedUserDetails(user);
  };

  const maxPage = 10;

  const getAllUsers = async (page: number) => {
    try {
      const response = await ApiFetcher.get(
        `/users/get-all-users-in-an-organization?PageNumber=${page}&PageSize=${maxPage}`
      );
      // console.log("users::", response);
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching users";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: allUsers,
    isPending,
    isLoading,
    error
  } = useQuery({
    queryKey: ["fetchAllUsers", currentPage],
    placeholderData: keepPreviousData,
    queryFn: () => getAllUsers(currentPage)
  });

  const selectedUser = allUsers?.data?.data?.find(
    (user: any) => user?.phoneNumber === selectedUserId
  );

  const handleRemoveUserFromOrganization = async () => {
    try {
      // console.log("Organization ID:", organizationId);
      // console.log("User Email:", selectedUserDetails.email);
      const response = await ApiFetcher.post(
        `/organization/remove-user-from-organization`,
        {
          organizationId: organizationId,
          userEmail: selectedUserDetails.email
        }
      );
      setSelectedUserDetails(null);
      toast.success("User removed sucessfully");
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error deleting a user.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const deleteMutation = useMutation({
    mutationFn: handleRemoveUserFromOrganization,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  const logout = () => {
    instance.logoutRedirect().catch((error: any) => console.log(error));
  };

  const onHandlerDelete = () => {
    try {
      deleteMutation.mutateAsync();
      // if (isAdmin) {
      //   return logout();
      // }
      return;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding department.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const handleExportEmployees = async () => {
    try {
      setLoading(true);
      const response = await ApiFetcher.get(
        "/users/export-users?pageSize=1000",
        {
          responseType: "blob"
        }
      );

      const blob = new Blob([response.data], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");

      const fileName = sanitizeFilename("users") + ".xlsx";

      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success("Export done successfully");
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error exporting users.";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="relative px-4 py-6 ">
      <Dialog open={openUserDialog} onOpenChange={setOpenUserDialog}>
        <section>
          <nav aria-label="Breadcrumb" className="flex mb-[24px]">
            <ol className="inline-flex text-primary text-sm items-center">
              <li>
                <span>Employees</span>
              </li>
            </ol>
          </nav>

          <div className="mb-[24px]">
            <h1 className="text-[40px] leading-[52px] font-semibold mb-[10px]">
              User Management
            </h1>
            <p className="text-sm text-[#1E1E1E]">
              Add and manage all your employees from one page.
            </p>
          </div>

          <div className="bg-white rounded-[4px] ">
            <div className="px-5 pt-6 ">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <CustomButton
                    type="button"
                    classType="primary"
                    className="text-sm py-2 px-4 rounded-[4px] flex items-center space-x-2"
                    onClick={() => setOpenUserDialog(true)}
                  >
                    <span>Add User</span>
                    <span className="text-xl">+</span>
                  </CustomButton>

                  <DialogContent className="bg-white max-h-screen overflow-y-scroll">
                    <DialogHeader>
                      <DialogTitle className="text-xl">
                        Add user to organisation
                      </DialogTitle>
                      <AccessUserForm setOpenUserDialog={setOpenUserDialog} />
                    </DialogHeader>
                  </DialogContent>
                </div>

                <CustomButton
                  type="button"
                  onClick={handleExportEmployees}
                  classType="secondary"
                  className="px-4 py-2 text-xs rounded-[4px] flex items-center space-x-2"
                >
                  {loading ? (
                    <TbLoader3 className="text-primary animate-spin text-xs " />
                  ) : (
                    <MdOutlineFileDownload className="w-6 h-6 " />
                    // <Tooltip>
                    //   <TooltipTrigger asChild>
                    //     <MdOutlineFileDownload className="w-6 h-6 " />
                    //   </TooltipTrigger>
                    //   <TooltipContent>
                    //     <p>Export all employees in the organization</p>
                    //   </TooltipContent>
                    // </Tooltip>
                  )}
                </CustomButton>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full mt-[24px]">
                <thead className="bg-[#DDEFE8]">
                  <tr className=" w-full">
                    <th className="text-left p-4 uppercase text-xs font-semibold ">
                      S/N
                    </th>

                    <th className="text-left p-4 uppercase text-xs font-semibold ">
                      Name
                    </th>

                    <th className="text-left p-4 uppercase text-xs font-semibold ">
                      Email
                    </th>

                    <th className="text-left p-4 uppercase text-xs font-semibold ">
                      Roles
                    </th>

                    <th className="text-left p-4 uppercase text-xs font-semibold ">
                      <IoMdMore className="text-2xl cursor-pointer" />
                    </th>
                  </tr>
                </thead>

                {isPending ? (
                  <div className="mt-6 flex items-center justify-center">
                    <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                  </div>
                ) : allUsers?.data?.data?.length === 0 ? (
                  <EmptyRecord />
                ) : (
                  <tbody className="text-[#1A1A1A]">
                    {allUsers?.data?.data.map((item: any, index: number) => (
                      <tr
                        key={item.email}
                        className="border-t border-t-[#E5E7EB] w-full border-b border-b-[#D9D9D9]"
                      >
                        <td className="text-left p-4 text-sm font-normal flex-1">
                          {++index}
                        </td>

                        <td className="text-left p-4 text-sm font-normal flex-1">
                          {item.firstName} {item.lastName}
                        </td>

                        <td className="text-left p-4 text-sm font-normal flex-1">
                          {item.email}
                        </td>

                        <td className="text-left p-4 text-xs font-normal flex-1">
                          <div className="flex flex-wrap">
                            {item.roles.map((role: any, index: number) => (
                              <div
                                key={index}
                                className="font-medium w-fit bg-[#DDEFE8] p-2 rounded-[4px]"
                              >
                                {role}
                              </div>
                            ))}
                          </div>
                        </td>

                        <td className="text-left p-4 text-xs font-normal flex items-center space-x-2 flex-1">
                          {/* <FaEdit
                            // onClick={() => setOpenUserActivateDialog(true)}
                            onClick={() =>
                              handleOpenEditDialog(item?.phoneNumber)
                            }
                            className="text-xl cursor-pointer"
                          /> */}
                          {/* {
                            (!activeRole?.includes("Admin") ) 
                          } */}
                          {!isAdmin && (
                            <RiDeleteBin5Line
                              onClick={() => handleOpenUserDialog(item)}
                              className="text-xl cursor-pointer"
                            />
                          )}
                          <RiDeleteBin5Line
                            onClick={() => handleOpenUserDialog(item)}
                            className="text-xl cursor-pointer"
                          />
                        </td>

                        <Dialog
                          open={openUserActivateDialog}
                          onOpenChange={handleCloseDialog}
                        >
                          <DialogContent className="text-[#334] bg-white z-50">
                            <DialogHeader>
                              <DialogTitle className="text-xl">
                                Update User
                              </DialogTitle>
                            </DialogHeader>
                            <ChangeStatusForm userId={item} />
                          </DialogContent>
                        </Dialog>
                      </tr>
                    ))}
                  </tbody>
                )}
              </table>

              <div className="mt-4 flex items-center justify-between py-2 px-4">
                <p className="text-[#63666A] text-xs">
                  {(allUsers?.data?.meta?.pageNumber - 1) *
                    allUsers?.data?.meta?.pageSize +
                    1}
                  -
                  {Math.min(
                    allUsers?.data?.meta.pageNumber *
                      allUsers?.data?.meta.pageSize,
                    allUsers?.data?.meta?.totalCount
                  )}{" "}
                  of {allUsers?.data?.meta?.totalCount} items
                </p>

                <div className="flex items-center space-x-3">
                  <button
                    disabled={currentPage <= 1}
                    onClick={() => setCurrentPage((e: number) => e - 1)}
                    className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
                  >
                    <RiArrowLeftSFill className="w-4 h-4" />
                  </button>

                  <button
                    disabled={currentPage >= (Number(allUsers?.data?.meta?.totalPages) || 1)}
                    onClick={() => setCurrentPage((e: number) => e + 1)}
                    className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
                  >
                    <RiArrowRightSFill className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </Dialog>

      <Dialog open={!!selectedUserDetails} onOpenChange={handleCloseUserDialog}>
        <DialogContent className="w-[400px] bg-white">
          <DialogHeader>
            <DialogTitle>You are about to delete a user</DialogTitle>
            <DialogDescription className="pt-2">
              This will delete{" "}
              <span className="font-bold">
                {selectedUserDetails?.firstName} {selectedUserDetails?.lastName}
              </span>{" "}
              from your list
            </DialogDescription>
          </DialogHeader>

          <DialogFooter className="flex items-center space-x-2">
            <DialogClose asChild>
              <Button type="button" className="bg-primary text-white">
                Close
              </Button>
            </DialogClose>

            <Button
              className="bg-[#FF3B30] hover:bg-[#e2544c] focus:bg-[#e2544c] text-white"
              type="submit"
              onClick={onHandlerDelete}
            >
              {deleteMutation.isPending ? (
                <TbLoader3 className="animate-spin w-4 h-4" />
              ) : (
                "Delete"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  );
};

export default Access;
