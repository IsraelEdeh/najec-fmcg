"use client";

import Dashboard2Rightsidebar from "@/components/dashboard/dashboard2/Dashboard2Rightsidebar";
import { Button } from "@/components/ui/button";
import React, { useState } from "react";

const Dashboard2 = () => {
  const [closeRightSidebar, setCloseRightSidebar] = useState<boolean>(false);
  return (
    <main className="mt-20 grid grid-cols-1 gap-4 overflow-x-hidden px-4 py-6 lg:grid-cols-10">
      <div
        className={`w-full min-w-0 ${closeRightSidebar ? "lg:col-span-10" : "col-span-10 lg:col-span-7"}`}
      >
        <div>
          <p className="text-sm text-[#63666A] mb-[10px]">25 February 2025</p>
          <p className="text-[#000000] text-[40px] leading-[52px] font-semibold mb-[10px]">
            Good afternoon, Samuel
          </p>
          <p className="text-[#000000] text-sm">
            Good to see you. How can we supercharge your business today?
          </p>
        </div>

        <div className="mt-[40px]">
          <p className="text-2xl text-[#000000] font-bold">Things to do</p>

          <div className="my-[24px] border border-[#D9D9D9] bg-[#FFFFFF] rounded-[8px] py-[24px] px-[24px]">
            <p className="text-[#000000] text-[16px] leading-[24px] font-semibold">
              Complete setup for your Organisation
            </p>
            <p className="py-[10px] text-[#000000] text-sm">
              Update your organisation profile, add departments and configure
              other settings related to your organisation.
            </p>

            <Button className="px-[24px] py-[11px] text-[#ffffff] bg-[#005587] rounded-[4px]">
              Go to organisation details
            </Button>
          </div>

          <div className="my-[24px] border border-[#D9D9D9] bg-[#FFFFFF] rounded-[8px] py-[24px] px-[24px]">
            <p className="text-[#000000] text-[16px] leading-[24px] font-semibold">
              Add your employees and other admins
            </p>
            <p className="py-[10px] text-[#000000] text-sm">
              Good to see you. How can we supercharge your business today?
            </p>

            <Button className="px-[24px] py-[11px] text-[#ffffff] bg-[#005587] rounded-[4px]">
              See Employees
            </Button>
          </div>

          <div className="my-[24px] border border-[#D9D9D9] bg-[#FFFFFF] rounded-[8px] py-[24px] px-[24px]">
            <p className="text-[#000000] text-[16px] leading-[24px] font-semibold">
              Configure payroll for your needs
            </p>
            <p className="py-[10px] text-[#000000] text-sm">
              Setup your pay schedule, allowances, deductions and other
              important components of payroll to enable Neptune take the load of
              your back with your upcoming payrolls.
            </p>

            <Button className="px-[24px] py-[11px] text-[#ffffff] bg-[#005587] rounded-[4px]">
              See Payroll settings
            </Button>
          </div>
        </div>
      </div>

      <div className={`${closeRightSidebar ? "hidden" : "block col-span-10 lg:col-span-3"}`}>
        <div className="h-screen">
          <Dashboard2Rightsidebar
            setCloseRightSidebar={setCloseRightSidebar}
            closeRightSidebar={closeRightSidebar}
          />
        </div>
      </div>
    </main>
  );
};

export default Dashboard2;
