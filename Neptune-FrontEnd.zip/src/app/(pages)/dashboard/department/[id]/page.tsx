"use client";

import { ChevronRightIcon } from "lucide-react";
import Link from "next/link";
import React from "react";
import CustomButton from "@/components/Elements/CustomButton";
import { useMutation, useQuery } from "@tanstack/react-query";
import { toast } from "react-toastify";
import ApiFetcher from "@/components/Utils/api";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@/app/store";

const schema = yup
  .object({
    departmentName: yup
      .string()
      .min(3, "Department name should be 3 characters or more")
  })
  .required();

const page = ({ params }: { params: Promise<{ slug: string }> }) => {
  const departmentId: any = params;

  const user: any = useSelector((state: RootState) => state.getUser.user);
  // console.log("user data", user);

  const fetchDepartmentDetails = async () => {
    try {
      const response = await ApiFetcher.get(
        `/departments/get-department-by-id/${departmentId?.id}`
      );

      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching employee details.";
      console.log(error);
      toast.error(errorMessage);
    }
  };

  const { isPending, data: departmentData } = useQuery({
    queryKey: ["fetchDepartmentDetails"],
    queryFn: fetchDepartmentDetails
  });

  const {
    register,
    handleSubmit,
    formState: { errors }
    // reset
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      departmentName: departmentData?.name || ""
    }
  });

  const updateDepartment = async (data: any) => {
    try {
      const payload: any = {
        organizationId: user?.userOrganizations[0]?.organizationId,
        name: data.departmentName || departmentData?.name
      };
      // console.log("payload:", payload);

      const response = await ApiFetcher.put(
        `/departments/update-Department/${departmentId?.id}`,
        payload
      );
      toast.success("Department updated successfully!");
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching employee details.";
      console.log(error);
      toast.error(errorMessage);
    }
  };

  const mutation = useMutation({
    mutationFn: updateDepartment,
    onSuccess: () => {
      console.log("Organization updated successfully!");
    }
  });

  const onHandlerSubmit = (data: any) => {
    mutation.mutateAsync(data);
  };

  return (
    <main className=" px-4 py-6">
      <nav className="flex" aria-label="Breadcrumb">
        <ol className="inline-flex items-center space-x-1 md:space-x-3">
          <li className="inline-flex items-center">
            <Link
              href="/dashboard/department"
              className="text-sm text-blue-700 hover:underline"
            >
              Departments
            </Link>
          </li>
          <li>
            <ChevronRightIcon className="w-4 h-4 text-gray-400" />
          </li>
          <li>
            <span className="text-sm font-medium text-gray-500">
              Update Department
            </span>
          </li>
        </ol>
      </nav>

      <h1 className="text-2xl font-semibold mt-4 mb-2">Department Details</h1>
      <p className="text-gray-600 mb-6">
        Click save after edits to update employee records
      </p>

      <form onSubmit={handleSubmit(onHandlerSubmit)}>
        <div className="border border-[#D9D9D9] rounded-[4px] bg-white px-[24px] pt-[28px] pb-[44px]">
          <div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="hidden md:col-span-2">
                <label
                  htmlFor="id"
                  className="block mb-2 text-sm font-medium text-gray-900"
                >
                  Staff number
                </label>
                <input
                  type="hidden"
                  id="id"
                  name="id"
                  defaultValue={departmentData?.id}
                  placeholder={departmentData?.id}
                  className="disabled:bg-gray-100 disabled:border-purple-50 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                  required
                  disabled
                />
              </div>

              <div className="md:col-span-2">
                <label
                  htmlFor="departmentName"
                  className="block mb-2 text-sm font-medium text-gray-900"
                >
                  Department Name
                </label>
                <input
                  type="text"
                  placeholder={departmentData?.name}
                  defaultValue={departmentData?.name}
                  {...register("departmentName")}
                  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                  required
                />
                <p
                  className="text-red-400 mt-1 text-xs lg:text-sm"
                  role="alert"
                >
                  {String(errors?.departmentName?.message || "")}
                </p>
              </div>

              <div className="md:col-span-2">
                <label
                  htmlFor="status"
                  className="block mb-2 text-sm font-medium text-gray-900"
                >
                  Status
                </label>
                <select
                  defaultValue={
                    departmentData?.isActive ? "Active" : "Inactive"
                  }
                  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                >
                  <option
                    value={departmentData?.isActive ? "Active" : "Inactive"}
                  >
                    {departmentData?.isActive ? "Active" : "Inactive"}
                  </option>
                  <option>Active</option>
                  <option>Inactive</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end mt-10">
              <CustomButton
                type="submit"
                classType="primary"
                className="px-10 py-2.5"
              >
                Update
              </CustomButton>
            </div>
          </div>
        </div>
      </form>
    </main>
  );
};

export default page;
