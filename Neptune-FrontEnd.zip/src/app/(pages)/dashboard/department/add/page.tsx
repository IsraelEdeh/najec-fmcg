"use client";

import { ChevronRightIcon } from "lucide-react";
import Link from "next/link";
import React from "react";
import CustomButton from "@/components/Elements/CustomButton";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import ApiFetcher from "@/components/Utils/api";
import { toast } from "react-toastify";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

// kjkjk
const schema = yup
  .object({
    name: yup.string().min(3, "Department name should be 3 characters or more")
  })
  .required();

const Page = () => {
  const user: any = useSelector((state: RootState) => state.getUser.user);

  const queryClient = useQueryClient();

  // console.log(
  //   "logged in user: ",
  //   user?.userOrganizations?.find(
  //     (item: any) => item.isCurrentLoggedInOrganization
  //   )?.organizationId
  // );

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset
  } = useForm({
    resolver: yupResolver(schema)
  });

  const handleAddDepartments = async (data: any) => {
    try {
      const response = await ApiFetcher.post(`/departments/create-department`, {
        organizationId: user?.userOrganizations?.find(
          (item: any) => item.isCurrentLoggedInOrganization
        )?.organizationId,
        name: data.name
      });

      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding departments up";
      console.log(errorMessage);
      toast.error(errorMessage);
    } finally {
      reset();
    }
  };

  const mutation = useMutation({
    mutationFn: handleAddDepartments,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    }
  });

  const onHandlerSubmit = (data: any) => {
    mutation.mutateAsync(data);
    // console.log(data);
  };

  return (
    <div className="px-4 pt-6 pb-[46px] h-screen">
      <nav className="flex" aria-label="Breadcrumb">
        <ol className="inline-flex items-center space-x-1 md:space-x-3">
          <li className="inline-flex items-center">
            <Link
              href="/dashboard/department"
              className="text-sm text-[#757575] hover:text-[#131313] underline-offset-4 transition-all duration-150 ease-in"
            >
              Departments
            </Link>
          </li>
          <li>
            <ChevronRightIcon className="w-4 h-4 text-[#B5B5C0]" />
          </li>
          <li>
            <span className="text-sm font-medium text-primary">
              Add Department
            </span>
          </li>
        </ol>
      </nav>

      <h1 className="text-2xl font-semibold mt-4 mb-2">Add Department</h1>
      <p className="text-gray-600 mb-6">
        Enter details of departments below to add them to Neptune
      </p>

      <form onSubmit={handleSubmit(onHandlerSubmit)}>
        <div className="border border-[#D9D9D9] rounded-[4px] bg-white px-[24px] pt-[28px] pb-[44px]">
          <div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="hidden md:col-span-2">
                <label
                  htmlFor="staffIdTag"
                  className="block mb-2 text-sm font-medium text-gray-900"
                >
                  Organization
                </label>
                <input
                  type="hidden"
                  id="organizationId"
                  name="organizationId"
                  placeholder={`OrganizationId`}
                  className="disabled:bg-gray-100 disabled:border-purple-50 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                  required
                  disabled
                />
              </div>

              <div className="md:col-span-2">
                <label
                  htmlFor="name"
                  className="block mb-2 text-sm font-medium text-gray-900"
                >
                  Department name
                </label>
                <input
                  type="text"
                  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                  placeholder="Add department name"
                  {...register("name")}
                  required
                />

                <p
                  className="text-red-400 mt-1 text-xs lg:text-sm"
                  role="alert"
                >
                  {errors.name?.message}
                </p>
              </div>
            </div>

            <div className="flex justify-end mt-10">
              <CustomButton
                type="submit"
                classType="primary"
                className="px-10 py-2.5"
              >
                {isSubmitting ? "Adding ..." : "Add"}
              </CustomButton>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default Page;
