"use client";

import React, { useState } from "react";
import Link from "next/link";
import CustomButton from "@/components/Elements/CustomButton";
import { FaPlus } from "react-icons/fa6";
import { AiFillDelete } from "react-icons/ai";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { MdOutlineArrowDropDown } from "react-icons/md";
import ApiFetcher from "@/components/Utils/api";
import { toast } from "react-toastify";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { FaEye } from "react-icons/fa";
import { LiaEditSolid } from "react-icons/lia";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import { CiExport } from "react-icons/ci";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { FiInfo } from "react-icons/fi";
import { Button } from "@/components/ui/button";

const page = () => {
  const queryClient = useQueryClient();

  const [deleteDataInput, setDeleteDataInput] = useState<string>("");
  const [selectedDepartment, setSelectedDeparment] = useState<any>(null);

  const handleOpenDialog = (department: any) => {
    setSelectedDeparment(department);
  };

  const handleCloseDialog = () => {
    setSelectedDeparment(null);
  };

  const user: any = useSelector((state: RootState) => state?.getUser?.user);

  const fetchDeparments = async() => {
    try {
      const response = await ApiFetcher.get(
        "/departments/get-all-departments-in-an-organization"
      );
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching departments";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  const { isLoading, data, error } = useQuery({
    queryKey: ["departments"],
    queryFn: fetchDeparments
  });

  const handleDeleteDepartment = async () => {
    try {
      const response = await ApiFetcher.delete(
        `/departments/delete-department/${selectedDepartment?.id}`
      );
      setSelectedDeparment(null);
      toast.success("Department removed sucessfully");
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error deleting a department.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const deleteMutation = useMutation({
    mutationFn: handleDeleteDepartment,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  const onHandlerDelete = () => {
    try {
      deleteMutation.mutateAsync();
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding department.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  return (
    <main className=" px-4 py-6">
      <Dialog open={!!selectedDepartment} onOpenChange={handleCloseDialog}>
        <div className="w-full">
          <p className="text-primary text-sm mb-4">Departments</p>
          <h1 className="text-[32px] font-semibold mb-2 text-[#1e1e1e]">
            Departments
          </h1>
          <p className="text-gray-600 mb-6">
            Add and manage all your departments from one page.
          </p>

          <div className="bg-white rounded-[16px]">
            <div className="px-5 pt-6 pb-4">
              <div className=" flex justify-end items-center">
                <div className="flex items-center space-x-4">
                  <Link href="/dashboard/department/add">
                    <CustomButton
                      classType="primary"
                      className="px-4 py-[9px] text-sm rounded-[4px] flex items-center space-x-2"
                    >
                      <span>Add Department</span>
                      <FaPlus />
                    </CustomButton>
                  </Link>

                  <CustomButton
                    classType="secondary"
                    className="px-4 py-[9px] text-sm rounded-[4px] flex items-center space-x-2"
                  >
                    <span>Export </span>
                    <CiExport />
                  </CustomButton>
                </div>
              </div>

              <div className="hidden items-center justify-between mt-[26px]">
                <div className="flex items-center space-x-4">
                  <div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button
                          className="flex items-center space-x-2 py-1 px-2 text-sm border border-[#d9d9d9] text-[#1E1E1E] rounded-[8px]"
                          type="button"
                        >
                          <span>Choose Department</span>

                          <MdOutlineArrowDropDown />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="w-56 bg-white">
                        <DropdownMenuGroup>
                          <DropdownMenuItem>Department: All</DropdownMenuItem>
                          <DropdownMenuItem>Department: Tax</DropdownMenuItem>
                          <DropdownMenuItem>Department: Cho</DropdownMenuItem>
                        </DropdownMenuGroup>
                        <DropdownMenuSeparator />
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <p>Rows: </p>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button
                        className="flex items-center space-x-2 py-1 px-2 text-sm border border-[#d9d9d9] text-[#1E1E1E] rounded-[8px]"
                        type="button"
                      >
                        <span>10</span>

                        <MdOutlineArrowDropDown />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="w-56 bg-white">
                      <DropdownMenuGroup>
                        <DropdownMenuItem>10</DropdownMenuItem>
                        <DropdownMenuItem>20</DropdownMenuItem>
                        <DropdownMenuItem>50</DropdownMenuItem>
                        <DropdownMenuItem>100</DropdownMenuItem>
                      </DropdownMenuGroup>
                      <DropdownMenuSeparator />
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full mt-[24px]">
                <thead className="bg-[#DDEFE8]">
                  <tr className=" w-full">
                    <th className="text-left p-4 uppercase text-xs font-semibold ">
                      S/N
                    </th>

                    <th className="text-left p-4 uppercase text-xs font-semibold ">
                      Department
                    </th>

                    <th className="text-left p-4 uppercase text-xs font-semibold ">
                      Organization
                    </th>

                    <th className="text-left p-4 uppercase text-xs font-semibold ">
                      Status
                    </th>

                    <th className="text-left p-4 uppercase text-xs font-semibold ">
                      <span className="hidden">Details</span>
                    </th>
                  </tr>
                </thead>

                <tbody className="text-[#1A1A1A]">
                  {isLoading ? (
                    <div className="pt-4 space-y-3">
                      <Skeleton className="bg-gray-200 h-[125px] w-full rounded-xl" />
                      <div className="space-y-2">
                        <Skeleton className="bg-gray-200 h-4 w-full" />
                        <Skeleton className="bg-gray-200 h-4 w-full" />
                      </div>
                    </div>
                  ) : (
                    data?.data?.data.map((item: any, index: number) => (
                      <tr
                        key={item?.name}
                        className="border-t border-t-[#E5E7EB] w-full border-b border-b-[#D9D9D9]"
                      >
                        <td className="text-left p-4 text-sm font-normal ">
                          {index + 1}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.name}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {user?.userOrganizations?.find(
                            (item: any) => item.isCurrentLoggedInOrganization
                          )?.organizationName || "N/A"}
                        </td>

                        <td className="text-left text-sm ">
                          <span
                            className={` font-medium text-white rounded-[4px] p-2 ${
                              item?.isActive ? " bg-green-600" : " bg-red-500"
                            }`}
                          >
                            {item?.isActive ? "Active" : "InActive"}
                          </span>
                        </td>

                        <td className="flex space-x-4 items-center p-4">
                          <Link href={`/dashboard/department/${item?.id}`}>
                            <LiaEditSolid className="cursor-pointer inline text-[24px]" />
                          </Link>
                          <AiFillDelete
                            onClick={() => handleOpenDialog(item)}
                            className="text-primary cursor-pointer hover:scale-110 w-6 h-6"
                          />
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>

              <DialogContent className="w-[620px] rounded-[4px] p-10">
                <DialogHeader>
                  <DialogTitle className="text-xl">Confirm Delete</DialogTitle>
                  <DialogDescription className="pt-2">
                    <div className="font-semibold">
                      You are attempting to delete this department.
                    </div>
                    <div className="mt-1">
                      This will remove all data related to this company,
                      including payroll history, employees and all
                      configurations done previously. Are you sure you want to
                      proceed with this action.
                    </div>

                    <div className="rounded-[4px] flex items-center space-x-2 my-6 border-[#757575] border-2 bg-[#f4f6f9] p-[18px]">
                      <FiInfo className="w-4 h-4 text-[#ff3b30] " />

                      <p className="text-[#1e1e1e]">
                        This action cannot be undone.
                      </p>
                    </div>
                  </DialogDescription>
                </DialogHeader>

                <div className="w-full">
                  <form className="flex items-center gap-2">
                    <div className="w-full">
                      <input
                        type="text"
                        placeholder="Type 'Delete' to confirm action"
                        value={deleteDataInput}
                        onChange={(e: any) =>
                          setDeleteDataInput(e.target.value)
                        }
                        className="rounded-[4px] border py-2.5 pl-3 w-full"
                      />
                    </div>
                    <div>
                      <Button
                        className="bg-[#FF3B30] hover:bg-[#e2544c] disabled:bg-[#DDC9C8] disabled:text-white focus:bg-[#e2544c] text-white"
                        type="button"
                        onClick={onHandlerDelete}
                        disabled={deleteDataInput !== "Delete"}
                      >
                        Delete
                      </Button>
                    </div>
                  </form>
                </div>
              </DialogContent>
            </div>
          </div>
        </div>
      </Dialog>
    </main>
  );
};

export default page;
