"use client";

import { Button } from "@/components/ui/button";
import { ChevronRightIcon, Trash2 } from "lucide-react";
import Link from "next/link";
import React, { useEffect, useState } from "react";
import BasicEmployeesDetails from "@/components/Employees/Details/BasicEmployeesDetails";
import PersonalInfoEmployeesDetails from "@/components/Employees/Details/PersonalInfoEmployeesDetails";
import PayslipEmployeeDetails from "@/components/Employees/Details/PayslipEmployeeDetails";
import AnnualEntitlements from "@/components/Employees/Details/AnnualEntitlements";
import EmployerTaxShare from "@/components/Employees/Details/EmployerTaxShare";
import ApiFetcher from "@/components/Utils/api";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { useForm, type FieldErrors } from "react-hook-form";
import { getNeptuneBusinessCountries } from "@/constants";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { FiInfo } from "react-icons/fi";
import { TbLoader3 } from "react-icons/tb";
import { useParams, useRouter } from "next/navigation";
import {
  toDateOnly,
  toEmployeeFormValues,
  toUpdateEmployeeRequest
} from "@/lib/employee-mappers";
import {
  isNotInFuture,
  isValidDate,
  optionalGender,
  optionalMinLength,
  optionalPastDate,
  optionalPhone
} from "@/lib/employee-validation";
import { getApiErrorMessage } from "@/lib/utils";
import useStates from "@/hooks/Custom-hook/useStates";
import type { EmployeeEditFormValues, EmployeeResponse } from "@/types/employee";

const schema: yup.ObjectSchema<EmployeeEditFormValues> = yup.object({
  staffNumber: yup.string().trim().required("Staff ID is required"),
  firstName: yup
    .string()
    .trim()
    .min(3, "First name should be 3 characters or more")
    .required("First name is required"),
  lastName: yup
    .string()
    .trim()
    .min(3, "Last name should be 3 characters or more")
    .required("Last name is required"),
  middleName: yup.string().default(""),
  phoneNumber: optionalPhone(),
  email: yup
    .string()
    .trim()
    .email("Invalid email address")
    .required("Email is required"),
  dateOfBirth: optionalPastDate("Date of birth"),
  gender: optionalGender(),
  address: optionalMinLength(3, "Address should be 3 characters or more"),
  employmentType: yup
    .string()
    .oneOf(["0", "1"], "Select a valid employment type")
    .required("Employment type is required"),
  departmentId: yup.string().default(""),
  employeeJobTitleId: yup.string().required("Job title is required"),
  employeeGradeId: yup.string().required("Grade is required"),
  costCenterId: yup.string().default(""),
  subsidiaryId: yup.string().required("Subsidiary is required"),
  payerId: yup.string().default(""),
  taxAuthority: yup
    .string()
    .min(2, "Tax authority must be 2 characters or more")
    .required("Tax authority is required"),
  rsaPin: optionalMinLength(5, "Pension pin must be 5 characters or more"),
  dateJoined: optionalPastDate("Date joined"),
  disengagementDate: yup
    .string()
    .default("")
    .test("valid-date", "Disengagement date must be a valid date", isValidDate)
    .test("not-in-future", "Disengagement date cannot be in the future", isNotInFuture)
    .test(
      "after-date-joined",
      "Disengagement date cannot be before the employment date",
      (value, context) => {
        const joined = toDateOnly(context.parent.dateJoined);
        return !value || !joined || toDateOnly(value) >= joined;
      }
    ),
  countryId: yup.string().required("Country is required"),
  stateId: yup.string().required("State is required"),
  pensionFundAdministrator: yup.string().default(""),
  bankName: yup.string().default(""),
  accountNumber: yup
    .string()
    .trim()
    .matches(/^\d{10}$/, "Account number must be 10 digits and only contain numbers")
    .required("Account number is required"),
  accountName: yup
    .string()
    .trim()
    .min(3, "Account name should be 3 characters or more")
    .required("Account name is required"),
  nhfNumber: yup.string().default(""),
  nhfExists: yup.boolean().default(false),
  nhisExists: yup.boolean().default(false),
  voluntaryPensionExists: yup.boolean().default(false),
  isPensionExempt: yup.boolean().default(false)
});

const basicStepFields = new Set<keyof EmployeeEditFormValues>([
  "staffNumber",
  "firstName",
  "lastName",
  "middleName",
  "countryId",
  "stateId",
  "employmentType",
  "departmentId",
  "employeeJobTitleId",
  "employeeGradeId",
  "costCenterId",
  "subsidiaryId",
  "dateJoined",
  "disengagementDate"
]);

const EmployeeDetailsPage = () => {
  const queryClient = useQueryClient();
  const router = useRouter();
  const params = useParams() as { id?: string };
  const id = params?.id;

  const [currentStep, setCurrentStep] = useState(1);
  const [isOrganizationDeleteDialogOpen, setIsOrganizationDeleteDialogOpen] =
    useState(false);

  const [deleteDataInput, setDeleteDataInput] = useState<string>("");

  const handleOpenOrganizationDeleteDialog = () => {
    setIsOrganizationDeleteDialogOpen(true);
  };

  const handleCloseOrganizationDeleteDialog = () => {
    setIsOrganizationDeleteDialogOpen(false);
  };

  const handleNext = () => {
    setCurrentStep((prevStep) => prevStep + 1);
  };

  const fetchEmployeeDetails = async (
    employeeId: string
  ): Promise<EmployeeResponse> => {
    const response = await ApiFetcher.get(
      `/employees/get-employee-by-id/${employeeId}`
    );
    const employee = response?.data?.data;
    if (!employee) throw new Error("Employee not found.");
    return employee;
  };

  const {
    isPending,
    isError,
    error: employeeFetchError,
    data: employeeData
  } = useQuery<EmployeeResponse>({
    queryKey: ["fetchEmployeesDetailsById", id],
    queryFn: () => fetchEmployeeDetails(String(id)),
    enabled: Boolean(id)
  });

  useEffect(() => {
    if (isError) {
      toast.error(
        getApiErrorMessage(employeeFetchError, "Error fetching employee details.")
      );
    }
  }, [isError, employeeFetchError]);

  const { data: employeeCountryData, isPending: isCountryLoading } = useQuery({
    queryKey: ["empCountryData"],
    queryFn: getNeptuneBusinessCountries
  });

  const { states } = useStates();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
    setValue,
    getValues
  } = useForm<EmployeeEditFormValues>({
    resolver: yupResolver(schema)
  });

  useEffect(() => {
    if (employeeData) reset(toEmployeeFormValues(employeeData));
  }, [employeeData, reset]);

  // Some responses expose `state` as a plain name, so resolve its id once the states list is available.
  useEffect(() => {
    const stateName = employeeData?.state;
    if (typeof stateName !== "string" || !Array.isArray(states) || getValues("stateId")) {
      return;
    }
    const match = states.find(
      (state: { id?: number; name?: string }) =>
        state?.name?.trim().toLowerCase() === stateName.trim().toLowerCase()
    );
    if (match?.id !== undefined) setValue("stateId", String(match.id));
  }, [employeeData, states, getValues, setValue]);

  const nhfExists = watch("nhfExists");
  const isPensionExempt = watch("isPensionExempt");

  const mutation = useMutation({
    mutationFn: (values: EmployeeEditFormValues) =>
      ApiFetcher.put(
        `/employees/update-employee/${id}`,
        toUpdateEmployeeRequest(values, employeeData)
      ),
    onSuccess: async () => {
      toast.success("Employee updated successfully");
      await queryClient.invalidateQueries();
    },
    onError: (error) => {
      toast.error(getApiErrorMessage(error, "Error updating employee"));
    }
  });

  const onHanderSubmit = (values: EmployeeEditFormValues) => {
    mutation.mutate(values);
  };

  const onInvalidSubmit = (formErrors: FieldErrors<EmployeeEditFormValues>) => {
    const fields = Object.keys(formErrors) as (keyof EmployeeEditFormValues)[];
    if (!fields.length) return;
    // Errors on the other tab are not visible, so switch to the tab holding the first error.
    setCurrentStep(basicStepFields.has(fields[0]) ? 1 : 2);
    toast.error(
      formErrors[fields[0]]?.message ?? "Please correct the highlighted fields."
    );
  };

  const handleDeleteEmployee = async () => {
    handleCloseOrganizationDeleteDialog();
    return ApiFetcher.delete(`/employees/delete-employee/${id}`);
  };

  const deleteMutation = useMutation({
    mutationFn: handleDeleteEmployee,
    onSuccess: () => {
      toast.success("Employee deleted successfully!");
      queryClient.removeQueries({ queryKey: ["fetchEmployeesDetailsById", id] });
      queryClient.invalidateQueries({ queryKey: ["fetchEmployees"] });
      router.push("/dashboard/employees");
    },
    onError: (error) => {
      toast.error(getApiErrorMessage(error, "Unable to delete employee."));
    }
  });

  const onHandlerDelete = () => {
    deleteMutation.mutate();
  };

  return (
    <div className="px-4 py-6">
      <nav className="flex" aria-label="Breadcrumb">
        <ol className="inline-flex items-center space-x-1 md:space-x-3">
          <li className="inline-flex items-center">
            <Link
              href="/dashboard/employees"
              className="text-sm text-blue-700 hover:underline"
            >
              Employees
            </Link>
          </li>
          <li>
            <ChevronRightIcon className="w-4 h-4 text-gray-400" />
          </li>
          <li>
            <span className="text-sm font-medium text-gray-500">
              Update Employee
            </span>
          </li>
        </ol>
      </nav>

      <h1 className="text-2xl font-semibold mt-4 mb-2">Employee Details</h1>
      <p className="text-gray-600 mb-6">
        Click save after edits to update employee records
      </p>

      <div className="border border-[#D9D9D9] bg-white p-[24px]">
        <div className="mb-6 flex space-x-4">
          <p
            onClick={() => setCurrentStep(1)}
            className={`${currentStep === 1
                ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                : "cursor-pointer"
              }`}
          >
            Basic
          </p>
          <p
            onClick={() => setCurrentStep(2)}
            className={`${currentStep === 2
                ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                : "cursor-pointer"
              }`}
          >
            Personal info
          </p>

          <p
            onClick={() => setCurrentStep(3)}
            className={`${currentStep === 3
                ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                : "cursor-pointer"
              }`}
          >
            Payslips
          </p>

          <p
            onClick={() => setCurrentStep(4)}
            className={`${currentStep === 4
                ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                : "cursor-pointer"
              }`}
          >
            Annual Entitlements
          </p>

          <p
            onClick={() => setCurrentStep(5)}
            className={`${currentStep === 5
                ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                : "cursor-pointer"
              }`}
          >
            Employer Tax Share
          </p>
        </div>

        <form
          onSubmit={handleSubmit(onHanderSubmit, onInvalidSubmit)}
          className="space-y-4"
        >
          {(currentStep === 1 || currentStep === 2) && isPending && (
            <div className="flex items-center justify-center py-6">
              <TbLoader3 className="text-primary animate-spin w-6 h-6" />
            </div>
          )}

          {(currentStep === 1 || currentStep === 2) && isError && (
            <p className="text-red-400 text-sm py-6 text-center" role="alert">
              {getApiErrorMessage(employeeFetchError, "Unable to load employee details.")}
            </p>
          )}

          {currentStep === 1 && employeeData && (
            <BasicEmployeesDetails
              employeeData={employeeData}
              employeeCountryData={employeeCountryData}
              register={register}
              isCountryLoading={isCountryLoading}
              errors={errors}
            />
          )}

          {currentStep === 2 && employeeData && (
            <PersonalInfoEmployeesDetails
              employeeData={employeeData}
              register={register}
              errors={errors}
              setValue={setValue}
              nhfExists={Boolean(nhfExists)}
              isPensionExempt={Boolean(isPensionExempt)}
            />
          )}

          <div
            className={`flex justify-end mt-6 gap-[24px] ${currentStep === 1 || currentStep === 2 ? "pb-[48px]" : "pb-[0px] "
              }`}
          >
            {currentStep === 1 && (
              <Button
                type="button"
                onClick={handleNext}
                className="bg-[#005587] hover:bg-[#2f80ae] text-white font-medium py-[11px] px-[103px] rounded-lg"
              >
                Next
              </Button>
            )}

            {currentStep === 2 && (
              <div className="flex items-center">
                <Button
                  type="submit"
                  className="disabled:bg-secondary disabled:bg-opacity-60 bg-[#005587] hover:bg-[#2f80ae] text-white font-medium py-[11px] px-[103px] rounded-lg"
                  disabled={mutation.isPending || !employeeData}
                >
                  {mutation.isPending ? "Saving . . ." : "Save"}
                </Button>
              </div>
            )}

            {currentStep === 2 && (
              <Button
                type="button"
                onClick={handleOpenOrganizationDeleteDialog}
                className="text-white hover:bg-[#FF3B30] bg-red-600 font-medium border py-[11px] px-[25px] rounded-lg"
              >
                Delete Employee <Trash2 size={20} />
              </Button>
            )}
          </div>
        </form>

        {currentStep === 3 && <PayslipEmployeeDetails id={id} />}

        {currentStep === 4 && (
          <AnnualEntitlements
            employeeId={String(id)}
            dateJoined={toDateOnly(employeeData?.dateJoined) || undefined}
          />
        )}

        {currentStep === 5 && <EmployerTaxShare employeeId={String(id)} />}
      </div>

      <Dialog
        open={isOrganizationDeleteDialogOpen}
        onOpenChange={handleCloseOrganizationDeleteDialog}
      >
        <DialogContent className="w-[620px] bg-white rounded-[4px] p-10">
          <DialogHeader>
            <DialogTitle className="text-xl">Confirm Delete</DialogTitle>
            <DialogDescription className="pt-2">
              <div className="font-semibold">
                You are attempting to delete this employee.
              </div>
              <div className="mt-1">
                This will remove all data related to this employee, including
                payroll history, profile data and all configurations done
                previously. Are you sure you want to proceed with this action.
              </div>

              <div className="rounded-[4px] flex items-center space-x-2 my-6 border-[#757575] border-2 bg-[#f4f6f9] p-[18px]">
                <FiInfo className="w-4 h-4 text-[#ff3b30] " />

                <p className="text-[#1e1e1e]">This action cannot be undone.</p>
              </div>
            </DialogDescription>
          </DialogHeader>

          <div className="w-full">
            <form className="flex items-center gap-2">
              <div className="w-full">
                <input
                  type="text"
                  placeholder="Type 'Delete' to confirm action"
                  value={deleteDataInput}
                  onChange={(e: any) => setDeleteDataInput(e.target.value)}
                  className="rounded-[4px] border py-2.5 pl-3 w-full"
                />
              </div>
              <div>
                <Button
                  className="bg-[#FF3B30] hover:bg-[#e2544c] disabled:bg-[#DDC9C8] disabled:text-white focus:bg-[#e2544c] text-white"
                  type="button"
                  onClick={onHandlerDelete}
                  disabled={deleteDataInput !== "Delete" || deleteMutation.isPending}
                >
                  Delete
                </Button>
              </div>
            </form>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default EmployeeDetailsPage;
