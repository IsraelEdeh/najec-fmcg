"use client";

import React, { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";

const BulkUpload = () => {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<string>("");
  const [error, setError] = useState<string>("");

  // console.log("file: ", file);
  // console.log("stats:", status);
  // console.log("error:", error);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      if (
        file.type ===
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      ) {
        setFile(file);
        setStatus("This file is correct");
        setError("");
      } else {
        setFile(null);
        setStatus("");
        setError(
          "This file is invalid. Please verify it matches the specified template."
        );
      }
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [
        ".xlsx, .xls, .csv"
      ]
    }
  });

  const handleUpload = () => {
    // console.log("dddo");
  };

  return (
    <div className="container mt-[4rem] p-[3rem] max-w-[700px]">
      <h1 className="text-2xl font-semibold mb-2">Employee Upload</h1>
      <p className="text-gray-600 mb-6">Add Employees in Bulk</p>
      <p className="mb-4">
        Select your employee schedule file to upload and add them to your
        account.
      </p>

      <div
        {...getRootProps()}
        className="border-2 border-gray-300 border-dashed p-6 text-center cursor-pointer"
      >
        <input {...getInputProps()} />
        {isDragActive ? (
          <p>Drop the file here ...</p>
        ) : (
          <p>
            Drag & Drop file here to upload
            <br />
            or <span className="underline">click to select</span> file
          </p>
        )}
        {file && <p>{file.name}</p>}
      </div>

      {error && <div className="mt-4 text-red-500">{error}</div>}
      {status && <div className="mt-4 text-green-500">{status}</div>}

      <div className="mt-6 flex justify-end">
        <Button
          variant="outline"
          className="mr-2 bg-red-600 hover:text-white hover:bg-red-600"
          onClick={() => setFile(null)}
        >
          Cancel
        </Button>
        <Button onClick={handleUpload}>Proceeds</Button>
      </div>

      {status === "Upload Completed" && (
        <div className="mt-6">
          <p>Your employees have been successfully added to your account.</p>
          <p>Would you like to send them invites to Neptune?</p>
          <div className="mt-4 flex justify-end">
            <Button variant="outline" className="mr-2">
              Not now
            </Button>
            <Button>Yes, Send Invites</Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default BulkUpload;
