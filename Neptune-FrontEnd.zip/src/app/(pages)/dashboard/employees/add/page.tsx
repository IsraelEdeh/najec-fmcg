"use client";

import { ChevronRightIcon } from "lucide-react";
import Link from "next/link";
import React, { useState } from "react";
import AddEmployeesBasic from "@/components/Employees/AddEmployeesBasic";
import AddEmployeesPersonal from "@/components/Employees/AddEmployeesPersonal";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useMutation, useQuery } from "@tanstack/react-query";
import { toast } from "react-toastify";
import axios from "axios";
import ApiFetcher from "@/components/Utils/api";
import { useRouter } from "next/navigation";
import PayperiodDialog from "@/components/dashboard/payroll/PayperiodDialog";
import { toCreateEmployeeRequest } from "@/lib/employee-mappers";
import {
  optionalGender,
  optionalMinLength,
  optionalPastDate,
  optionalPhone
} from "@/lib/employee-validation";
import { GENDER_UNSPECIFIED } from "@/types/employee";

export interface IEmployeesFormInput {
  staffNumber: string;
  firstName: string;
  middleName: string;
  lastName: string;
  phoneNumber?: string | null;
  email: string;
  dateOfBirth?: string | null;
  gender?: string | null;
  address?: string | null;
  employmentType: any;
  departmentId?: string | null;
  payerId: string;
  employeeJobTitleId: string;
  employeeGradeId: string;
  costCenterId: string;
  subsidiaryId: string;
  taxAuthority: string;
  rsaPin?: string | null;
  dateJoined?: string | null;
  countryId: any;
  nhfExists?: boolean;
  nhisExists?: boolean;
  voluntaryPensionExists?: boolean;
  isPensionExempt?: boolean;
}

const AddEmployee = () => {
  const router = useRouter();

  const [currentStep, setCurrentStep] = useState(1);

  const handleNextButton = () => {
    setCurrentStep((prev) => prev + 1);
  };

  const schema = yup
    .object({
      firstName: yup
        .string()
        .min(3, "First name should be 3 characters or more")
        .required("First name is required"),
      lastName: yup
        .string()
        .min(3, "Last name should be 3 characters or more")
        .required("Last name is required"),
      middleName: yup.string().optional(),
      phoneNumber: optionalPhone(),
      email: yup.string().email("Invalid email address").required("Email is required"),
      dateOfBirth: optionalPastDate("Date of birth"),
      gender: optionalGender(),
      address: optionalMinLength(3, "Address should be 3 characters or more"),
      employmentType: yup.string().oneOf(["0", "1"], "Select a valid employment type").required("Employment type is required"),
      departmentId: yup.string().default(""),
      employeeJobTitleId: yup.string().required("Job title is required"),
      employeeGradeId: yup.string().required("Grade is required"),
      subsidiaryId: yup.string().required("Subsidiary is required"),
      costCenterId: yup.string(),
      taxAuthority: yup
        .string()
        .min(2, "Tax authority must be 2 characters or more")
        .required("Tax authority is required"),
      rsaPin: optionalMinLength(5, "Pension pin must be 5 characters or more"),
      dateJoined: optionalPastDate("Date joined"),
      countryId: yup.string().required("Country is required"),
      stateId: yup.string().required("State is required"),
      payerId: yup.string(),
      pensionFundAdministrator: yup.string(),
      bankName: yup.string(),
      accountNumber: yup
        .string()
        .matches(
          /^\d{10}$/,
          "Account number must be 10 digits and only contain numbers"
        ),
      accountName: yup.string(),
      nhfNumber: yup.string().optional(),
      // annualGrossSalary: yup
      //   .string()
      //   .min(
      //     4,
      //     "Tax authority must be 4 digits or more and only contain numbers"
      //   ),
      nhfExists: yup.boolean().optional(),
      nhisExists: yup.boolean().optional(),
      voluntaryPensionExists: yup.boolean().optional(),
      isPensionExempt: yup.boolean().default(false)
    })
    .required();

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: { gender: String(GENDER_UNSPECIFIED) }
  });

  const handleAddEmployee = async (data: any) => {
    try {
      const response = await ApiFetcher.post(
        "/employees/create-employee",
        toCreateEmployeeRequest(data)
      );
      toast.success("You have successfully created an Employee");
      router.push("/dashboard/employees");
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error creating an employee.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const mutation = useMutation({
    mutationFn: handleAddEmployee,
    onSuccess: () => {
      console.log("Good gooooooood");
    }
  });

  const onHandlerSubmit = (data: any) => {
    console.log(data);
    mutation.mutate(data);
  };

  const getNeptuneBusinessCountries = async () => {
    try {
      const response = await axios.get(
        `${process.env.NEXT_PUBLIC_BASE_URL}/auth/countries`
      );

      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching country data";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    error: countryFetchError,
    data: countryData,
    isPending
  } = useQuery({
    queryKey: ["countryData"],
    queryFn: getNeptuneBusinessCountries
  });

  return (
    <div className=" px-4 pt-6 pb-[46px]">
      <nav className="flex" aria-label="Breadcrumb">
        <ol className="inline-flex items-center space-x-1 md:space-x-3">
          <li className="inline-flex items-center">
            <Link
              href="/dashboard/employees"
              className="text-sm text-[#757575] hover:text-[#131313] underline-offset-4 transition-all duration-150 ease-in"
            >
              Employees
            </Link>
          </li>
          <li>
            <ChevronRightIcon className="w-4 h-4 text-[#B5B5C0]" />
          </li>
          <li>
            <span className="text-sm font-medium text-primary">
              Add Employee
            </span>
          </li>
        </ol>
      </nav>

      <h1 className="text-2xl font-semibold mt-4 mb-2">Add Employee</h1>
      <p className="text-gray-600 mb-6">
        Enter details of employee below to add them to Neptune
      </p>

      <form onSubmit={handleSubmit(onHandlerSubmit)}>
        <div className="border border-[#D9D9D9] rounded-[4px] bg-white px-[24px] pt-[24px] pb-[44px]">
          <div className="mb-6 flex space-x-4">
            <p
              onClick={() => setCurrentStep(1)}
              className={`${
                currentStep === 1
                  ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                  : "cursor-pointer"
              }`}
            >
              Basic
            </p>
            <p
              onClick={() => setCurrentStep(2)}
              className={`${
                currentStep === 2
                  ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                  : "cursor-pointer"
              }`}
            >
              Personal info
            </p>
          </div>

          <div className="space-y-4">
            {currentStep === 1 && (
              <AddEmployeesBasic
                next={handleNextButton}
                register={register}
                errors={errors}
                countryData={countryData}
              />
            )}

            {currentStep === 2 && (
              <AddEmployeesPersonal
                returnNext={() => setCurrentStep((e) => e - 1)}
                register={register}
                errors={errors}
                countryData={countryData}
                isPending={mutation.isPending}
                watch={watch}
              />
            )}
          </div>
        </div>
      </form>
    </div>
  );
};

export default AddEmployee;
