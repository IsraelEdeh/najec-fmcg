"use client";

import RightEmployeeDetails from "@/components/dashboard/RightEmployeeDetails";
import DisEngage from "@/components/Employees/Emanagement/DisEngage";
import Promotion from "@/components/Employees/Emanagement/Promotion";
import Suspension from "@/components/Employees/Emanagement/Suspension";
import { SquareChevronLeft } from "lucide-react";
import React, { useState } from "react";
import { CiExport } from "react-icons/ci";
import CustomButton from "@/components/Elements/CustomButton";
import { FaPlus } from "react-icons/fa";
import Link from "next/link";
import { TbLoader3 } from "react-icons/tb";

const Emanagement = () => {
  const [closeRightSidebar, setCloseRightSidebar] = useState<boolean>(false);
  const [status, setStatus] = useState("promote");
  const [currentStep, setCurrentStep] = useState<number>(1);

  console.log("check::", status);

  const switchPayrollRunComponent = () => {
    switch (currentStep) {
      case 1:
        return <Promotion />;
      case 2:
        return <Suspension />;
      case 3:
        return <DisEngage />;
    }
  };

  return (
    <main className="relative grid grid-cols-1 gap-4 overflow-x-hidden px-4 py-6 lg:grid-cols-10">
      {closeRightSidebar && (
        <div className="z-50 fixed top-20 right-0 hidden lg:block">
          <SquareChevronLeft
            onClick={() => setCloseRightSidebar(false)}
            className="cursor-pointer text-secondary transition duration-300 ease-linear mr-4"
            size={40}
          />
        </div>
      )}
      <div
        className={`w-full ${
          closeRightSidebar ? "lg:col-span-10" : "col-span-10 lg:col-span-7 "
        }`}
      >
        <p className="text-primary text-sm mb-4">Employee Management</p>
        <h1 className="text-[32px] font-semibold mb-2 text-[#1e1e1e]">
          Employee Management
        </h1>
        <p className="text-gray-600 mb-6">
          <span className="capitalize">{status} </span>employee{" "}
        </p>

        <div className="flex justify-end">
          <div className="flex items-center space-x-4">
            <Link href={`/dashboard/employees/emanagement/${status}`}>
              <CustomButton
                classType="primary"
                className="px-4 py-[9px] text-sm rounded-[4px] flex items-center space-x-2"
              >
                <span>
                  {" "}
                  <span className="capitalize">{status} </span> Employee
                </span>
                <FaPlus />
              </CustomButton>
            </Link>

            {/* <CustomButton
              type="button"
              // onClick={handleExportEmployees}
              classType="secondary"
              className="px-4 py-[9px] text-sm rounded-[4px] flex items-center space-x-2"
            >
              {true ? (
                <TbLoader3 className="text-primary animate-spin " />
              ) : (
                <CiExport />
              )}
            </CustomButton> */}
          </div>
        </div>
        <div className="border border-[#D9D9D9] rounded-[4px] p-6 bg-white mt-6 ">
          <div className="mb-6 flex space-x-4">
            <button
              onClick={() => {
                setCurrentStep(1);
                setStatus("promote");
              }}
              className={`
                ${currentStep === 1 ? "border-b-[#146ADC]" : "border-none"}
                text-primary font-bold border-b-[1.5px] pb-[9px] 
                cursor-pointer disabled:text-[#757575] `}
            >
              Promotion
            </button>

            <button
              onClick={() => {
                setCurrentStep(2);
                setStatus("suspend");
              }}
              className={`
                 ${currentStep === 2 ? "border-b-[#146ADC]" : "border-none"}
                text-primary font-bold border-b-[1.5px] pb-[9px] 
                cursor-pointer disabled:text-[#757575] `}
            >
              Suspension
            </button>

            <button
              onClick={() => {
                setCurrentStep(3);
                setStatus("disengage");
              }}
              className={`
                 ${currentStep === 3 ? "border-b-[#146ADC]" : "border-none"}
                text-primary font-bold border-b-[1.5px] pb-[9px]
                cursor-not-allowed disabled:text-[#757575]`}
              disabled
            >
              Disengage
            </button>
          </div>

          <div>{switchPayrollRunComponent()}</div>
        </div>
      </div>

      <div
        className={`${
          closeRightSidebar
            ? "hidden"
            : `${currentStep === 1 && "block col-span-10 lg:col-span-3"}`
        }`}
      >
        <div className="h-screen">
          <RightEmployeeDetails
            setCloseRightSidebar={setCloseRightSidebar}
            closeRightSidebar={closeRightSidebar}
          />
        </div>
      </div>
    </main>
  );
};

export default Emanagement;
