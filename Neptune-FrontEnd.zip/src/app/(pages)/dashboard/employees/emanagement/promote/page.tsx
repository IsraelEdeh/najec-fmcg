"use client";

import { Button } from "@/components/ui/button";
import ApiFetcher from "@/components/Utils/api";
import { yupResolver } from "@hookform/resolvers/yup";
import { useMutation } from "@tanstack/react-query";
import { ChevronRightIcon } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import React from "react";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";
import * as yup from "yup";

const schema = yup
  .object({
    staffNumber: yup
      .string()
      .min(2, "Staff Number should be 2 characters or more"),
    jobTitle: yup.string().min(3, "Job title should be 3 characters or more"),
    annualGrossSalary: yup.string().min(3, "Annual gross salary is required"),
    lastPromotionDate: yup.date()
  })
  .required();

const page = () => {
  const router = useRouter();

  const handlePromoteEmployees = async (data: any) => {
    try {
      const response = await ApiFetcher.post(`/employees/promote-employee`, {
        staffNumber: data.staffNumber,
        jobTitle: data.jobTitle,
        annualGrossSalary: Number(data.annualGrossSalary),
        lastPromotionDate: data.lastPromotionDate
      });

      toast.success("Employee promoted successfully")

      router.push("/dashboard/employees/emanagement");
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error updating organization";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm({ resolver: yupResolver(schema) });

  const mutation = useMutation({
    mutationFn: handlePromoteEmployees,
    onSuccess: async () => {},
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onHandlerSubmit = (data: any) => {
    mutation.mutateAsync(data);
    mutation.reset();
    reset();
  };
  return (
    <div className=" px-4 pt-6 pb-[46px]">
      <nav className="flex" aria-label="Breadcrumb">
        <ol className="inline-flex items-center space-x-1 md:space-x-3">
          <li className="inline-flex items-center">
            <Link
              href="/dashboard/employees"
              className="text-sm text-[#757575] hover:text-[#131313] underline-offset-4 transition-all duration-150 ease-in"
            >
              Employees
            </Link>
          </li>
          <li>
            <ChevronRightIcon className="w-4 h-4 text-[#B5B5C0]" />
          </li>
          <li>
            <span className="text-sm font-medium text-primary">
              Promote Employee
            </span>
          </li>
        </ol>
      </nav>

      <h1 className="text-2xl font-semibold mt-4 mb-2">Promote Employee</h1>
      <p className="text-gray-600 mb-6">Enter details of promoted employee</p>

      <div className="bg-white border border-[#D9D9D9] py-[20px] pb-[40px] px-[24px]">
        <form onSubmit={handleSubmit(onHandlerSubmit)}>
          <div>
            <label
              htmlFor="staffNumber"
              className="block mb-2 text-sm font-bold text-[#1E1E1E] mt-[24px]"
            >
              Staff number
            </label>
            <input
              className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
              type="text"
              placeholder="SN009"
              {...register("staffNumber")}
            />

            <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
              {errors.staffNumber?.message}
            </p>
          </div>

          <div>
            <label
              htmlFor="jobTitle"
              className="block mb-2 text-sm font-bold text-[#1E1E1E] mt-[24px]"
            >
              Job title
            </label>
            <input
              className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
              type="text"
              placeholder="Senior consultant"
              {...register("jobTitle")}
            />

            <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
              {errors.jobTitle?.message}
            </p>
          </div>

          <div>
            <label
              htmlFor="annualGrossSalary"
              className="block mb-2 text-sm font-bold text-[#1E1E1E] mt-[24px]"
            >
              Annual gross salary
            </label>
            <input
              className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
              type="text"
              placeholder="N887388"
              {...register("annualGrossSalary")}
            />

            <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
              {errors.annualGrossSalary?.message}
            </p>
          </div>

          <div>
            <label
              htmlFor="lastPromotionDate"
              className="block mb-2 text-sm font-bold text-[#1E1E1E] mt-[24px]"
            >
              Last promotion date
            </label>
            <input
              className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
              type="date"
              placeholder={new Date().toLocaleDateString()}
              {...register("lastPromotionDate")}
            />

            <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
              {errors.lastPromotionDate?.message}
            </p>
          </div>

          <div className="mt-10 flex justify-start">
            <Button
              type="submit"
              disabled={mutation.isPending}
              className="disabled:bg-secondary disabled:bg-opacity-60  bg-primary text-white text-sm font-semibold py-[11px] px-[32px] w-[30%]"
            >
              {mutation.isPending ? "Saving..." : "Save"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default page;
