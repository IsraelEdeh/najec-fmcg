"use client";

import React, { useState, useMemo, useEffect } from "react";
import Link from "next/link";
import RightEmployeeDetails from "@/components/dashboard/RightEmployeeDetails";
import CustomButton from "@/components/Elements/CustomButton";
import { FaPlus } from "react-icons/fa6";
import { CiExport } from "react-icons/ci";
import { IoEyeOutline } from "react-icons/io5";
import EmptyRecord from "@/components/dashboard/EmptyRecord";
import { toast } from "react-toastify";
import ApiFetcher from "@/components/Utils/api";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { AiOutlineLoading3Quarters } from "react-icons/ai";

import { RiArrowLeftSFill, RiArrowRightSFill } from "react-icons/ri";
import { SquareChevronLeft } from "lucide-react";
import { TbLoader3 } from "react-icons/tb";
import BulkUpload from "@/components/dashboard/BulkUpload";

import { MdOutlineFileDownload } from "react-icons/md";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";

import {
  Tooltip,
  TooltipContent,
  TooltipTrigger
} from "@/components/ui/tooltip";
import { FaSearch } from "react-icons/fa";
import { sanitizeFilename } from "@/lib/helpers";
import { formatPageRange } from "@/lib/utils";

const Employees = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const [closeRightSidebar, setCloseRightSidebar] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState<number>(1);

  const [searchTerm, setSearchTerm] = useState<string>("");
  const [debouncedSearch, setDebouncedSearch] = useState<string>("");

  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(searchTerm.trim()), 300);
    return () => clearTimeout(t);
  }, [searchTerm]);

  const user: any = useSelector((state: RootState) => state.getUser.user);

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const maxPage = 10;

  const fetchEmployees = async (page: number) => {
    try {
      const response: any = await ApiFetcher.get(
        `/employees/get-all-employees-in-an-organization?PageNumber=${page}&PageSize=${maxPage}`
      );

      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error fetching employees";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  // Keep the current rows on screen while the next page loads instead of swapping in a spinner.
  const { data, isPending, isLoading, error } = useQuery({
    queryKey: ["fetchEmployees", currentPage],
    queryFn: () => fetchEmployees(currentPage),
    placeholderData: keepPreviousData
  });
  const totalPages = Number(data?.data?.meta?.totalPages ?? 1) || 1;

  // derive list and apply client-side search/filter
  const employeesList = data?.data?.data || [];

  const filteredEmployees = useMemo(() => {
    const q = debouncedSearch.toLowerCase();
    const matches = !debouncedSearch
      ? employeesList
      : employeesList.filter((item: any) => {
          const fullName = `${item?.firstName || ""} ${
            item?.lastName || ""
          }`.toLowerCase();
          const staffNumber = (item?.staffNumber || "").toLowerCase();
          const email = (item?.email || "").toLowerCase();
          return (
            fullName.includes(q) || staffNumber.includes(q) || email.includes(q)
          );
        });
    // Sort a copy with tie-breakers: sorting the cached array in place on every render reorders rows with equal names.
    const text = (value: unknown) => String(value ?? "");
    return [...matches].sort(
      (a: any, b: any) =>
        text(a?.firstName).localeCompare(text(b?.firstName)) ||
        text(a?.lastName).localeCompare(text(b?.lastName)) ||
        text(a?.staffNumber).localeCompare(text(b?.staffNumber)) ||
        text(a?.id).localeCompare(text(b?.id))
    );
  }, [employeesList, debouncedSearch]);

  const handleExportEmployees = async () => {
    try {
      setLoading(true);
      const response = await ApiFetcher.get(
        "/employees/export-employees?pageSize=1000",
        {
          responseType: "blob"
        }
      );

      const blob = new Blob([response.data], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");

      const fileName = sanitizeFilename("employee-report") + ".xlsx";
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success("Export done successfully");
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error exporting employees";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="relative grid grid-cols-1 gap-4 overflow-x-hidden px-4 py-6 lg:grid-cols-10">
      {closeRightSidebar && (
        <div className="z-40 fixed top-20 right-0 hidden lg:block">
          <SquareChevronLeft
            onClick={() => setCloseRightSidebar(false)}
            className="cursor-pointer text-secondary transition duration-300 ease-linear mr-4"
            size={40}
          />
        </div>
      )}

      <div
        className={`w-full min-w-0 ${closeRightSidebar ? "lg:col-span-10" : "col-span-10 lg:col-span-7"}`}
      >
        <p className="text-primary text-sm mb-4">Employees</p>
        <h1 className="text-[32px] font-semibold mb-2 text-[#1e1e1e]">
          Employees
        </h1>
        <p className="text-gray-600 mb-6">
          Add and manage all your employees from one page.
        </p>

        <div className="bg-white rounded-[16px] ">
          <div className="px-5 pt-6 pb-4">
            <div className="w-full flex items-center justify-between">
              {employeesList.length > 0 && (
                <div className="relative flex items-center space-x-3">
                  <FaSearch className="absolute top-1/2 left-4 transform -translate-y-1/2 text-xs text-[#6B7280]" />
                  <input
                    type="search"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search employees by name, staff number or email"
                    className={`pl-6 pr-2 py-[9px] rounded-[4px] border text-xs border-[#D9D9D9] ${
                      closeRightSidebar ? "w-full" : "w-[180px]"
                    } `}
                  />
                  {debouncedSearch && (
                    <button
                      onClick={() => {
                        setSearchTerm("");
                        setDebouncedSearch("");
                      }}
                      className="text-sm text-[#6B7280] underline"
                      type="button"
                    >
                      Clear
                    </button>
                  )}
                </div>
              )}

              <div className="flex items-center space-x-2">
                {(activeRole?.includes("Admin") ||
                  activeRole?.includes("Initiator")) && (
                  <>
                    <div>
                      <BulkUpload />
                    </div>

                    <Link className="block" href="/dashboard/employees/add">
                      <CustomButton
                        classType="primary"
                        className="w-full px-4 py-[9px] text-xs rounded-[4px] flex items-center space-x-2"
                      >
                        <span className="inline">Add Employee</span>
                        <FaPlus />
                      </CustomButton>
                    </Link>

                    <CustomButton
                      type="button"
                      onClick={handleExportEmployees}
                      classType="secondary"
                      className="px-4 py-[9px] text-xs rounded-[4px] flex items-center space-x-2"
                    >
                      {loading ? (
                        <TbLoader3 className="text-primary animate-spin text-xs " />
                      ) : (
                        <MdOutlineFileDownload className="text-primary text-xs" />
                        // <Tooltip>
                        //   <TooltipTrigger asChild>
                        //     <MdOutlineFileDownload className="w-6 h-6 " />
                        //   </TooltipTrigger>
                        //   <TooltipContent>
                        //     <p>Export all employees in the organization</p>
                        //   </TooltipContent>
                        // </Tooltip>
                      )}
                    </CustomButton>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="mt-6 pb-10 flex items-center justify-center">
                <AiOutlineLoading3Quarters className="w-10 h-10 animate-spin text-primary" />
              </div>
            ) : filteredEmployees?.length > 0 ? (
              <table className="w-full mt-[24px]">
                <thead className="bg-[#DDEFE8] py-4">
                  <tr className=" w-full">
                    <th className="p-4 text-left uppercase text-xs font-semibold ">
                      S/N
                    </th>

                    <th className="p-4 text-left uppercase text-xs font-semibold ">
                      Employee
                    </th>

                    <th className="p-4 text-left uppercase text-xs font-semibold ">
                      Emp. Type
                    </th>

                    <th className="p-4 text-left uppercase text-xs font-semibold ">
                      Department
                    </th>

                    <th className="p-4 text-left uppercase text-xs font-semibold ">
                      Actions
                    </th>
                  </tr>
                </thead>

                <tbody className="text-[#1A1A1A]">
                  {filteredEmployees
                    .map((item: any, index: number) => {
                      return (
                        <tr
                          key={item.id}
                          className="border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9]"
                        >
                          <td className="p-4 text-left text-sm font-normal ">
                            {++index}
                          </td>
                          <td className="p-4 text-left text-sm font-normal ">
                            <span className="block font-bold text-sm">
                              {item?.firstName} {item?.lastName}
                            </span>
                            <span className="block text-xs text-[#0a0a0a]">
                              {item?.staffNumber || ""}
                            </span>
                          </td>

                          <td className="p-4 text-left text-sm font-normal ">
                            {item?.employmentType}
                          </td>

                          <td className="p-4 text-left text-sm font-normal ">
                            {item?.department?.name || "-"}
                          </td>

                          <td className="p-4 text-left text-sm font-normal ">
                            <Link
                              className="text-[#757577] hover:underline"
                              href={`/dashboard/employees/${item.id}`}
                            >
                              <IoEyeOutline className="w-6 h-6" />
                            </Link>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            ) : (
              <div className="py-8">
                <EmptyRecord />
              </div>
            )}
          </div>
          <div className="mt-4 flex items-center justify-between py-2 px-4">
            <p className="text-[#63666A] text-xs">
              {formatPageRange(data?.data?.meta, maxPage)}
            </p>

            <div className="flex items-center space-x-3">
              <button
                aria-label="Previous page"
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((e: number) => Math.max(1, e - 1))}
                className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
              >
                <RiArrowLeftSFill className="w-6 h-6" />
              </button>

              <button
                aria-label="Next page"
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage((e: number) => Math.min(totalPages, e + 1))}
                className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
              >
                <RiArrowRightSFill className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className={`${closeRightSidebar ? "hidden" : "block col-span-10 lg:col-span-3"}`}>
        <div className="h-screen">
          <RightEmployeeDetails
            setCloseRightSidebar={setCloseRightSidebar}
            closeRightSidebar={closeRightSidebar}
          />
        </div>
      </div>
    </main>
  );
};

export default Employees;
