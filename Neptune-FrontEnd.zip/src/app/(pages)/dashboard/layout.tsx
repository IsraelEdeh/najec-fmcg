import HeaderBar from "@/components/dashboard/HeaderBar";
import { AppSidebar } from "@/components/dashboard/utils/AppSidebar";
import { SidebarProvider } from "@/components/ui/sidebar";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Neptune - Dashboard",
  description: "HR Payroll Streamline"
};

export default async function DashboardLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <main className="min-h-screen overflow-x-hidden bg-[#f6f6f6]">
      <SidebarProvider>
        <HeaderBar />
        <div className="relative flex min-h-screen w-full min-w-0 pt-16">
          <AppSidebar />
          <div className="min-w-0 flex-1 overflow-x-hidden bg-[#F4F6F9]">
            <section className="w-full min-w-0">{children}</section>
          </div>
        </div>
      </SidebarProvider>
    </main>
  );
}
