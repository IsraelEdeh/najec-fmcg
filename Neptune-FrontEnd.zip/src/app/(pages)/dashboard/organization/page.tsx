"use client";

import Profile from "@/components/Company/Profile";
import Settings from "@/components/Company/Settings";
import UserRoles from "@/components/Company/UserRoles";
import { getNeptuneBusinessCountries } from "@/constants";
import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import React, { useState } from "react";

const Company = () => {
  const [currentStep, setCurrentStep] = useState(1);

  const handleTabClick = (step: any) => {
    setCurrentStep(step);
  };

  const {
    error: countryFetchError,
    data: employeeCountryData,
    isPending: isCountryLoading
  } = useQuery({
    queryKey: ["countryData"],
    queryFn: getNeptuneBusinessCountries
  });

  const renderComponent = () => {
    switch (currentStep) {
      case 1:
        return (
          <Profile
            employeeCountryData={employeeCountryData}
            isCountryLoading={isCountryLoading}
          />
        );
      case 2:
        return <Settings />;
      default:
        return (
          <Profile
            employeeCountryData={employeeCountryData}
            isCountryLoading={isCountryLoading}
          />
        );
    }
  };

  return (
    <main className=" px-4 py-6">
      <nav className="flex" aria-label="Breadcrumb">
        <ol className="inline-flex items-center space-x-1 md:space-x-3">
          <li className="inline-flex items-center">
            <p className="text-sm text-primary hover:underline">Organization</p>
          </li>
        </ol>
      </nav>

      <div className="mb-[24px] mt-4">
        <h1 className="text-[40px] leading-[52px] font-semibold">
          Organization Details
        </h1>
        <p className="text-sm mt-2 text-[#1E1E1E]">
          Enter details of organization below to add them to Neptune
        </p>
      </div>

      <div className="bg-white border border-[#D9D9D9] py-[20px] px-[24px]">
        <div className="flex gap-[10px] mb-4">
          {["Profile", "Settings"].map((tab, index) => (
            <span
              key={index}
              onClick={() => handleTabClick(index + 1)}
              className={`text-sm cursor-pointer text-[#63666A] pb-2 border-b-2 border-transparent ${
                currentStep === index + 1
                  ? "text-[#146ADC] border-b-secondary"
                  : ""
              }`}
            >
              {tab}
            </span>
          ))}
        </div>
        {renderComponent()}
      </div>
    </main>
  );
};

export default Company;
