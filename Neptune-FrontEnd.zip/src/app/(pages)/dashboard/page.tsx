"use client"

import React from "react";
import DashboardHome from "@/components/dashboard/HomePage";
import SecurityNotice from "@/components/dashboard/SecurityNotice";

const Home = () => {
  return (
    <div>
      <SecurityNotice />    
      <DashboardHome />
    </div>
  );
};

export default Home;
