"use client";

import Approval from "@/components/Payroll/History/Approval";
import OutputReview from "@/components/Payroll/History/OutputReview";
import React, { useState } from "react";

const HistoryDetails = () => {
  const [currentStep, setCurrentStep] = useState<number>(1);

  const switchPayrollRunComponent = () => {
    switch (currentStep) {
      case 1:
        return <OutputReview />;
      case 2:
        return <Approval />;
      default:
        return <OutputReview />;
    }
  };
  return (
    <div className=" px-4 py-6 gap-4">
      <div>
        <p className="text-primary text-sm mb-4">Payroll</p>
        <h1 className="text-[52px] font-semibold mb-2 text-[#1e1e1e]">
          Run Payroll
        </h1>
        <p className="text-gray-600 mb-6">Setup and customise your payroll</p>

        <div className="border border-[#D9D9D9] rounded-[4px] p-6 bg-white mt-6 ">
          <ul className="mb-6 flex space-x-4">
            <li
              onClick={() => setCurrentStep(1)}
              className={`${
                currentStep === 1
                  ? "text-primary font-bold border-b pb-[4px] border-b-[#146ADC]"
                  : "cursor-pointer"
              }`}
            >
              Output Review
            </li>

            <li
              onClick={() => setCurrentStep(2)}
              className={`${
                currentStep === 2
                  ? "text-primary font-bold border-b pb-[4px] border-b-[#146ADC]"
                  : "cursor-pointer"
              }`}
            >
              Approval
            </li>
          </ul>

          <div>{switchPayrollRunComponent()}</div>
        </div>
      </div>
    </div>
  );
};

export default HistoryDetails;
