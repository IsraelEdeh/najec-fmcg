"use client";

import Link from "next/link";
import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { MdOutlineArrowDropDown } from "react-icons/md";
import { useQuery } from "@tanstack/react-query";
import { formatPageRange } from "@/lib/utils";
import { toast } from "react-toastify";
import ApiFetcher from "@/components/Utils/api";
import EmptyRecord from "@/components/dashboard/EmptyRecord";
import { TbLoader3 } from "react-icons/tb";
import { RiArrowLeftSFill, RiArrowRightSFill } from "react-icons/ri";
import PeriodPayrollGroup, {
  PERIOD_GROUP_COLUMN_COUNT,
  type HistoryPayrollItem
} from "@/components/Payroll/History/PeriodPayrollGroup";

const groupByPeriod = (items: HistoryPayrollItem[]) => {
  const groups = new Map<string, HistoryPayrollItem[]>();
  items.forEach((item) => {
    const key = String(item?.payPeriodId ?? "");
    groups.set(key, [...(groups.get(key) ?? []), item]);
  });
  return [...groups.values()].sort(
    (left, right) =>
      new Date(right[0]?.payPeriod?.startDate ?? 0).getTime() -
      new Date(left[0]?.payPeriod?.startDate ?? 0).getTime()
  );
};

const History = () => {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const maxPage = 10;

  const formatNumber = (value: any) => {
    if (value === null || value === undefined || value === "") return "N/A";
    const num = Number(value);
    if (Number.isNaN(num)) return "N/A";
    return num.toLocaleString("en-US");
  };

  const formatAmount = new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN"
  });

  const getAllPayroll = async (page: Number) => {
    try {
      const response = await ApiFetcher.get(
        `/payroll/get-all-payroll?PageNumber=${page}&PageSize=${maxPage}`
      );

      // console.log("all payroll response::", response);

      return response || [];
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching payroll summary";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: allPayroll,
    isPending,
    isLoading,
    error
  } = useQuery({
    queryKey: ["fetchAllPayroll", currentPage],
    queryFn: () => getAllPayroll(currentPage)
  });

  const getPayrollYear = async () => {
    try {
      const response = await ApiFetcher.get(`/payperiods/get-distinct-years`);
      return response || [];
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching payroll years";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: yearsData,
    isPending: isYearsLoading,
    isError
  } = useQuery({
    queryKey: ["fetchPayrollYears"],
    queryFn: getPayrollYear
  });

  // console.log("Payroll years::", yearsData);

  return (
    <main className="mt- p-[24px] ">
      <div>
        <nav aria-label="Breadcrumb" className="flex mb-[24px]">
          <ol className="inline-flex text-primary text-sm items-center">
            <li>
              <Link href="">Payroll History</Link>
            </li>
          </ol>
        </nav>

        <div className="mb-[24px] flex justify-between items-center">
          <div>
            <h1 className="text-[40px] leading-[52px] font-semibold mb-[10px]">
              Payroll History
            </h1>
            <p className="text-sm text-[#1E1E1E]">
              All your past payroll data is safe with us. Always readily
              available.
            </p>
          </div>

          <select className="cursor-pointer bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-2xl">
            <option value="">Select range</option>
            {yearsData?.data?.data?.map((year: any) => (
              <option className="cursor-pointer" key={year} value={year}>
                {year}
              </option>
            ))}
          </select>
        </div>

        <div className="flex justify-between mt-[14px]">
          <div>
            <h2 className="text-xs text-[#878787] text-center">
              Total Net Pay
            </h2>
            <p className="text-[20px] text-center mt-2 text-[#191919] font-medium">
              <p className="text-[20px] text-center mt-2 text-[#191919] font-medium">
                {formatAmount.format(
                  allPayroll?.data?.meta?.dataReport?.summary?.totalNetPay
                )}
              </p>
            </p>
          </div>
          <div>
            <h2 className="text-xs text-[#878787] text-center">
              Total Pension
            </h2>
            <p className="text-[20px] text-center mt-2 text-[#191919] font-medium">
              {/* {formatAmount.format(allPayslips?.totalPensionPayable ?? 0)} */}{" "}
              {formatAmount.format(
                allPayroll?.data?.meta?.dataReport?.summary?.totalPension
              )}
            </p>
          </div>
          <div>
            <h2 className="text-xs text-[#878787] text-center">
              Total Cost to Company
            </h2>
            <p className="text-[20px] text-center mt-2 text-[#191919] font-medium">
              {/* {formatAmount.format(allPayslips?.totalCompanyContributions ?? 0)} */}{" "}
              {formatAmount.format(
                allPayroll?.data?.meta?.dataReport?.summary?.totalCostToCompany
              )}
            </p>
          </div>
          <div>
            <h2 className="text-xs text-[#878787] text-center">
              Total Deductions
            </h2>
            <p className="text-[20px] text-center mt-2 text-[#191919] font-medium">
              {/* {formatAmount.format(allPayslips?.totalTaxPayable ?? 0)} */}
              {formatAmount.format(
                allPayroll?.data?.meta?.dataReport?.summary?.totalDeductions
              )}
            </p>
          </div>

          {/* <div>
            <h2 className="text-xs text-[#878787] text-center">
              Total Gross Salary
            </h2>
            <p className="text-[20px] text-center mt-2 text-[#191919] font-medium">
              0
            </p>
          </div> */}
        </div>

        <div className="bg-white rounded-[4px] mt-[24px]">
          <div className="px-5 pt-6 ">
            <div className="hidden items-center justify-between">
              <div className="flex items-center space-x-4">
                <div>
                  <input
                    type="date"
                    id=""
                    name=""
                    value=""
                    onChange={() => {}}
                    className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <p>Rows: </p>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button
                      className="flex items-center space-x-2 py-1 px-2 text-sm border border-[#d9d9d9] text-[#1E1E1E] rounded-[8px]"
                      type="button"
                    >
                      <span>10</span>

                      <MdOutlineArrowDropDown />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56 bg-white">
                    <DropdownMenuGroup>
                      <DropdownMenuItem>10</DropdownMenuItem>
                      <DropdownMenuItem>20</DropdownMenuItem>
                      <DropdownMenuItem>50</DropdownMenuItem>
                      <DropdownMenuItem>100</DropdownMenuItem>
                    </DropdownMenuGroup>
                    <DropdownMenuSeparator />
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full mt-[24px]">
              <thead className="bg-[#DDEFE8] py-4">
                <tr className=" w-full">
                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Pay period
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Run
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Status
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Net Pay
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Gross Pay
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Pension
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>

              {isPending ? (
                <tbody>
                  <tr>
                    <td colSpan={PERIOD_GROUP_COLUMN_COUNT}>
                      <TbLoader3 className="mt-4 mx-auto text-primary animate-spin w-6 h-6" />
                    </td>
                  </tr>
                </tbody>
              ) : !allPayroll?.data?.data?.length ? (
                <tbody>
                  <tr>
                    <td colSpan={PERIOD_GROUP_COLUMN_COUNT}>
                      <EmptyRecord />
                    </td>
                  </tr>
                </tbody>
              ) : (
                groupByPeriod(allPayroll.data.data).map((items) => (
                  <PeriodPayrollGroup
                    key={String(items[0].payPeriodId)}
                    payPeriodId={items[0].payPeriodId}
                    periodName={items[0].payPeriod?.name || String(items[0].payPeriodId)}
                    items={items}
                    formatNumber={formatNumber}
                  />
                ))
              )}
            </table>

            <div className="mt-4 flex items-center justify-between py-2 px-4">
              <p className="text-[#63666A] text-xs">
                {formatPageRange(allPayroll?.data?.meta, maxPage)}
              </p>

              <div className="flex items-center space-x-3">
                <button
                  disabled={currentPage <= 1}
                  onClick={() => setCurrentPage((e: number) => e - 1)}
                  className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
                >
                  <RiArrowLeftSFill className="w-6 h-6" />
                </button>

                <button
                  disabled={currentPage === allPayroll?.data?.meta?.totalPages}
                  onClick={() => setCurrentPage((e: number) => e + 1)}
                  className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
                >
                  <RiArrowRightSFill className="w-6 h-6" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default History;
