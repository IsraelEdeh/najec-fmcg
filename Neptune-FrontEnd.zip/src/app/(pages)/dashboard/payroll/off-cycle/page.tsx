"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { FaPlus } from "react-icons/fa";
import { TbLoader3 } from "react-icons/tb";
import CustomButton from "@/components/Elements/CustomButton";
import { Button } from "@/components/ui/button";
import CreateOffCycleRunDialog from "@/components/Payroll/OffCycle/CreateOffCycleRunDialog";
import OffCycleTemplateDialog from "@/components/Payroll/OffCycle/OffCycleTemplateDialog";
import OffCycleUploadDialog from "@/components/Payroll/OffCycle/OffCycleUploadDialog";
import { PeriodStatusBadge } from "@/components/Payroll/Runs/Badges";
import ConfirmDialog from "@/components/Payroll/Runs/ConfirmDialog";
import DisabledHint from "@/components/Payroll/Runs/DisabledHint";
import PayPeriodSelect from "@/components/Payroll/Runs/PayPeriodSelect";
import { findRunPayroll, isRunLocked } from "@/components/Payroll/Runs/useRunSelection";
import useActiveRoles from "@/hooks/Custom-hook/useActiveRoles";
import usePayPeriods from "@/hooks/Custom-hook/usePayPeriods";
import {
  PAY_PERIOD_CLOSED_MESSAGE,
  deleteOffCycleRun,
  getOffCycleRuns,
  getPayrollsByPayPeriod,
  offCycleRunsKey,
  offCycleTypeLabel,
  payrollStatusLabel,
  payrollsByPeriodKey,
  sameId
} from "@/lib/payroll-api";
import { getApiErrorMessage } from "@/lib/utils";
import type { Id, OffCycleRun } from "@/types/payroll";

const LOCKED_RUN_HINT = "This run's payroll has been processed. Reject it first to change the schedule.";

const actionClassName =
  "text-xs rounded-[4px] py-[6px] px-3 h-auto bg-white text-primary border border-primary hover:bg-primary hover:text-white disabled:opacity-50";

const OffCycleRunsPage = () => {
  const queryClient = useQueryClient();
  const { canManagePayrollRuns } = useActiveRoles();
  const { openPeriods, currentPeriod, isLoading: isLoadingPeriods } = usePayPeriods();
  const [payPeriodId, setPayPeriodId] = useState<Id>();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [templateRun, setTemplateRun] = useState<OffCycleRun | null>(null);
  const [uploadRun, setUploadRun] = useState<OffCycleRun | null>(null);
  const [deleteRun, setDeleteRun] = useState<OffCycleRun | null>(null);
  const [highlightRunId, setHighlightRunId] = useState<string>();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const periodParam = params.get("payPeriodId");
    if (periodParam) setPayPeriodId(periodParam);
    if (params.get("create") === "1") setIsCreateOpen(true);
    const runParam = params.get("offCycleRunId");
    if (runParam) setHighlightRunId(runParam);
  }, []);

  useEffect(() => {
    if (payPeriodId !== undefined || openPeriods.length === 0) return;
    const current = openPeriods.find((period) => sameId(period.id, currentPeriod?.id));
    setPayPeriodId((current ?? openPeriods[0]).id);
  }, [openPeriods, currentPeriod, payPeriodId]);

  const period = openPeriods.find((item) => sameId(item.id, payPeriodId));
  const hasPeriod = payPeriodId !== undefined;

  const { data: periodPayrolls } = useQuery({
    queryKey: payrollsByPeriodKey(payPeriodId),
    queryFn: () => getPayrollsByPayPeriod(payPeriodId as Id),
    enabled: hasPeriod
  });

  const { data: runs = [], isPending: isLoadingRuns, isError } = useQuery({
    queryKey: offCycleRunsKey(payPeriodId),
    queryFn: () => getOffCycleRuns(payPeriodId as Id),
    enabled: hasPeriod
  });

  const payrolls = periodPayrolls?.payrolls ?? [];
  const isClosed = Boolean(period?.isClosed ?? periodPayrolls?.isClosed);
  const closedHint = isClosed ? PAY_PERIOD_CLOSED_MESSAGE : undefined;

  const deleteMutation = useMutation({
    mutationFn: (run: OffCycleRun) => deleteOffCycleRun(run.id),
    onSuccess: async () => {
      toast.success("Off-cycle run deleted.");
      setDeleteRun(null);
      await queryClient.invalidateQueries();
    },
    onError: (error) => toast.error(getApiErrorMessage(error, "Unable to delete the off-cycle run."))
  });

  return (
    <main className="p-[24px]">
      <nav aria-label="Breadcrumb" className="flex mb-[24px]">
        <ol className="inline-flex text-primary text-sm items-center gap-2">
          <li>
            <Link href="/dashboard/payroll">Payroll</Link>
          </li>
          <li aria-hidden>/</li>
          <li aria-current="page">Off-cycle runs</li>
        </ol>
      </nav>

      <div className="mb-[24px] flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[40px] leading-[52px] font-semibold mb-[10px]">Off-cycle runs</h1>
          <p className="text-sm text-[#1E1E1E]">
            Pay 13th month, bonus, mid-month or arrears outside the regular payroll.
          </p>
        </div>

        {canManagePayrollRuns && (
          <DisabledHint hint={closedHint ?? (!hasPeriod ? "Select an open pay period first." : undefined)}>
            <CustomButton
              classType="primary"
              disabled={isClosed || !hasPeriod}
              onClick={() => setIsCreateOpen(true)}
              className="px-4 py-[9px] text-sm rounded-[4px] flex items-center space-x-2 disabled:opacity-50"
            >
              <span>New off-cycle run</span>
              <FaPlus aria-hidden />
            </CustomButton>
          </DisabledHint>
        )}
      </div>

      <div className="bg-white rounded-[4px] p-5">
        <div className="flex flex-wrap items-end gap-3 mb-4">
          <PayPeriodSelect
            periods={openPeriods}
            value={payPeriodId}
            onChange={setPayPeriodId}
            isLoading={isLoadingPeriods}
          />
          {period && <PeriodStatusBadge isClosed={isClosed} className="mb-3" />}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#DDEFE8]">
              <tr>
                <th scope="col" className="p-4 text-left uppercase text-xs font-semibold">Name</th>
                <th scope="col" className="p-4 text-left uppercase text-xs font-semibold">Type</th>
                <th scope="col" className="p-4 text-left uppercase text-xs font-semibold">Processed</th>
                <th scope="col" className="p-4 text-left uppercase text-xs font-semibold">Payroll status</th>
                <th scope="col" className="p-4 text-left uppercase text-xs font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="text-[#1A1A1A]">
              {!hasPeriod ? (
                <tr>
                  <td colSpan={5} className="p-6 text-center text-sm">
                    {isLoadingPeriods ? "Loading pay periods…" : "No open pay period."}
                  </td>
                </tr>
              ) : isLoadingRuns ? (
                <tr>
                  <td colSpan={5} className="p-6">
                    <TbLoader3 className="mx-auto text-primary animate-spin w-6 h-6" aria-label="Loading" />
                  </td>
                </tr>
              ) : isError ? (
                <tr>
                  <td colSpan={5} className="p-6 text-center text-sm text-red-700">
                    Unable to load off-cycle runs.
                  </td>
                </tr>
              ) : runs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-6 text-center text-sm">
                    No off-cycle runs for this period. Create one for 13th month, bonus, mid-month or arrears
                    payments.
                  </td>
                </tr>
              ) : (
                runs.map((run) => {
                  const payroll = findRunPayroll(run, payrolls);
                  const processed = run.isProcessed ?? Boolean(payroll);
                  const locked = isRunLocked(run, payrolls);
                  const editHint = closedHint ?? (locked ? LOCKED_RUN_HINT : undefined);

                  return (
                    <tr
                      key={String(run.id)}
                      aria-current={sameId(run.id, highlightRunId) ? "true" : undefined}
                      className={`border-t border-t-[#E5E7EB] border-b border-b-[#D9D9D9] ${
                        sameId(run.id, highlightRunId) ? "bg-[#E6F0F6]" : ""
                      }`}
                    >
                      <td className="p-4 text-sm font-semibold">{run.name}</td>
                      <td className="p-4 text-sm">{offCycleTypeLabel(run.offCycleType)}</td>
                      <td className="p-4 text-sm">{processed ? "Yes" : "No"}</td>
                      <td className="p-4 text-sm">
                        {payroll || run.payrollStatus !== undefined
                          ? payrollStatusLabel(run.payrollStatus ?? payroll?.status)
                          : "Not processed"}
                      </td>
                      <td className="p-4 text-sm">
                        <div className="flex flex-wrap gap-2">
                          {canManagePayrollRuns ? (
                            <>
                              <DisabledHint hint={closedHint}>
                                <Button
                                  type="button"
                                  className={actionClassName}
                                  disabled={isClosed}
                                  onClick={() => setTemplateRun(run)}
                                >
                                  Download template
                                </Button>
                              </DisabledHint>
                              <DisabledHint hint={editHint}>
                                <Button
                                  type="button"
                                  className={actionClassName}
                                  disabled={Boolean(editHint)}
                                  onClick={() => setUploadRun(run)}
                                >
                                  Upload schedule
                                </Button>
                              </DisabledHint>
                              <DisabledHint hint={editHint}>
                                {editHint ? (
                                  <Button type="button" className={actionClassName} disabled>
                                    Run payroll
                                  </Button>
                                ) : (
                                  <Link
                                    href={`/dashboard/payroll/run?payPeriodId=${encodeURIComponent(
                                      String(payPeriodId)
                                    )}&offCycleRunId=${encodeURIComponent(String(run.id))}`}
                                    className={`${actionClassName} inline-flex items-center`}
                                  >
                                    Run payroll
                                  </Link>
                                )}
                              </DisabledHint>
                              <DisabledHint hint={editHint}>
                                <Button
                                  type="button"
                                  className="text-xs rounded-[4px] py-[6px] px-3 h-auto bg-white text-red-600 border border-red-600 hover:bg-red-600 hover:text-white disabled:opacity-50"
                                  disabled={Boolean(editHint)}
                                  onClick={() => setDeleteRun(run)}
                                >
                                  Delete
                                </Button>
                              </DisabledHint>
                            </>
                          ) : (
                            <span className="text-xs text-[#63666A]">View only</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {hasPeriod && (
        <CreateOffCycleRunDialog
          open={isCreateOpen}
          onOpenChange={setIsCreateOpen}
          payPeriodId={payPeriodId as Id}
          periodName={period?.name}
        />
      )}
      <OffCycleTemplateDialog run={templateRun} onOpenChange={(open) => !open && setTemplateRun(null)} />
      <OffCycleUploadDialog run={uploadRun} onOpenChange={(open) => !open && setUploadRun(null)} />
      <ConfirmDialog
        open={Boolean(deleteRun)}
        onOpenChange={(open) => !open && setDeleteRun(null)}
        title={`Delete ${deleteRun?.name ?? "off-cycle run"}?`}
        description="The run and any schedule uploaded for it will be removed."
        confirmLabel="Delete"
        destructive
        isPending={deleteMutation.isPending}
        onConfirm={() => deleteRun && deleteMutation.mutate(deleteRun)}
      />
    </main>
  );
};

export default OffCycleRunsPage;
