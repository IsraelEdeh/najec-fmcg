"use client";

import { Clock3, SquareChevronLeft } from "lucide-react";
import React, { useState } from "react";
import CustomButton from "@/components/Elements/CustomButton";
import Image from "next/image";
import PayrollScheduleSidebar from "@/components/dashboard/payroll/PayrollScheduleSidebar";
import Link from "next/link";
import { MdHourglassEmpty } from "react-icons/md";
import ApiFetcher from "@/components/Utils/api";
import { toast } from "react-toastify";
import { useMutation, useQuery } from "@tanstack/react-query";
import EmptyPayroll from "@/components/Payroll/EmptyPayroll";
import UpcomingPayroll from "@/components/dashboard/UpcomingPayroll";
import ProgressThread from "@/components/dashboard/payroll/ProgressThread";
import RunSelectionBar from "@/components/Payroll/Runs/RunSelectionBar";
import useRunSelection from "@/components/Payroll/Runs/useRunSelection";
import useActiveRoles from "@/hooks/Custom-hook/useActiveRoles";
import { PAY_PERIOD_CLOSED_MESSAGE, allowedActionsOf, buildQuery, payrollStatusLabel } from "@/lib/payroll-api";

const Payroll = () => {
  const [closeRightSidebar, setCloseRightSidebar] = useState<boolean>(false);

  const getPayrollSummary = async () => {
    try {
      const response = await ApiFetcher.get(
        "/payroll/get-payroll-schedule-summary"
      );

      // console.log("use::", response);

      return response;
    } catch (error: any) {
      const errorMessage = error?.response?.data?.message
        ? error?.response?.data?.message
        : "Error fetching payroll summary";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  const {
    data: payrollSummary,
    isPending,
    isLoading,
    error
  } = useQuery({
    queryKey: ["fetchPayrollSummary"],
    queryFn: getPayrollSummary
  });

  const selection = useRunSelection(payrollSummary?.data?.data?.payPeriodId, "review");
  const { roles } = useActiveRoles();
  const selectedEntry = selection.selectedEntry;
  const selectedPayrollId = selectedEntry?.payrollId;

  const statusMap: Record<string, { label: string; bg: string }> = {
    "Not processed": { label: "Payroll not processed yet", bg: "bg-gray-300 text-gray-800" },
    Pending: { label: "Payroll pending submission", bg: "bg-gray-300 text-gray-800" },
    Submitted: { label: "Payroll awaiting review", bg: "bg-yellow-300 text-yellow-900" },
    Reviewed: { label: "Payroll awaiting approval", bg: "bg-yellow-300 text-yellow-900" },
    Approved: { label: "Approved", bg: "bg-green-300 text-green-900" },
    Rejected: { label: "Rejected - reprocess from Data Check", bg: "bg-red-300 text-red-900" }
  };

  const statusName =
    selectedPayrollId === undefined ? "Not processed" : payrollStatusLabel(selectedEntry?.status);
  const { label: statusLabel, bg: statusBg } = selection.isClosed
    ? { label: PAY_PERIOD_CLOSED_MESSAGE, bg: "bg-gray-300 text-gray-800" }
    : statusMap[statusName] ?? { label: statusName, bg: "bg-gray-200 text-gray-800" };
  const pendingActions = selection.isClosed ? [] : allowedActionsOf(selectedEntry, roles);
  const viewHref = `/dashboard/payroll/run${buildQuery({
    payPeriodId: selection.payPeriodId,
    payrollId: selectedPayrollId,
    offCycleRunId: selectedPayrollId === undefined ? selectedEntry?.offCycleRunId : undefined
  })}`;

  return (
    <main className="relative grid grid-cols-1 gap-4 overflow-x-hidden px-4 py-6 lg:grid-cols-10">
      {/* {closeRightSidebar && (
        <div className="z-40 fixed top-20 right-0 hidden lg:block">
          <SquareChevronLeft
            onClick={() => setCloseRightSidebar(false)}
            className="cursor-pointer text-secondary transition duration-300 ease-linear mr-4"
            size={40}
          />
        </div>
      )} */}

      <div
        className={`w-full ${closeRightSidebar ? "col-span-10" : "col-span-10 "
          }`}
      >
        <p className="text-primary text-sm mb-4">Payroll</p>
        <h1 className="text-[40px] leading-[52px] font-semibold mb-[10px]">
          Payroll Overview
        </h1>
        <p className="text-[#000000] text-sm mb-6">
          Here is what happening with your payroll today.
        </p>

        <div className="mb-4">
          <ProgressThread />
        </div>

        {payrollSummary?.status === 200 ? (
          <div className="block">
            <RunSelectionBar selection={selection} mode="review" />
            <div className="flex items-center justify-between w-full bg-primary p-6 border border-[#005587] rounded-[4px] my-6">
              <div>
                <p className="text-white text-sm font-bold mb-1">
                  Payroll status
                </p>

                <p
                  role="status"
                  className={`inline-block px-3 py-1 rounded ${statusBg} font-semibold mb-3`}
                >
                  {statusLabel}
                </p>
                {pendingActions.length > 0 && (
                  <p className="text-white text-xs">
                    Awaiting your action: {pendingActions.join(", ")}
                  </p>
                )}
              </div>

              <div className="text-sm text-white">
                <p className="font-bold mb-1">Pay period</p>
                <p className="font-medium">
                  {selection.periodName}
                </p>
              </div>

              <div className="flex items-center space-x-4">
                <Link href={viewHref}>
                  <CustomButton
                    className="py-[9px] px-[25px] rounded-[4px] text-sm"
                    classType="tertiary"
                  >
                    View
                  </CustomButton>
                </Link>
                <CustomButton
                  className="py-[9px] px-[25px] rounded-[4px] text-white"
                  classType="secondary"
                >
                  Cancel
                </CustomButton>
              </div>
            </div>

            <div className="p-[24px] bg-white rounded-[4px]">
              <h2 className="text-2xl font-bold mb-3">{statusLabel}</h2>

              <div className="flex w-[300px] justify-between text-sm mb-2">
                <h1 className="flex items-center space-x-1">
                  <Clock3 size={15} className="text-[#404040]" />
                  <span>Pay period</span>
                </h1>
                {/* <h1>Pay day deadline</h1> */}
              </div>

              <div className="flex w-[300px] justify-between text-sm mb-4">
                <p>{selection.periodName}</p>
                {/* <p>{payrollSummary?.data?.data?.deadLine}</p> */}
              </div>
            </div>
          </div>
        ) : (
          <EmptyPayroll />
        )}
        <UpcomingPayroll />
      </div>
    </main>
  );
};

export default Payroll;
