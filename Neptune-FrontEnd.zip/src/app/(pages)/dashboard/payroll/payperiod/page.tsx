"use client";

import Link from "next/link";
import React, { useState } from "react";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { MdOutlineArrowDropDown } from "react-icons/md";
import { Download, Pencil, Trash2 } from "lucide-react";
import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import ApiFetcher from "@/components/Utils/api";
import EmptyRecord from "@/components/dashboard/EmptyRecord";
import { TbLoader3 } from "react-icons/tb";
import { FaPlus } from "react-icons/fa";
import CustomButton from "@/components/Elements/CustomButton";
import IconActionButton from "@/components/Elements/IconActionButton";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import PayperiodDialog from "@/components/dashboard/payroll/PayperiodDialog";
import { RiArrowLeftSFill, RiArrowRightSFill } from "react-icons/ri";
import { PeriodStatusBadge } from "@/components/Payroll/Runs/Badges";
import ClosePeriodButton from "@/components/Payroll/Runs/ClosePeriodButton";
import ChooseRunDialog from "@/components/Payroll/Runs/ChooseRunDialog";
import ConfirmDialog from "@/components/Payroll/Runs/ConfirmDialog";
import {
  deletePayPeriod,
  getPayrollsByPayPeriod,
  normalizeRunType,
  payrollsByPeriodKey,
  withPayrollId,
  withRunSuffix
} from "@/lib/payroll-api";
import { getApiErrorMessage } from "@/lib/utils";
import { PayrollRunType, type Id, type PayPeriod, type PayrollRunSummary } from "@/types/payroll";

const TABLE_COLUMN_COUNT = 7;

const Payperiod = () => {
  const [openPayPeriodDialog, setOpenPayPeriodDialog] = useState(false);
  const [selectedPayPeriod, setSelectedPayPeriod] = useState<PayPeriod | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const maxPage = 10;
  const queryClient = useQueryClient();
  const user: any = useSelector((state: RootState) => state?.getUser.user);

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);
  const canManage = activeRole?.includes("Admin") || activeRole?.includes("Initiator");
  const canDownload = activeRole?.includes("Admin") || activeRole?.includes("Approver");
  const [deleteTarget, setDeleteTarget] = useState<PayPeriod | null>(null);

  const [downloading, setDownloading] = useState<{ [key: number]: boolean }>(
    {}
  );
  const [chooseRunFor, setChooseRunFor] = useState<{
    payPeriodId: Id;
    periodName?: string;
    runs: PayrollRunSummary[];
  } | null>(null);

  const handleClosePayPeriodDialog = () => {
    setOpenPayPeriodDialog(false);
    setSelectedPayPeriod(null);
  };

  const handleOpenPayPeriodDialog = (payPeriod: PayPeriod) => {
    setSelectedPayPeriod(payPeriod);
    setOpenPayPeriodDialog(true);
  };

  const getAllPayroll = async (page: Number) => {
    try {
      const response = await ApiFetcher.get(
        `/payperiods/get-all-pay-period?PageNumber=${page}&PageSize=${maxPage}`
      );

      return response || [];
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching payroll summary";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  const {
    data: allPayperiod,
    isPending,
    error
  } = useQuery({
    queryKey: ["fetchAllPayroll", currentPage],
    placeholderData: keepPreviousData,
    queryFn: () => getAllPayroll(currentPage)
  });

  const deleteMutation = useMutation({
    mutationFn: (id: Id) => deletePayPeriod(id),
    onSuccess: () => {
      toast.success("Pay period removed successfully");
      queryClient.invalidateQueries();
    },
    onError: (error) => {
      toast.error(getApiErrorMessage(error, "Error deleting payperiod."));
    },
    onSettled: () => setDeleteTarget(null)
  });

  const getProcessThread = async (id: any) => {
    try {
      const response = await ApiFetcher.get(`/payroll/payroll-process-thread`);

      console.log("Check:>>>", response);
      return response;
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error getting current payroll";
      console.error(errorMessage);
      // toast.error(errorMessage);
    }
  };

  // console.log("XXX", allPayperiod);

  const {
    data: checkPayperiodExists,
    isPending: loadingCurrentPayroll,
    error: payDownloadError
  } = useQuery({
    queryKey: ["getProcessThread"],
    queryFn: getProcessThread
  });

  const handleBulkUpload = async (payPeriodId: any, run?: PayrollRunSummary) => {
    if (!payPeriodId) {
      console.error("Pay period ID is required");
      return;
    }

    // The Regular payroll is the API default, so only off-cycle runs send payrollId.
    const offCycleRun =
      run && normalizeRunType(run.runType) === PayrollRunType.OffCycle ? run : undefined;

    try {
      setDownloading((prev) => ({ ...prev, [payPeriodId]: true }));
      const response = await ApiFetcher.get(
        withPayrollId(`/payroll/bulk-download-payslips/${payPeriodId}`, offCycleRun?.id),
        {
          responseType: "blob", // Ensure the response is treated as binary data
          headers: {
            "Content-Type": "application/zip"
            // Add any necessary headers here, such as authentication tokens
          }
        }
      );

      if (!response) {
        throw new Error("Network response was not ok");
      }

      const blobUrl = window.URL.createObjectURL(response.data);
      const link = document.createElement("a");
      console.log("blobURL:", blobUrl), console.log("link:", link);
      link.href = blobUrl;
      link.setAttribute(
        "download",
        `${withRunSuffix("Payslips", offCycleRun?.runName)}.zip`
      );
      document.body.appendChild(link);
      link.click();
      link?.parentNode?.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (error: any) {
      console.log("Error downloading the file:", error);
      if (error?.response?.data instanceof Blob) {
        try {
          error.response.data = JSON.parse(await error.response.data.text());
        } catch {
          error.response.data = undefined;
        }
      }
      const errorMessage = getApiErrorMessage(error, "Error downloading payslips");
      console.log(errorMessage);
      toast.error(errorMessage);
    } finally {
      setDownloading((prev) => ({ ...prev, [payPeriodId]: false }));
    }
  };

  const mutation = useMutation({
    mutationFn: ({ payPeriodId, run }: { payPeriodId: Id; run?: PayrollRunSummary }) =>
      handleBulkUpload(payPeriodId, run)
  });

  const onHandlerSubmit = async (payPeriodId: Id, periodName?: string) => {
    try {
      const { payrolls } = await queryClient.fetchQuery({
        queryKey: payrollsByPeriodKey(payPeriodId),
        queryFn: () => getPayrollsByPayPeriod(payPeriodId)
      });
      if (payrolls.length > 1) {
        setChooseRunFor({ payPeriodId, periodName, runs: payrolls });
        return;
      }
    } catch {
      // Fall back to the original single-payroll download.
    }
    mutation.mutate({ payPeriodId });
  };

  return (
    <main className="p-[24px] ">
      <div>
        <nav aria-label="Breadcrumb" className="flex mb-[24px]">
          <ol className="inline-flex text-primary text-sm items-center">
            <li>
              <Link href="">Pay period</Link>
            </li>
          </ol>
        </nav>

        <div className="mb-[24px]">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-[40px] leading-[52px] font-semibold mb-[10px]">
                Pay Period
              </h1>
              <p className="text-sm text-[#1E1E1E]">
                All your past payperiod data is safe with us.
              </p>
            </div>

            {canManage && (
              <Link href="/dashboard/payroll/settings">
                <CustomButton
                  classType="primary"
                  className="px-4 py-[9px] text-sm rounded-[4px] flex items-center space-x-2"
                >
                  <span>Create pay period</span>
                  <FaPlus />
                </CustomButton>
              </Link>
            )}
          </div>
        </div>

        <div className="bg-white rounded-[4px] ">
          <div className="hidden px-5 pt-6 ">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div>
                  <input
                    type="date"
                    id=""
                    name=""
                    value=""
                    onChange={() => {}}
                    className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <p>Rows: </p>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button
                      className="flex items-center space-x-2 py-1 px-2 text-sm border border-[#d9d9d9] text-[#1E1E1E] rounded-[8px]"
                      type="button"
                    >
                      <span>10</span>

                      <MdOutlineArrowDropDown />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56 bg-white">
                    <DropdownMenuGroup>
                      <DropdownMenuItem>10</DropdownMenuItem>
                      <DropdownMenuItem>20</DropdownMenuItem>
                      <DropdownMenuItem>50</DropdownMenuItem>
                      <DropdownMenuItem>100</DropdownMenuItem>
                    </DropdownMenuGroup>
                    <DropdownMenuSeparator />
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full mt-[24px]">
              <thead className="bg-[#DDEFE8] py-4">
                <tr className=" w-full">
                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    S/N
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Start date
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    End date
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Deadline
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Frequency
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Status
                  </th>

                  <th className="p-4 text-right uppercase text-xs font-semibold ">
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody className="text-[#1A1A1A]">
                {isPending ? (
                  <tr>
                    <td colSpan={TABLE_COLUMN_COUNT} className="p-6">
                      <div className="flex items-center justify-center">
                        <TbLoader3 className="text-primary animate-spin w-6 h-6" aria-label="Loading pay periods" />
                      </div>
                    </td>
                  </tr>
                ) : allPayperiod?.data?.data?.length === 0 ? (
                  <tr>
                    <td colSpan={TABLE_COLUMN_COUNT}>
                      <EmptyRecord />
                    </td>
                  </tr>
                ) : (
                  allPayperiod?.data?.data?.map((item: any, index: number) => (
                    <tr
                      key={item?.id}
                      className="border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9] transition-colors hover:bg-[#F7F9FA]"
                    >
                      <td className="p-4 text-left text-sm font-normal ">
                        <p className="text-sm ">{++index}</p>
                      </td>
                      <td className="p-4 text-left text-sm font-normal ">
                        <p className="text-sm ">
                          {item?.startDate?.split("T")[0]}
                        </p>
                      </td>

                      <td className="p-4 text-left text-sm font-normal ">
                        {item?.endDate?.split("T")[0]}
                      </td>

                      <td className="p-4 text-left text-sm font-normal ">
                        {item?.deadLine?.split("T")[0]}
                      </td>

                      <td className="p-4 text-left text-sm font-normal ">
                        Monthly
                      </td>

                      <td className="p-4 text-left text-sm font-normal ">
                        <PeriodStatusBadge isClosed={item?.isClosed} />
                      </td>

                      <td className="p-4 text-sm font-normal">
                        {/* Right-aligned with the row-dependent Close action first, so the remaining icons line up across rows. */}
                        <div className="flex items-center justify-end gap-1">
                          <ClosePeriodButton
                            variant="icon"
                            payPeriodId={item?.id}
                            periodName={item?.name ?? "this pay period"}
                            isClosed={item?.isClosed}
                            canClose={item?.canClose}
                            closeBlockers={item?.closeBlockers}
                          />
                          {canDownload && (
                            <IconActionButton
                              label="Download payslips"
                              loadingLabel="Downloading payslips…"
                              icon={<Download />}
                              tone="primary"
                              loading={Boolean(downloading[item?.id])}
                              onClick={() => onHandlerSubmit(item?.id, item?.name)}
                            />
                          )}
                          {canManage && (
                            <>
                              <span aria-hidden className="mx-1 h-5 w-px bg-[#D9D9D9]" />
                              <IconActionButton
                                label="Edit pay period"
                                icon={<Pencil />}
                                onClick={() => handleOpenPayPeriodDialog(item)}
                              />
                              <IconActionButton
                                label="Delete pay period"
                                loadingLabel="Deleting pay period…"
                                icon={<Trash2 />}
                                tone="danger"
                                loading={
                                  deleteMutation.isPending &&
                                  deleteMutation.variables === item?.id
                                }
                                onClick={() => setDeleteTarget(item)}
                              />
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>

            <div className="mt-4 flex items-center justify-between py-2 px-4">
              <p className="text-[#63666A] text-xs">
                {(() => {
                  const meta = allPayperiod?.data?.meta;
                  const total = Number(meta?.totalCount ?? 0);
                  const pageNumber = Number(meta?.pageNumber ?? currentPage);
                  const pageSize = Number(meta?.pageSize ?? maxPage);
                  const start = total === 0 ? 0 : (pageNumber - 1) * pageSize + 1;
                  const end = Math.min(pageNumber * pageSize, total);
                  return `${start}-${end} of ${total} items`;
                })()}
              </p>

              <div className="flex items-center space-x-3">
                <button
                  disabled={currentPage <= 1}
                  onClick={() => setCurrentPage((e: number) => e - 1)}
                  className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
                >
                  <RiArrowLeftSFill className="w-6 h-6" />
                </button>

                <button
                  disabled={
                    currentPage >= (Number(allPayperiod?.data?.meta?.totalPages) || 1)
                  }
                  onClick={() => setCurrentPage((e: number) => e + 1)}
                  className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
                >
                  <RiArrowRightSFill className="w-6 h-6" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
        title={`Delete ${deleteTarget?.name ?? "this pay period"}?`}
        description="This pay period will be permanently removed. This cannot be undone."
        confirmLabel="Delete"
        destructive
        isPending={deleteMutation.isPending}
        onConfirm={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
      />

      <ChooseRunDialog
        open={Boolean(chooseRunFor)}
        periodName={chooseRunFor?.periodName}
        runs={chooseRunFor?.runs ?? []}
        onOpenChange={(open) => !open && setChooseRunFor(null)}
        onConfirm={(run) => {
          if (chooseRunFor) mutation.mutate({ payPeriodId: chooseRunFor.payPeriodId, run });
          setChooseRunFor(null);
        }}
      />

      <Dialog
        open={openPayPeriodDialog}
        onOpenChange={(open) => (open ? setOpenPayPeriodDialog(true) : handleClosePayPeriodDialog())}
      >
        <DialogContent className="bg-white max-h-screen overflow-y-scroll">
          <DialogHeader>
            <DialogTitle className="sr-only">Update pay period</DialogTitle>
            <PayperiodDialog
              payPeriod={selectedPayPeriod}
              setOpenPayPeriodDialog={(open) =>
                open ? setOpenPayPeriodDialog(true) : handleClosePayPeriodDialog()
              }
            />
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </main>
  );
};

export default Payperiod;
