"use client";

import { Button } from "@/components/ui/button";
import { ChevronRightIcon, Trash2 } from "lucide-react";
import Link from "next/link";
import React, { useMemo, useState, useEffect } from "react";
import ApiFetcher from "@/components/Utils/api";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { useForm } from "react-hook-form";
import { getNeptuneBusinessCountries, getThread } from "@/constants";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { FiInfo } from "react-icons/fi";
import { useRouter, useParams } from "next/navigation"; // <-- added useParams
import { TbLoader3 } from "react-icons/tb";
import { buildQuery } from "@/lib/payroll-api";
import {
  SchedulePeriodPicker,
  useSchedulePayPeriod
} from "@/components/Payroll/Runs/useSchedulePayPeriod";

const schema = yup.object({
  staffNumber: yup.string().min(3, "First name should be 3 characters or more"),
  employeeName: yup.string().min(3, "Last name should be 3 characters or more")
});

const page = (_props: any) => {
  const queryClient = useQueryClient();
  const schedulePeriod = useSchedulePayPeriod();
  const router = useRouter();
  const params = useParams() as { id?: string }; // useParams works in client components
  const id = params?.id;
  // console.log("employee id param::", id);

  const [currentStep, setCurrentStep] = useState(1);
  const [isOrganizationDeleteDialogOpen, setIsOrganizationDeleteDialogOpen] =
    useState(false);

  const [deleteDataInput, setDeleteDataInput] = useState<string>("");

  const [payComponentsState, setPayComponentsState] = useState<
    {
      payComponentId: number;
      payComponentValue: number;
      payComponentName?: string;
    }[]>(
      []
    );

  const handleOpenOrganizationDeleteDialog = () => {
    setIsOrganizationDeleteDialogOpen(true);
  };

  const handleCloseOrganizationDeleteDialog = () => {
    setIsOrganizationDeleteDialogOpen(false);
  };

  const handleNext = () => {
    setCurrentStep((prevStep) => prevStep + 1);
  };

  const fetchPayrollSchedule = async () => {
    try {
      const response: any = await ApiFetcher.get(
        `/payroll/get-payroll-schedule`
      );

      // console.log("payroll schedule response:", response);
      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error fetching payroll schedule";
      console.log(errorMessage);
      throw error;
    }
  };

  const {
    data: payrollScheduleData,
    isPending: isPayComponentsLoading,
    isLoading,
    error
  } = useQuery({
    queryKey: ["fetchPayrollSchedule"],
    queryFn: fetchPayrollSchedule
  });

  const fetchEmployeePayrollSchedule = async (id: any) => {
    try {
      if (!id) return;
      const response = await ApiFetcher.get(
        `/payroll/get-payroll-schedule-by-employeeId/${id}`
      );
      // console.log("pay schedule response::", response);
      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error fetching employee details.";

      toast.error(errorMessage);
    }
  };

  const { isPending, data: employeeData } = useQuery({
    queryKey: ["fetchEmployeePayrollScheduleById", id],
    queryFn: () => fetchEmployeePayrollSchedule(id),
    enabled: Boolean(id) // <-- prevent query when id is undefined
  });

  useEffect(() => {
    if (!employeeData) return;

    let components: any[] = [];
    if (Array.isArray(employeeData)) {
      components = employeeData;
    } else if (
      employeeData?.payComponents &&
      Array.isArray(employeeData.payComponents)
    ) {
      components = employeeData.payComponents;
    } else {
      components = [];
    }

    if (components.length > 0) {
      setPayComponentsState(
        components.map((c: any) => ({
          payComponentId: Number(c.payComponentId ?? c.payComponentId),
          payComponentValue: Number(
            c.payComponentValue ?? c.payComponentValue ?? 0
          ),
          payComponentName: c.payComponentName ?? c.payComponentName
        }))
      );
    } else {
      setPayComponentsState([]);
    }
  }, [employeeData]);

  const updateComponentValue = (componentId: number, value: string) => {
    const num = Number(value);
    setPayComponentsState((prev) =>
      prev.map((p) =>
        p.payComponentId === componentId
          ? { ...p, payComponentValue: Number.isNaN(num) ? 0 : num }
          : p
      )
    );
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch
  } = useForm({
    resolver: yupResolver(schema)
  });

  const savePayrollSchedule = async (payload: any) => {
    try {
      const response = await ApiFetcher.put(
        `/payroll/add-or-edit-payroll-schedule${buildQuery({ payPeriodId: schedulePeriod.payPeriodId })}`,
        payload
      );
      return response;
    } catch (error: any) {
      const msg =
        error?.response?.data?.message || "Error saving payroll schedule";
      throw new Error(msg);
    }
  };

  const payrollMutation = useMutation({
    mutationFn: savePayrollSchedule,
    onSuccess: () => {
      toast.success("Payroll schedule saved");
      queryClient.invalidateQueries({ queryKey: ["fetchPayrollSchedule"] });
      queryClient.invalidateQueries({
        queryKey: ["fetchEmployeePayrollScheduleById", id]
      });
    },
    onError: (err: any) => {
      toast.error(err?.message || "Failed to save payroll schedule");
    }
  });

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!id) {
      toast.error("Missing EmployeeId");
      return;
    }

    if (payrollMutation.isPending) return;

    const payload = {
      StaffNumber: employeeData?.staffNumber,
      PayComponents: payComponentsState.map((p) => ({
        PayComponentId: Number(p.payComponentId),
        PayComponentValue: Number(p.payComponentValue ?? 0)
      }))
    };

    try {
      await payrollMutation.mutateAsync(payload);
      // optional: keep user on the page, or navigate / refresh as needed
    } catch (err: any) {
      // mutateAsync already surfaces errors to onError, but catch to avoid unhandled rejection
      console.error("Save payroll schedule failed", err);
    }
  };

  const handleDeleteEmployee = async () => {
    try {
      handleCloseOrganizationDeleteDialog();

      const response = await ApiFetcher.delete(
        `/employees/delete-employee/${id}`
      );

      toast.success("Employee deleted successfully!");
      router.push("/dashboard/employees");
      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Unable to delete employee.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const deleteMutation = useMutation({
    mutationFn: handleDeleteEmployee,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  const onHandlerDelete = () => {
    try {
      deleteMutation.mutateAsync();
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error adding department.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const getPayrollSummary = async () => {
    try {
      const response = await ApiFetcher.get(
        "/payroll/get-payroll-schedule-summary"
      );

      // console.log("use::", response);

      return response;
    } catch (error: any) {
      const errorMessage = error?.response?.data?.message
        ? error?.response?.data?.message
        : "Error fetching payroll summary";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  const {
    data: payrollSummary,
    isPending: isPendingPayrollSummary,
    isLoading: isLoadingPayrollSummary,
    error: isErrorPayrollSummary
  } = useQuery({
    queryKey: ["fetchPayrollSummary"],
    queryFn: getPayrollSummary
  });

  // console.log("payrollSummary::", payrollSummary);

  const payrollId = schedulePeriod.payPeriodId;

  const { data: payrollProcessData, isLoading: isPayrollProcessLoading } = useQuery({
    queryKey: ["fetchCurrentPayrollProcess", payrollId],
    queryFn: () => getThread(payrollId),
    enabled: !!payrollId
  });

  return (
    <div className=" px-4 py-6">
      <nav className="flex" aria-label="Breadcrumb">
        <ol className="inline-flex items-center space-x-1 md:space-x-3">
          <li className="inline-flex items-center">
            <Link
              href="/dashboard/payroll/payroll-schedule"
              className="text-sm text-blue-700 hover:underline"
            >
              Payroll Schedule
            </Link>
          </li>
          <li>
            <ChevronRightIcon className="w-4 h-4 text-gray-400" />
          </li>
          <li>
            <span className="text-sm font-medium text-gray-500">
              Update Payroll Schedule
            </span>
          </li>
        </ol>
      </nav>

      <h1 className="text-2xl font-semibold mt-4 mb-2">
        Employee Payroll Schedule
      </h1>
      <p className="text-gray-600 mb-6">
        Click save after edits to update payroll schedule for this employee.
      </p>

      <div className="border border-[#D9D9D9] bg-white p-[24px]">
        <div className="mb-4">
          <SchedulePeriodPicker selection={schedulePeriod} />
        </div>
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-1">
              <label
                htmlFor="staffNumber"
                className="block mb-2 text-sm font-medium text-gray-900"
              >
                Staff ID / Tag
              </label>
              <input
                type="text"
                placeholder={employeeData?.staffNumber}
                defaultValue={employeeData?.staffNumber}
                // {...register("staffNumber")}
                name="staffNumber"
                className="disabled:border-gray-200 disabled:bg-gray-50 disabled:text-gray-500 disabled:shadow-none dark:disabled:border-gray-700 dark:disabled:bg-gray-800/20 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                required
                disabled
              />
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors?.staffNumber?.message}
              </p>
            </div>

            <div className="col-span-1">
              <label
                htmlFor="employeeName"
                className="block mb-2 text-sm font-medium text-gray-900"
              >
                Employee Name
              </label>
              <input
                type="text"
                placeholder={employeeData?.employeeName}
                defaultValue={employeeData?.employeeName}
                // {...register("employeeName")}
                // name="employeeName"
                className="disabled:border-gray-200 disabled:bg-gray-50 disabled:text-gray-500 disabled:shadow-none dark:disabled:border-gray-700 dark:disabled:bg-gray-800/20 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                disabled
              />
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors?.employeeName?.message}
              </p>
            </div>

            {isPending ? (
              <TbLoader3 className="text-primary animate-spin w-6 h-6" />
            ) : payrollScheduleData?.data?.data?.length === 0 ? null : (
              <>
                {payComponentsState.map((component) => {
                  return (
                    <div className="col-span-1" key={component.payComponentId}>
                      <label
                        htmlFor={`payComponent-${component.payComponentId}`}
                        className="block mb-2 text-sm font-medium text-gray-900"
                      >
                        {component.payComponentName ||
                          payrollScheduleData?.data?.data
                            ?.flatMap((p: any) => p.payComponents || [])
                            .find(
                              (c: any) =>
                                Number(c.payComponentId) ===
                                Number(component.payComponentId)
                            )?.payComponentName ||
                          `Component ${component.payComponentId}`}
                      </label>
                      <input
                        id={`payComponent-${component.payComponentId}`}
                        type="number"
                        step="0.01"
                        min="0"
                        value={component.payComponentValue}
                        onChange={(e) =>
                          updateComponentValue(
                            component.payComponentId,
                            e.target.value
                          )
                        }
                        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                        disabled={payrollProcessData?.isPayrollScheduleUploaded && payrollProcessData?.isPayrollSubmitted}
                      />
                      <p
                        className="text-red-400 mt-1 text-xs lg:text-sm"
                        role="alert"
                      >
                        {/* optional per-component validation messages could go here */}
                      </p>
                    </div>
                  );
                })}
              </>
            )}
          </div>

          <div className={`flex justify-end mt-6 gap-[24px] pt-[48px] `}>
            <div className="flex items-center">
              <Button
                type="submit"
                className="disabled:bg-secondary disabled:bg-opacity-60 bg-[#005587] hover:bg-secondary text-white font-medium py-[11px] px-[103px] rounded-lg"
                // disabled={payrollMutation.isPending || payrollProcessData?.isPayrollSubmitted}
                disabled={payrollProcessData?.isPayrollScheduleUploaded && payrollProcessData?.isPayrollSubmitted}
              >
                {payrollMutation.isPending ? "Saving . . ." : "Save"}
              </Button>
            </div>
          </div>
        </form>
      </div>

      <Dialog
        open={isOrganizationDeleteDialogOpen}
        onOpenChange={handleCloseOrganizationDeleteDialog}
      >
        <DialogContent className="w-[620px] bg-white rounded-[4px] p-10">
          <DialogHeader>
            <DialogTitle className="text-xl">Confirm Delete</DialogTitle>
            <DialogDescription className="pt-2">
              <div className="font-semibold">
                You are attempting to delete this employee.
              </div>
              <div className="mt-1">
                This will remove all data related to this employee, including
                payroll history, profile data and all configurations done
                previously. Are you sure you want to proceed with this action.
              </div>

              <div className="rounded-[4px] flex items-center space-x-2 my-6 border-[#757575] border-2 bg-[#f4f6f9] p-[18px]">
                <FiInfo className="w-4 h-4 text-[#ff3b30] " />

                <p className="text-[#1e1e1e]">This action cannot be undone.</p>
              </div>
            </DialogDescription>
          </DialogHeader>

          <div className="w-full">
            <form className="flex items-center gap-2">
              <div className="w-full">
                <input
                  type="text"
                  placeholder="Type 'Delete' to confirm action"
                  value={deleteDataInput}
                  onChange={(e: any) => setDeleteDataInput(e.target.value)}
                  className="rounded-[4px] border py-2.5 pl-3 w-full"
                />
              </div>
              <div>
                <Button
                  className="bg-[#FF3B30] hover:bg-[#e2544c] disabled:bg-[#DDC9C8] disabled:text-white focus:bg-[#e2544c] text-white"
                  type="button"
                  onClick={onHandlerDelete}
                  disabled={deleteDataInput !== "Delete"}
                >
                  Delete
                </Button>
              </div>
            </form>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default page;
