"use client";

import ApiFetcher from "@/components/Utils/api";
import { Button } from "@/components/ui/button";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronRightIcon } from "lucide-react";
import Link from "next/link";
import React, { useMemo, useState } from "react";
import { TbLoader3 } from "react-icons/tb";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import { toast } from "react-toastify";
import { useRouter } from "next/navigation";
import { buildQuery } from "@/lib/payroll-api";
import {
  SchedulePeriodPicker,
  useSchedulePayPeriod
} from "@/components/Payroll/Runs/useSchedulePayPeriod";

const Page = () => {
  const router = useRouter();
  const queryClient = useQueryClient();
  const schedulePeriod = useSchedulePayPeriod();
  const [isLoading, setIsLoading] = useState(false);

  const user: any = useSelector((state: RootState) => state?.getUser.user);

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const fetchPayrollSchedule = async () => {
    try {
      const response: any = await ApiFetcher.get(
        `/payroll/get-payroll-schedule`
      );
      return response?.data?.data || [];
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response?.data?.message
        : "Error fetching payroll schedule";
      console.log(errorMessage);
      throw error;
    }
  };

  const { data: payrollScheduleList = [] } = useQuery({
    queryKey: ["fetchPayrollSchedule"],
    queryFn: fetchPayrollSchedule
  });

  const payComponentColumns = useMemo(() => {
    const map = new Map<number | string, string>();
    
    // --- CHANGED: add safety check for array ---
    if (!Array.isArray(payrollScheduleList)) {
      return [];
    }

    payrollScheduleList.forEach((item: any) => {
      (item?.payComponents || []).forEach((c: any) => {
        if (!map.has(c?.payComponentId)) {
          map.set(c?.payComponentId, c?.payComponentName);
        }
      });
    });
    return Array.from(map.entries()).map(([id, name]) => ({ id, name }));
  }, [payrollScheduleList]);

  const dynamicSchema = useMemo(() => {
    const shape: any = {
      staffNumber: yup.string().required("Staff number is required")
    };

    payComponentColumns.forEach((col: any) => {
      shape[`payComponent_${col.id}`] = yup
        .number()
        .typeError(`${col.name} must be a number`)
        .min(0, `${col.name} must be 0 or greater`)
        .required(`${col.name} is required`);
    });

    return yup.object(shape).required();
  }, [payComponentColumns]);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm({
    resolver: yupResolver(dynamicSchema),
    defaultValues: {
      staffNumber: "",

      ...Object.fromEntries(
        payComponentColumns.map((col) => [`payComponent_${col.id}`, 0])
      )
    }
  });

  // console.log("pay components cols::", payComponentColumns);

  const handleAddPayroll = async (data: any) => {
    try {
      setIsLoading(true);

      const payComponents = payComponentColumns.map((col: any) => ({
        payComponentId: Number(col.id),
        payComponentValue: Number(data[`payComponent_${col.id}`] ?? 0)
      }));

      const payload = {
        staffNumber: data.staffNumber,
        payComponents: payComponents
      };

      const response = await ApiFetcher.put(
        `/payroll/add-or-edit-payroll-schedule${buildQuery({ payPeriodId: schedulePeriod.payPeriodId })}`,
        payload
      );

      toast.success("Payroll schedule added successfully!");
      reset();
      queryClient.invalidateQueries({ queryKey: ["fetchPayrollSchedule"] });
      router.push("/dashboard/payroll/payroll-schedule");
      return response;
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error adding payroll schedule";
      console.error(errorMessage);
      toast.error(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const addPayrollMutation = useMutation({
    mutationFn: handleAddPayroll,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  const onSubmit = async (data: any) => {
    await addPayrollMutation.mutateAsync(data);
  };

  return (
    <div className=" px-4 py-6">
      <nav className="flex mb-6" aria-label="Breadcrumb">
        <ol className="inline-flex items-center space-x-1 md:space-x-3">
          <li className="inline-flex items-center">
            <a
              href="/dashboard/payroll/payroll-schedule"
              className="text-sm text-blue-700 hover:underline"
            >
              Payroll Schedule
            </a>
          </li>
          <li>
            <span className="mx-2 text-gray-400">/</span>
          </li>
          <li>
            <span className="text-sm font-medium text-gray-500">
              Add Payroll Schedule
            </span>
          </li>
        </ol>
      </nav>

      <h1 className="text-2xl font-semibold mt-4 mb-2">Add Payroll Schedule</h1>
      <p className="text-gray-600 mb-6">
        Create a new payroll schedule for an employee.
      </p>

      <div className="border border-[#D9D9D9] bg-white p-[24px] rounded-lg">
        <div className="mb-4">
          <SchedulePeriodPicker selection={schedulePeriod} />
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Staff Number */}
          <div>
            <label
              htmlFor="staffNumber"
              className="block mb-2 text-sm font-medium text-gray-900"
            >
              Staff Number
            </label>
            <input
              id="staffNumber"
              type="text"
              placeholder="Enter staff number"
              {...register("staffNumber")}
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            />
            {/* <p className="text-red-400 mt-1 text-xs" role="alert">
              {errors?.staffNumber?.message}
            </p> */}
          </div>

          {payComponentColumns?.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-4">Pay Components</h3>
              <div className="grid grid-cols-2 gap-4">
                {payComponentColumns?.map((column: any) => (
                  <div key={column.id}>
                    <label
                      htmlFor={`payComponent_${column.id}`}
                      className="block mb-2 text-sm font-medium text-gray-900"
                    >
                      {column.name}
                    </label>
                    <input
                      id={`payComponent_${column.id}`}
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      {...register(`payComponent_${column.id}`, {
                        valueAsNumber: true
                      })}
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                    />
                    {/* <p className="text-red-400 mt-1 text-xs" role="alert">
                      {errors[`payComponent_${column.id}` as keyof typeof errors]?.message}
                    </p> */}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-4 pt-4">
            <Button
              type="button"
              onClick={() => router.back()}
              className="bg-gray-400 hover:bg-gray-500 text-white px-6 py-2 rounded"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="bg-primary hover:bg-secondary text-white px-6 py-2 rounded flex items-center space-x-2"
            >
              {isLoading ? (
                <>
                  <TbLoader3 className="animate-spin w-4 h-4" />
                  <span>Saving...</span>
                </>
              ) : (
                <span>Save Payroll Schedule</span>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Page;
