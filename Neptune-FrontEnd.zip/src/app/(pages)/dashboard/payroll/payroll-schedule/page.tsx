"use client";

import React, { useState, useMemo, useEffect, act } from "react";
import Link from "next/link";
import CustomButton from "@/components/Elements/CustomButton";
import { FaPlus } from "react-icons/fa6";
import { CiExport } from "react-icons/ci";
import { IoEyeOutline } from "react-icons/io5";
import EmptyRecord from "@/components/dashboard/EmptyRecord";
import { toast } from "react-toastify";
import ApiFetcher from "@/components/Utils/api";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { AiOutlineLoading3Quarters } from "react-icons/ai";
import { RiArrowLeftSFill, RiArrowRightSFill } from "react-icons/ri";
import { SquareChevronLeft } from "lucide-react";
import { TbLoader3 } from "react-icons/tb";
import BulkUpload from "@/components/dashboard/BulkUpload";

import { MdOutlineFileDownload } from "react-icons/md";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import { FaSearch } from "react-icons/fa";
import RightPayrollScheduleDetails from "@/components/dashboard/RightPayrollScheduleDetails";
import BulkUploadSchedule from "@/components/dashboard/BulkUploadSchedule";
import { sanitizeFilename } from "@/lib/helpers";
import { getThread } from "@/constants";
import { useSchedulePayPeriod } from "@/components/Payroll/Runs/useSchedulePayPeriod";

const Page = () => {
  const user: any = useSelector((state: RootState) => state.getUser.user);

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const getClosedBarStatus = (activeRole: string[]) => {
    if (activeRole?.includes("Admin") || activeRole?.includes("Initiator")) {
      return false;
    }
    return true;
  };
  const [loading, setLoading] = useState<boolean>(false);
  const [closeRightSidebar, setCloseRightSidebar] = useState<boolean>(
    getClosedBarStatus(activeRole || [])
  );
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [debouncedSearch, setDebouncedSearch] = useState<string>("");

  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(searchTerm.trim()), 300);
    return () => clearTimeout(t);
  }, [searchTerm]);

  const maxPage = 10;

  const fetchPayrollSchedule = async (page: number) => {
    try {
      const response: any = await ApiFetcher.get(
        `/payroll/get-payroll-schedule?PageNumber=${page}&PageSize=${maxPage}`
      );

      console.log("reponse object for this::", response);

      // console.log("payroll schedule response:", response);
      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error fetching payroll schedule";
      console.log(errorMessage);
      // toast.error(errorMessage);
      throw error;
    }
  };

  const { data, isPending, isLoading, error } = useQuery({
    queryKey: ["fetchPayrollSchedule", currentPage],
    placeholderData: keepPreviousData,
    queryFn: () => fetchPayrollSchedule(currentPage)
  });

  const payrollScheduleList: any[] = data?.data?.data || [];

  const payComponentColumns = useMemo(() => {
    const map = new Map<number | string, string>();
    payrollScheduleList.forEach((item: any) => {
      (item?.payComponents || []).forEach((c: any) => {
        if (!map.has(c?.payComponentId)) {
          map.set(c?.payComponentId, c?.payComponentName);
        }
      });
    });
    return Array.from(map.entries()).map(([id, name]) => ({ id, name }));
  }, [payrollScheduleList]);

  const filteredPayrollSchedule = useMemo(() => {
    if (!debouncedSearch) return payrollScheduleList;
    const q = debouncedSearch.toLowerCase();
    return payrollScheduleList.filter((item: any) => {
      const name = (item?.employeeName || "").toString().toLowerCase();
      const staffNo = (item?.staffNumber || "").toString().toLowerCase();
      const empId = (item?.employeeId || "").toString().toLowerCase();
      const componentsText = (item?.payComponents || [])
        .map((c: any) => `${c.payComponentName} ${c.payComponentValue}`)
        .join(" ")
        .toLowerCase();
      return (
        name.includes(q) ||
        staffNo.includes(q) ||
        empId.includes(q) ||
        componentsText.includes(q)
      );
    });
  }, [payrollScheduleList, debouncedSearch]);

  // console.log("filteredPayrollSchedule::", filteredPayrollSchedule);

  const formatCurrency = (val: any) => {
    if (val === null || val === undefined || val === "") return "₦0.00";
    const n = Number(val);
    if (Number.isNaN(n)) return "₦0.00";
    return `₦${n.toLocaleString("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })}`;
  };

  const { payPeriodId: payrollId } = useSchedulePayPeriod();

  const { data: payrollProcessData, isLoading: isPayrollProcessLoading } = useQuery({
    queryKey: ["fetchCurrentPayrollProcess", payrollId],
    queryFn: () => getThread(payrollId),
    enabled: !!payrollId
  });

  // console.log("payrollProcessData::", payrollProcessData);

  const handleExportEmployees = async () => {
    try {
      setLoading(true);
      const response = await ApiFetcher.get(
        "/payroll/export-payroll-schedule?pageSize=1000",
        {
          responseType: "blob"
        }
      );

      const blob = new Blob([response.data], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");

      const fileName = sanitizeFilename("payroll-schedule") + ".xlsx";

      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success("Export done successfully");
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error exporting payroll schedule";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="relative grid grid-cols-1 gap-4 overflow-x-hidden px-4 py-6 lg:grid-cols-10">
      {closeRightSidebar &&
        (activeRole?.includes("Admin") ||
          activeRole?.includes("Initiator")) && (
          <>
            (
            <div className="z-40 fixed top-20 right-0 hidden lg:block">
              <SquareChevronLeft
                onClick={() => setCloseRightSidebar(false)}
                className="cursor-pointer text-secondary transition duration-300 ease-linear mr-4"
                size={40}
              />
            </div>
            )
          </>
        )}

      <div
        className={`w-full min-w-0 ${closeRightSidebar ? "lg:col-span-10" : "col-span-10 lg:col-span-7"}`}
      >
        <p className="text-primary text-sm mb-4">Payroll</p>
        <h1 className="text-[32px] font-semibold mb-2 text-[#1e1e1e]">
          Payroll Schedule
        </h1>
        <p className="text-gray-600 mb-6">
          Setup and customise your payroll schedule
        </p>

        <div className="bg-white rounded-[16px]">
          <div className="px-5 pt-6 pb-4">
            <div className="w-full flex items-center justify-between">
              {payrollScheduleList.length > 0 && (
                <div className="relative flex items-center space-x-3">
                  <FaSearch className="absolute text-xs top-2 left-4 text-[#6B7280]" />
                  <input
                    type="search"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search by name, staff number or component"
                    className="pl-4 pr-2 py-[9px] rounded-[4px] border text-xs border-[#D9D9D9] w-[180px]"
                  />
                  {debouncedSearch && (
                    <button
                      onClick={() => {
                        setSearchTerm("");
                        setDebouncedSearch("");
                      }}
                      className="text-sm text-[#6B7280] underline"
                      type="button"
                    >
                      Clear
                    </button>
                  )}
                </div>
              )}

              <div className="flex items-center space-x-2">
                {(activeRole?.includes("Admin") ||
                  activeRole?.includes("Initiator")) && (
                    <>
                      <div>
                        <BulkUploadSchedule payrollProcessData={payrollProcessData} />
                      </div>

                      <Link
                        className="block"
                        href="/dashboard/payroll/payroll-schedule/add"
                      >
                        <CustomButton
                          classType="primary"
                          className="w-full disabled:bg-opacity-60 px-4 py-[9px] text-xs rounded-[4px] flex items-center space-x-2"
                          disabled={payrollProcessData?.isPayrollSubmitted}
                        >
                          <span className="inline">Add Payroll Schedule</span>
                          <FaPlus />
                        </CustomButton>
                      </Link>

                      <CustomButton
                        type="button"
                        onClick={handleExportEmployees}
                        classType="secondary"
                        className="px-4 py-[9px] text-xs rounded-[4px] flex items-center space-x-2"
                      >
                        {loading ? (
                          <TbLoader3 className="text-primary animate-spin text-xs " />
                        ) : (
                          <MdOutlineFileDownload className="text-primary text-xs" />
                        )}
                      </CustomButton>
                    </>
                  )}
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="mt-6 pb-10 flex items-center justify-center">
                <AiOutlineLoading3Quarters className="w-10 h-10 animate-spin text-primary" />
              </div>
            ) : filteredPayrollSchedule?.length > 0 ? (
              <table className="w-full mt-[24px]">
                <thead className="bg-[#DDEFE8] py-4">
                  <tr className=" w-full">
                    <th className="p-4 text-left uppercase text-xs font-semibold ">
                      Staff No.
                    </th>

                    <th className="p-4 text-left uppercase text-xs font-semibold ">
                      Employee
                    </th>

                    {/* render pay component headers from derived columns */}
                    {payComponentColumns.map((col) => (
                      <th
                        key={col.id}
                        className="p-4 text-left uppercase text-xs font-semibold "
                      >
                        {col.name}
                      </th>
                    ))}

                    <th className="p-4 text-left uppercase text-xs font-semibold ">
                      Actions
                    </th>
                  </tr>
                </thead>

                <tbody className="text-[#1A1A1A]">
                  {filteredPayrollSchedule
                    .sort((a: any, b: any) =>
                      (a?.employeeName || "").localeCompare(
                        b?.employeeName || ""
                      )
                    )
                    .map((item: any, index: number) => {
                      const totalPay = (item?.payComponents || []).reduce(
                        (sum: number, c: any) =>
                          sum + Number(c?.payComponentValue || 0),
                        0
                      );

                      return (
                        <tr
                          key={item?.employeeId || index}
                          className="border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9]"
                        >
                          <td className="p-4 text-left text-sm font-normal ">
                            {item?.staffNumber || "N/A"}
                          </td>

                          <td className="p-4 text-left text-sm font-normal ">
                            <span className="block font-bold text-sm">
                              {item?.employeeName || "N/A"}
                            </span>
                          </td>

                          {/* render cells in same order as headers */}
                          {payComponentColumns.map((col) => {
                            const comp = (item?.payComponents || []).find(
                              (c: any) => c?.payComponentId === col.id
                            );
                            return (
                              <td
                                key={String(col.id)}
                                className="p-4 text-left text-sm font-normal"
                              >
                                {comp
                                  ? formatCurrency(comp.payComponentValue)
                                  : "-"}
                              </td>
                            );
                          })}

                          <td className="p-4 text-left text-sm font-normal ">
                            <Link
                              className="text-[#757577] hover:underline"
                              href={`/dashboard/payroll/payroll-schedule/${item?.employeeId}`}
                            >
                              <IoEyeOutline className="w-6 h-6" />
                            </Link>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            ) : (
              <div className="py-8">
                <EmptyRecord />
              </div>
            )}
          </div>
          <div className="mt-4 flex items-center justify-between py-2 px-4">
            <p className="text-[#63666A] text-xs">
              {(data?.data?.meta?.pageNumber - 1) * data?.data?.meta?.pageSize +
                1}
              -
              {Math.min(
                data?.data?.meta.pageNumber * data?.data?.meta.pageSize,
                data?.data?.meta?.totalCount
              )}{" "}
              of {data?.data?.meta?.totalCount} items
            </p>

            <div className="flex items-center space-x-3">
              <button
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((e: number) => e - 1)}
                className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
              >
                <RiArrowLeftSFill className="w-6 h-6" />
              </button>

              <button
                disabled={currentPage >= (Number(data?.data?.meta?.totalPages) || 1)}
                onClick={() => setCurrentPage((e: number) => e + 1)}
                className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
              >
                <RiArrowRightSFill className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className={`${closeRightSidebar ? "hidden" : "block col-span-10 lg:col-span-3"}`}>
        <div className="h-screen">
          <RightPayrollScheduleDetails
            setCloseRightSidebar={setCloseRightSidebar}
            closeRightSidebar={closeRightSidebar}
          />
        </div>
      </div>
    </main>
  );
};

export default Page;
