"use client";

import { RootState } from "@/app/store";
import RunPayrollSidebar from "@/components/dashboard/payroll/RunPayrollSidebar";
import UploadPayroll from "@/components/dashboard/payroll/UploadPayroll";
import Approval from "@/components/Payroll/Approval";
import DataCheck from "@/components/Payroll/DataCheck";
import OutputReview from "@/components/Payroll/OutputReview";
import SubmitForReview from "@/components/Payroll/Submit";
import SubmitInitiator from "@/components/Payroll/SubmitInitiator";
import SubmitToAuthorize from "@/components/Payroll/SubmitToAuthorize";
import ApiFetcher from "@/components/Utils/api";
import RunSelectionBar from "@/components/Payroll/Runs/RunSelectionBar";
import useRunSelection from "@/components/Payroll/Runs/useRunSelection";
import { buildQuery, getPayrollScheduleSummary, getPayrollsByPayPeriod, isRejectedStatus, normalizeRunType, sameId } from "@/lib/payroll-api";
import { getApiErrorMessage } from "@/lib/utils";
import { PayrollRunType, type Id } from "@/types/payroll";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { SquareChevronLeft } from "lucide-react";
import Image from "next/image";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";

const RunPayroll = () => {
  const [closeRightSidebar, setCloseRightSidebar] = useState<boolean>(false);
  const user: any = useSelector((state: RootState) => state?.getUser?.user);
  const isAdmin = user?.roles?.some(
    (roleObject: any) => roleObject.role === "Admin"
  );

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const initiatorRole = user?.roles?.some((roleObject: any) =>
    roleObject.role.toLowerCase().includes("initiator")
  );

  const approvalRole = user?.roles?.some((roleObject: any) =>
    roleObject.role.toLowerCase().includes("approver")
  );

  // console.log("other roles: initiatir::", initiatorRole);
  const checkRoleStep = () => {
    if (activeRole?.includes("Admin") || activeRole?.includes("Initiator")) {
      return 1;
    } else if (activeRole?.includes("Reviewer")) {
      return 3;
    } else if (activeRole?.includes("Approver")) {
      return 3;
    } else {
      return 1;
    }
  };
  const [currentStep, setCurrentStep] = useState<number>(checkRoleStep());

  const getPayrollSummary = async () => {
    const response: any = await ApiFetcher.get(
      "/payroll/get-payroll-schedule-summary"
    );

    return response;
  };

  const {
    data: payrollSummary,
    isPending,
    isLoading,
    error
  } = useQuery({
    queryKey: ["fetchPayrollSummaryDb"],
    queryFn: getPayrollSummary,
    retry: false
  });

  const getThread = async (id: string | number, payrollId?: Id) => {
    if (!id) return null;

    try {
      const response = await ApiFetcher.get(
        `/payroll/payroll-process-thread${buildQuery({ payPeriodId: id, payrollId })}`
      );

      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching data.";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  const queryClient = useQueryClient();
  const summaryPeriodId = payrollSummary?.data?.data?.payPeriodId;
  const selection = useRunSelection(summaryPeriodId, currentStep >= 3 ? "review" : "run");
  const id = selection.payPeriodId;
  const reviewPayrollId = selection.requestPayrollId;
  const { initialStep, summaryParams } = selection;

  const {
    data: selectedSummary,
    isFetching: isSelectedSummaryLoading,
    error: selectedSummaryError
  } = useQuery({
    queryKey: [
      "payrollScheduleSummary",
      summaryParams?.payPeriodId ?? null,
      summaryParams?.offCycleRunId ?? null
    ],
    queryFn: () => getPayrollScheduleSummary(summaryParams),
    enabled: Boolean(summaryParams),
    retry: false
  });
  const summaryError = summaryParams ? selectedSummaryError : error;

  useEffect(() => {
    if (initialStep === undefined) return;
    // Reviewers/Approvers cannot open Data Check, so a run deep link lands them on Output Review.
    const canRun = activeRole?.includes("Admin") || activeRole?.includes("Initiator");
    setCurrentStep(initialStep === 2 && !canRun ? 3 : initialStep);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialStep]);

  const {
    data: threadData,
    isLoading: threadLoading,
    isError
  } = useQuery({
    queryKey: ["threadAPI", id, reviewPayrollId ?? null],
    queryFn: () => getThread(id as Id, reviewPayrollId)
  });

  // After a run, review and approval steps follow the payroll it created.
  const handleRunComplete = async () => {
    if (id === undefined) return;
    const run = selection.selectedOffCycleRun;
    try {
      const { payrolls } = await queryClient.fetchQuery({
        queryKey: ["payrollsByPayPeriod", id],
        queryFn: () => getPayrollsByPayPeriod(id),
        staleTime: 0
      });
      const payroll = run
        ? payrolls.find((item) => sameId(item.offCycleRunId, run.id))
        : payrolls.find(
            (item) =>
              normalizeRunType(item.runType) === PayrollRunType.Regular &&
              !isRejectedStatus(item.status)
          );
      if (payroll) selection.selectPayroll(payroll.id);
    } catch {
      selection.selectEntry(undefined);
    }
  };

  const runContext = {
    payPeriodId: id,
    periodName: selection.periodName,
    isDefaultPeriod: selection.isDefaultPeriod,
    isClosed: selection.isClosed,
    isBackRun: selection.isBackRun,
    isPastRegular: selection.isPastRegular,
    offCycleRun: selection.selectedOffCycleRun,
    canProcess: Boolean(selection.selectedEntry?.runnable),
    blockedReason: selection.selectedEntry?.disabledReason,
    hasProcessedPayroll: selection.hasProcessedPayroll,
    summary: summaryParams ? selectedSummary : payrollSummary?.data?.data,
    isSummaryLoading: Boolean(summaryParams) && isSelectedSummaryLoading,
    summaryError: summaryError
      ? getApiErrorMessage(summaryError, "Unable to load the payroll summary.")
      : undefined,
    onRunComplete: handleRunComplete
  };

  const reviewPeriod =
    id === undefined ? undefined : { id: id as Id, name: selection.periodName ?? "" };

  // A rejected payroll is fixed by running its period and run again from Data Check.
  const handleReprocess = () => {
    const entry = selection.entries.find(
      (item) => item.kind !== "payroll" && sameId(item.payrollId, reviewPayrollId)
    );
    if (entry) selection.selectEntry(entry.key);
    setCurrentStep(2);
  };
  const actionProps = {
    setCurrentStep,
    threadData,
    payPeriodId: id,
    payrollId: reviewPayrollId,
    isClosed: selection.isClosed,
    onReprocess: handleReprocess
  };

  // console.log("threadData here::", threadData);

  const switchPayrollRunComponent = () => {
    switch (currentStep) {
      case 1:
        return (
          <UploadPayroll
            payPeriodId={id}
            payrollSummary={payrollSummary}
            threadData={threadData}
            setCurrentStep={setCurrentStep}
            currentStep={currentStep}
          />
        );
      case 2:
        return (
          <DataCheck
            payrollSummary={payrollSummary}
            setCurrentStep={setCurrentStep}
            threadData={threadData}
            runContext={runContext}
          />
        );
      case 3:
        return (
          <OutputReview
            payrollSummary={payrollSummary}
            setCurrentStep={setCurrentStep}
            threadData={threadData}
            payrollId={reviewPayrollId}
            payPeriod={reviewPeriod}
          />
        );
      case 4:
        return <Approval {...actionProps} />;
      case 5:
        return <SubmitForReview {...actionProps} />;
      case 6:
        return <SubmitInitiator {...actionProps} />;
      // case 7:
      //   return (
      //     <SubmitToAuthorize
      //       setCurrentStep={setCurrentStep}
      //       threadData={threadData}
      //     />
      //   );
      default:
        return (
          <UploadPayroll
            payPeriodId={id}
            payrollSummary={payrollSummary}
            threadData={threadData}
            setCurrentStep={setCurrentStep}
            currentStep={currentStep}
          />
        );
    }
  };

  return (
    <main className="relative grid grid-cols-1 gap-4 overflow-x-hidden px-4 py-6 lg:grid-cols-10">
      {closeRightSidebar && (
        <div className="z-50 fixed top-20 right-0 hidden lg:block">
          <SquareChevronLeft
            onClick={() => setCloseRightSidebar(false)}
            className="cursor-pointer text-secondary transition duration-300 ease-linear mr-4"
            size={40}
          />
        </div>
      )}
      <div
        className={`w-full min-w-0 ${currentStep === 3 || currentStep === 4 ? "lg:col-span-10" : "col-span-10 lg:col-span-7 "
          }`}
      >
        <p className="text-primary text-sm mb-4">Payroll</p>
        <h1 className="text-[32px] font-semibold mb-2 text-[#1e1e1e]">
          Run Payroll
        </h1>
        <p className="text-gray-600 mb-6">Setup and customise your payroll</p>

        <div className="border border-[#D9D9D9] rounded-[4px] p-6 bg-white mt-6 ">
          <div className="mb-6 flex space-x-4 text-sm">
            <button
              onClick={() => setCurrentStep(1)}
              className={`
                ${activeRole?.includes("Admin") ||
                  activeRole?.includes("Initiator")
                  ? "block"
                  : "hidden"
                } 
                ${currentStep === 1
                  ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                  : "cursor-pointer disabled:text-[#757575]"
                } `}
            // disabled={!threadData?.isPayrollScheduleUploaded}
            >
              Guide
            </button>

            <button
              onClick={() => {
                setCurrentStep(2);
                setCloseRightSidebar(false);
              }}
              // ${!isAdmin ? "hidden" : "block"}
              className={` 
                ${activeRole?.includes("Admin") ||
                  activeRole?.includes("Initiator")
                  ? "block"
                  : "hidden"
                }
                ${currentStep === 2
                  ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                  : "cursor-pointer disabled:text-[#757575]"
                } `}
            // disabled={!threadData?.isPayrollScheduleUploaded}
            >
              Data Check
            </button>

            <button
              onClick={() => setCurrentStep(3)}
              className={`
                ${activeRole?.includes("Admin") ||
                  activeRole?.includes("Initiator") ||
                  activeRole?.includes("Reviewer") ||
                  activeRole?.includes("Approver")
                  ? "block"
                  : "hidden"
                }
                ${currentStep === 3
                  ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                  : "cursor-pointer disabled:text-[#757575]"
                }  `}
            // disabled={!threadData?.isPayrollRun}
            >
              Output Review
            </button>

            <button
              onClick={() => setCurrentStep(5)}
              className={`
                ${activeRole?.includes("Reviewer")
                  ? // activeRole?.includes("Approver")
                  "block"
                  : "hidden"
                }
                ${currentStep === 5
                  ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                  : "cursor-pointer disabled:text-[#757575]"
                } `}
            // disabled={!threadData?.isPayrollApproved}
            >
              Submit
            </button>

            <button
              onClick={() => setCurrentStep(6)}
              className={`
                ${activeRole?.includes("Initiator")
                  ? // activeRole?.includes("Approver")
                  "block"
                  : "hidden"
                }
                ${currentStep === 6
                  ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                  : "cursor-pointer disabled:text-[#757575]"
                } `}
              disabled={!threadData?.isPayrollApproved}
            >
              Submit
            </button>

            {/* <button
              onClick={() => setCurrentStep(7)}
              className={`
                ${
                  activeRole?.includes("Approver")
                    ? // activeRole?.includes("Approver")
                      "block"
                    : "hidden"
                }
                ${
                  currentStep === 7
                    ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                    : "cursor-pointer disabled:text-[#757575]"
                } `}
              disabled={!threadData?.isPayrollApproved}
            >
              Submit
            </button> */}

            <button
              onClick={() => setCurrentStep(4)}
              className={`
                ${activeRole?.includes("Admin") ||
                  activeRole?.includes("Approver")
                  ? "block"
                  : "hidden"
                }
                ${currentStep === 4
                  ? "text-primary font-bold border-b-[1.5px] pb-[9px] border-b-[#146ADC]"
                  : "cursor-pointer disabled:text-[#757575]"
                } `}
            // disabled={!threadData?.isPayrollApproved}
            >
              Approval
            </button>
          </div>

          {currentStep >= 2 && (
            <RunSelectionBar
              selection={selection}
              mode={currentStep === 2 ? "run" : "review"}
            />
          )}

          <div>{switchPayrollRunComponent()}</div>
        </div>
      </div>

      <div
        className={`${closeRightSidebar
          ? "hidden"
          : `${currentStep === 1 || currentStep === 2
            ? "block col-span-10 lg:col-span-3"
            : "hidden"
          }`
          }`}
      >
        <div className="h-screen">
          <RunPayrollSidebar
            setCloseRightSidebar={setCloseRightSidebar}
            closeRightSidebar={closeRightSidebar}
          />
        </div>
      </div>
    </main>
  );
};

export default RunPayroll;
