"use client";

import RightPayrollSettings from "@/components/Payroll/RightPayrollSettings";
import { ChevronRightIcon, SquareChevronLeft } from "lucide-react";
import Link from "next/link";
import React from "react";
import { useState } from "react";
import CustomButton from "@/components/Elements/CustomButton";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import ApiFetcher from "@/components/Utils/api";
import { useRouter } from "next/navigation";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger
} from "@/components/ui/tooltip";
import usePayPeriods from "@/hooks/Custom-hook/usePayPeriods";
import {
  lastDayOfMonth,
  parseDate,
  payPeriodSchema as schema,
  toInputDate,
  toUtcDate
} from "@/lib/pay-period-form";

const DAY_MS = 24 * 60 * 60 * 1000;

const Settings = () => {
  const router = useRouter();
  const user: any = useSelector((state: RootState) => state.getUser.user);
  const organizationId = user?.userOrganizations?.find(
    (item: any) => item.isCurrentLoggedInOrganization
  )?.organizationId;

  const queryClient = useQueryClient();

  const [closeRightSidebar, setCloseRightSidebar] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const {
    register,
    handleSubmit,
    reset,
    watch,
    setValue,
    trigger,
    formState: { errors, isValid }
  } = useForm({ resolver: yupResolver(schema), mode: "onChange" });

  const { periods } = usePayPeriods();
  const [endDateEdited, setEndDateEdited] = useState(false);
  const startValue = parseDate(watch("startDate"));
  const endValue = parseDate(watch("endDate"));

  // Warnings only inform; the backend remains the authority on valid periods.
  const periodWarnings: string[] = [];
  if (startValue && startValue.getDate() !== 1) {
    periodWarnings.push("The start date is not the 1st of the month.");
  }
  if (endValue && endValue.getDate() !== lastDayOfMonth(endValue).getDate()) {
    periodWarnings.push("The end date is not the last day of the month.");
  }
  if (startValue && endValue) {
    const ranges = periods
      .map((period) => ({
        name: period.name,
        start: parseDate(period.startDate),
        end: parseDate(period.endDate)
      }))
      .filter((range): range is { name: string; start: Date; end: Date } =>
        Boolean(range.start && range.end)
      );
    ranges
      .filter((range) => range.start <= endValue && range.end >= startValue)
      .forEach((range) => periodWarnings.push(`This period overlaps ${range.name}.`));
    const previous = ranges
      .filter((range) => range.end < startValue)
      .sort((left, right) => right.end.getTime() - left.end.getTime())[0];
    if (previous && startValue.getTime() - previous.end.getTime() > DAY_MS) {
      periodWarnings.push(`There is a gap between ${previous.name} and this period.`);
    }
    const next = ranges
      .filter((range) => range.start > endValue)
      .sort((left, right) => left.start.getTime() - right.start.getTime())[0];
    if (next && next.start.getTime() - endValue.getTime() > DAY_MS) {
      periodWarnings.push(`There is a gap between this period and ${next.name}.`);
    }
  }

  const handlePayPeriod = async (data: any) => {
    try {
      setLoading(true);

      const payload = {
        ...data,
        startDate: toUtcDate(data.startDate),
        endDate: toUtcDate(data.endDate),
        deadLine: toUtcDate(data.deadLine),
        dayOfTheMonth: Number(data.dayOfTheMonth),
        organizationId
      };
      // console.log("Payload with UTC dates:", payload);

      const response = await ApiFetcher.post(
        "/payperiods/create-pay-period",
        payload
      );

      toast.success(
        response?.data?.data?.message || "Pay period created successfully"
      );

      return router.push("/dashboard/payroll/payperiod");
      // return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error creating a pay period.";
      console.log(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const mutation = useMutation({
    mutationFn: handlePayPeriod,
    onSuccess: () => {
      queryClient.invalidateQueries();
      reset();
    }
  });

  const onHandlerSubmit = (data: any) => {
    try {
      mutation.mutateAsync(data);
      // mutation.reset();
      // reset();
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error submitting a pay period.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  return (
    <main className="relative mt-20 grid grid-cols-1 gap-4 overflow-x-hidden p-4 lg:grid-cols-10 lg:p-6">
      {closeRightSidebar && (
        <div className="z-50 fixed top-20 right-0 hidden lg:block">
          <SquareChevronLeft
            onClick={() => setCloseRightSidebar(false)}
            className="cursor-pointer text-secondary transition duration-300 ease-linear mr-4"
            size={40}
          />
        </div>
      )}
      <div
        className={`w-full ${
          closeRightSidebar ? "lg:col-span-10" : "col-span-10 lg:col-span-7 "
        }`}
      >
        <nav className="flex mb-6" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1 md:space-x-3">
            <li className="inline-flex items-center">
              <Link
                href="/dashboard/payroll"
                className="text-sm text-blue-700 hover:underline"
              >
                Payroll
              </Link>
            </li>
            <li>
              <ChevronRightIcon className="w-4 h-4 text-gray-400" />
            </li>
            <li>
              <span className="text-sm font-medium text-gray-500">
                Payroll Settings
              </span>
            </li>
          </ol>
        </nav>

        <div>
          <h1 className="text-[40px] text-primary leading-[52px] font-semibold">
            Pay Period
          </h1>
          <p className="text-sm text-[#757575] mb-[24px]">
            Setup and customise your pay-period.
          </p>
        </div>

        <form
          onSubmit={handleSubmit(onHandlerSubmit)}
          className="bg-white border border-[#D9D9D9] p-6 rounded-lg mb-4"
        >
          <span className="text-secondary pb-2 border-b-[1.5px] border-b-secondary font-bold ">
            Pay Payperiod
          </span>

          <div className="space-y-6 mt-8">
            <div>
              <label
                htmlFor="dayOfMonth"
                className="block mb-2 text-sm font-bold text-[#1E1E1E]"
              >
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span>Day of the month</span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>
                      Select the day employees should receive their salary each
                      month.
                    </p>
                  </TooltipContent>
                </Tooltip>
              </label>

              <p className="text-sm text-[#63666A] mb-1">
                This is the day of the month you would like your employees to be
                paid.
              </p>
              <input
                type="number"
                {...register("dayOfTheMonth")}
                className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                placeholder="26"
                maxLength={2}
                required
              />
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors.dayOfTheMonth?.message}
              </p>
            </div>

            <div>
              <label
                htmlFor="startDate"
                className="block mb-2 text-sm font-bold text-[#1E1E1E]"
              >
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span>Start date</span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Enter the date when this payroll cycle begins.</p>
                  </TooltipContent>
                </Tooltip>
              </label>
              <p className="text-sm text-[#63666A] mb-1">Payroll start date</p>
              <input
                type="date"
                {...register("startDate", {
                  onChange: (event: React.ChangeEvent<HTMLInputElement>) => {
                    const start = parseDate(event.target.value);
                    if (start && !endDateEdited) {
                      setValue("endDate", toInputDate(lastDayOfMonth(start)) as unknown as Date, {
                        shouldValidate: true
                      });
                      trigger("deadLine");
                    }
                  }
                })}
                className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                required
              />
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors.startDate?.message}
              </p>
            </div>

            <div>
              <label
                htmlFor="deadlineToRunPayroll"
                className="block mb-2 text-sm font-bold text-[#1E1E1E]"
              >
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span>Deadline to run payroll</span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>
                      Specify how many days before payday payroll must be
                      processed.
                    </p>
                  </TooltipContent>
                </Tooltip>
              </label>
              <p className="text-sm text-[#63666A] mb-1">
                The number of days before the pay date by which payroll must be
                processed.
              </p>
              <input
                type="date"
                {...register("deadLine")}
                className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                placeholder="5"
                required
              />
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors.deadLine?.message}
              </p>
            </div>

            <div>
              <label
                htmlFor="endDate"
                className="block mb-2 text-sm font-bold text-[#1E1E1E]"
              >
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span>End date</span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Enter the date when this payroll cycle ends.</p>
                  </TooltipContent>
                </Tooltip>
              </label>
              <p className="text-sm text-[#63666A] mb-1">Payroll end date</p>
              <input
                type="date"
                {...register("endDate", {
                  onChange: () => {
                    setEndDateEdited(true);
                    trigger("deadLine");
                  }
                })}
                className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                required
              />
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors.endDate?.message}
              </p>
              {periodWarnings.length > 0 && (
                <ul
                  role="status"
                  className="mt-2 list-disc space-y-1 rounded-[4px] border border-amber-200 bg-amber-50 p-3 pl-6 text-xs text-amber-900"
                >
                  {periodWarnings.map((warning) => (
                    <li key={warning}>{warning}</li>
                  ))}
                </ul>
              )}
            </div>

            <div className="flex justify-end">
              <CustomButton
                type="submit"
                disabled={loading || !isValid}
                className={`disabled:bg-secondary disabled:bg-opacity-60 text-white text-sm bg-secondary py-2.5 px-12`}
              >
                {loading ? "Creating..." : "Create pay period"}
              </CustomButton>
            </div>
          </div>
        </form>
      </div>

      <div className={`${closeRightSidebar ? "hidden" : "block col-span-10 lg:col-span-3"}`}>
        <div className="h-screen">
          <RightPayrollSettings
            setCloseRightSidebar={setCloseRightSidebar}
            closeRightSidebar={closeRightSidebar}
          />
        </div>
      </div>
    </main>
  );
};

export default Settings;
