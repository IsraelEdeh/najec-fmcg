"use client";

import Allowances from "@/components/Taxes/Allowances";
import Deductions from "@/components/Taxes/Deductions";
import RightsideTaxes from "@/components/Taxes/RightsideTaxes";
import CustomButton from "@/components/Elements/CustomButton";
import { SquareChevronLeft, X } from "lucide-react";
import Link from "next/link";
import React, { useState } from "react";
import {
  Dialog,
  DialogHeader,
  DialogContent,
  DialogTitle
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import ApiFetcher from "@/components/Utils/api";
import { toast } from "react-toastify";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import Relief from "@/components/Taxes/Relief";
import useAllowances from "@/hooks/Custom-hook/useAllowances";
import useDeductions from "@/hooks/Custom-hook/useDeductions";
import useReliefs from "@/hooks/Custom-hook/useReliefs";
import { validateAllowance } from "@/lib/allowance-rules";

const schema = yup.object().shape({
  name: yup
    .string()
    .min(3, "Name must be at least 3 characters")
    .required("Name is required"),
  taxRelief: yup
    .string()
    .matches(/^\d+(\.\d{1,2})?$/, "Tax relief must be a valid decimal number"),
  amountType: yup.string(),
  frequency: yup.string(),
  timesPayable: yup.string(),
  isNHF: yup.boolean().optional(),
  isVoluntaryPension: yup.boolean().optional(),
  isProrated: yup.boolean().optional(),
  others: yup.boolean().optional()
});

const Taxes = () => {
  const queryClient = useQueryClient();
  const [currentTab, setCurrentTab] = useState("allowances");
  const [openAllowanceItem, setOpenAllowanceItem] = useState<boolean>(false);
  const [openDeductionItem, setOpenDeductionItem] = useState<boolean>(false);
  const [closeRightSidebar, setCloseRightSidebar] = useState<boolean>(false);
  const [openReliefItem, setOpenReliefItem] = useState<boolean>(false);
  const [isTaxable, setIsTaxable] = useState(false);
  const [isPension, setIsPension] = useState(false);
  const [isDeductionTaxable, setIsDeductionTaxable] = useState(false);
  const [isDeductionPension, setIsDeductionPension] = useState(false);
  const [includeAllowanceInGrossPay, setIncludeAllowanceInGrossPay] =
    useState(true);
  const [isAllowanceNSITF, setIsAllowanceNSITF] = useState(false);
  const [isAllowanceEmployerTaxBorne, setIsAllowanceEmployerTaxBorne] =
    useState(false);
  const [isAllowanceGrossUp, setIsAllowanceGrossUp] = useState(false);
  const [allowanceEmployerShare, setAllowanceEmployerShare] = useState("100");
  const [allowancePaymentMonth, setAllowancePaymentMonth] = useState("");
  const [allowanceTrueUpOnChange, setAllowanceTrueUpOnChange] = useState(false);

  const { allowances, loadingAllowances } = useAllowances();
  const { deductions, loadingDeductions } = useDeductions();
  const { reliefs, loadingReliefs } = useReliefs();

  const handleTaxableChange = (event: any) => {
    const taxable = event.target.checked;
    setIsTaxable(taxable);
    if (taxable) setIsAllowanceNSITF(true);
    if (!taxable) {
      setIsAllowanceEmployerTaxBorne(false);
      setIsAllowanceGrossUp(false);
    }
  };

  const handlePensionChange = (event: any) => {
    setIsPension(event.target.checked);
  };

  const user: any = useSelector((state: RootState) => state.getUser.user);

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const handleTabChange = (tab: string) => {
    setCurrentTab(tab.toLowerCase());
  };

  const renderTabContent = () => {
    switch (currentTab) {
      case "allowances":
        return <Allowances />;
      case "deductions":
        return <Deductions />;
      case "relief":
        return <Relief />;
      default:
        return null;
    }
  };

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, touchedFields },
    watch
  } = useForm({ resolver: yupResolver(schema) });

  const allowanceNameChecked = watch("others");
  // console.log("check check", allowanceNameChecked);

  const handleSaveAllowance = async (data: any) => {
    try {
      const ruleError = validateAllowance({
        name: String(data.name ?? ""),
        isTaxable,
        isGrossUp: isAllowanceGrossUp,
        trueUpOnChange: allowanceTrueUpOnChange,
        paymentMonth: allowancePaymentMonth,
        isEmployerTaxBorne: isAllowanceEmployerTaxBorne,
        employerTaxSharePercent: allowanceEmployerShare,
        timesPayable: data.timesPayable
      });
      if (ruleError) {
        toast.error(ruleError);
        return;
      }

      const payload = {
        organizationId: user?.userOrganizations?.find(
          (item: any) => item.isCurrentLoggedInOrganization
        )?.organizationId,
        payComponents: [
          {
            name: data.name,
            isNHF: data.isNHF,
            isTaxable: Boolean(isTaxable),
            isDeduction: false,
            isPension: Boolean(isPension),
            // isVoluntaryPension: data.isVoluntaryPension,
            isProrated: data.isProrated,
            taxRelief: 0,
            amountType: 0, // Assuming amountType is always 0 for now
            frequency: 0, // Assuming frequency is always 0 for now,
            noOfTimesPayable: Number(data.timesPayable),
            isBasisOnly: !includeAllowanceInGrossPay,
            isNSITF: isAllowanceNSITF,
            isEmployerTaxBorne: isAllowanceEmployerTaxBorne,
            employerTaxSharePercent: isAllowanceEmployerTaxBorne
              ? Number(allowanceEmployerShare || 100)
              : undefined,
            isGrossUp:
              isAllowanceGrossUp &&
              includeAllowanceInGrossPay &&
              !allowancePaymentMonth,
            paymentMonth: allowancePaymentMonth
              ? Number(allowancePaymentMonth)
              : undefined,
            trueUpOnChange: allowanceTrueUpOnChange
          }
        ]
      };

      const response = await ApiFetcher.post(
        "/tax/create-allowance-items",
        payload
      );

      setOpenAllowanceItem(false);
      toast.success("Created successfully");
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding allowance items.";
      console.log(errorMessage);
      toast.error(errorMessage);
    } finally {
      // setLoading(false);
    }
  };

  const handleSaveDeduction = async (data: any) => {
    try {
      const payload = {
        organizationId: user?.userOrganizations?.find(
          (item: any) => item.isCurrentLoggedInOrganization
        )?.organizationId,
        payComponents: [
          {
            name: data.name,
            isNHF: data.isNHF,
            isTaxable: Boolean(isDeductionTaxable),
            isVoluntaryPension: data.isVoluntaryPension,
            isDeduction: true,
            isPension: Boolean(isDeductionPension),
            taxRelief: 0,
            amountType: 0, // Assuming amountType is always 0 for now
            frequency:
              // Number(data.frequency)
              0, // Assuming frequency is always 0 for now
            noOfTimesPayable: Number(data.timesPayable)
          }
        ]
      };

      const response = await ApiFetcher.post(
        "/tax/create-deductions-items",
        payload
      );

      setOpenDeductionItem(false);
      toast.success("Created successfully");
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding deduction items.";
      console.log(errorMessage);
      toast.error(errorMessage);
    } finally {
      // setLoading(false);
    }
  };

  const handleSaveRelief = async (data: any) => {
    try {
      const payload = {
        organizationId: user?.userOrganizations?.find(
          (item: any) => item.isCurrentLoggedInOrganization
        )?.organizationId,
        payComponents: [
          {
            name: data.name,
            isNHF: false,
            isVoluntaryPension: data.isVoluntaryPension,
            // isTaxable: Boolean(isDeductionTaxable),
            isTaxable: false,
            isDeduction: false,
            isRelief: true,
            // isPension: Boolean(isDeductionPension),
            isPension: false,
            taxRelief: 0,
            amountType: 0, // Assuming amountType is always 0 for now
            frequency:
              // Number(data.frequency)
              0, // Assuming frequency is always 0 for now,
            noOfTimesPayable: Number(data.timesPayable)
          }
        ]
      };

      const response = await ApiFetcher.post(
        "/tax/create-relief-items",
        payload
      );

      setOpenReliefItem(false);
      toast.success("Created successfully");
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding deduction items.";
      console.log(errorMessage);
      toast.error(errorMessage);
    } finally {
      // setLoading(false);
    }
  };

  const mutation = useMutation({
    mutationFn: handleSaveAllowance,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const mutationDeduction = useMutation({
    mutationFn: handleSaveDeduction,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onHandlerSubmit = (data: any) => {
    mutation.mutateAsync(data);
    mutation.reset();
    reset();
  };

  const onDeductionHandlerSubmit = (data: any) => {
    mutationDeduction.mutateAsync(data);
    mutation.reset();
    reset();
  };

  const mutationRelief = useMutation({
    mutationFn: handleSaveRelief,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onReliefHandlerSubmit = (data: any) => {
    mutationRelief.mutateAsync(data);
    mutation.reset();
    reset();
  };

  return (
    <>
      <Dialog open={openAllowanceItem} onOpenChange={setOpenAllowanceItem}>
        <main className="relative grid w-full grid-cols-1 gap-4 overflow-x-hidden p-3 lg:grid-cols-10 lg:p-4">
          {/* {closeRightSidebar && (
            <div className="z-40 fixed top-20 right-0 hidden lg:block">
              <SquareChevronLeft
                onClick={() => setCloseRightSidebar(false)}
                className="cursor-pointer text-secondary transition duration-300 ease-linear mr-4"
                size={40}
              />
            </div>
          )} */}

          <div
            // className={`${
            //   closeRightSidebar ? "col-span-10" : "col-span-7"
            // } block `}

            className="col-span-10 block"
          >
            <nav aria-label="Breadcrumb" className="flex mb-[24px]">
              <ul className="inline-flex text-primary text-sm items-center">
                <li>
                  <Link href="">Pay Component Setup</Link>
                </li>
              </ul>
            </nav>
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-bold mb-[10px]">Pay components</h1>
                <p className="mb-4">
                  Handle your tax configurations from one place
                </p>
              </div>

              {(activeRole?.includes("Admin") ||
                activeRole?.includes("Initiator")) && (
                <>
                  {currentTab === "allowances" && (
                    <>
                      <CustomButton
                        onClick={() => setOpenAllowanceItem(true)}
                        className="py-2 px-4 text-xs bg-primary text-white"
                      >
                        Add Allowance item
                      </CustomButton>
                    </>
                  )}
                </>
              )}

              <DialogContent className="bg-white">
                <DialogHeader>
                  <DialogTitle className="text-xl">
                    Create allowance items
                  </DialogTitle>

                  <form
                    onSubmit={handleSubmit(onHandlerSubmit)}
                    className="pt-3"
                  >
                    <div className="grid grid-cols-2 gap-4">
                      <div className="col-span-2">
                        {allowanceNameChecked ? (
                          <input
                            className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                            type="text"
                            placeholder="Allowance title"
                            {...register("name", {
                              required: true
                            })}
                          />
                        ) : (
                          <select
                            className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                            {...register("name", {
                              required: true
                            })}
                          >
                            <option value="">Select allowance</option>
                            {loadingAllowances
                              ? "loading"
                              : allowances?.data?.map((allowance: any) => (
                                  <option key={allowance} value={allowance}>
                                    {allowance}
                                  </option>
                                ))}
                          </select>
                        )}
                      </div>

                      <div className="col-span-2 text-sm">
                        <input
                          type="checkbox"
                          id="others"
                          {...register("others")}
                        />
                        <span className="pl-1">Add other allowances</span>
                      </div>

                      <div className="col-span-2">
                        <input
                          className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                          type="number"
                          placeholder="Number of months payable"
                          {...register("timesPayable")}
                          required
                        />
                      </div>

                      <div className="col-span-2 flex items-start gap-2">
                        <input
                          type="checkbox"
                          checked={includeAllowanceInGrossPay}
                          onChange={(e) =>
                            setIncludeAllowanceInGrossPay(e.target.checked)
                          }
                        />
                        <div>
                          <span>Include in gross pay</span>
                          {!includeAllowanceInGrossPay && (
                            <p className="text-xs text-gray-600">
                              Not paid. Only counts towards the ticked items
                              (taxable, pensionable, NHF, NSITF).
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="col-span-2 flex items-center">
                        <input
                          type="checkbox"
                          checked={isAllowanceNSITF}
                          onChange={(e) => setIsAllowanceNSITF(e.target.checked)}
                        />
                        <span className="pl-1">NSITF</span>
                      </div>

                      <div className="col-span-2 flex items-center">
                        <input
                          type="checkbox"
                          checked={isAllowanceEmployerTaxBorne}
                          disabled={!isTaxable}
                          onChange={(e) =>
                            setIsAllowanceEmployerTaxBorne(e.target.checked)
                          }
                        />
                        <span className="pl-1">Employer tax borne</span>
                      </div>

                      {isAllowanceEmployerTaxBorne && (
                        <div className="col-span-2">
                          <label className="block text-sm mb-1">
                            Employer share %
                          </label>
                          <input
                            className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                            type="number"
                            min={0}
                            max={100}
                            placeholder="100"
                            value={allowanceEmployerShare}
                            onChange={(e) =>
                              setAllowanceEmployerShare(e.target.value)
                            }
                          />
                        </div>
                      )}

                      {isTaxable &&
                        includeAllowanceInGrossPay &&
                        !allowancePaymentMonth && (
                          <div className="col-span-2 flex items-center">
                            <input
                              type="checkbox"
                              checked={isAllowanceGrossUp}
                              onChange={(e) =>
                                setIsAllowanceGrossUp(e.target.checked)
                              }
                            />
                            <span className="pl-1">Gross up</span>
                          </div>
                        )}

                      <div className="col-span-2">
                        <label className="block text-sm mb-1">
                          Payment month
                        </label>
                        <select
                          className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                          value={allowancePaymentMonth}
                          onChange={(e) => setAllowancePaymentMonth(e.target.value)}
                        >
                          <option value="">None</option>
                          {Array.from({ length: 12 }, (_, index) => (
                            <option key={index + 1} value={index + 1}>
                              {new Date(2000, index, 1).toLocaleString("en", {
                                month: "long"
                              })}
                            </option>
                          ))}
                        </select>
                      </div>

                      {!!allowancePaymentMonth && (
                        <div className="col-span-2 flex items-center">
                          <input
                            type="checkbox"
                            checked={allowanceTrueUpOnChange}
                            onChange={(e) =>
                              setAllowanceTrueUpOnChange(e.target.checked)
                            }
                          />
                          <span className="pl-1">Top up on change</span>
                        </div>
                      )}

                      <div className="col-span-2">
                        <input
                          type="checkbox"
                          id="isNHF"
                          {...register("isNHF")}
                        />
                        <span className="pl-1">
                          {" "}
                          Is this item liable to NHF?
                        </span>
                      </div>

                      <div className="col-span-2">
                        <input
                          type="checkbox"
                          id="isProrated"
                          {...register("isProrated")}
                        />
                        <span className="pl-1">
                          {" "}
                          is this item liable to proration?
                        </span>
                      </div>

                      <div className="col-span-2">
                        <input
                          type="checkbox"
                          id="isTaxable"
                          name="isTaxable"
                          value="true"
                          checked={isTaxable}
                          onChange={(e) => handleTaxableChange(e)}
                        />
                        <span className="pl-1">
                          {" "}
                          Is this allowance item taxable
                        </span>
                      </div>

                      <div className="col-span-2">
                        <input
                          type="checkbox"
                          id="isPension"
                          name="isPension"
                          value="true"
                          checked={isPension}
                          onChange={(e) => handlePensionChange(e)}
                        />
                        <span className="pl-1">
                          Is this allowance item pensionable
                        </span>
                      </div>

                      <div className="col-span-2">
                        <button className="w-full bg-secondary text-white text-center rounded-[4px] py-2.5 px-3">
                          Save allowance
                        </button>
                      </div>
                    </div>
                  </form>
                </DialogHeader>
              </DialogContent>

              {(activeRole?.includes("Admin") ||
                activeRole?.includes("Initiator")) && (
                <>
                  {currentTab === "deductions" && (
                    <CustomButton
                      onClick={() => setOpenDeductionItem(true)}
                      className="py-2 px-4 text-xs bg-primary text-white"
                    >
                      Add deduction item
                    </CustomButton>
                  )}
                </>
              )}

              {(activeRole?.includes("Admin") ||
                activeRole?.includes("Initiator")) && (
                <>
                  {currentTab === "relief" && (
                    <CustomButton
                      onClick={() => setOpenReliefItem(true)}
                      className="py-2 px-4 text-xs bg-primary text-white"
                    >
                      Add relief item
                    </CustomButton>
                  )}
                </>
              )}
            </div>
            <div className="bg-white border border-gray-200 p-4 rounded mb-4">
              <div className="flex space-x-4 mb-4">
                {["Allowances", "Deductions", "Relief"].map((tab, index) => (
                  <div
                    key={index}
                    onClick={() => handleTabChange(tab)}
                    className={` border-b-2 ${
                      currentTab === tab.toLowerCase()
                        ? "border-b-secondary text-primary"
                        : "border-transparent text-[#63666A]"
                    } cursor-pointer`}
                  >
                    {tab}
                  </div>
                ))}
              </div>

              <div className="border border-[#63666A] bg-gray-100 p-4 rounded mb-4">
                <div className="flex justify-between mb-[8px]">
                  <h2 className="text-[16px] leading-[24px] font-bold ">
                    How does this work
                  </h2>
                  {/* <X size={24} className="text-[#63666A] cursor-pointer" /> */}
                </div>

                <ol className="list-decimal list-inside text-sm text-[#404040]">
                  <li>
                    Configure allowances and deductions to reflect those
                    provided by your company
                  </li>
                  <li>Download payschedule template</li>
                  <li>Configure payschedule</li>
                </ol>
              </div>

              {renderTabContent()}
            </div>
          </div>

          {/* <div
            className={`${closeRightSidebar ? "hidden" : "col-span-10 block lg:col-span-3"}`}
          >
            <RightsideTaxes
              setCloseRightSidebar={setCloseRightSidebar}
              closeRightSidebar={closeRightSidebar}
            />
          </div> */}
        </main>
      </Dialog>

      <Dialog open={openDeductionItem} onOpenChange={setOpenDeductionItem}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle className="text-xl">
              Create Deductions items
            </DialogTitle>

            <form
              onSubmit={handleSubmit(onDeductionHandlerSubmit)}
              className="pt-3"
            >
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  {allowanceNameChecked ? (
                    <input
                      className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                      type="text"
                      placeholder="Deduction title"
                      {...register("name", {
                        required: true
                      })}
                    />
                  ) : (
                    <select
                      className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                      {...register("name", {
                        required: true
                      })}
                    >
                      <option value="">Select deduction</option>
                      {loadingDeductions
                        ? "loading"
                        : deductions?.data?.map((item: any) => (
                            <option key={item} value={item}>
                              {item}
                            </option>
                          ))}
                    </select>
                  )}
                </div>

                <div className="col-span-2 text-sm">
                  <input type="checkbox" id="others" {...register("others")} />
                  <span className="pl-1">Add other deductions</span>
                </div>

                <div className="col-span-2">
                  <input
                    className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                    type="number"
                    placeholder="Number of months payable"
                    {...register("timesPayable")}
                    required
                  />
                </div>

                <div className="col-span-2">
                  <input
                    type="checkbox"
                    id="isVoluntaryPension"
                    {...register("isVoluntaryPension")}
                  />
                  <span className="pl-1">
                    {" "}
                    Is this a Voluntary Pension item?
                  </span>
                </div>

                <div className="col-span-2">
                  <button className="w-full bg-secondary text-white text-center rounded-[4px] py-2.5 px-3">
                    Save deductions
                  </button>
                </div>
              </div>
            </form>
          </DialogHeader>
        </DialogContent>
      </Dialog>

      <Dialog open={openReliefItem} onOpenChange={setOpenReliefItem}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle className="text-xl">Create Relief items</DialogTitle>

            <form
              onSubmit={handleSubmit(onReliefHandlerSubmit)}
              className="pt-3"
            >
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  {allowanceNameChecked ? (
                    <input
                      className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                      type="text"
                      placeholder="Relief title"
                      {...register("name", {
                        required: true
                      })}
                    />
                  ) : (
                    <select
                      className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                      {...register("name", {
                        required: true
                      })}
                    >
                      <option value="">Select relief</option>
                      {loadingReliefs
                        ? "loading"
                        : reliefs?.data?.map((item: any) => (
                            <option key={item} value={item}>
                              {item}
                            </option>
                          ))}
                    </select>
                  )}
                </div>

                <div className="col-span-2 text-sm">
                  <input type="checkbox" id="others" {...register("others")} />
                  <span className="pl-1">Add other relief</span>
                </div>

                <div className="col-span-2">
                  <input
                    className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                    type="number"
                    placeholder="Number of months payable"
                    {...register("timesPayable")}
                    required
                  />
                </div>

                <div className="col-span-2">
                  <input
                    type="checkbox"
                    id="isVoluntaryPension"
                    {...register("isVoluntaryPension")}
                  />
                  <span className="pl-1">
                    {" "}
                    Is this a Voluntary Pension item?
                  </span>
                </div>

                <div className="col-span-2">
                  <button className="w-full bg-secondary text-white text-center rounded-[4px] py-2.5 px-3">
                    Save relief item
                  </button>
                </div>
              </div>
            </form>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default Taxes;
