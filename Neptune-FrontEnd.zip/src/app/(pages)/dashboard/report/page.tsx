"use client";

import EmptyRecord from "@/components/dashboard/EmptyRecord";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import ApiFetcher from "@/components/Utils/api";
import { useQuery } from "@tanstack/react-query";
import React, { useState } from "react";
import { MdOutlineArrowDropDown, MdOutlineFileDownload } from "react-icons/md";
import { RiArrowLeftSFill, RiArrowRightSFill } from "react-icons/ri";
import { TbLoader3 } from "react-icons/tb";
import { toast } from "react-toastify";
import RunPicker from "@/components/Payroll/Runs/RunPicker";
import { buildQuery, withRunSuffix } from "@/lib/payroll-api";
import { formatPageRange } from "@/lib/utils";
import { displayValue, formatDisplayDate, genderLabel } from "@/lib/employee-mappers";
import type { Id } from "@/types/payroll";
import {
  hasSpecialComponents,
  orderAllowanceColumns,
  parseComponentName
} from "@/lib/report-components";
import {
  BasisOnlyGroupRow,
  ComponentHeaderCell,
  ComponentLegend,
  basisOnlyCellClassName
} from "@/components/Reports/ComponentHeaderCell";

// Statutory reports combine the Regular payroll with approved off-cycle payrolls on the server.
const RUN_SPECIFIC_REPORTS = new Set(["client", "bank", "master-payroll"]);

// Safely format a Naira amount. Returns "N/A" instead of crashing when the
// API sends back null / undefined / non-numeric values.
const formatNaira = (value?: number | null) =>
  value === null || value === undefined || isNaN(Number(value))
    ? "N/A"
    : `₦${Number(value).toLocaleString("en-US")}`;

const SUPPORTED_REPORT_EXPORTS = new Set([
  "payee",
  "nsitf",
  "nhf",
  "pension",
  "client",
  "bank",
  "master-payroll"
]);

const getSafeReportExportName = (value: string, fallback: string) => {
  const safeValue = SUPPORTED_REPORT_EXPORTS.has(value) ? value : fallback;
  return `${safeValue.replace(/[^a-z0-9-]+/gi, "-").replace(/-+/g, "-")}-report.xlsx`;
};

const Report = () => {
  const [loading] = useState<boolean>(false);
  const [loadingReport, setLoadingReport] = useState<boolean>(false);
  const [reportName, setReportName] = useState<string>("payee");
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [maxPage, setMaxPage] = useState<number>(10);
  const [selectedPayPeriod, setSelectedPayPeriod] = useState<string>("");
  const [selectedRun, setSelectedRun] = useState<{ payrollId?: Id; runName?: string | null }>({});

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setReportName(e.target.value);
    setCurrentPage(1);
    setSelectedRun({});
  };

  const getPayperiods = async () => {
    try {
      const response = await ApiFetcher.get("/payperiods/get-all-pay-period");

      // Auto-select the first pay period so the default report can load.
      setSelectedPayPeriod((prev) => prev || response.data.data[0]?.name || "");

      return response;
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error fetching pay periods";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  const {
    data: payperiods,
    isPending: pendingPayperiods,
    error
  } = useQuery({
    queryKey: ["fetchAllPayperiods"],
    queryFn: getPayperiods
  });

  const isRunSpecificReport = RUN_SPECIFIC_REPORTS.has(reportName);
  const reportPayrollId = isRunSpecificReport ? selectedRun.payrollId : undefined;
  const reportRunName = isRunSpecificReport ? selectedRun.runName : undefined;
  const selectedPayPeriodId = payperiods?.data?.data?.find(
    (period: any) => period?.name === selectedPayPeriod
  )?.id;

  const runReportParams = (name: string) => {
    if (!RUN_SPECIFIC_REPORTS.has(name)) return "";
    const query = buildQuery({ payPeriodId: selectedPayPeriodId, payrollId: reportPayrollId });
    return query ? `&${query.slice(1)}` : "";
  };

  const getReport = async (name: string, page: number, id: string) => {
    try {
      const response = await ApiFetcher.get(
        `/report/get-${name}-report?PageNumber=${page}&PageSize=${maxPage}&payPeriodName=${encodeURIComponent(id)}${runReportParams(name)}`
      );

      // console.log("master report::", response);
      return response;
    } catch (error: any) {
      // Use optional chaining everywhere so the catch block can't throw a
      // second (uncaught) error when error.response is undefined.
      const errorMessage =
        error?.response?.data?.message ||
        error?.message ||
        "Error fetching report";
      console.log(errorMessage);
      toast.error(errorMessage);
      // Re-throw so react-query knows the request failed and isError flips on.
      throw error;
    }
  };

  const { isPending, data, isError } = useQuery({
    queryKey: [
      "reportByName",
      reportName,
      currentPage,
      maxPage,
      selectedPayPeriod,
      selectedPayPeriodId ?? null,
      reportPayrollId ?? null
    ],
    // Keep rows only while paging the same report, period and run; other changes start fresh.
    placeholderData: (previous, previousQuery) => {
      const key = previousQuery?.queryKey;
      return key?.[1] === reportName &&
        key?.[3] === maxPage &&
        key?.[4] === selectedPayPeriod &&
        key?.[6] === (reportPayrollId ?? null)
        ? previous
        : undefined;
    },
    queryFn: () => getReport(reportName, currentPage, selectedPayPeriod),
    // Only fetch a report once a pay period has been selected. This prevents
    // the request from firing on mount with an empty payPeriodName.
    enabled: !!selectedPayPeriod
  });

  const payrollData = Array.isArray(data?.data?.data) ? data.data.data : [];

  // console.log("payrollData::", data);

  // Get unique allowance names
  const allowanceHeaders = [
    ...new Set(
      payrollData.flatMap(
        (item: any) => item?.allowances?.map((a: any) => a?.name) ?? []
      )
    )
  ];

  // Get unique deduction names
  const deductionHeaders = [
    ...new Set(
      payrollData.flatMap(
        (item: any) => item?.deductions?.map((d: any) => d?.name) ?? []
      )
    )
  ];

  // Get unique relief names
  const reliefHeaders = [
    ...new Set(
      payrollData.flatMap(
        (item: any) => item?.reliefs?.map((r: any) => r?.name) ?? []
      )
    )
  ];

  const { paid: paidAllowanceHeaders, basisOnly: basisOnlyHeaders } =
    orderAllowanceColumns(allowanceHeaders.filter(Boolean) as string[]);
  const showComponentLegend = hasSpecialComponents(
    [...allowanceHeaders, ...deductionHeaders, ...reliefHeaders].filter(Boolean) as string[]
  );

  // Totals always come from the response; basis-only columns intentionally exceed totalAllowanceValue.
  const componentCell = (items: any[] | undefined, name: string) => {
    const found = items?.find((component: any) => component?.name === name);
    const muted =
      parseComponentName(name).kind === "basisOnly" ? basisOnlyCellClassName : "";
    return (
      <td className={`text-left p-4 text-sm font-normal ${muted}`} key={name}>
        {formatNaira(found?.amount)}
      </td>
    );
  };

  const handleExportMasterReport = async () => {
    if (!selectedPayPeriod) return;
    try {
      setLoadingReport(true);
      const response = await ApiFetcher.get(
        `/report/export-master-payroll-report?PageSize=1000&payPeriodName=${encodeURIComponent(selectedPayPeriod)}${runReportParams("master-payroll")}`,
        {
          responseType: "blob"
        }
      );

      const blob = new Blob([response.data], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${withRunSuffix("master-report", reportRunName)}.xlsx`;
      a.rel = "noopener noreferrer";
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      toast.success("Export done successfully");
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error exporting master report";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoadingReport(false);
    }
  };

  const handleExportReportByName = async (reportName: string) => {
    if (!selectedPayPeriod) return;
    try {
      setLoadingReport(true);
      const response = await ApiFetcher.get(
        `/report/export-${reportName}-report?PageSize=1000&payPeriodName=${encodeURIComponent(selectedPayPeriod)}${runReportParams(reportName)}`,
        { responseType: "blob" }
      );

      console.log("export report::", response);

      const blob = new Blob([response.data], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      const sanitizedReportName = getSafeReportExportName(
        reportName,
        "master-payroll"
      );
      a.download = reportRunName
        ? sanitizedReportName.replace(/\.xlsx$/, `${withRunSuffix("", reportRunName)}.xlsx`)
        : sanitizedReportName;
      a.rel = "noopener noreferrer";
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      toast.success("Report downloaded successfully");

      return response;
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message ||
        error?.message ||
        `Error exporting ${reportName} report`;
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoadingReport(false);
    }
  };

  // Controls (report type / export) stay locked until a pay period is ready.
  const controlsDisabled = !selectedPayPeriod || pendingPayperiods;

  return (
    <main className=" grid grid-cols-1 gap-4 overflow-x-hidden px-4 py-6 lg:grid-cols-10">
      <div className="col-span-10">
        <nav className="flex" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1 md:space-x-3">
            <li className="inline-flex items-center">
              <p className="text-sm text-primary hover:underline">Report</p>
            </li>
          </ol>
        </nav>

        <div className="flex justify-between items-center">
          <div className="mb-[24px] mt-4">
            <h1 className="text-[40px] leading-[52px] font-semibold">
              All reports
            </h1>
            <p className="text-sm mt-2 text-[#1E1E1E]">
              See all reports on Neptune
            </p>
          </div>

          <div>
            <select
              value={reportName}
              onChange={handleChange}
              disabled={controlsDisabled}
              title={
                controlsDisabled ? "Select a pay period first" : "Select report"
              }
              className="bg-primary hover:bg-secondary text-white rounded-[4px] py-2.5 px-3 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <option value="payee">PAYE Report</option>
              <option value="nsitf">NSITF Report</option>
              <option value="nhf">NHF Report</option>
              <option value="pension">PENSION Report</option>
              <option value="client">CLIENT Report</option>
              <option value="bank">BANK Report</option>
              <option value="master-payroll">MASTER Report</option>
            </select>
          </div>
        </div>
      </div>

      <div className="col-span-10 flex justify-between items-center mb-4">
        <div className="flex flex-col space-y-2">
          <select
            aria-label="Pay period"
            value={selectedPayPeriod}
            onChange={(e) => {
              setSelectedPayPeriod(e.target.value);
              setCurrentPage(1);
              setSelectedRun({});
            }}
            className="bg-white border border-[#E9EAEC] rounded-[4px] py-2.5 px-3"
          >
            <option value="">Select Payperiod</option>
            {pendingPayperiods ? (
              <option>Loading pay periods...</option>
            ) : error ? (
              <option>Error loading pay periods</option>
            ) : payperiods?.data?.data?.length === 0 ? (
              <option>No pay period exists</option>
            ) : (
              payperiods?.data?.data?.map((period: any) => (
                <option key={period?.id} value={period?.name}>
                  {period?.name}
                </option>
              ))
            )}
          </select>
          {isRunSpecificReport ? (
            <RunPicker
              payPeriodId={selectedPayPeriodId}
              value={selectedRun.payrollId}
              onChange={(payrollId, run) => {
                setSelectedRun({ payrollId, runName: payrollId ? run?.runName : undefined });
                setCurrentPage(1);
              }}
            />
          ) : (
            selectedPayPeriod && (
              <p className="text-xs text-[#63666A] pb-1">
                Includes the regular payroll and approved off-cycle payrolls for this month.
              </p>
            )
          )}
        </div>

        <div className="flex space-x-3 items-center">
          {reportName !== "master-payroll" ? (
            loading ? (
              <TbLoader3 className="text-primary animate-spin w-6 h-6" />
            ) : (
              <button
                disabled={loadingReport || controlsDisabled}
                onClick={() => handleExportReportByName(reportName)}
                className="flex items-center w-fit space-x-2 border bg-transparent hover:bg-secondary hover:text-white rounded-[4px] py-1 px-4 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-inherit"
              >
                {loadingReport ? (
                  <TbLoader3 className="text-primary hover:text-white animate-spin w-6 h-6" />
                ) : (
                  <MdOutlineFileDownload className="cursor-pointer w-6 h-6 " />
                )}
                Export <span className="capitalize">{reportName}</span>{" "}Report
              </button>
            )
          ) : (
            <button
              disabled={loadingReport || controlsDisabled}
              onClick={handleExportMasterReport}
              className="flex  w-fit items-center text-sm space-x-2 border bg-transparent rounded-[4px] py-1 px-4 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <MdOutlineFileDownload className="cursor-pointer w-6 h-6" />
              {loadingReport ? "Exporting..." : "Export Master Report"}
            </button>
          )}

          <div className="flex items-center space-x-2">
            <p>Rows per page </p>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className="flex items-center space-x-2 py-1 px-2 text-sm border border-[#d9d9d9] text-[#1E1E1E] rounded-[8px]"
                  type="button"
                >
                  <span>{maxPage}</span>

                  <MdOutlineArrowDropDown />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 bg-white">
                <DropdownMenuGroup>
                  <DropdownMenuItem onClick={() => setMaxPage(10)}>
                    10
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setMaxPage(20)}>
                    20
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setMaxPage(50)}>
                    50
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setMaxPage(100)}>
                    100
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      <div className="col-span-10">
        <div className="">
          {!selectedPayPeriod ? (
            <div className="flex justify-center items-center py-20">
              <div className="bg-[#FFF7E6] border border-[#FFD580] rounded-lg shadow-sm px-8 py-10 flex flex-col items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-12 w-12 text-[#FFA500] mb-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 8v4m0 4h.01M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9 9 4.03 9 9z"
                  />
                </svg>
                <h2 className="text-lg font-semibold text-[#B45309] mb-2">
                  {pendingPayperiods
                    ? "Loading pay periods..."
                    : "No Pay Period Selected"}
                </h2>
                <p className="text-[#B45309] text-sm text-center">
                  Please select a{" "}
                  <span className="font-medium">pay period</span> from the
                  dropdown above to view the report.
                </p>
              </div>
            </div>
          ) : isPending ? (
            <div className="flex justify-center items-center">
              <TbLoader3 className="text-secondary text-opacity-80 animate-spin w-6 h-6" />
            </div>
          ) : isError ? (
            <div className="text-primary">Error getting reports</div>
          ) : data?.data?.data?.length === 0 ? (
            <EmptyRecord />
          ) : (
            <div className="overflow-x-auto">
              {reportName === "payee" && (
                <table className="w-full mt-[24px]">
                  <thead className="bg-[#DDEFE8]">
                    <tr className=" w-full">
                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Staff ID
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Employee
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Tax Authority
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        State
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Paye Amount
                        {/* Net Salary */}
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Payer ID
                      </th>
                    </tr>
                  </thead>

                  <tbody className="text-[#1A1A1A]">
                    {data?.data?.data?.map((item: any) => (
                      <tr
                        key={item.staffId}
                        className="border-t border-t-[#E5E7EB] w-full border-b border-b-[#D9D9D9]"
                      >
                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.staffId}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.employeeName}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.taxAuthority}
                        </td>

                        <td className="text-left p-4 text-xs font-normal ">
                          {item?.state || "N/A"}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {formatNaira(item?.payeeAmount) || "N/A"}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {item?.payerId || "N/A"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {reportName === "nsitf" && (
                <table className="w-full mt-[24px]">
                  <thead className="bg-[#DDEFE8]">
                    <tr className=" w-full">
                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Staff ID
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Staff Name
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Date of Birth
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Gender
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Gross Income
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        NSITF Contribution
                      </th>
                    </tr>
                  </thead>

                  <tbody className="text-[#1A1A1A]">
                    {data?.data?.data?.map((item: any) => (
                      <tr
                        key={item.staffId}
                        className="border-t border-t-[#E5E7EB] w-full border-b border-b-[#D9D9D9]"
                      >
                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.staffId}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.staffName}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {formatDisplayDate(item?.dateofBirth ?? item?.dateOfBirth)}
                        </td>

                        <td className="text-left p-4 text-xs font-normal ">
                          {genderLabel(item?.gender)}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {formatNaira(item?.grossIncome) || "N/A"}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {formatNaira(item?.nsitfContribution)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {reportName === "nhf" && (
                <table className="w-full mt-[24px]">
                  <thead className="bg-[#DDEFE8]">
                    <tr className=" w-full">
                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Staff ID
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Name
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        NHF Number
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Gross Income
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        NHF Amount
                      </th>

                    </tr>
                  </thead>

                  <tbody className="text-[#1A1A1A]">
                    {data?.data?.data?.map((item: any) => (
                      <tr
                        key={item.staffId}
                        className="border-t border-t-[#E5E7EB] w-full border-b border-b-[#D9D9D9]"
                      >
                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.staffId}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.fullName}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.nhfNumber || "N/A"}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {formatNaira(item?.grossIncome)}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {formatNaira(item?.nhfAmount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {reportName === "pension" && (
                <table className="w-full mt-[24px]">
                  <thead className="bg-[#DDEFE8]">
                    <tr className=" w-full">
                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Staff ID
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Name
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        RSA Pin
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        PFA Name
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Employee Contribution
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Employer Contribution
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Voluntary Employee Pension
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Total Contribution
                      </th>
                    </tr>
                  </thead>

                  <tbody className="text-[#1A1A1A]">
                    {data?.data?.data?.map((item: any) => (
                      <tr
                        key={item.staffId}
                        className="border-t border-t-[#E5E7EB] w-full border-b border-b-[#D9D9D9]"
                      >
                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.staffId}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.employeeName}
                        </td>

                        <td className="text-left p-4 text-xs font-normal ">
                          {displayValue(item?.rsaPin)}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.pfaName}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {formatNaira(item?.employeeContribution)}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {formatNaira(item?.employerPension)}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {formatNaira(item?.voluntaryEmployeePension)}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {formatNaira(item?.totalContribution)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {reportName === "client" && (
                <>
                <table className="min-w-max whitespace-nowrap mt-[24px]">
                  <thead className="bg-[#DDEFE8]">
                    <BasisOnlyGroupRow
                      leading={8 + paidAllowanceHeaders.length}
                      basisCount={basisOnlyHeaders.length}
                      trailing={reliefHeaders.length + deductionHeaders.length + 4}
                    />
                    <tr className=" w-full">
                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Staff ID
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Staff Name
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Job Title
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Grade
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Subsidiary
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Cost Center
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Total Allowances
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Total Deductions
                      </th>

                      {/* Allowances */}
                      {paidAllowanceHeaders.map((name) => (
                        <ComponentHeaderCell key={`allow-${name}`} name={name} />
                      ))}

                      {basisOnlyHeaders.map((name) => (
                        <ComponentHeaderCell key={`basis-${name}`} name={name} />
                      ))}

                      {/* Reliefs */}
                      {reliefHeaders?.map((name: any, i: any) => (
                        <th
                          key={`relief-${i}`}
                          className="p-4 text-xs font-semibold"
                        >
                          {name}
                        </th>
                      ))}

                      {/* Deductions */}
                      {deductionHeaders?.map((name: any, i: any) => (
                        <th
                          key={`deduct-${i}`}
                          className="p-4 text-xs font-semibold"
                        >
                          {name}
                        </th>
                      ))}

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Paye amount
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        NSITF amount
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        NHF amount
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Pension Amount
                      </th>
                    </tr>
                  </thead>

                  <tbody className="text-[#1A1A1A]">
                    {data?.data?.data?.map((item: any) => (
                      <tr
                        key={item.staffNumber}
                        className="border-t border-t-[#E5E7EB] w-full border-b border-b-[#D9D9D9]"
                      >
                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.staffNumber}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.staffName}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.jobTitle || "N/A"}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.grade || "N/A"}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.organizationSubsidiary || "N/A"}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.costCenter || "N/A"}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {formatNaira(item?.totalAllowanceValue ?? item?.allAllowances)}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {formatNaira(item?.totalDeductionValue ?? item?.allDeductions)}
                        </td>

                        {paidAllowanceHeaders.map((name) => componentCell(item?.allowances, name))}
                        {basisOnlyHeaders.map((name) => componentCell(item?.allowances, name))}
                        {reliefHeaders.map((name: any) => componentCell(item?.reliefs, name))}
                        {deductionHeaders.map((name: any) => componentCell(item?.deductions, name))}

                        <td className="text-left p-4 text-sm font-normal ">
                          {formatNaira(item?.payeeAmount)}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {formatNaira(item?.nsitfAmount)}
                        </td>

                        <td className="text-left p-4 text-xs font-normal ">
                          {formatNaira(item?.nhfAmount)}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {formatNaira(item?.pensionAmount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {showComponentLegend && <ComponentLegend />}
                </>
              )}

              {reportName === "bank" && (
                <table className="w-full mt-[24px]">
                  <thead className="bg-[#DDEFE8]">
                    <tr className=" w-full">
                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Payment Amount
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Payment Date
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Reference
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Remark
                      </th>

                      {/* <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Total Pension
                      </th> */}

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Vendor Code
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Vendor Name
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Vendor Account Number
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Vendor Bank Sort Code
                      </th>
                    </tr>
                  </thead>

                  <tbody className="text-[#1A1A1A]">
                    {data?.data?.data?.map((item: any, index: number) => (
                      <tr
                        key={index}
                        className="border-t border-t-[#E5E7EB] w-full border-b border-b-[#D9D9D9]"
                      >
                        <td className="text-left p-4 text-sm font-normal ">
                          {formatNaira(item?.paymentAmount)}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.paymentDate}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.reference || "N/A"}
                        </td>

                        <td className="text-left p-4 text-xs font-normal ">
                          {item?.remark || "N/A"}
                        </td>

                        {/* <td className="text-left p-4 text-sm font-normal ">
                          {formatNaira(item?.totalPension)}
                        </td> */}

                        <td className="text-left p-4 text-xs font-normal">
                          {item?.vendorCode || "N/A"}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {item?.vendorName || "N/A"}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {item?.vendorAcctNumber || "N/A"}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {item?.vendorBankSortCode || "N/A"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {reportName === "master-payroll" && (
                <>
                <table className="min-w-max whitespace-nowrap mt-[24px]">
                  <thead className="bg-[#DDEFE8]">
                    <BasisOnlyGroupRow
                      leading={6 + paidAllowanceHeaders.length}
                      basisCount={basisOnlyHeaders.length}
                      trailing={reliefHeaders.length + deductionHeaders.length + 5}
                    />
                    <tr className=" w-full">
                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Staff Name
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Staff Number
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Job Title
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Grade
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Cost Center
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Subsidiary
                      </th>

                      {/* Allowances */}
                      {paidAllowanceHeaders.map((name) => (
                        <ComponentHeaderCell key={`allow-${name}`} name={name} className="uppercase" />
                      ))}

                      {basisOnlyHeaders.map((name) => (
                        <ComponentHeaderCell key={`basis-${name}`} name={name} className="uppercase" />
                      ))}

                      {/* Reliefs */}
                      {reliefHeaders?.map((name: any, i: any) => (
                        <th
                          key={`relief-${i}`}
                          className="p-4 text-xs font-semibold uppercase"
                        >
                          {name}
                        </th>
                      ))}

                      {/* Deductions */}
                      {deductionHeaders?.map((name: any, i: any) => (
                        <th
                          key={`deduct-${i}`}
                          className="p-4 text-xs font-semibold"
                        >
                          {name}
                        </th>
                      ))}

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Total Allowance
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Total Relief
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Paye
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Total Deduction
                      </th>

                      <th className="text-left p-4 uppercase text-xs font-semibold ">
                        Net Pay
                      </th>
                    </tr>
                  </thead>

                  <tbody className="text-[#1A1A1A]">
                    {data?.data?.data?.map((item: any, index: number) => (
                      <tr
                        key={index}
                        className="border-t border-t-[#E5E7EB] w-full border-b border-b-[#D9D9D9]"
                      >
                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.staffName}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.staffNumber}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.jobTitle || "N/A"}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.grade || "N/A"}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.costCenter || "N/A"}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {item?.organizationSubsidiary || "N/A"}
                        </td>

                        {paidAllowanceHeaders.map((name) => componentCell(item?.allowances, name))}
                        {basisOnlyHeaders.map((name) => componentCell(item?.allowances, name))}
                        {reliefHeaders.map((name: any) => componentCell(item?.reliefs, name))}
                        {deductionHeaders.map((name: any) => componentCell(item?.deductions, name))}

                        <td className="text-left p-4 text-sm font-normal ">
                          {formatNaira(item?.totalAllowanceValue)}
                        </td>

                        <td className="text-left p-4 text-sm font-normal ">
                          {formatNaira(item?.totalReliefValue)}
                        </td>

                        <td className="text-left p-4 text-xs font-normal ">
                          {formatNaira(item?.paye)}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {formatNaira(item?.totalDeductionValue)}
                        </td>

                        <td className="text-left p-4 text-xs font-normal">
                          {formatNaira(item?.netPay)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {showComponentLegend && <ComponentLegend />}
                </>
              )}
            </div>
          )}
        </div>
        <div className="mt-4 flex items-center justify-between py-2 px-4">
          <p className="text-[#63666A] text-xs">
            {formatPageRange(data?.data?.meta, maxPage)}
          </p>

          <div className="flex items-center space-x-3">
            <button
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage((e: number) => e - 1)}
              className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
            >
              <RiArrowLeftSFill className="w-6 h-6" />
            </button>

            <button
              disabled={currentPage >= (Number(data?.data?.meta?.totalPages) || 1)}
              onClick={() => setCurrentPage((e: number) => e + 1)}
              className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
            >
              <RiArrowRightSFill className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </main>
  );
};

export default Report;
