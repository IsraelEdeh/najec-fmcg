"use client";
import React, { useEffect } from "react";
import { useMsal } from "@azure/msal-react";
import { useRouter } from "next/navigation";
import { TbLoader3 } from "react-icons/tb";
import ApiFetcher from "@/components/Utils/api";
import { toast } from "react-toastify";
import { useDispatch } from "react-redux";
import { fetchUserAsync } from "@/components/widgets/Features/GetUserSlice";
import Image from "next/image";

const Page = () => {
  const { instance } = useMsal();
  const router = useRouter();
  const dispatch = useDispatch();

  const getAuthentication = async () => {
    try {
      // console.log("instance:", instance);
      await instance.initialize();
      const getActiveAcc = instance.getActiveAccount;
      // console.log("MSAL instance initialized.", getActiveAcc);

      const response = await instance.handleRedirectPromise();
      // console.log("Response from handleRedirectPromise: ", response);

      if (response) {
        // console.log("Authentication successful: ", response);

        if (response.idToken) {
          document.cookie = `jwt=${response.idToken}; path=/; Secure`;
          const res = await ApiFetcher.post(`/auth/exchange-token`);

          // console.log("Token exchange response: ", res);

          if (res?.data?.data?.token) {
            document.cookie = `jwt=${res.data.data.token}; path=/; Secure`;
            const fetchResult = await dispatch(fetchUserAsync() as any);
            // console.log("fetchResult::", fetchResult);

            if (fetchResult.payload.error) {
              toast.error(fetchResult.payload.error);
              return;
            }

            if (fetchResult?.payload?.userOrganizations?.length > 1) {
              return router.push("/company-select");
            } else if (fetchResult?.payload?.userOrganizations?.length === 1) {
              return router.push("/create-organisation/success");
            }

            return router.push("/contact-adminstrator");
          } else if (res?.data?.errors) {
            return router.push("/contact-adminstrator");
          } else {
            console.log("Token exchange failed or token not found");
            toast.error("Token exchange failed or token not found");
            return;
          }
        } else {
          console.log("ID token not found in response");
          toast.error("ID token not found in response");
          return;
        }
      } else {
        console.log("No response from authentication");
        toast.error("No response from authentication");
        return;
      }
    } catch (error: any) {
      console.log("Authentication failed", error);

      return router.push("/");
    }
  };

  useEffect(() => {
    getAuthentication();
  }, [instance, router]);

  return (
    <div className="h-screen flex gap-2 justify-center items-center">
    
      <Image 
        src="/landing-page/neptune-logo.png"
        alt="logo"
        width={180}
        height={35} 
        className="animate-bounce"   
      />

      <TbLoader3 className="text-secondary animate-spin w-6 h-6" />
    </div>
  );
};

export default Page;
