import type { Metadata } from "next";
import "./globals.css";
import QueryClientProviderContainer from "@/components/Utils/QueryClientProviderContainer";
import StoreProvider from "@/components/Utils/StoreProvider";
import MsalProviderContainer from "@/lib/MsalProviderContainer";

export const metadata: Metadata = {
  title: "Neptune",
  description: "Payroll software for business"
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/logo2.png" sizes="any" />
      </head>
      <body>
        <MsalProviderContainer>
          <StoreProvider>
            <QueryClientProviderContainer>
              {children}
            </QueryClientProviderContainer>
          </StoreProvider>
        </MsalProviderContainer>
      </body>
    </html>
  );
}
