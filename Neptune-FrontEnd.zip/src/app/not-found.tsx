import Link from "next/link";
import Container from "@/components/Elements/Container";
import Navbar from "@/components/LandingPage/Navbar";
import Footer from "@/components/LandingPage/Footer";
import { TbError404 } from "react-icons/tb";

export default function NotFound() {
  return (
    <main className="  text-text">
      <Navbar />
      <Container>
        <div className="flex justify-center items-center h-[70vh] w-full">
          <div className="text-center px-4">
            <div className="flex justify-center">
              <TbError404 className="w-40 h-40" />
            </div>
            <p className="text-[24px] mb-1 mt-2">
              Could not find requested resource
            </p>
            <Link className="hover:underline underline-offset-4 duration-300 ease-in text-lg text-gold" href="/">
              Return Home
            </Link>
          </div>
        </div>
      </Container>
      <Footer />
    </main>
  );
}
