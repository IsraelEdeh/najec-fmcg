import Footer2 from "@/components/LandingPage/Footer";
import Hero from "@/components/LandingPage/Hero";
import PayrollCapabilities from "@/components/LandingPage/PayrollCapabilities";

import React from "react";

const page = () => {
  return (
    <main>
      <Hero />
      <PayrollCapabilities />
      <Footer2 />
    </main>
  );
};

export default page;
