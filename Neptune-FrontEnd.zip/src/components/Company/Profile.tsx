"use client";

import Image from "next/image";
import React, { useEffect, useState } from "react";
import { Button } from "../ui/button";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@/app/store";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { fetchUserAsync } from "../widgets/Features/GetUserSlice";
import { TbLoader3 } from "react-icons/tb";
import { convertFileToBase64 } from "@/constants";
import { User } from "lucide-react";

export interface IFormInput {
  tin: string;
  countryId: string;
  website: string;
  address: string;
  phoneNumber: string;
  logo?: string;
  email?: string;
  netPayRoundingMode?: string;
  netPayRoundingUnit?: string;
}

const schema = yup
  .object({
    tin: yup.string().min(4, "TIN should be 4 characters or more"),
    email: yup.string().email("Invalid email address").optional(),
    phoneNumber: yup
      .string()
      .min(11, "Phone must be 9 digits or more")
      .max(14, "Phone must be 14 digits or less"),
    countryId: yup.string(),
    website: yup.string().optional(),
    address: yup.string().min(4, "Address should be 4 characters or more"),
    logo: yup.string().optional(),
    netPayRoundingMode: yup.string().required(),
    netPayRoundingUnit: yup.string().when("netPayRoundingMode", {
      is: (mode: string) => mode !== "0",
      then: (value) =>
        value
          .required("Net pay rounding unit is required")
          .test("positive", "Net pay rounding unit must be greater than 0", (unit) =>
            Number(unit) > 0
          ),
      otherwise: (value) => value.notRequired()
    })
  })
  .required();

const Profile = ({
  employeeCountryData,
  isCountryLoading
}: {
  employeeCountryData: any;
  isCountryLoading: any;
}) => {
  const dispatch: any = useDispatch();
  const queryClient = useQueryClient();
  const user: any = useSelector((state: RootState) => state?.getUser.user);

  const [logoUpload, setLogoUpload] = useState<string | null>("");
  const [logoDisplay, setLogoDisplay] = useState<any>("");

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const handleFileChange = async (event: any) => {
    const files = event.target.files;
    console.log("files::: ", files);
    if (files && files[0]) {
      try {
        setLogoDisplay(files[0]);
        const base64String: any = await convertFileToBase64(files[0]);
        setLogoUpload(base64String);
      } catch (error) {
        console.error("Error converting file to base64:", error);
        toast.error("Failed to convert image to base64");
      }
    }
  };

  const organizationId = user?.userOrganizations?.find(
    (item: any) => item.isCurrentLoggedInOrganization
  )?.organizationId;

  const getOrganizationDetails = async (id: any) => {
    try {
      const response = await ApiFetcher.get(
        `organization/get-organization-by-id/${id}`
      );

      console.log("org details:::", response);

      return response?.data?.data[0];
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching organization profile data";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    error: organizationByIdError,
    data: organizationDetails,
    isPending
  } = useQuery({
    queryKey: ["organizationByIdDetails", organizationId],
    queryFn: () => getOrganizationDetails(organizationId)
  });

  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
    reset,
    watch
  }: {
    register: any;
    handleSubmit: any;
    formState: any;
    reset: any;
    watch: any;
  } = useForm(
    {
      resolver: yupResolver(schema),
      mode: "onChange"
    }
  );

  const roundingMode = watch("netPayRoundingMode", "0");

  const handleUpdateOrganization = async (data: any) => {
    const payload: any = {
      organizationName: user?.userOrganizations?.find(
        (item: any) => item.isCurrentLoggedInOrganization
      )?.organizationName,
      phoneNumber: data?.phoneNumber,
      email: data?.email || organizationDetails?.email,
      taxIdentificationNumber:
        data.tin || organizationDetails?.taxIdentificationNumber,
      countryId: Number(data.countryId) || Number(user?.country?.id),
      website:
        data.website === "" ? "" : data.website || organizationDetails?.website,
      address: data.address || organizationDetails?.address,
      logo: logoUpload === "" ? "" : logoUpload || organizationDetails?.logo,
      netPayRoundingMode: Number(data.netPayRoundingMode ?? 0),
      netPayRoundingUnit:
        Number(data.netPayRoundingMode ?? 0) === 0
          ? null
          : Number(data.netPayRoundingUnit)
    };
    const existingRoundingMode = Number(
      organizationDetails?.netPayRoundingMode ?? 0
    );
    const existingRoundingUnit = organizationDetails?.netPayRoundingUnit ?? null;
    if (
      payload.netPayRoundingMode === existingRoundingMode &&
      payload.netPayRoundingUnit === existingRoundingUnit
    ) {
      delete payload.netPayRoundingMode;
      delete payload.netPayRoundingUnit;
    }
    try {
      const response: any = await ApiFetcher.put(
        `/organization/update-organization/${organizationId}`,
        payload
      );

      toast.success("Organization updated successfully");
      // dispatch(fetchUserAsync());
      fetchUserAsync();
      return response;
    } catch (error: any) {
      console.log("profile error:::", error);
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error updating organization";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const mutation = useMutation({
    mutationFn: handleUpdateOrganization,
    onSuccess: () => {
      queryClient.invalidateQueries();
      dispatch(fetchUserAsync());
    }
  });

  const onHandlerSubmit = (data: any) => {
    mutation.mutateAsync(data);
  };

  useEffect(() => {
    if (organizationDetails) {
      reset({
        tin: organizationDetails.taxIdentificationNumber || "",
        website: organizationDetails.website || "",
        email: organizationDetails.email || "",
        address: organizationDetails.address || "",
        countryId: String(user?.country?.id),
        netPayRoundingMode: String(organizationDetails.netPayRoundingMode ?? 0),
        netPayRoundingUnit: organizationDetails.netPayRoundingUnit ?? ""
      });
    }
  }, [organizationDetails, reset]);

  return (
    <div>
      {isPending ? (
        <div className="flex items-center justify-center py-6">
          <TbLoader3 className="text-primary animate-spin w-6 h-6" />
        </div>
      ) : (
        <form onSubmit={handleSubmit(onHandlerSubmit)}>
          <div className="space-y-6 w-[70%]">
            <div className="block ">
              <label className="text-sm font-bold">Organization Logo</label>
              {organizationDetails?.logo && (
                <img
                  src={`data:image/png;base64,${organizationDetails?.logo}`}
                  width={200}
                  height={200}
                  alt="upload"
                  className="mt-2 rounded-full border border-secondary"
                />
              )}
              <div className="flex w-full mt-[8px] gap-[16px] items-center py-[12px] px-[16px] border border-[#D9D9D9]">
                {logoUpload ? (
                  <img src={logoUpload} width={60} height={60} alt="upload" />
                ) : organizationDetails?.logo ? (
                  <img
                    src={`data:image/png;base64,${organizationDetails?.logo}`}
                    width={40}
                    height={40}
                    alt="logo"
                  />
                ) : (
                  <div className="flex items-center justify-center w-[40px] h-[40px] bg-gray-200 rounded-full">
                    <User size={24} className="text-gray-500" />
                  </div>
                )}

                <input
                  type="file"
                  disabled={
                    !(
                      activeRole?.includes("Admin") ||
                      activeRole?.includes("Initiator")
                    )
                  }
                  {...register("logo")}
                  onChange={handleFileChange}
                  className="file:mr-4 file:rounded-full file:border-0 file:bg-secondary/400 file:bg-opacity-40 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-secondary/400 hover:file:bg-secondary dark:file:bg-secondary dark:file:text-secondary dark:hover:file:bg-secondary"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              <div>
                <label
                  htmlFor="netPayRoundingMode"
                  className="mb-2 block text-sm font-bold text-[#1E1E1E]"
                >
                  Net pay rounding mode
                </label>
                <select
                  id="netPayRoundingMode"
                  {...register("netPayRoundingMode")}
                  disabled={
                    !(
                      activeRole?.includes("Admin") ||
                      activeRole?.includes("Initiator")
                    )
                  }
                  className="w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm"
                >
                  <option value="0">None</option>
                  <option value="1">Up</option>
                  <option value="2">Nearest</option>
                  <option value="3">Down</option>
                </select>
              </div>

              {roundingMode !== "0" && (
                <div>
                  <label
                    htmlFor="netPayRoundingUnit"
                    className="mb-2 block text-sm font-bold text-[#1E1E1E]"
                  >
                    Net pay rounding unit
                  </label>
                  <input
                    id="netPayRoundingUnit"
                    type="number"
                    min="0.01"
                    step="0.01"
                    {...register("netPayRoundingUnit")}
                    className="w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm"
                  />
                  <p className="text-red-400 mt-1 text-xs" role="alert">
                    {errors.netPayRoundingUnit?.message}
                  </p>
                </div>
              )}
            </div>

            <div>
              <label
                htmlFor="organizationName"
                className="block mb-2 text-sm font-bold text-[#1E1E1E]"
              >
                Organization Name
              </label>
              <input
                type="text"
                defaultValue={organizationDetails?.organizationName}
                className="disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-opacity-70 bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                required
                disabled
              />
              {/* <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.organizationName?.message}
          </p> */}
            </div>

            <div>
              <label
                htmlFor="tin"
                className="flex items-center space-x-1 mb-2 text-sm font-bold text-[#1E1E1E] "
              >
                <span>Tax Identification Number (TIN)</span>
                <Image
                  src="/dashboard/required.png"
                  width={8}
                  height={20}
                  alt="required icon"
                />
              </label>
              <input
                type="text"
                defaultValue={organizationDetails?.taxIdentificationNumber}
                className="bg-gray-50 border border-gray-300 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-opacity-70 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                placeholder="eg. CX9908881111"
                disabled={
                  !(
                    activeRole?.includes("Admin") ||
                    activeRole?.includes("Initiator")
                  )
                }
                {...register("tin")}
                required
              />
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors.tin?.message}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 w-full space-x-[24px]">
              <div className="w-full">
                <label
                  htmlFor="officialEmail"
                  className="flex items-center space-x-2 mb-2 text-sm font-bold text-[#1E1E1E] "
                >
                  <span>Official Email</span>
                  <Image
                    src="/dashboard/required.png"
                    width={8}
                    height={20}
                    alt="required icon"
                  />
                </label>
                <input
                  type="email"
                  defaultValue={organizationDetails?.email}
                  className="bg-gray-50 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-opacity-70 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                  required
                  disabled={
                    !(
                      activeRole?.includes("Admin") ||
                      activeRole?.includes("Initiator")
                    )
                  }
                  placeholder="info@company.com"
                  {...register("email")}
                />
                {/* <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
              {errors.email?.message}
            </p> */}
              </div>

              <div>
                <label
                  htmlFor="phoneNumber"
                  className="flex items-center space-x-1 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-opacity-70 mb-2 text-sm font-bold text-[#1E1E1E]  "
                >
                  <span>Phone number</span>
                  <Image
                    src="/dashboard/required.png"
                    width={8}
                    height={20}
                    alt="required icon"
                  />
                </label>
                <input
                  type="type"
                  defaultValue={organizationDetails?.phoneNumber}
                  className="bg-gray-50  border border-gray-300 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-opacity-70 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                  placeholder="e.g 0814 5***"
                  disabled={
                    !(
                      activeRole?.includes("Admin") ||
                      activeRole?.includes("Initiator")
                    )
                  }
                  {...register("phoneNumber")}
                  required
                // disabled
                />
                <p
                  className="text-red-400 mt-1 text-xs lg:text-sm"
                  role="alert"
                >
                  {errors.phoneNumber?.message}
                </p>
              </div>
            </div>

            <div>
              <label
                htmlFor="countryId"
                className="flex items-center space-x-1 mb-2 text-sm font-bold text-[#1E1E1E] "
              >
                <span>Country</span>
                <Image
                  src="/dashboard/required.png"
                  width={8}
                  height={20}
                  alt="required icon"
                />
              </label>
              <select
                defaultValue={user?.country?.id}
                disabled={
                  !(
                    activeRole?.includes("Admin") ||
                    activeRole?.includes("Initiator")
                  )
                }
                {...register("countryId")}
                className="bg-gray-50 border border-gray-300 text-gray-900 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-opacity-70 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
              >
                <option
                  value={user?.country?.id}
                  className="font-semibold text-secondary"
                >
                  {user?.country?.name}
                </option>
                {isCountryLoading ? (
                  "loading"
                ) : !isCountryLoading && employeeCountryData ? (
                  employeeCountryData?.data?.data?.data?.map((country: any) => (
                    <option value={country.id} key={country.id}>
                      <>{country.name}</>
                    </option>
                  ))
                ) : (
                  <p
                    className="text-red-400 mt-1 text-xs lg:text-sm"
                    role="alert"
                  >
                    Error loading country data.
                  </p>
                )}
              </select>
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors.countryId?.message}
              </p>
            </div>

            <div className="w-full">
              <label
                htmlFor="website"
                className="flex items-center space-x-1 mb-2 text-sm font-bold text-[#1E1E1E] "
              >
                <span>Website</span>
              </label>
              <input
                defaultValue={organizationDetails?.website}
                type="text"
                placeholder="e.g www.company.com"
                disabled={
                  !(
                    activeRole?.includes("Admin") ||
                    activeRole?.includes("Initiator")
                  )
                }
                {...register("website")}
                className="bg-gray-50 border border-gray-300 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-opacity-70 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
              />
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors.website?.message}
              </p>
            </div>

            <div>
              <label
                htmlFor="address"
                className="flex items-center space-x-1 mb-2 text-sm font-bold text-[#1E1E1E] "
              >
                <span>Address</span>
                <Image
                  src="/dashboard/required.png"
                  width={8}
                  height={20}
                  alt="required icon"
                />
              </label>
              <textarea
                defaultValue={organizationDetails?.address}
                className="bg-gray-50 border border-gray-300 disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-opacity-70 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                rows={4}
                cols={4}
                placeholder="3, Coker street, Maryland"
                disabled={
                  !(
                    activeRole?.includes("Admin") ||
                    activeRole?.includes("Initiator")
                  )
                }
                {...register("address")}
              ></textarea>
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors.address?.message}
              </p>
            </div>
          </div>

          {(activeRole?.includes("Admin") ||
            activeRole?.includes("Initiator")) && (
              <div className=" w-full">
                <Button
                  type="submit"
                  disabled={mutation.isPending || !isValid}
                  className="disabled:bg-secondary disabled:bg-opacity-70  bg-primary text-white text-sm font-semibold py-[11px] px-[32px] w-[30%]"
                >
                  {mutation.isPending ? "Saving..." : "Save"}
                </Button>
              </div>
            )}
        </form>
      )}
    </div>
  );
};

export default Profile;
