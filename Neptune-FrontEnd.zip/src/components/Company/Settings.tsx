"use client";

import React, { useState } from "react";
import { Button } from "../ui/button";
import { Trash2 } from "lucide-react";
import { MdCancel } from "react-icons/md";
import ApiFetcher from "../Utils/api";
import { toast } from "react-toastify";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { TbLoader } from "react-icons/tb";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import { FiInfo } from "react-icons/fi";
import { useRouter } from "next/navigation";
import WorkingCalendar from "./WorkingCalendar";
import { fetchUserAsync } from "../widgets/Features/GetUserSlice";
import { useDispatch } from "react-redux";
import { useMsal } from "@azure/msal-react";

const departmentSchema = yup
  .object({
    name: yup.string().min(3, "Department name should be 3 characters or more")
  })
  .required();

const jobTitleSchema = yup
  .object({
    name: yup.string().min(2, "Job title should be 2 characters or more")
  })
  .required();

const gradeSchema = yup
  .object({ name: yup.string().min(1, "Grade name is required") })
  .required();

const costCenterSchema = yup
  .object({ name: yup.string().min(1, "Grade name is required") })
  .required();

const subsidiariesSchema = yup
  .object({ name: yup.string().min(1, "Subsidiary name is required") })
  .required();

const Settings = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  const { instance } = useMsal();

  const [loading, setLoading] = useState<boolean>(false);
  const queryClient = useQueryClient();

  // Department state
  const [selectedDepartment, setSelectedDeparment] = useState<any>(null);

  // Job title state
  const [selectedJobTitle, setSelectedJobTitle] = useState<any>(null);

  // Employee grade state
  const [selectedGrade, setSelectedGrade] = useState<any>(null);

  // Cost center
  const [selectedCostCenter, setSelectedCostCenter] = useState<any>(null);

  // Subsidiary
  const [selectedSubsidiaries, setSelectedSubsidiaries] = useState<any>(null);

  const [isOrganizationDeleteDialogOpen, setIsOrganizationDeleteDialogOpen] =
    useState(false);
  const [deleteDataInput, setDeleteDataInput] = useState<string>("");

  const user: any = useSelector((state: RootState) => state.getUser.user);

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const orgId = user?.userOrganizations?.[0]?.organizationId;

  // ─── Department forms ────────────────────────────────────────────────────────
  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
    reset
  } = useForm({ resolver: yupResolver(departmentSchema), mode: "onChange" });

  // ─── Job title forms ─────────────────────────────────────────────────────────
  const {
    register: registerJobTitle,
    handleSubmit: handleSubmitJobTitle,
    formState: { errors: jobTitleErrors, isValid: isJobTitleValid },
    reset: resetJobTitle
  } = useForm({ resolver: yupResolver(jobTitleSchema), mode: "onChange" });

  // ─── Employee grade forms ────────────────────────────────────────────────────
  const {
    register: registerGrade,
    handleSubmit: handleSubmitGrade,
    formState: { errors: gradeErrors, isValid: isGradeValid },
    reset: resetGrade
  } = useForm({ resolver: yupResolver(gradeSchema), mode: "onChange" });

  // ─── Employee cost center ────────────────────────────────────────────────────
  const {
    register: registerCostCenter,
    handleSubmit: handleSubmitCostCenter,
    formState: { errors: costCenterErrors, isValid: isCostCenterValid },
    reset: resetCostCenter
  } = useForm({ resolver: yupResolver(costCenterSchema), mode: "onChange" });

  // ─── Employee cost center ────────────────────────────────────────────────────
  const {
    register: registerSubsidiaries,
    handleSubmit: handleSubmitSubsidiaries,
    formState: { errors: subsidiaryErrors, isValid: isSubsidiaryValid },
    reset: resetSubsidiaries
  } = useForm({ resolver: yupResolver(subsidiariesSchema), mode: "onChange" });

  // ─── Department API ───────────────────────────────────────────────────────────
  const fetchDeparments = async () => {
    try {
      const response = await ApiFetcher.get(
        `/departments/get-all-departments-in-an-organization?PageSize=100`
      );
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error fetching department";
      console.log(errorMessage);
    }
  };

  const { isPending, data: departments } = useQuery({
    queryKey: ["departmentSettings"],
    queryFn: fetchDeparments
  });

  const handleAddDepartments = async (data: any) => {
    try {
      const response = await ApiFetcher.post("/departments/create-department", {
        organizationId: orgId,
        name: data?.name,
        costCenter: data?.costCenter || ""
      });
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error adding a department.";
      toast.error(errorMessage);
    } finally {
      reset();
    }
  };

  const addDepartmentMutation = useMutation({
    mutationFn: handleAddDepartments,
    onSuccess: () => {
      toast.success("Department added successfully");
      queryClient.invalidateQueries();
    }
  });

  const handleDeleteDepartment = async () => {
    try {
      const response = await ApiFetcher.delete(
        `/departments/delete-department/${selectedDepartment?.id}`
      );
      setSelectedDeparment(null);
      toast.success("Department removed successfully");
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error deleting a department.";
      toast.error(errorMessage);
    }
  };

  const deleteDepartmentMutation = useMutation({
    mutationFn: handleDeleteDepartment,
    onSuccess: () => queryClient.invalidateQueries()
  });

  // ─── Job Title API ────────────────────────────────────────────────────────────
  const fetchJobTitles = async () => {
    try {
      const response = await ApiFetcher.get(
        `/employeejobtitles/get-all-employee-job-titles-in-an-organization?PageSize=100`
      );
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error fetching job titles";
      console.log(errorMessage);
    }
  };

  const { isPending: isJobTitlesPending, data: jobTitles } = useQuery({
    queryKey: ["jobTitles"],
    queryFn: fetchJobTitles
  });

  const handleAddJobTitle = async (data: any) => {
    try {
      const response = await ApiFetcher.post(
        "/employeejobtitles/create-employee-job-title",
        { organizationId: orgId, name: data?.name }
      );
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error adding job title.";
      toast.error(errorMessage);
    } finally {
      resetJobTitle();
    }
  };

  const addJobTitleMutation = useMutation({
    mutationFn: handleAddJobTitle,
    onSuccess: () => {
      toast.success("Job title added successfully");
      queryClient.invalidateQueries();
    }
  });

  const handleDeleteJobTitle = async () => {
    try {
      const response = await ApiFetcher.delete(
        `/employeejobtitles/delete-employee-job-title/${selectedJobTitle?.id}`
      );
      setSelectedJobTitle(null);
      toast.success("Job title removed successfully");
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error deleting job title.";
      toast.error(errorMessage);
    }
  };

  const deleteJobTitleMutation = useMutation({
    mutationFn: handleDeleteJobTitle,
    onSuccess: () => queryClient.invalidateQueries()
  });

  // ─── Cost Center API ───────────────────────────────────────────────────────
  const fetchCostCenter = async () => {
    try {
      const response = await ApiFetcher.get(
        `/costcenters/get-all-costcenters-in-an-organization?PageSize=100`
      );
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error fetching cost centers";
      console.log(errorMessage);
    }
  };

  const { isPending: isCostCenterPending, data: costCenter } = useQuery({
    queryKey: ["costCenters"],
    queryFn: fetchCostCenter
  });

  const handleAddCostCenter = async (data: any) => {
    try {
      const response = await ApiFetcher.post("/costcenters/create-costcenter", {
        organizationId: orgId,
        name: data?.name
      });
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error adding cost center.";
      toast.error(errorMessage);
    } finally {
      resetCostCenter();
    }
  };

  const addCostCenterMutation = useMutation({
    mutationFn: handleAddCostCenter,
    onSuccess: () => {
      toast.success("Cost center added successfully");
      queryClient.invalidateQueries();
    }
  });

  const handleDeleteCostCenter = async () => {
    try {
      const response = await ApiFetcher.delete(
        `/costcenters/delete-costcenter/${selectedCostCenter?.id}`
      );
      setSelectedCostCenter(null);
      toast.success("Cost center removed successfully");
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error deleting cost center.";
      toast.error(errorMessage);
    }
  };

  const deleteCostCenterMutation = useMutation({
    mutationFn: handleDeleteCostCenter,
    onSuccess: () => queryClient.invalidateQueries()
  });

  // ─── Employee Grade API ───────────────────────────────────────────────────────
  const fetchGrades = async () => {
    try {
      const response = await ApiFetcher.get(
        `/employeegrades/get-all-employee-grades-in-an-organization?PageSize=100`
      );
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error fetching grades";
      console.log(errorMessage);
    }
  };

  const { isPending: isGradesPending, data: grades } = useQuery({
    queryKey: ["employeeGrades"],
    queryFn: fetchGrades
  });

  const handleAddGrade = async (data: any) => {
    try {
      const response = await ApiFetcher.post(
        "/employeegrades/create-employee-grade",
        { organizationId: orgId, name: data?.name }
      );
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error adding employee grade.";
      toast.error(errorMessage);
    } finally {
      resetGrade();
    }
  };

  const addGradeMutation = useMutation({
    mutationFn: handleAddGrade,
    onSuccess: () => {
      toast.success("Employee grade added successfully");
      queryClient.invalidateQueries();
    }
  });

  const handleDeleteGrade = async () => {
    try {
      const response = await ApiFetcher.delete(
        `/employeegrades/delete-employee-grade/${selectedGrade?.id}`
      );
      setSelectedGrade(null);
      toast.success("Employee grade removed successfully");
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error deleting employee grade.";
      toast.error(errorMessage);
    }
  };

  const deleteGradeMutation = useMutation({
    mutationFn: handleDeleteGrade,
    onSuccess: () => queryClient.invalidateQueries()
  });

  // ─── Cost Center API ───────────────────────────────────────────────────────
  const fetchSubsidiaries = async () => {
    try {
      const response = await ApiFetcher.get(
        `/organizationsubsidiaries/get-all-organizationsubsidiaries-in-an-organization?PageSize=100`
      );
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error fetching subsidiaries";
      console.log(errorMessage);
    }
  };

  const { isPending: isSubsidiariesPending, data: subsidiaries } = useQuery({
    queryKey: ["subsidiaries"],
    queryFn: fetchSubsidiaries
  });

  const handleAddSubsidiaries = async (data: any) => {
    try {
      const response = await ApiFetcher.post(
        "/organizationsubsidiaries/create-organizationsubsidiary",
        {
          organizationId: orgId,
          name: data?.name
        }
      );
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error adding subsidiary.";
      toast.error(errorMessage);
    } finally {
      resetSubsidiaries();
    }
  };

  const addSubsidiariesMutation = useMutation({
    mutationFn: handleAddSubsidiaries,
    onSuccess: () => {
      toast.success("Subsidiaries added successfully");
      queryClient.invalidateQueries();
    }
  });

  const handleDeleteSubsidiaries = async () => {
    try {
      const response = await ApiFetcher.delete(
        `/organizationsubsidiaries/delete-organizationsubsidiary/${selectedSubsidiaries?.id}`
      );
      setSelectedSubsidiaries(null);
      toast.success("Subsidiary removed successfully");
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Error deleting subsidiary.";
      toast.error(errorMessage);
    }
  };

  const deleteSubsidiaryMutation = useMutation({
    mutationFn: handleDeleteSubsidiaries,
    onSuccess: () => queryClient.invalidateQueries()
  });

  // ─── Organization delete ──────────────────────────────────────────────────────
  const logout = () => {
    instance.logoutRedirect().catch((error: any) => console.log(error));
  };

  const handleDeleteOrganization = async () => {
    const loggedInUserID = user?.userOrganizations?.find(
      (item: any) => item.isCurrentLoggedInOrganization
    )?.organizationId;

    try {
      setLoading(true);
      const response = await ApiFetcher.delete(
        `/organization/delete-organization/${loggedInUserID}`
      );
      setIsOrganizationDeleteDialogOpen(false);
      logout();
      return response;
    } catch (error: any) {
      const errorMessage =
        error.response.data.message || "Unable to delete organisation.";
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const canManage =
    activeRole?.includes("Admin") || activeRole?.includes("Initiator");

  return (
    <section className="relative">
      {/* ── Department delete dialog ─────────────────────────────────── */}
      <Dialog
        open={!!selectedDepartment}
        onOpenChange={() => setSelectedDeparment(null)}
      >
        <DialogContent className="w-[400px] bg-white">
          <DialogHeader>
            <DialogTitle>You are about to delete a department</DialogTitle>
            <DialogDescription className="pt-2">
              This will delete{" "}
              <span className="font-bold">
                {selectedDepartment?.name?.toLowerCase()}
              </span>{" "}
              department from your list.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex items-center space-x-2">
            <DialogClose asChild>
              <Button type="button" className="bg-primary text-white">
                Close
              </Button>
            </DialogClose>
            <Button
              className="bg-[#FF3B30] hover:bg-[#e2544c] text-white"
              type="button"
              onClick={() => deleteDepartmentMutation.mutateAsync()}
              disabled={deleteDepartmentMutation.isPending}
            >
              {deleteDepartmentMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Job Title delete dialog ──────────────────────────────────── */}
      <Dialog
        open={!!selectedJobTitle}
        onOpenChange={() => setSelectedJobTitle(null)}
      >
        <DialogContent className="w-[400px] bg-white">
          <DialogHeader>
            <DialogTitle>You are about to delete a job title</DialogTitle>
            <DialogDescription className="pt-2">
              This will delete{" "}
              <span className="font-bold">
                {selectedJobTitle?.name?.toLowerCase()}
              </span>{" "}
              from your list.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex items-center space-x-2">
            <DialogClose asChild>
              <Button type="button" className="bg-primary text-white">
                Close
              </Button>
            </DialogClose>
            <Button
              className="bg-[#FF3B30] hover:bg-[#e2544c] text-white"
              type="button"
              onClick={() => deleteJobTitleMutation.mutateAsync()}
              disabled={deleteJobTitleMutation.isPending}
            >
              {deleteJobTitleMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Cost center delete dialog ──────────────────────────────────── */}
      <Dialog
        open={!!selectedCostCenter}
        onOpenChange={() => setSelectedCostCenter(null)}
      >
        <DialogContent className="w-[400px] bg-white">
          <DialogHeader>
            <DialogTitle>You are about to delete a cost center</DialogTitle>
            <DialogDescription className="pt-2">
              This will delete{" "}
              <span className="font-bold">
                {selectedCostCenter?.name?.toLowerCase()}
              </span>{" "}
              from your list.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex items-center space-x-2">
            <DialogClose asChild>
              <Button type="button" className="bg-primary text-white">
                Close
              </Button>
            </DialogClose>
            <Button
              className="bg-[#FF3B30] hover:bg-[#e2544c] text-white"
              type="button"
              onClick={() => deleteCostCenterMutation.mutateAsync()}
              disabled={deleteCostCenterMutation.isPending}
            >
              {deleteCostCenterMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Employee Grade delete dialog ─────────────────────────────── */}
      <Dialog
        open={!!selectedGrade}
        onOpenChange={() => setSelectedGrade(null)}
      >
        <DialogContent className="w-[400px] bg-white">
          <DialogHeader>
            <DialogTitle>You are about to delete an employee grade</DialogTitle>
            <DialogDescription className="pt-2">
              This will delete{" "}
              <span className="font-bold">
                {selectedGrade?.name?.toLowerCase()}
              </span>{" "}
              grade from your list.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex items-center space-x-2">
            <DialogClose asChild>
              <Button type="button" className="bg-primary text-white">
                Close
              </Button>
            </DialogClose>
            <Button
              className="bg-[#FF3B30] hover:bg-[#e2544c] text-white"
              type="button"
              onClick={() => deleteGradeMutation.mutateAsync()}
              disabled={deleteGradeMutation.isPending}
            >
              {deleteGradeMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Subsidiaries delete dialog ─────────────────────────────── */}
      <Dialog
        open={!!selectedSubsidiaries}
        onOpenChange={() => setSelectedSubsidiaries(null)}
      >
        <DialogContent className="w-[400px] bg-white">
          <DialogHeader>
            <DialogTitle>You are about to delete a subsidiary</DialogTitle>
            <DialogDescription className="pt-2">
              This will delete{" "}
              <span className="font-bold">
                {selectedSubsidiaries?.name?.toLowerCase()}
              </span>{" "}
              from your organisation.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex items-center space-x-2">
            <DialogClose asChild>
              <Button type="button" className="bg-primary text-white">
                Close
              </Button>
            </DialogClose>
            <Button
              className="bg-[#FF3B30] hover:bg-[#e2544c] text-white"
              type="button"
              onClick={() => deleteSubsidiaryMutation.mutateAsync()}
              disabled={deleteSubsidiaryMutation.isPending}
            >
              {deleteSubsidiaryMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Organization delete dialog ───────────────────────────────── */}
      <Dialog
        open={isOrganizationDeleteDialogOpen}
        onOpenChange={setIsOrganizationDeleteDialogOpen}
      >
        <DialogContent className="w-[620px] bg-white rounded-[8px] p-10">
          <DialogHeader>
            <DialogTitle className="text-xl">Confirm Delete</DialogTitle>
            <DialogDescription className="pt-2">
              <div className="font-semibold">
                You are attempting to delete this company.
              </div>
              <div className="mt-1">
                This will remove all data related to this company, including
                payroll history, employees and all configurations done
                previously. Are you sure you want to proceed with this action.
              </div>
              <div className="rounded-[4px] flex items-center space-x-2 my-6 border-[#757575] border-2 bg-[#f4f6f9] p-[18px]">
                <FiInfo className="w-4 h-4 text-[#ff3b30]" />
                <p className="text-[#1e1e1e]">This action cannot be undone.</p>
              </div>
            </DialogDescription>
          </DialogHeader>
          <div className="w-full">
            <form className="flex items-center gap-2">
              <div className="w-full">
                <input
                  type="text"
                  placeholder="Type 'Delete' to confirm action"
                  value={deleteDataInput}
                  onChange={(e: any) => setDeleteDataInput(e.target.value)}
                  className="rounded-[4px] border py-2.5 pl-3 w-full"
                />
              </div>
              <div>
                {activeRole?.includes("Admin") && (
                  <Button
                    className="bg-[#FF3B30] hover:bg-[#e2544c] disabled:bg-[#DDC9C8] disabled:text-white focus:bg-[#e2544c] text-white"
                    type="button"
                    onClick={handleDeleteOrganization}
                    disabled={deleteDataInput !== "Delete"}
                  >
                    {loading ? "Deleting" : "Delete"}
                  </Button>
                )}
              </div>
            </form>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Main content ─────────────────────────────────────────────── */}
      <div className="mt-[24px] w-[70%]">
        {/* Departments */}
        {canManage && (
          <>
            <h2 className="font-bold text-sm">Departments</h2>
            <p className="text-sm text-[#63666A] mt-[4px]">
              Enter department details and click add to add new departments
            </p>
            <form
              onSubmit={handleSubmit((data) =>
                addDepartmentMutation.mutateAsync(data)
              )}
            >
              <div className="flex space-x-[10px] items-end mb-[4px]">
                <div className="flex flex-col w-full gap-[8px]">
                  <div className="flex flex-col">
                    <label className="text-xs text-[#63666A] mb-[4px]">
                      Department Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="Type department name..."
                      {...register("name")}
                      className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                    />
                    <p className="text-red-400 mt-1 text-xs" role="alert">
                      {errors.name?.message}
                    </p>
                  </div>
                </div>
                <Button
                  type="submit"
                  className="disabled:bg-secondary disabled:bg-opacity-70 py-[11px] px-[16px] bg-primary text-white font-semibold text-sm shrink-0 mb-[4px]"
                  disabled={addDepartmentMutation.isPending || !isValid}
                >
                  {addDepartmentMutation.isPending ? "Adding..." : "Add +"}
                </Button>
              </div>
            </form>
          </>
        )}

        <div className="mt-3 mb-6">
          {isPending ? (
            <div className="flex items-center space-x-2">
              <TbLoader className="animate-spin" />
              <span className="text-sm">Loading departments...</span>
            </div>
          ) : departments?.data?.data?.length > 0 ? (
            <div className="flex items-center gap-2 flex-wrap">
              {departments?.data?.data?.map((department: any) => (
                <button
                  key={department.id ?? department.name}
                  className="bg-[#DDEFE8] rounded-[4px] border border-[#d9d9d9] py-[4px] px-[8px] text-sm flex items-center space-x-3"
                >
                  <span>{department.name}</span>
                  {department.costCenter && (
                    <span className="text-xs text-[#63666A] border-l border-[#b0c9be] pl-3">
                      {department.costCenter}
                    </span>
                  )}
                  {canManage && (
                    <MdCancel
                      onClick={() => setSelectedDeparment(department)}
                      className="cursor-pointer"
                    />
                  )}
                </button>
              ))}
            </div>
          ) : (
            <p className="text-sm italic text-[#63666A]">
              No departments found
            </p>
          )}
        </div>

        <hr className="border-[#D9D9D9] mb-6" />

        {/* Job Titles */}
        {canManage && (
          <>
            <h2 className="font-bold text-sm">Job Titles</h2>
            <p className="text-sm text-[#63666A] mt-[4px]">
              Enter a job title and click add to include it in your organisation
            </p>
            <form
              onSubmit={handleSubmitJobTitle((data) =>
                addJobTitleMutation.mutateAsync(data)
              )}
            >
              <div className="flex space-x-[10px] items-center mb-[4px]">
                <input
                  type="text"
                  placeholder="Type job title..."
                  {...registerJobTitle("name")}
                  className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] mt-[5px] text-gray-900 text-sm rounded-lg w-full"
                />
                <Button
                  type="submit"
                  className="disabled:bg-secondary disabled:bg-opacity-70 py-[11px] px-[16px] bg-primary text-white font-semibold text-sm"
                  disabled={addJobTitleMutation.isPending || !isJobTitleValid}
                >
                  {addJobTitleMutation.isPending ? "Adding..." : "Add +"}
                </Button>
              </div>
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {jobTitleErrors.name?.message}
              </p>
            </form>
          </>
        )}

        {!canManage && <h2 className="font-bold text-sm">Job Titles</h2>}

        <div className="mt-3 mb-6">
          {isJobTitlesPending ? (
            <div className="flex items-center space-x-2">
              <TbLoader className="animate-spin" />
              <span className="text-sm">Loading job titles...</span>
            </div>
          ) : jobTitles?.data?.data?.length > 0 ? (
            <div className="flex items-center gap-2 flex-wrap">
              {jobTitles?.data?.data?.map((jobTitle: any) => (
                <button
                  key={jobTitle.id ?? jobTitle.name}
                  className="bg-[#DDEFE8] rounded-[4px] border border-[#d9d9d9] py-[4px] px-[8px] text-sm flex items-center space-x-4"
                >
                  <span>{jobTitle.name}</span>
                  {canManage && (
                    <MdCancel
                      onClick={() => setSelectedJobTitle(jobTitle)}
                      className="cursor-pointer"
                    />
                  )}
                </button>
              ))}
            </div>
          ) : (
            <p className="text-sm italic text-[#63666A]">No job titles found</p>
          )}
        </div>

        <hr className="border-[#D9D9D9] mb-6" />

        {/* Cost Center */}
        {canManage && (
          <>
            <h2 className="font-bold text-sm">Cost Centers</h2>
            <p className="text-sm text-[#63666A] mt-[4px]">
              Enter a cost center and click add to include it in your
              organisation
            </p>
            <form
              onSubmit={handleSubmitCostCenter((data) =>
                addCostCenterMutation.mutateAsync(data)
              )}
            >
              <div className="flex space-x-[10px] items-center mb-[4px]">
                <input
                  type="text"
                  placeholder="Type cost center..."
                  {...registerCostCenter("name")}
                  className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] mt-[5px] text-gray-900 text-sm rounded-lg w-full"
                />
                <Button
                  type="submit"
                  className="disabled:bg-secondary disabled:bg-opacity-70 py-[11px] px-[16px] bg-primary text-white font-semibold text-sm"
                  disabled={addCostCenterMutation.isPending || !isCostCenterValid}
                >
                  {addCostCenterMutation.isPending ? "Adding..." : "Add +"}
                </Button>
              </div>
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {costCenterErrors.name?.message}
              </p>
            </form>
          </>
        )}

        {!canManage && <h2 className="font-bold text-sm">Cost center</h2>}

        <div className="mt-3 mb-6">
          {isCostCenterPending ? (
            <div className="flex items-center space-x-2">
              <TbLoader className="animate-spin" />
              <span className="text-sm">Loading cost center...</span>
            </div>
          ) : costCenter?.data?.data?.length > 0 ? (
            <div className="flex items-center gap-2 flex-wrap">
              {costCenter?.data?.data?.map((grade: any) => (
                <button
                  key={grade.id ?? grade.name}
                  className="bg-[#DDEFE8] rounded-[4px] border border-[#d9d9d9] py-[4px] px-[8px] text-sm flex items-center space-x-4"
                >
                  <span>{grade.name}</span>
                  {canManage && (
                    <MdCancel
                      onClick={() => setSelectedGrade(grade)}
                      className="cursor-pointer"
                    />
                  )}
                </button>
              ))}
            </div>
          ) : (
            <p className="text-sm italic text-[#63666A]">
              No cost center found
            </p>
          )}
        </div>

        {/* Organization Subsidiary */}
        {canManage && (
          <>
            <h2 className="font-bold text-sm">Subsidairies</h2>
            <p className="text-sm text-[#63666A] mt-[4px]">
              Enter a subsidiary and click add to include it in your
              organisation
            </p>
            <form
              onSubmit={handleSubmitSubsidiaries((data) =>
                addSubsidiariesMutation.mutateAsync(data)
              )}
            >
              <div className="flex space-x-[10px] items-center mb-[4px]">
                <input
                  type="text"
                  placeholder="Type subsidiary..."
                  {...registerSubsidiaries("name")}
                  className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] mt-[5px] text-gray-900 text-sm rounded-lg w-full"
                />
                <Button
                  type="submit"
                  className="disabled:bg-secondary disabled:bg-opacity-70 py-[11px] px-[16px] bg-primary text-white font-semibold text-sm"
                  disabled={
                    addSubsidiariesMutation.isPending || !isSubsidiaryValid
                  }
                >
                  {addSubsidiariesMutation.isPending ? "Adding..." : "Add +"}
                </Button>
              </div>
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {subsidiaryErrors.name?.message}
              </p>
            </form>
          </>
        )}

        {!canManage && <h2 className="font-bold text-sm">Subsidiaries</h2>}

        <div className="mt-3 mb-6">
          {isSubsidiariesPending ? (
            <div className="flex items-center space-x-2">
              <TbLoader className="animate-spin" />
              <span className="text-sm">Loading employee subsidiaries...</span>
            </div>
          ) : subsidiaries?.data?.data?.length > 0 ? (
            <div className="flex items-center gap-2 flex-wrap">
              {subsidiaries?.data?.data?.map((grade: any) => (
                <button
                  key={grade.id ?? grade.name}
                  className="bg-[#DDEFE8] rounded-[4px] border border-[#d9d9d9] py-[4px] px-[8px] text-sm flex items-center space-x-4"
                >
                  <span>{grade.name}</span>
                  {canManage && (
                    <MdCancel
                      onClick={() => setSelectedGrade(grade)}
                      className="cursor-pointer"
                    />
                  )}
                </button>
              ))}
            </div>
          ) : (
            <p className="text-sm italic text-[#63666A]">
              No subsidiaries found
            </p>
          )}
        </div>

        {/* Employee Grades */}
        {canManage && (
          <>
            <h2 className="font-bold text-sm">Employee Grades</h2>
            <p className="text-sm text-[#63666A] mt-[4px]">
              Enter a grade and click add to include it in your organisation
            </p>
            <form
              onSubmit={handleSubmitGrade((data) =>
                addGradeMutation.mutateAsync(data)
              )}
            >
              <div className="flex space-x-[10px] items-center mb-[4px]">
                <input
                  type="text"
                  placeholder="Type employee grade..."
                  {...registerGrade("name")}
                  className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] mt-[5px] text-gray-900 text-sm rounded-lg w-full"
                />
                <Button
                  type="submit"
                  className="disabled:bg-secondary disabled:bg-opacity-70 py-[11px] px-[16px] bg-primary text-white font-semibold text-sm"
                  disabled={addGradeMutation.isPending || !isGradeValid}
                >
                  {addGradeMutation.isPending ? "Adding..." : "Add +"}
                </Button>
              </div>
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {gradeErrors.name?.message}
              </p>
            </form>
          </>
        )}

        {!canManage && <h2 className="font-bold text-sm">Employee Grades</h2>}

        <div className="mt-3 mb-6">
          {isGradesPending ? (
            <div className="flex items-center space-x-2">
              <TbLoader className="animate-spin" />
              <span className="text-sm">Loading employee grades...</span>
            </div>
          ) : grades?.data?.data?.length > 0 ? (
            <div className="flex items-center gap-2 flex-wrap">
              {grades?.data?.data?.map((grade: any) => (
                <button
                  key={grade.id ?? grade.name}
                  className="bg-[#DDEFE8] rounded-[4px] border border-[#d9d9d9] py-[4px] px-[8px] text-sm flex items-center space-x-4"
                >
                  <span>{grade.name}</span>
                  {canManage && (
                    <MdCancel
                      onClick={() => setSelectedGrade(grade)}
                      className="cursor-pointer"
                    />
                  )}
                </button>
              ))}
            </div>
          ) : (
            <p className="text-sm italic text-[#63666A]">
              No employee grades found
            </p>
          )}
        </div>

        {/* Working Calendar */}
        <div className="my-10 w-full justify-between border border-[#D9D9D9] bg-[#FFFFFF] rounded-[8px] py-[24px] px-[24px]">
          <WorkingCalendar />
        </div>

        {/* Employee Types */}
        <h2 className="font-bold text-sm mt-[40px]">Employee Types</h2>
        <div className="hidden">
          <p className="text-sm text-[#63666A] mt-[4px]">
            Enter name and click add to add new contracts
          </p>
          <div className="flex space-x-[10px] items-center mb-[10px]">
            <input
              type="text"
              placeholder="type here ..."
              className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] mt-[5px] text-gray-900 text-sm rounded-lg w-full"
            />
            <Button className="py-[11px] px-[16px] bg-primary text-white font-semibold text-sm">
              Add +
            </Button>
          </div>
        </div>

        <div className="mt-3 flex items-center gap-3 flex-wrap">
          <button className="bg-[#DDEFE8] rounded-[4px] border border-[#d9d9d9] py-[4px] px-[8px] text-sm flex items-center space-x-4">
            <span>Full time</span>
          </button>
          <button className="bg-[#DDEFE8] rounded-[4px] border border-[#d9d9d9] py-[4px] px-[8px] text-sm flex items-center space-x-4">
            <span>Contract</span>
          </button>
        </div>

        {/* Delete Organisation */}
        {activeRole?.includes("Admin") && (
          <div>
            <Button
              type="button"
              onClick={() => setIsOrganizationDeleteDialogOpen(true)}
              className="bg-[#FF3B30] hover:bg-[#e2544c] text-white text-sm font-semibold py-[11px] px-[32px] mt-6 disabled:bg-opacity-60"
            >
              Delete Organisation <Trash2 />
            </Button>
          </div>
        )}
      </div>
    </section>
  );
};

export default Settings;
