"use client";

import { RootState } from "@/app/store";
import React from "react";
import { useSelector } from "react-redux";

const UserRoles = () => {
  const user: any = useSelector((state: RootState) => state?.getUser?.user);

  // console.log("user::", user);
  return (
    <div>
      <div className="overflow-x-auto">
        <table className="w-full mt-[24px]">
          <thead className="bg-[#DDEFE8]">
            <tr className=" w-full">
              <th className="text-left p-4 uppercase text-xs font-semibold ">
                S/N
              </th>

              <th className="text-left p-4 uppercase text-xs font-semibold ">
                Name
              </th>

              <th className="text-left p-4 uppercase text-xs font-semibold ">
                Email
              </th>

              <th className="text-left p-4 uppercase text-xs font-semibold ">
                Roles
              </th>
            </tr>
          </thead>

          <tbody className="text-[#1A1A1A]">
            <tr className="border-t border-t-[#E5E7EB] w-full border-b border-b-[#D9D9D9]">
              <td className="text-left p-4 text-sm font-normal ">1</td>

              <td className="text-left p-4 text-sm font-normal ">
                {user?.firstName} {user?.lastName}
              </td>

              <td className="text-left p-4 text-sm font-normal ">
                {user?.email}
              </td>

              <td className="text-left p-4 text-xs font-normal flex gap-2">
                {user?.roles.map((role: any) => (
                  <div key={role?.rank} className="font-medium w-fit bg-[#DDEFE8] p-2 rounded-[4px]">
                    {role?.role}
                  </div>
                ))}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UserRoles;
