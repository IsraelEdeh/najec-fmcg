/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";
import { toast } from "react-toastify";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle
} from "../ui/dialog";
import ApiFetcher from "../Utils/api";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import { Button } from "../ui/button";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { TbLoader } from "react-icons/tb";

type WorkDayTypeNames = {
  [key: number]: string;
};

// Mapping object
const workDayTypeNames: WorkDayTypeNames = {
  1: "Total Days in Month",
  2: "Working Days",
  3: "Fixed Number of Days"
};

// Function to get the name
const getWorkDayTypeName = (workDayType: number): string => {
  return workDayTypeNames[workDayType] || "Unknown Type";
};

const schema = yup
  .object({
    workDayType: yup.string().required("Please select a work day type"),
    fixedDays: yup.string().optional()
  })
  .required();

const WorkingCalendar = () => {
  const [isCalendarConfigOpen, setIsCalendarConfigOpen] = useState(false);
  const [selectedOption, setSelectedOption] = useState("");
  const [fixedDays, setFixedDays] = useState("");
  const queryClient = useQueryClient();

  const handleSelectChange = (event: any) => {
    setSelectedOption(event.target.value);
  };

  const handleFixedDaysChange = (event: any) => {
    setFixedDays(event.target.value);
  };

  const handleCloseCreateDialog = () => {
    setIsCalendarConfigOpen(false);
  };

  const handleOpenCreateDialog = () => {
    setIsCalendarConfigOpen(true);
  };

  const user: any = useSelector((state: RootState) => state?.getUser?.user);
  const organizationId = user?.userOrganizations?.find(
    (item: any) => item.isCurrentLoggedInOrganization
  )?.organizationId;

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const getOrganizationCalendar = async () => {
    try {
      const response = await ApiFetcher.get(
        `/organization/get-work-calendar-configuration/${organizationId}`
      );
      console.log("res::", response);
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching organization configuration";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  const {
    data: configData,
    isPending: configPending,
    isError
  } = useQuery({
    queryKey: ["getOrganizationCalendar"],
    queryFn: getOrganizationCalendar
  });

  const handleConfigSubmit = async (data: any) => {
    try {
      const payload : any = {
        workDayType: Number(data.workDayType),
        fixedNumberOfDays: Number(data.fixedDays) || 0
      };
      console.log("payload", payload);
      const response = await ApiFetcher.post(
        `/organization/create-working-calendar/${organizationId}`,
        payload
      );
      setIsCalendarConfigOpen(false);
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error setting calendar configuration";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const handleUpdateConfigSubmit = async (data: any) => {
    try {
      const payload = {
        workDayType: Number(data.workDayType),
        fixedNumberOfDays: Number(data?.fixedDays) || null
      };
      const response = await ApiFetcher.put(
        `/organization/update-work-calendar-configuration/${organizationId}`,
        payload
      );
      setIsCalendarConfigOpen(false);
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error updating calendar configuration";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(schema)
  });

  const mutation = useMutation({
    mutationFn: configData?.data?.data
      ? handleUpdateConfigSubmit
      : handleConfigSubmit,
    onSuccess: () => {
      reset();
      queryClient.invalidateQueries();
    }
  });

  const onHandlerSubmit = (data: any) => {
    mutation.mutate(data);
  };

  console.log("conf", configData);

  return (
    <Dialog open={isCalendarConfigOpen} onOpenChange={handleCloseCreateDialog}>
      <div className="mt-4">
        <h2 className="font-bold text-sm">Working calendar</h2>
        <p className="text-sm text-[#63666A] mt-[4px]">
          Create a working calendar for your organisation
        </p>
        <div className="mt-2">
          {/* {isError && <div className="italic">Work calendar not found.</div>} */}
          <div className="flex items-center space-x-4 mb-3">
            {/* <p>1</p> */}
            <p>
              {" "}
              {configPending ? (
                <TbLoader className="animate-spin" />
              ) : isError ? (
                <div className="italic">Work calendar not found.</div>
              ) : (
                <p className="flex items-center space-x-4">
                  <span>
                    {" "}
                    {getWorkDayTypeName(
                      configData?.data?.data?.workDayType || 0
                    )}
                  </span>

                  <span>
                    {configData?.data?.data?.fixedNumberOfDays
                      ? `${configData?.data?.data?.fixedNumberOfDays} days`
                      : ""}
                  </span>
                </p>
              )}
               </p>

                    {(activeRole?.includes("Admin") ||
                activeRole?.includes("Initiator")) && (
                <>
                  {configData?.data?.data ? (
                    <Button
                      type="submit"
                      onClick={handleOpenCreateDialog}
                      className="disabled:bg-secondary disabled:bg-opacity-60 rounded-[10px] bg-secondary text-white text-xs font-semibold px-[22px]"
                    >
                      Update
                    </Button>
                  ) : (
                    <Button
                      type="submit"
                      onClick={handleOpenCreateDialog}
                      className="disabled:bg-secondary disabled:bg-opacity-60 rounded-[10px] bg-secondary text-white text-xs font-semibold px-[22px]"
                    >
                      Add calendar
                    </Button>
                  )}
                </>
              )}

          </div>
        </div>
       
      </div>
      <DialogContent className="bg-white z-50">
        <DialogHeader>
          <DialogTitle className="text-xl">Create Working Calendar</DialogTitle>
          <DialogDescription className="pt-1">
            <div className="font-semibold">
              Create a working calendar for an organisation
            </div>
          </DialogDescription>
          <form
            onSubmit={handleSubmit(onHandlerSubmit)}
            className="space-y-4 pt-6"
          >
            <div>
              <select
                {...register("workDayType")}
                value={selectedOption}
                onChange={handleSelectChange}
                className="rounded-[4px] border py-2.5 pl-3 w-full"
              >
                <option value="">Select work day type</option>
                <option value="1">Total days in month</option>
                <option value="2">Working days</option>
                <option value="3">Fixed number of days</option>
              </select>
            </div>
            <div>
              {selectedOption === "3" && (
                <div>
                  <input
                    type="text"
                    placeholder="Fixed number of days"
                    className="rounded-[4px] border py-2.5 pl-3 w-full"
                    {...register("fixedDays")}
                    // value={fixedDays}
                    onChange={handleFixedDaysChange}
                  />
                </div>
              )}
            </div>
            <div>
              <Button
                type="submit"
                disabled={mutation.isPending}
                className="disabled:bg-secondary disabled:bg-opacity-60  bg-primary text-white text-sm font-semibold py-[11px] px-[32px] w-[30%]"
              >
                {mutation.isPending ? "Saving..." : "Save configuration"}
              </Button>
            </div>
          </form>
        </DialogHeader>
      </DialogContent>
    </Dialog>
  );
};

export default WorkingCalendar;
