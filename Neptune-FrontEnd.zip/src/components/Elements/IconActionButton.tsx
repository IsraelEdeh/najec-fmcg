"use client";

import React from "react";
import { TbLoader3 } from "react-icons/tb";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

type Tone = "primary" | "warning" | "danger" | "neutral";

const toneClasses: Record<Tone, string> = {
  primary: "text-primary hover:bg-[#DDEFE8] hover:border-[#B5DCCB]",
  warning: "text-amber-600 hover:bg-amber-50 hover:border-amber-200",
  danger: "text-[#63666A] hover:text-red-600 hover:bg-red-50 hover:border-red-200",
  neutral: "text-[#63666A] hover:text-primary hover:bg-[#F2F8F5] hover:border-[#D9D9D9]"
};

interface IconActionButtonProps {
  label: string;
  icon: React.ReactNode;
  onClick?: () => void;
  tone?: Tone;
  loading?: boolean;
  loadingLabel?: string;
  disabled?: boolean;
  // Shown instead of the label, e.g. to explain why the action is disabled.
  hint?: React.ReactNode;
}

const IconActionButton = ({
  label,
  icon,
  onClick,
  tone = "neutral",
  loading = false,
  loadingLabel,
  disabled = false,
  hint
}: IconActionButtonProps) => {
  const isDisabled = disabled || loading;
  const accessibleLabel = loading && loadingLabel ? loadingLabel : label;

  const button = (
    <button
      type="button"
      aria-label={accessibleLabel}
      aria-busy={loading || undefined}
      onClick={onClick}
      disabled={isDisabled}
      className={cn(
        "inline-flex h-9 w-9 items-center justify-center rounded-full border border-transparent bg-white transition-all duration-150",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-1",
        "active:scale-95 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-white disabled:hover:border-transparent",
        "[&_svg]:h-[18px] [&_svg]:w-[18px]",
        toneClasses[tone]
      )}
    >
      {loading ? <TbLoader3 className="animate-spin" aria-hidden /> : icon}
    </button>
  );

  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          {/* Disabled buttons don't emit pointer/focus events, so a focusable wrapper keeps the tooltip reachable. */}
          {isDisabled ? (
            <span
              tabIndex={0}
              className="inline-flex rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-primary [&>*]:pointer-events-none"
            >
              {button}
            </span>
          ) : (
            button
          )}
        </TooltipTrigger>
        <TooltipContent
          side="top"
          className="max-w-xs border-none bg-[#1E1E1E] text-xs text-white shadow-lg"
        >
          {hint ?? accessibleLabel}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default IconActionButton;
