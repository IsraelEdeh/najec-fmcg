import React, { useState } from "react";
import CustomButton from "@/components/Elements/CustomButton";
import { useQuery } from "@tanstack/react-query";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import Image from "next/image";
import { HiMiniChevronDown } from "react-icons/hi2";
import {
  countryCodeToFlag,
  fetchDeparments,
  fetchJobTitles,
  fetchEmployeesGrade,
  fetchCostCenter,
  fetchSubsidiaries
} from "@/constants";
import ReactCountryFlag from "react-country-flag";

const AddEmployeesBasic = ({
  next,
  register,
  errors,
  countryData
}: {
  next: () => void;
  register: any;
  errors: any;
  countryData: any;
}) => {
  // const [selectedCode, setSelectedCode] = useState<string>("+234");
  // const [selectedFlag, setSelectedFlag] = useState<any>(
  //   `data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAAT4AAACfCAMAAABX0UX9AAAACVBMVEUAh1H///8AgUWLtPGkAAABX0lEQVR4nO3QQQ0AIAzAwIF/0Yi4ZA/Sc9DObLlnzV2L2tM+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+0j7SPtI+8uW+B3AYRFPn9q1JAAAAAElFTkSuQmCC`
  // );

  const [selectedCode, setSelectedCode] = useState<string>("+234");
  const [selectedFlag, setSelectedFlag] = useState<string>("NG");
  const [selectedCountryId, setSelectedCountryId] = useState<number>(1);

  const handleFlagSelected = (id: string) => {
    return countryCodeToFlag[id] || countryCodeToFlag["default"];
  };
  const handleCodeSelect = (code: string, flag: string, id: number) => {
    setSelectedCode(code);
    setSelectedFlag(flag);
    setSelectedCountryId(id);
  };

  const today = new Date().toISOString().split("T")[0];

  const { isLoading, data, error } = useQuery({
    queryKey: ["addEmployeesDepartments"],
    queryFn: fetchDeparments
  });

  const {
    isLoading: isLoadingJobTitles,
    data: jobTitlesData,
    error: jobTitlesError
  } = useQuery({
    queryKey: ["addEmployeesJobTitles"],
    queryFn: fetchJobTitles
  });

  const { isPending: isLodingcostCenter, data: costCenterData } = useQuery({
    queryKey: ["addCostCenter"],
    queryFn: fetchCostCenter
  });

  const { isPending: isLodingSubsidiaries, data: subsidiariesData } = useQuery({
    queryKey: ["addSubsidiaries"],
    queryFn: fetchSubsidiaries
  });

  const {
    isLoading: isLoadingEmployeesGrade,
    data: employeesGradeData,
    error: employeesGradeError
  } = useQuery({
    queryKey: ["addEmployeesGrades"],
    queryFn: fetchEmployeesGrade
  });

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="md:col-span-2">
          <label
            htmlFor="staffNumber"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Staff number
          </label>
          <input
            type="text"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder="eg. E0000001"
            {...register("staffNumber", {
              required: true,
              minLength: 3
            })}
            required
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.staffNumber?.message}
          </p>
        </div>

        <div>
          <label
            htmlFor="firstName"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            First Name
          </label>
          <input
            type="text"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder=""
            {...register("firstName", {
              required: true,
              minLength: 3
            })}
            required
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.firstName?.message}
          </p>
        </div>

        <div>
          <label
            htmlFor="lastName"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Last Name
          </label>
          <input
            type="text"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder=""
            {...register("lastName", {
              required: true,
              minLength: 3
            })}
            required
          />
        </div>

        <div className="col-span-1">
          <label
            htmlFor="middleName"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Middle Name
          </label>
          <input
            type="text"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder=""
            {...register("middleName", {
              required: true,
              minLength: 3
            })}
            required
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.middleName?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="dateJoined"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Date Joined
          </label>
          <input
            id="dateJoined"
            type="date"
            max={today}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            {...register("dateJoined")}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.dateJoined?.message}
          </p>
        </div>

        <div className="col-span-1">
          <label
            htmlFor="phoneNumber"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Phone number
          </label>
          <div className="relative">
            <div className="absolute left-3 top-3 z-40 flex items-center space-x-2 ">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    className="flex outline-none items-center space-x-1 px-2 text-sm border-none text-[#1E1E1E] bg-none"
                    type="button"
                  >
                    <ReactCountryFlag
                      countryCode={selectedFlag}
                      style={{
                        fontSize: "2em",
                        lineHeight: "2em"
                      }}
                      svg
                    />
                    <span>{selectedCode}</span>
                    <HiMiniChevronDown />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 bg-white">
                  <DropdownMenuGroup>
                    {countryData?.data?.data?.data?.map((code: any) => (
                      <DropdownMenuItem
                        key={code.id}
                        className="flex space-x-1 cursor-pointer"
                        onClick={() =>
                          handleCodeSelect(
                            code.countryCode,
                            handleFlagSelected(code.countryCode),
                            code.id
                          )
                        }
                      >
                        <Image
                          src={`data:image/png;base64, ${code.flag}`}
                          alt="flag"
                          width={24}
                          height={24}
                          className="w-6 h-6"
                        />
                        <span>{code.countryCode}</span>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <input
              id="phoneNumber"
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              {...register("phoneNumber")}
              className={`relative bg-none z-30 w-full text-16 py-3 pl-[110px] pr-3 rounded-[4px] border border-[#D0D0CE] text-gray-900 placeholder:text-gray-500`}
            />
            <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
              {errors.phoneNumber?.message}
            </p>
          </div>

          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.phoneNumber?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="employmentType"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Employment type
          </label>
          <select
            {...register("employmentType", {
              required: true
            })}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
          >
            <option>Select employment type</option>
            <option value={0}>Full time</option>
            <option value={1}>Contract</option>
          </select>
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.employmentType?.message}
          </p>
        </div>

        {/* <div className="md:col-span-1">
          <label
            htmlFor="jobTitle"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Job title
          </label>
          <input
            type="text"
            {...register("jobTitle", {
              required: true,
              minLength: 3
            })}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder="Type here..."
            required
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.jobTitle?.message}
          </p>
        </div> */}

        <div className="md:col-span-2">
          <label
            htmlFor="departmentId"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Department
          </label>
          <select
            id="departmentId"
            {...register("departmentId")}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
          >
            <option value="">Select department</option>
            {data?.data?.data.map((item: any, index: number) => (
              <option value={item?.id} key={item?.name}>
                {item?.name}
              </option>
            ))}
          </select>
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.departmentId?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="employeeJobTitleId"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Job Title
          </label>
          <select
            {...register("employeeJobTitleId", {
              required: true
            })}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
          >
            <option value="">Select job title</option>
            {jobTitlesData?.data?.data.map((item: any, index: number) => (
              <option value={item?.id} key={item?.name}>
                {item?.name}
              </option>
            ))}
          </select>
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.employeeJobTitleId?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="employeeGradeId"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Employee Grade
          </label>
          <select
            {...register("employeeGradeId", {
              required: true
            })}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
          >
            <option value="">Select employee grade</option>
            {employeesGradeData?.data?.data.map((item: any, index: number) => (
              <option value={item?.id} key={item?.name}>
                {item?.name}
              </option>
            ))}
          </select>
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.employeeGradeId?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="costCenterId"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Select cost center
          </label>
          <select
            id="costCenterId"
            {...register("costCenterId")}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
          >
            <option value="">No cost center</option>
            {costCenterData?.data?.data.map((item: any, index: number) => (
              <option value={item?.id} key={item?.name}>
                {item?.name}
              </option>
            ))}
          </select>
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.costCenterId?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="subsidiaryId"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Select subsidiary
          </label>
          <select
            {...register("subsidiaryId", {
              required: true
            })}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
          >
            <option value="">Select subsidiary</option>
            {subsidiariesData?.data?.data.map((item: any, index: number) => (
              <option value={item?.id} key={item?.name}>
                {item?.name}
              </option>
            ))}
          </select>
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.subsidiaryId?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="staffNumber"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Payer ID
          </label>
          <input
            type="text"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder="eg. E0000001"
            {...register("payerId", {
              required: true,
              minLength: 3
            })}
            required
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors?.payerId?.message}
          </p>
        </div>
      </div>

      <div className="flex justify-end mt-10">
        <div className="flex items-center space-x-6">
          {/* <CustomButton
            type="button"
            classType="secondary"
            className="px-[45px] py-[11px]"
          >
            Cancel
          </CustomButton> */}
          <CustomButton
            type="button"
            onClick={next}
            classType="primary"
            className="px-[103px] py-[11px]"
          >
            Next
          </CustomButton>
        </div>
      </div>
    </div>
  );
};

export default AddEmployeesBasic;
