import React from "react";
import CustomButton from "@/components/Elements/CustomButton";
import { ICountryDataResponse, pfas, slugify } from "@/constants";
import useBank from "@/hooks/Custom-hook/useBank";
import useStates from "@/hooks/Custom-hook/useStates";
import { GENDER_OPTIONS, todayDateOnly } from "@/lib/employee-mappers";

const AddEmployeesPersonal = ({
  returnNext,
  register,
  errors,
  countryData,
  isPending,
  watch
}: {
  returnNext: () => void;
  register: any;
  errors: any;
  countryData: any;
  isPending: boolean;
  watch: any;
}) => {
  const nhfExistsChecked = watch("nhfExists");
  const pensionExemptChecked = watch("isPensionExempt");

  const { banks, loadingBanks } = useBank();
  const { states, loadingStates } = useStates();
  // console.log("state::", states);

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="hidden md:col-span-2 w-[full]  sm:w-[40%]  items-center mb-4 p-3 border-[1px] border-gray-400 rounded-xl">
          <div className="bg-gray-200 w-16 h-16 rounded-full flex justify-center items-center mr-4"></div>
          <span className="bg-primary text-sm text-white cursor-pointer font-medium py-2 px-4 rounded-[4px]">
            Add Photo
          </span>
          <input
            type="file"
            //   ref={fileInputRef}
            //   onChange={handleFileChange}
            accept="image/*"
            className="hidden"
          />
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="gender"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Gender
          </label>
          <select
            id="gender"
            {...register("gender")}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
          >
            {GENDER_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>

          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.gender?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="dateOfBirth"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Date of birth
          </label>
          <input
            id="dateOfBirth"
            type="date"
            max={todayDateOnly()}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            {...register("dateOfBirth")}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.dateOfBirth?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="email"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Email
          </label>
          <input
            type="email"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder="example@mail.com"
            {...register("email", {
              required: true,
              minLength: 3
            })}
            required
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.email?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="rsaPin"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            RSA pin
          </label>
          <input
            id="rsaPin"
            type="text"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder="e.g PEN1..."
            {...register("rsaPin")}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.rsaPin?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="pensionFundAdministrator"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Pension fund administrator
          </label>

          <select
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            {...register("pensionFundAdministrator", {
              required: true
            })}
          >
            <option value="">Select licensed PFA</option>
            {pfas.map((pfa) => (
              <option key={slugify(pfa)} value={slugify(pfa)}>
                {pfa}
              </option>
            ))}
          </select>
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.pensionFundAdministrator?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="bankName"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Bank name
          </label>

          <select
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            {...register("bankName", {
              required: true
            })}
          >
            <option value="">Select bank</option>
            {loadingBanks
              ? "loading"
              : banks?.map((bank: any) => (
                  <option key={bank?.id} value={bank?.bankName}>
                    {bank?.bankName}
                  </option>
                ))}
          </select>
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.bankName?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="text"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Account number
          </label>
          <input
            type="number"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder="3010903030"
            {...register("accountNumber", {
              required: true
            })}
            required
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.accountNumber?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="text"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Account name
          </label>
          <input
            type="text"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder="John Doe"
            {...register("accountName", {
              required: true,
              minLength: 3
            })}
            required
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.accountName?.message}
          </p>
        </div>

        <div className="md:col-span-2 grid grid-cols-3 gap-x-2 my-2">
          <div className="md:col-span-1 text-sm">
            <input type="checkbox" id="nhfExists" {...register("nhfExists")} />
            <label htmlFor="nhfExists" className="pl-1 ">
              Does NHF exist?
            </label>
          </div>

          <div className="md:col-span-1 text-sm">
            <input
              type="checkbox"
              id="nhisExists"
              {...register("nhisExists")}
              value="true"
            />
            <label htmlFor="nhisExists" className="pl-1 ">
              {" "}
              Does NHIS exist?
            </label>
          </div>

          <div className="md:col-span-1 text-sm">
            <input
              type="checkbox"
              id="voluntaryPensionExists"
              {...register("voluntaryPensionExists")}
              value="true"
              disabled={pensionExemptChecked}
            />
            <label htmlFor="voluntaryPensionExists" className="pl-1">
              {" "}
              Does Voluntary Pension exist?
            </label>
          </div>

          <div className="md:col-span-1 text-sm">
            <input
              type="checkbox"
              id="isPensionExempt"
              {...register("isPensionExempt")}
            />
            <label htmlFor="isPensionExempt" className="pl-1">
              Pension Exempt
            </label>
            <p className="pl-5 text-xs text-gray-600">
              No employee, employer or voluntary pension.
            </p>
          </div>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="text"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            NHF number
          </label>
          <input
            type="text"
            className="disabled:bg-gray-100 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder="NF00000001234"
            {...register("nhfNumber", {
              required: true,
              minLength: 4
            })}
            disabled={!nhfExistsChecked}
            required
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.nhfNumber?.message}
          </p>
        </div>

        {/* <div className="md:col-span-1">
          <label
            htmlFor="text"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Gross salary
          </label>
          <input
            type="number"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder="₦34,800,000"
            {...register("annualGrossSalary", {
              required: true
            })}
            required
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.annualGrossSalary?.message}
          </p>
        </div> */}

        <div className="md:col-span-1">
          <label
            htmlFor="taxAuthority"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Tax authority
          </label>

          <select
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            {...register("taxAuthority", {
              required: true
            })}
          >
            <option value="">Select tax authority</option>
            <option value="Abia(ABIRS)"> Abia(ABIRS)</option>
            <option value="Adamawa(ADIRS)"> Adamawa(ADIRS)</option>
            <option value="Akwa Ibom(AKIRS)"> Akwa Ibom(AKIRS)</option>
            <option value="Anambra(ANIRS)"> Anambra(ANIRS)</option>
            <option value="Bauchi(BAIRS)"> Bauchi(BAIRS)</option>
            <option value="Bayelsa(BYIRS)"> Bayelsa(BYIRS)</option>
            <option value="Benue(BEIRS)"> Benue(BEIRS)</option>
            <option value="Borno(BOIRS)"> Borno(BOIRS)</option>
            <option value="Cross River(CRIRS)"> Cross River(CRIRS)</option>
            <option value="Delta(DEIRS)"> Delta(DEIRS)</option>
            <option value="Ebonyi(EBIRS)"> Ebonyi(EBIRS)</option>
            <option value="Edo(EDIRS)"> Edo(EDIRS)</option>
            <option value="Ekiti(EKIRS)"> Ekiti(EKIRS)</option>
            <option value="Enugu(ENIRS)"> Enugu(ENIRS)</option>
            <option value="Federal Capital Territory(FCTIRS)">
              Federal Capital Territory(FCTIRS)
            </option>
            <option value="Gombe(GOIRS)"> Gombe(GOIRS)</option>
            <option value="Imo(IMIRS)"> Imo(IMIRS)</option>
            <option value="Jigawa(JIIRS)"> Jigawa(JIIRS)</option>
            <option value="Kaduna(KDIRS)"> Kaduna(KDIRS)</option>
            <option value="Kano(KNIRS)"> Kano(KNIRS)</option>
            <option value="Katsina(KTIRS)"> Katsina(KTIRS)</option>
            <option value="Kebbi(KEIRS)"> Kebbi(KEIRS)</option>
            <option value="Kogi(KOIRS)"> Kogi(KOIRS)</option>
            <option value="Kwara(KWIRS)"> Kwara(KWIRS)</option>
            <option value="Lagos(LIRS)"> Lagos(LIRS)</option>
            <option value="Nasarawa(NAIRS)"> Nasarawa(NAIRS)</option>
            <option value="Niger(NIIRS)"> Niger(NIIRS)</option>
            <option value="Ogun(OGIRS)"> Ogun(OGIRS)</option>
            <option value="Ondo(ONIRS)"> Ondo(ONIRS)</option>
            <option value="Osun(OSIRS)"> Osun(OSIRS)</option>
            <option value="Oyo(OYIRS)"> Oyo(OYIRS)</option>
            <option value="Plateau(PLIRS)"> Plateau(PLIRS)</option>
            <option value="Rivers(RIIRS)"> Rivers(RIIRS)</option>
            <option value="Sokoto(SOIRS)"> Sokoto(SOIRS)</option>
            <option value="Taraba(TAIRS)"> Taraba(TAIRS)</option>
            <option value="Yobe(YOIRS)"> Yobe(YOIRS)</option>
            <option value="Zamfara(ZAIRS)"> Zamfara(ZAIRS)</option>
          </select>
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.taxAuthority?.message}
          </p>
        </div>

        <div className="md:col-span-2">
          <label
            htmlFor="address"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Residential address
          </label>
          <textarea
            id="address"
            rows={3}
            cols={4}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            placeholder="3, Coker street . . ."
            {...register("address")}
          ></textarea>

          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.address?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="countryId"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Country
          </label>
          <select
            placeholder="Select country"
            {...register("countryId", {
              required: true
            })}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
          >
            <option value="">Select country</option>
            {isPending ? (
              "loading"
            ) : !isPending && countryData ? (
              countryData?.data?.data?.data?.map(
                (country: ICountryDataResponse) => (
                  <option value={country.id} key={country.id}>
                    <>{country.name}</>
                  </option>
                )
              )
            ) : (
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                Error loading country data.
              </p>
            )}
          </select>

          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.countryId?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="stateId"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            State
          </label>

          <select
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
            {...register("stateId")}
          >
            <option value="">Select state</option>
            {loadingStates
              ? "loading"
              : states?.map((states: any) => (
                  <option key={states?.id} value={states?.id}>
                    {states?.name}
                  </option>
                ))}
          </select>
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.stateId?.message}
          </p>
        </div>
      </div>

      <div className="flex justify-end mt-10">
        <div className="flex items-center space-x-6">
          <CustomButton
            type="button"
            onClick={returnNext}
            classType="secondary"
            className="px-[45px] py-[11px]"
          >
            Back
          </CustomButton>
          <CustomButton
            type="submit"
            classType="primary"
            disabled={isPending}
            className="px-[103px] py-[11px] disabled:bg-secondary disabled:bg-opacity-70"
          >
            {isPending ? "Adding" : "Add Employee"}
          </CustomButton>
        </div>
      </div>
    </>
  );
};

export default AddEmployeesPersonal;
