"use client";

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import ApiFetcher from "@/components/Utils/api";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type {
  EmployeeEntitlement,
  SaveAnnualEntitlementRequest
} from "@/types/backend";
import EmployeeFeatureTabs from "./EmployeeFeatureTabs";

interface AnnualEntitlementsProps {
  employeeId: string;
  dateJoined?: string;
}

const getData = (response: any) =>
  response?.data?.data ?? response?.data ?? response ?? [];

const getComponentId = (component: any) =>
  Number(component?.id ?? component?.payComponentId ?? component?.value);

const getComponentName = (component: any) =>
  component?.name ?? component?.payComponentName ?? component?.label ?? "";

const getEntitlements = (response: any): EmployeeEntitlement[] => {
  const data = getData(response);
  const rows = Array.isArray(data) ? data : data?.items ?? data?.data ?? [];
  return Array.isArray(rows) ? rows : [];
};

export default function AnnualEntitlements({
  employeeId,
  dateJoined
}: AnnualEntitlementsProps) {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState<EmployeeEntitlement | null>(null);
  const [payComponentId, setPayComponentId] = useState("");
  const [annualAmount, setAnnualAmount] = useState("");
  const [effectiveFrom, setEffectiveFrom] = useState("");
  const [sortBy, setSortBy] = useState<"component" | "date">("component");
  const [isSaving, setIsSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [activeTab, setActiveTab] = useState("Overview");

  const { data: entitlements = [], isPending } = useQuery({
    queryKey: ["annualEntitlements", employeeId],
    queryFn: async () =>
      getEntitlements(
        await ApiFetcher.get(
          `/annual-entitlement/get-employee-entitlements/${employeeId}`
        )
      )
  });

  const { data: annualComponents = [] } = useQuery({
    queryKey: ["annualAllowanceComponents"],
    queryFn: async () => {
      const response = await ApiFetcher.get(
        "/tax/get-all-allowanceItems?PageNumber=1&PageSize=1000"
      );
      const page = response?.data;
      const pageData = page?.data;
      const components =
        (Array.isArray(pageData) ? pageData : pageData?.items ?? pageData?.data) ??
        page?.items ??
        getData(response);

      return (Array.isArray(components) ? components : []).filter(
        (component: any) =>
          getComponentId(component) > 0 && component?.paymentMonth != null
      );
    }
  });

  const resetForm = () => {
    setEditing(null);
    setPayComponentId("");
    setAnnualAmount("");
    setEffectiveFrom("");
  };

  const saveEntitlement = async (event: React.FormEvent) => {
    event.preventDefault();
    const amount = Number(annualAmount);
    const joinDate = dateJoined ? new Date(dateJoined) : null;
    const selectedDate = effectiveFrom ? new Date(effectiveFrom) : null;
    const selectedComponent = annualComponents.find(
      (component: any) => String(getComponentId(component)) === payComponentId
    );

    if (!payComponentId || !selectedComponent) {
      toast.error("Component must be an annual item");
      return;
    }
    if (!Number.isFinite(amount) || amount < 0) {
      toast.error("Annual amount must be greater than or equal to 0");
      return;
    }
    if (!selectedDate) {
      toast.error("Effective date is required");
      return;
    }
    if (joinDate && selectedDate < joinDate) {
      toast.error("Effective date cannot predate employee join date");
      return;
    }

    const payload: SaveAnnualEntitlementRequest = {
      payComponentId: Number(payComponentId),
      annualAmount: amount,
      effectiveFrom: selectedDate.toISOString()
    };

    try {
      setIsSaving(true);
      await ApiFetcher.post(
        `/annual-entitlement/save-employee-entitlement/${employeeId}`,
        payload
      );
      toast.success(editing ? "Annual entitlement updated successfully" : "Annual entitlement created successfully");
      await queryClient.invalidateQueries({
        queryKey: ["annualEntitlements", employeeId]
      });
      resetForm();
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Unable to save annual entitlement");
    } finally {
      setIsSaving(false);
    }
  };

  const editEntitlement = (entitlement: EmployeeEntitlement) => {
    setEditing(entitlement);
    setPayComponentId(String(entitlement.payComponentId));
    setAnnualAmount(String(entitlement.annualAmount ?? ""));
    setEffectiveFrom(entitlement.effectiveFrom?.split("T")[0] ?? "");
  };

  const deleteEntitlement = async (id: number) => {
    try {
      await ApiFetcher.delete(`/annual-entitlement/delete-entitlement/${id}`);
      toast.success("Annual entitlement deleted successfully");
      await queryClient.invalidateQueries({
        queryKey: ["annualEntitlements", employeeId]
      });
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Unable to delete annual entitlement");
    }
  };

  const downloadTemplate = async () => {
    try {
      const response = await ApiFetcher.get(
        "/annual-entitlement/download-entitlement-template",
        { responseType: "blob" }
      );
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = "annual-entitlement-template.xlsx";
      anchor.click();
      window.URL.revokeObjectURL(url);
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Unable to download template");
    }
  };

  const uploadEntitlements = async (file?: File) => {
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);
    try {
      setUploading(true);
      await ApiFetcher.post("/annual-entitlement/upload-entitlements", formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      toast.success("Annual entitlements uploaded successfully");
      await queryClient.invalidateQueries({
        queryKey: ["annualEntitlements", employeeId]
      });
    } catch (error: any) {
      const errors = error?.response?.data?.errors;
      if (Array.isArray(errors)) {
        errors.forEach((message: any) =>
          toast.error(typeof message === "string" ? message : JSON.stringify(message))
        );
      } else {
        toast.error(error?.response?.data?.message || "Unable to upload annual entitlements");
      }
    } finally {
      setUploading(false);
    }
  };

  const sortedEntitlements = [...entitlements].sort((left, right) => {
    if (sortBy === "date") {
      return String(left.effectiveFrom).localeCompare(String(right.effectiveFrom));
    }
    return String(left.payComponentName ?? left.componentName ?? "").localeCompare(
      String(right.payComponentName ?? right.componentName ?? "")
    );
  });

  return (
    <section className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Annual Entitlements</h2>
          <p className="text-sm text-gray-600">
            Configure annual pay component entitlements for this employee.
          </p>
        </div>
        <Badge className="border-blue-200 bg-blue-50 text-blue-700">
          {entitlements.length} items
        </Badge>
      </div>

      <EmployeeFeatureTabs
        tabs={["Overview", "Bulk upload"]}
        activeTab={activeTab}
        onChange={setActiveTab}
      />

      <p className="rounded border border-blue-100 bg-blue-50 p-3 text-sm text-blue-900">
        Annual items are no longer in the payroll schedule template. Enter them
        here with the date the amount takes effect.
      </p>

      {activeTab === "Bulk upload" && (
        <div className="rounded border border-[#D9D9D9] bg-white p-4">
          <p className="mb-3 text-sm text-gray-600">
            Download a template or upload annual entitlement rows. Validation
            errors returned by the backend are shown after upload.
          </p>
          <div className="flex flex-wrap items-center gap-3">
        <Button type="button" variant="outline" onClick={downloadTemplate}>
          Download template
        </Button>
        <label className="cursor-pointer rounded border px-3 py-2 text-sm">
          {uploading ? "Uploading..." : "Upload entitlements"}
          <input
            type="file"
            accept=".csv,.xlsx,.xls"
            className="hidden"
            disabled={uploading}
            onChange={(event) => uploadEntitlements(event.target.files?.[0])}
          />
        </label>
          </div>
      </div>
      )}

      {activeTab === "Overview" && <>
      <form onSubmit={saveEntitlement} className="grid grid-cols-1 gap-4 rounded border border-[#D9D9D9] bg-white p-4 md:grid-cols-3">
        <label className="text-sm">
          Component
          <select
            value={payComponentId}
            onChange={(event) => setPayComponentId(event.target.value)}
            className="mt-1 w-full rounded border p-2"
            required
          >
            <option value="">Select annual component</option>
            {annualComponents.map((component: any) => (
              <option key={getComponentId(component)} value={getComponentId(component)}>
                {getComponentName(component)}
              </option>
            ))}
          </select>
        </label>
        <label className="text-sm">
          Annual amount
          <input
            type="number"
            min="0"
            step="0.01"
            value={annualAmount}
            onChange={(event) => setAnnualAmount(event.target.value)}
            className="mt-1 w-full rounded border p-2"
            required
          />
        </label>
        <label className="text-sm">
          Effective from
          <input
            type="date"
            min={dateJoined?.split("T")[0]}
            value={effectiveFrom}
            onChange={(event) => setEffectiveFrom(event.target.value)}
            className="mt-1 w-full rounded border p-2"
            required
          />
        </label>
        <div className="flex gap-2 md:col-span-3">
          <Button type="submit" disabled={isSaving} className="bg-primary text-white">
            {isSaving ? "Saving..." : editing ? "Update entitlement" : "Add entitlement"}
          </Button>
          {editing && (
            <Button type="button" variant="outline" onClick={resetForm}>
              Cancel
            </Button>
          )}
        </div>
      </form>

      <div className="flex items-center justify-end gap-2 text-sm">
        <span>Sort by</span>
        <select
          value={sortBy}
          onChange={(event) => setSortBy(event.target.value as "component" | "date")}
          className="rounded border p-1"
        >
          <option value="component">Component</option>
          <option value="date">Date</option>
        </select>
      </div>

      <div className="overflow-x-auto rounded border border-[#D9D9D9] bg-white">
        <table className="w-full text-left text-sm">
          <thead className="bg-[#DDEFE8]">
            <tr>
              <th className="p-3">Component</th>
              <th className="p-3">Annual Amount</th>
              <th className="p-3">Effective From</th>
              <th className="p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {isPending ? (
              <tr><td className="p-3" colSpan={4}>Loading...</td></tr>
            ) : sortedEntitlements.length === 0 ? (
              <tr><td className="p-3" colSpan={4}>No annual entitlements found.</td></tr>
            ) : (
              sortedEntitlements.map((entitlement) => (
                <tr key={entitlement.id} className="border-t">
                  <td className="p-3">{entitlement.payComponentName ?? entitlement.componentName ?? entitlement.payComponentId}</td>
                  <td className="p-3">{entitlement.annualAmount}</td>
                  <td className="p-3">{entitlement.effectiveFrom?.split("T")[0]}</td>
                  <td className="flex gap-2 p-3">
                    <Button type="button" variant="outline" onClick={() => editEntitlement(entitlement)}>
                      Edit
                    </Button>
                    <Button type="button" variant="outline" onClick={() => deleteEntitlement(entitlement.id)}>
                      Delete
                    </Button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      </>}
    </section>
  );
}
