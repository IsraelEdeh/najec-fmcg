import {
  fetchCostCenter,
  fetchDeparments,
  fetchEmployeesGrade,
  fetchJobTitles,
  fetchSubsidiaries
} from "@/constants";
import useStates from "@/hooks/Custom-hook/useStates";
import { todayDateOnly } from "@/lib/employee-mappers";
import type {
  EmployeeEditFormValues,
  EmployeeLookup,
  EmployeeResponse
} from "@/types/employee";
import { useQuery } from "@tanstack/react-query";
import React from "react";
import type { FieldErrors, UseFormRegister } from "react-hook-form";
import EmployeeSelectField, {
  employeeFieldClassName,
  type EmployeeSelectOption
} from "./EmployeeSelectField";

const toOptions = (items: unknown): EmployeeSelectOption[] =>
  Array.isArray(items)
    ? items
        .filter((item: Partial<EmployeeLookup>) => item?.id !== undefined && item?.id !== null)
        .map((item: EmployeeLookup) => ({
          value: String(item.id),
          label: String(item.name ?? item.id)
        }))
    : [];

const toCurrentOption = (
  lookup: EmployeeLookup | string | null | undefined
): EmployeeSelectOption | undefined =>
  lookup && typeof lookup === "object" && lookup.id !== undefined && lookup.id !== null
    ? { value: String(lookup.id), label: lookup.name }
    : undefined;

const employmentTypeOptions: EmployeeSelectOption[] = [
  { value: "0", label: "Fulltime" },
  { value: "1", label: "Contract" }
];

const BasicEmployeesDetails = ({
  employeeData,
  register,
  employeeCountryData,
  isCountryLoading,
  errors
}: {
  employeeData?: EmployeeResponse;
  register: UseFormRegister<EmployeeEditFormValues>;
  employeeCountryData: any;
  isCountryLoading: boolean;
  errors: FieldErrors<EmployeeEditFormValues>;
}) => {
  const { isPending: isLoadingDepartments, data: departmentsData } = useQuery({
    queryKey: ["addEmployeesDepartments"],
    queryFn: fetchDeparments
  });

  const { isPending: isLoadingJobTitles, data: jobTitlesData } = useQuery({
    queryKey: ["addJobTitles"],
    queryFn: fetchJobTitles
  });

  const { isPending: isLoadingGrades, data: employeesGradeData } = useQuery({
    queryKey: ["addEmployeesGrades"],
    queryFn: fetchEmployeesGrade
  });

  const { isPending: isLoadingCostCenters, data: costCenterData } = useQuery({
    queryKey: ["addCostCenter"],
    queryFn: fetchCostCenter
  });

  const { isPending: isLoadingSubsidiaries, data: subsidiariesData } = useQuery({
    queryKey: ["addSubsidiaries"],
    queryFn: fetchSubsidiaries
  });

  const { states, loadingStates } = useStates();

  const today = todayDateOnly();

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="md:col-span-2">
          <label
            htmlFor="staffNumber"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Staff ID / Tag
          </label>
          <input
            id="staffNumber"
            type="text"
            {...register("staffNumber")}
            className={employeeFieldClassName}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.staffNumber?.message}
          </p>
        </div>

        <div className="col-span-1">
          <label
            htmlFor="firstName"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            First Name
          </label>
          <input
            id="firstName"
            type="text"
            {...register("firstName")}
            className={employeeFieldClassName}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.firstName?.message}
          </p>
        </div>

        <div className="col-span-1">
          <label
            htmlFor="lastName"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Last Name
          </label>
          <input
            id="lastName"
            type="text"
            {...register("lastName")}
            className={employeeFieldClassName}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.lastName?.message}
          </p>
        </div>

        <div className="md:col-span-1">
          <label
            htmlFor="middleName"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Other Names
          </label>
          <input
            id="middleName"
            type="text"
            {...register("middleName")}
            className={employeeFieldClassName}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.middleName?.message}
          </p>
        </div>

        <EmployeeSelectField
          id="countryId"
          label="Country"
          className="col-span-1"
          registration={register("countryId")}
          options={toOptions(employeeCountryData?.data?.data?.data)}
          isLoading={isCountryLoading}
          placeholder="Select country"
          currentOption={toCurrentOption(employeeData?.country)}
          error={errors.countryId?.message}
        />

        <EmployeeSelectField
          id="stateId"
          label="State"
          className="md:col-span-1"
          registration={register("stateId")}
          options={toOptions(states)}
          isLoading={loadingStates}
          placeholder="Select state"
          currentOption={toCurrentOption(employeeData?.state)}
          error={errors.stateId?.message}
        />

        <EmployeeSelectField
          id="employmentType"
          label="Employment Type"
          registration={register("employmentType")}
          options={employmentTypeOptions}
          placeholder="Select employment type"
          error={errors.employmentType?.message}
        />

        <EmployeeSelectField
          id="departmentId"
          label="Department"
          className="col-span-1"
          registration={register("departmentId")}
          options={toOptions(departmentsData?.data?.data)}
          isLoading={isLoadingDepartments}
          placeholder="Select department"
          currentOption={toCurrentOption(employeeData?.department)}
          error={errors.departmentId?.message}
        />

        <EmployeeSelectField
          id="employeeJobTitleId"
          label="Job Title"
          className="col-span-1"
          registration={register("employeeJobTitleId")}
          options={toOptions(jobTitlesData?.data?.data)}
          isLoading={isLoadingJobTitles}
          placeholder="Select job title"
          currentOption={toCurrentOption(employeeData?.employeeJobTitle)}
          error={errors.employeeJobTitleId?.message}
        />

        <EmployeeSelectField
          id="employeeGradeId"
          label="Employee Grade"
          className="col-span-1"
          registration={register("employeeGradeId")}
          options={toOptions(employeesGradeData?.data?.data)}
          isLoading={isLoadingGrades}
          placeholder="Select employee grade"
          currentOption={toCurrentOption(employeeData?.employeeGrade)}
          error={errors.employeeGradeId?.message}
        />

        <EmployeeSelectField
          id="costCenterId"
          label="Cost Center"
          className="col-span-1"
          registration={register("costCenterId")}
          options={toOptions(costCenterData?.data?.data)}
          isLoading={isLoadingCostCenters}
          placeholder="No cost center"
          currentOption={toCurrentOption(employeeData?.costCenter)}
          error={errors.costCenterId?.message}
        />

        <EmployeeSelectField
          id="subsidiaryId"
          label="Organization Subsidiary"
          className="col-span-1"
          registration={register("subsidiaryId")}
          options={toOptions(subsidiariesData?.data?.data)}
          isLoading={isLoadingSubsidiaries}
          placeholder="Select subsidiary"
          currentOption={toCurrentOption(employeeData?.organizationSubsidiary)}
          error={errors.subsidiaryId?.message}
        />

        <div>
          <label
            htmlFor="dateJoined"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Employment date
          </label>
          <input
            id="dateJoined"
            type="date"
            max={today}
            {...register("dateJoined")}
            className={employeeFieldClassName}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.dateJoined?.message}
          </p>
        </div>

        <div>
          <label
            htmlFor="disengagementDate"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Disengagement date
          </label>
          <input
            id="disengagementDate"
            type="date"
            max={today}
            {...register("disengagementDate")}
            className={employeeFieldClassName}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.disengagementDate?.message}
          </p>
        </div>
      </div>
    </div>
  );
};

export default BasicEmployeesDetails;
