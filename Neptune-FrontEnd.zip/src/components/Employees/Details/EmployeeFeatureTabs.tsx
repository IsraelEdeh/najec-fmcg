"use client";

import { cn } from "@/lib/utils";

interface EmployeeFeatureTabsProps {
  tabs: string[];
  activeTab: string;
  onChange: (tab: string) => void;
}

export default function EmployeeFeatureTabs({
  tabs,
  activeTab,
  onChange
}: EmployeeFeatureTabsProps) {
  return (
    <div className="flex flex-wrap gap-x-5 gap-y-2 border-b border-[#D9D9D9]">
      {tabs.map((tab) => (
        <button
          key={tab}
          type="button"
          onClick={() => onChange(tab)}
          className={cn(
            "border-b-2 border-transparent pb-3 text-sm text-[#63666A] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#146ADC]",
            activeTab === tab && "border-b-secondary text-[#146ADC]"
          )}
        >
          {tab}
        </button>
      ))}
    </div>
  );
}
