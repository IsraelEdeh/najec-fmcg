import React from "react";
import type { UseFormRegisterReturn } from "react-hook-form";

export interface EmployeeSelectOption {
  value: string;
  label: string;
}

export const employeeFieldClassName =
  "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5";

interface EmployeeSelectFieldProps {
  id: string;
  label: string;
  registration: UseFormRegisterReturn;
  options?: EmployeeSelectOption[];
  placeholder: string;
  isLoading?: boolean;
  currentOption?: EmployeeSelectOption;
  error?: string;
  className?: string;
}

const EmployeeSelectField = ({
  id,
  label,
  registration,
  options = [],
  placeholder,
  isLoading = false,
  currentOption,
  error,
  className
}: EmployeeSelectFieldProps) => {
  // Keep the persisted value selectable even if it is missing from the lookup list.
  const includeCurrent =
    currentOption?.value &&
    !options.some((option) => option.value === currentOption.value);
  const allOptions = includeCurrent ? [currentOption, ...options] : options;

  return (
    <div className={className}>
      <label htmlFor={id} className="block mb-2 text-sm font-medium text-gray-900">
        {label}
      </label>
      {/* Remount once options arrive so react-hook-form re-applies the stored value to the DOM. */}
      <select
        key={isLoading ? "loading" : "ready"}
        id={id}
        {...registration}
        className={employeeFieldClassName}
      >
        <option value="">{isLoading ? "Loading..." : placeholder}</option>
        {allOptions.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
        {error}
      </p>
    </div>
  );
};

export default EmployeeSelectField;
