"use client";

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import ApiFetcher from "@/components/Utils/api";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import EmployeeFeatureTabs from "./EmployeeFeatureTabs";

type EmployerTaxShareRow = {
  payComponentId: number;
  payComponentName: string;
  componentDefaultPercent: number;
  employeeOverridePercent: number | null;
  effectivePercent: number;
  isOverridden: boolean;
};

const normalizeRows = (response: any): EmployerTaxShareRow[] => {
  const payload = response?.data?.data ?? response?.data ?? response ?? [];
  const rows = Array.isArray(payload)
    ? payload
    : payload?.items ?? payload?.taxShares ?? payload?.data ?? [];

  return Array.isArray(rows)
    ? rows.map((row: any) => ({
        payComponentId: Number(row.payComponentId ?? row.id),
        payComponentName: row.payComponentName ?? row.name ?? "",
        componentDefaultPercent: Number(
          row.componentDefaultPercent ?? row.defaultPercent ?? 100
        ),
        employeeOverridePercent:
          row.employeeOverridePercent ?? row.employerTaxSharePercent ?? null,
        effectivePercent: Number(
          row.effectivePercent ??
            row.employeeOverridePercent ??
            row.employerTaxSharePercent ??
            row.componentDefaultPercent ??
            row.defaultPercent ??
            100
        ),
        isOverridden:
          row.isOverridden === true ||
          row.employeeOverridePercent != null ||
          row.employerTaxSharePercent != null
      }))
    : [];
};

export default function EmployerTaxShare({ employeeId }: { employeeId: string }) {
  const queryClient = useQueryClient();
  const [values, setValues] = useState<Record<number, string>>({});
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [activeTab, setActiveTab] = useState("Overview");

  const { data: rows = [], isPending } = useQuery({
    queryKey: ["employerTaxShares", employeeId],
    queryFn: async () => {
      const result = normalizeRows(
        await ApiFetcher.get(`/employer-tax-share/get-employee-tax-shares/${employeeId}`)
      );
      setValues(
        Object.fromEntries(
          result.map((row) => [
            row.payComponentId,
            row.employeeOverridePercent == null
              ? ""
              : String(row.employeeOverridePercent)
          ])
        )
      );
      return result;
    }
  });

  const save = async () => {
    const invalid = rows.some((row) => {
      const value = values[row.payComponentId];
      return value !== "" && (!Number.isFinite(Number(value)) || Number(value) < 0 || Number(value) > 100);
    });
    if (invalid) {
      toast.error("Employer tax share must be between 0 and 100");
      return;
    }

    try {
      setSaving(true);
      await ApiFetcher.put(`/employer-tax-share/update-employee-tax-shares/${employeeId}`, {
        taxShares: rows.map((row) => ({
          payComponentId: row.payComponentId,
          employerTaxSharePercent:
            values[row.payComponentId] === ""
              ? null
              : Number(values[row.payComponentId])
        }))
      });
      toast.success("Employer tax shares updated successfully");
      await queryClient.invalidateQueries({ queryKey: ["employerTaxShares", employeeId] });
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Unable to update employer tax shares");
    } finally {
      setSaving(false);
    }
  };

  const downloadTemplate = async () => {
    try {
      const response = await ApiFetcher.get(
        "/employer-tax-share/download-tax-share-template",
        { responseType: "blob" }
      );
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = "employer-tax-share-template.xlsx";
      anchor.click();
      window.URL.revokeObjectURL(url);
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Unable to download template");
    }
  };

  const uploadTemplate = async (file?: File) => {
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);
    try {
      setUploading(true);
      await ApiFetcher.post("/employer-tax-share/upload-tax-shares", formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      toast.success("Employer tax shares uploaded successfully");
      await queryClient.invalidateQueries({ queryKey: ["employerTaxShares", employeeId] });
    } catch (error: any) {
      const errors = error?.response?.data?.errors;
      if (Array.isArray(errors)) {
        errors.forEach((message: any) =>
          toast.error(typeof message === "string" ? message : JSON.stringify(message))
        );
      } else {
        toast.error(error?.response?.data?.message || "Unable to upload employer tax shares");
      }
    } finally {
      setUploading(false);
    }
  };

  return (
    <section className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
        <h2 className="text-xl font-semibold">Employer tax share</h2>
        <p className="text-sm text-gray-600">
          Set employee-specific overrides for employer-borne tax components.
        </p>
        </div>
        <div className="flex gap-2">
          <Badge className="border-[#D9D9D9] bg-[#F4F6F9] text-[#63666A]">
            {rows.length} components
          </Badge>
          <Badge className="border-blue-200 bg-blue-50 text-blue-700">
            {rows.filter((row) => values[row.payComponentId] !== "").length} overridden
          </Badge>
        </div>
      </div>

      <EmployeeFeatureTabs
        tabs={["Overview", "Bulk upload"]}
        activeTab={activeTab}
        onChange={setActiveTab}
      />

      {activeTab === "Bulk upload" ? (
        <div className="rounded border border-[#D9D9D9] bg-white p-4">
          <p className="mb-4 text-sm text-gray-600">
            Enter 0–100 or 60%. Leave blank to keep the current value. Type
            DEFAULT to remove an override.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button type="button" variant="outline" onClick={downloadTemplate}>
              Download template
            </Button>
            <label className="cursor-pointer rounded border px-3 py-2 text-sm">
              {uploading ? "Uploading..." : "Upload overrides"}
              <input
                type="file"
                accept=".csv,.xlsx,.xls"
                className="hidden"
                disabled={uploading}
                onChange={(event) => uploadTemplate(event.target.files?.[0])}
              />
            </label>
          </div>
        </div>
      ) : isPending ? (
        <p>Loading employer tax shares...</p>
      ) : rows.length === 0 ? (
        <p className="rounded border p-4 text-sm text-gray-600">
          No pay components are set as employer-borne.
        </p>
      ) : (
        <>
          <div className="overflow-x-auto rounded border border-[#D9D9D9] bg-white">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead className="bg-[#DDEFE8]">
                <tr>
                  <th className="p-3">Component</th>
                  <th className="p-3">Default %</th>
                  <th className="p-3">Employee override</th>
                  <th className="p-3">Effective %</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.payComponentId} className="border-t">
                    <td className="p-3">{row.payComponentName}</td>
                    <td className="p-3">{row.componentDefaultPercent}</td>
                    <td className="p-3">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        placeholder="Default"
                        value={values[row.payComponentId] ?? ""}
                        onChange={(event) =>
                          setValues((current) => ({
                            ...current,
                            [row.payComponentId]: event.target.value
                          }))
                        }
                        className="w-32 rounded border p-2"
                      />
                    </td>
                    <td className="p-3">{row.effectivePercent}</td>
                    <td className="p-3">
                      {values[row.payComponentId] !== "" && (
                        <Badge className="border-blue-200 bg-blue-50 text-blue-700">
                          Overridden
                        </Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Button type="button" onClick={save} disabled={saving} className="bg-primary text-white">
            {saving ? "Saving..." : "Save employer tax shares"}
          </Button>
        </>
      )}
    </section>
  );
}
