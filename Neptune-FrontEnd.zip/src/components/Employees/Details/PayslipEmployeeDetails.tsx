"use client";

import Link from "next/link";
import React, { useState } from "react";
import CustomButton from "@/components/Elements/CustomButton";
import { MdFileDownload } from "react-icons/md";
import { toast } from "react-toastify";
import ApiFetcher from "@/components/Utils/api";
import { useQuery } from "@tanstack/react-query";
import EmptyRecord from "@/components/dashboard/EmptyRecord";
import { TbLoader3 } from "react-icons/tb";
import { PDFDownloadLink } from "@react-pdf/renderer";
import PayslipDocument from "@/components/dashboard/PayslipDocument";
import { sanitizeFilename } from "@/lib/helpers";
import { RunBadge } from "@/components/Payroll/Runs/Badges";
import { normalizeRunType, withPayrollId, withRunSuffix } from "@/lib/payroll-api";
import { PayrollRunType } from "@/types/payroll";

// Payslip items only carry run details once the API returns them; otherwise they are the Regular payroll.
const offCycleRunName = (item: any) =>
  item?.runType !== undefined && normalizeRunType(item.runType) === PayrollRunType.OffCycle
    ? item?.runName
    : undefined;

const PayslipEmployeeDetails = ({ id }: { id: any }) => {
  const [selectedItem, setSelectedItem] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  console.log("use::", selectedItem);

  const handlePayslipPreview = (item: any) => {
    setSelectedItem(item);
  };

  const getPaySlips = async () => {
    try {
      const response = await ApiFetcher.get(
        `/payroll/get-payslips-by-employeeId/${id}`
      );

      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Unable to get employee payslip.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const { data, isPending, isError } = useQuery({
    queryKey: ["getPayslips"],
    queryFn: getPaySlips
  });

  console.log("get all payslips::", data);

  const handlePayslipDownload = async () => {
    try {
      setLoading(true);
      const response = await ApiFetcher.get(
        withPayrollId(
          `employees/download-payslips/${selectedItem?.payPeriodId}/${selectedItem?.payslip?.employeeId}`,
          selectedItem?.payrollId
        ),
        {
          responseType: "blob"
        }
      );

      const blob = new Blob([response.data], {
        type: "application/pdf"
      });
      const url = window.URL.createObjectURL(blob);

      const fileName =
        withRunSuffix(sanitizeFilename("employee-report"), offCycleRunName(selectedItem)) + ".pdf";

      const a = document.createElement("a");
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success("Export done successfully");
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error exporting employees";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      {isPending ? (
        <div className="flex justify-center items-center h-[50vh]">
          <TbLoader3 className="animate-spin text-3xl text-secondary" />
        </div>
      ) : data?.data?.data?.length === 0 ? (
        <EmptyRecord />
      ) : (
        <div className="flex space-x-4">
          <div className="w-1/2">
            {selectedItem && (
              <div className="flex items-center justify-end mb-4">
                <button
                  onClick={handlePayslipDownload}
                  className="flex space-x-2 text-sm items-center bg-white text-primary px-4 py-2 border border-[#005587] rounded-[4px]"
                >
                  <span>
                    {loading ? "Generating PDF..." : "Download Payslip"}
                    {/* Download Payslip */}
                  </span>
                  <MdFileDownload />
                </button>
                {/* <PDFDownloadLink
                  document={<PayslipDocument selectedItem={selectedItem} />}
                  fileName={`payslip-${selectedItem.payPeriodName.replace(
                    /[^a-zA-Z0-9]/g,
                    "-"
                  )}.pdf`}
                >
                  {({ url, loading, error }) => (
                    <button
                      className="flex space-x-2 text-sm items-center bg-white text-primary px-4 py-2 border border-[#005587] rounded-[4px]"
                      disabled={loading}
                    >
                      <span>
                        {loading ? "Generating PDF..." : "Download Payslip"}
                      </span>
                      <MdFileDownload />
                    </button>
                  )}
                </PDFDownloadLink> */}
              </div>
            )}

            <div className="overflow-y-auto max-h-[300px] border border-gray-300 rounded-lg">
              <table className="w-full text-sm text-left text-gray-500">
                <thead className="bg-[#d3e8d3] py-4">
                  <tr>
                    <th className="w-1/2 p-4 text-left uppercase text-xs font-semibold ">
                      Pay period
                    </th>

                    <th className="w-1/2 p-4 text-left uppercase text-xs font-semibold ">
                      Payroll type
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {data?.data?.data.map((item: any) => (
                    <tr
                      key={`${item.payPeriodId}-${item.payrollId ?? "regular"}`}
                      onClick={() => handlePayslipPreview(item)}
                      className="cursor-pointer border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9]"
                    >
                      <td className="p-4 text-left text-sm font-normal">
                        {item.payPeriodName}
                      </td>
                      <td className="p-4 text-left text-sm font-normal">
                        {item.runType !== undefined ? (
                          <span className="flex flex-col gap-1">
                            <RunBadge runType={item.runType} offCycleType={item.offCycleType} />
                            {offCycleRunName(item) && (
                              <span className="text-xs">{offCycleRunName(item)}</span>
                            )}
                          </span>
                        ) : (
                          "Standard"
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Right Section: Payslip Preview */}
          {selectedItem && (
            <div className="w-1/2 p-8 border rounded-[10px] border-gray-300 ">
              {/* <p className="text-center text-base font-semibold">
                Company Name
              </p> */}
              <p className="text-center text-sm mb-2">
                Preview payslip for{" "}
                <span className="font-medium">
                  {selectedItem?.payPeriodName}
                </span>{" "}
                payperiod
              </p>

              <div className="bg-primary rounded-t-[10px] py-4 px-3 text-white border-b border-b-white">
                <div className="grid grid-cols-2 text-sm">
                  <p>Item</p>
                  <p className="flex justify-end font-medium">Value</p>
                </div>
              </div>

              <div className=" space-y-3 py-8 px-3 border border-gray-300 rounded-lg">
                <div className="grid grid-cols-2 text-sm">
                  <p>Employee contributions</p>
                  <p className="flex justify-end font-medium">
                    ₦{selectedItem?.payslip.employeeContributions}
                  </p>
                </div>

                <div className="grid grid-cols-2 text-sm">
                  <p>National housing fund</p>
                  <p className="flex justify-end font-medium">
                    ₦{selectedItem?.payslip.nationalHousingFund}
                  </p>
                </div>

                <div className="grid grid-cols-2 text-sm">
                  <p>Nigeria Social Insurance TrustFund</p>
                  <p className="flex justify-end font-medium">
                    ₦{selectedItem?.payslip.nigeriaSocialInsuranceTrustFund}
                  </p>
                </div>

                <div className="grid grid-cols-2 text-sm">
                  <p>Company contributions</p>
                  <p className="flex justify-end font-medium">
                    ₦{selectedItem?.payslip.companyContributions}
                  </p>
                </div>

                <div className="grid grid-cols-2 text-sm">
                  <p>Net pay</p>
                  <p className="flex justify-end font-medium">
                    ₦{selectedItem?.payslip.netPay}
                  </p>
                </div>

                <div className="grid grid-cols-2 text-sm">
                  <p>Gross salary</p>
                  <p className="flex justify-end font-medium">
                    ₦{selectedItem?.payslip.grossSalary}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PayslipEmployeeDetails;
