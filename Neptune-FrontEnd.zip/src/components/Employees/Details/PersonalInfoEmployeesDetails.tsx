import { pfas } from "@/constants";
import useBank from "@/hooks/Custom-hook/useBank";
import { GENDER_OPTIONS } from "@/lib/employee-mappers";
import type { EmployeeEditFormValues, EmployeeResponse } from "@/types/employee";
import React from "react";
import type {
  FieldErrors,
  UseFormRegister,
  UseFormSetValue
} from "react-hook-form";
import EmployeeSelectField, {
  employeeFieldClassName,
  type EmployeeSelectOption
} from "./EmployeeSelectField";

const genderOptions: EmployeeSelectOption[] = GENDER_OPTIONS;

const taxAuthorityOptions: EmployeeSelectOption[] = [
  "Abia(ABIRS)",
  "Adamawa(ADIRS)",
  "Akwa Ibom(AKIRS)",
  "Anambra(ANIRS)",
  "Bauchi(BAIRS)",
  "Bayelsa(BYIRS)",
  "Benue(BEIRS)",
  "Borno(BOIRS)",
  "Cross River(CRIRS)",
  "Delta(DEIRS)",
  "Ebonyi(EBIRS)",
  "Edo(EDIRS)",
  "Ekiti(EKIRS)",
  "Enugu(ENIRS)",
  "Federal Capital Territory(FCTIRS)",
  "Gombe(GOIRS)",
  "Imo(IMIRS)",
  "Jigawa(JIIRS)",
  "Kaduna(KDIRS)",
  "Kano(KNIRS)",
  "Katsina(KTIRS)",
  "Kebbi(KEIRS)",
  "Kogi(KOIRS)",
  "Kwara(KWIRS)",
  "Lagos(LIRS)",
  "Nasarawa(NAIRS)",
  "Niger(NIIRS)",
  "Ogun(OGIRS)",
  "Ondo(ONIRS)",
  "Osun(OSIRS)",
  "Oyo(OYIRS)",
  "Plateau(PLIRS)",
  "Rivers(RIIRS)",
  "Sokoto(SOIRS)",
  "Taraba(TAIRS)",
  "Yobe(YOIRS)",
  "Zamfara(ZAIRS)"
].map((value) => ({ value, label: value }));

const pfaOptions: EmployeeSelectOption[] = pfas.map((pfa: string) => ({
  value: pfa,
  label: pfa
}));

const textOption = (value?: string): EmployeeSelectOption | undefined =>
  value ? { value, label: value } : undefined;

const PersonalInfoEmployeesDetails = ({
  employeeData,
  register,
  errors,
  setValue,
  nhfExists,
  isPensionExempt
}: {
  employeeData?: EmployeeResponse;
  register: UseFormRegister<EmployeeEditFormValues>;
  errors: FieldErrors<EmployeeEditFormValues>;
  setValue: UseFormSetValue<EmployeeEditFormValues>;
  nhfExists: boolean;
  isPensionExempt: boolean;
}) => {
  const { banks, loadingBanks } = useBank();

  const bankOptions: EmployeeSelectOption[] = Array.isArray(banks)
    ? banks
        .filter((bank: { bankName?: string }) => Boolean(bank?.bankName))
        .map((bank: { bankName: string }) => ({
          value: bank.bankName,
          label: bank.bankName
        }))
    : [];

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <EmployeeSelectField
          id="gender"
          label="Gender"
          registration={register("gender")}
          options={genderOptions}
          placeholder="Select gender"
          error={errors.gender?.message}
        />

        <div>
          <label
            htmlFor="dateOfBirth"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Date of birth
          </label>
          <input
            id="dateOfBirth"
            type="date"
            {...register("dateOfBirth")}
            className={employeeFieldClassName}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.dateOfBirth?.message}
          </p>
        </div>

        <div>
          <label
            htmlFor="email"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Email
          </label>
          <input
            id="email"
            type="email"
            {...register("email")}
            className={employeeFieldClassName}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.email?.message}
          </p>
        </div>

        <div>
          <label
            htmlFor="phoneNumber"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Phone Number
          </label>
          <input
            id="phoneNumber"
            type="text"
            {...register("phoneNumber")}
            className={employeeFieldClassName}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.phoneNumber?.message}
          </p>
        </div>

        <EmployeeSelectField
          id="taxAuthority"
          label="Tax authority"
          className="md:col-span-2"
          registration={register("taxAuthority")}
          options={taxAuthorityOptions}
          placeholder="Select tax authority"
          currentOption={textOption(employeeData?.taxAuthority)}
          error={errors.taxAuthority?.message}
        />

        <div className="md:col-span-1">
          <label
            htmlFor="rsaPin"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            RSA pin
          </label>
          <input
            id="rsaPin"
            type="text"
            {...register("rsaPin")}
            className={employeeFieldClassName}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.rsaPin?.message}
          </p>
        </div>

        <EmployeeSelectField
          id="pensionFundAdministrator"
          label="Pension fund administrator"
          className="md:col-span-1"
          registration={register("pensionFundAdministrator")}
          options={pfaOptions}
          placeholder="Select licensed PFA"
          currentOption={textOption(employeeData?.pensionFundAdministrator)}
          error={errors.pensionFundAdministrator?.message}
        />

        <EmployeeSelectField
          id="bankName"
          label="Bank name"
          className="md:col-span-1"
          registration={register("bankName")}
          options={bankOptions}
          isLoading={loadingBanks}
          placeholder="Select bank"
          currentOption={textOption(employeeData?.bankName)}
          error={errors.bankName?.message}
        />

        <div className="md:col-span-1">
          <label
            htmlFor="accountNumber"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Account number
          </label>
          <input
            id="accountNumber"
            type="text"
            inputMode="numeric"
            maxLength={10}
            {...register("accountNumber")}
            className={employeeFieldClassName}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.accountNumber?.message}
          </p>
        </div>

        <div className="md:col-span-2">
          <label
            htmlFor="accountName"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Account name
          </label>
          <input
            id="accountName"
            type="text"
            {...register("accountName")}
            className={employeeFieldClassName}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.accountName?.message}
          </p>
        </div>

        <div className="grid grid-cols-3 gap-x-2 my-2">
          <div className="md:col-span-1 text-sm">
            <input type="checkbox" id="nhfExists" {...register("nhfExists")} />
            <label htmlFor="nhfExists" className="pl-1 ">
              Does NHF exists?
            </label>
          </div>

          <div className="md:col-span-1 text-sm">
            <input type="checkbox" id="nhisExists" {...register("nhisExists")} />
            <label htmlFor="nhisExists" className="pl-1 ">
              Does NHIS exists?
            </label>
          </div>

          <div className="md:col-span-1 text-sm">
            <input
              type="checkbox"
              id="voluntaryPensionExists"
              disabled={isPensionExempt}
              {...register("voluntaryPensionExists")}
            />
            <label htmlFor="voluntaryPensionExists" className="pl-1 ">
              Does Voluntary Pension exist?
            </label>
          </div>
        </div>

        <div className="md:col-span-2 text-sm">
          <input
            type="checkbox"
            id="isPensionExempt"
            {...register("isPensionExempt", {
              onChange: (event: React.ChangeEvent<HTMLInputElement>) => {
                if (event.target.checked) {
                  setValue("voluntaryPensionExists", false, { shouldDirty: true });
                }
              }
            })}
          />
          <label htmlFor="isPensionExempt" className="pl-1">
            Pension Exempt
          </label>
          <p className="pl-5 text-xs text-gray-600">
            No employee, employer or voluntary pension.
          </p>
        </div>

        <div className="md:col-span-2">
          <label
            htmlFor="nhfNumber"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            NHF number
          </label>
          <input
            id="nhfNumber"
            type="text"
            placeholder="NF00000001234"
            readOnly={!nhfExists}
            {...register("nhfNumber")}
            className={`${employeeFieldClassName} read-only:opacity-60`}
          />
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.nhfNumber?.message}
          </p>
        </div>

        <div className="md:col-span-2">
          <label
            htmlFor="address"
            className="block mb-2 text-sm font-medium text-gray-900"
          >
            Home address
          </label>
          <textarea
            id="address"
            rows={4}
            {...register("address")}
            className={employeeFieldClassName}
          ></textarea>
          <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
            {errors.address?.message}
          </p>
        </div>
      </div>
    </div>
  );
};

export default PersonalInfoEmployeesDetails;
