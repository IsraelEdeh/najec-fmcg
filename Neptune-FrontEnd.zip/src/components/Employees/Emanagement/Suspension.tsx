"use client";

import EmptyRecord from "@/components/dashboard/EmptyRecord";
import ApiFetcher from "@/components/Utils/api";
import { useQuery } from "@tanstack/react-query";
import { formatPageRange } from "@/lib/utils";
import Link from "next/link";
import React, { useState } from "react";
import { AiOutlineLoading3Quarters } from "react-icons/ai";
import { IoEyeOutline } from "react-icons/io5";
import { RiArrowLeftSFill, RiArrowRightSFill } from "react-icons/ri";
import { toast } from "react-toastify";

const Suspension = () => {
  const [currentPage, setCurrentPage] = useState<number>(1);

  const maxPage = 10;

  const getAllSuspendedEmployees = async (page: number) => {
    try {
      const response = await ApiFetcher.get(
        "/employees/get-all-suspended-employees-in-an-organization"
      );
      // console.log("ress::", response);
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching allowance items";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const { data, isPending, isLoading, error } = useQuery({
    queryKey: ["getAllSuspendedEmployees", currentPage],
    queryFn: () => getAllSuspendedEmployees(currentPage)
  });

  return (
    <div>
      <div className="overflow-x-auto">
        {isPending ? (
          <div className="mt-6 pb-10 flex items-center justify-center">
            <AiOutlineLoading3Quarters className="w-10 h-10 animate-spin text-primary" />
          </div>
        ) : data?.data?.data?.length > 0 ? (
          <table className="w-full mt-[24px]">
            <thead className="bg-[#DDEFE8] py-4">
              <tr className=" w-full">
                <th className="p-4 text-left uppercase text-xs font-semibold ">
                  S/N
                </th>

                <th className="p-4 text-left uppercase text-xs font-semibold ">
                  Staff number
                </th>

                <th className="p-4 text-left uppercase text-xs font-semibold ">
                  Employee
                </th>

                <th className="p-4 text-left uppercase text-xs font-semibold ">
                  Job title
                </th>

                <th className="p-4 text-left uppercase text-xs font-semibold ">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody className="text-[#1A1A1A]">
              {data?.data?.data
                .sort((a: any, b: any) =>
                  a.firstName.localeCompare(b.firstName)
                )
                .map((item: any, index: number) => {
                  return (
                    <tr
                      key={item.id}
                      className="border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9]"
                    >
                      <td className="p-4 text-left text-sm font-normal ">
                        {++index}
                      </td>

                      <td className="p-4 text-left text-sm font-normal ">
                        <span className="block font-bold text-sm">
                          {item?.staffNumber}
                        </span>
                      </td>

                      <td className="p-4 text-left text-sm font-normal ">
                        <span>
                          {item?.firstName} {item?.lastName}
                        </span>
                      </td>

                      <td className="p-4 text-left text-sm font-normal ">
                        {item?.jobTitle || "N/A"}
                      </td>

                      <td className="p-4 text-left text-sm font-normal ">
                        <Link
                          className="text-[#757577] hover:underline"
                          href={`/dashboard/employees/${item.id}`}
                        >
                          <IoEyeOutline className="w-6 h-6" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        ) : (
          <EmptyRecord />
        )}
      </div>

      <div className="mt-4 flex items-center justify-between py-2 px-4">
        <p className="text-[#63666A] text-xs">
          {formatPageRange(data?.data?.meta, maxPage)}
        </p>

        <div className="flex items-center space-x-3">
          <button
            disabled={currentPage <= 1}
            onClick={() => setCurrentPage((e: number) => e - 1)}
            className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
          >
            <RiArrowLeftSFill className="w-6 h-6" />
          </button>

          <button
            disabled={currentPage === data?.data?.meta?.totalPages}
            onClick={() => setCurrentPage((e: number) => e + 1)}
            className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
          >
            <RiArrowRightSFill className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Suspension;
