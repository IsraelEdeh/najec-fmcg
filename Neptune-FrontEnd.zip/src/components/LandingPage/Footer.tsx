import React from "react";
import Container from "../Elements/Container";
import { Button } from "../ui/button";
import Link from "next/link";
import Image from "next/image";

const footerGroups = [
  {
    title: "How it Works",
    links: ["Hire Employees", "Hire Contractors", "Global Payroll", "Integrations"]
  },
  {
    title: "Company",
    links: ["About", "Contact Us", "Countries", "Careers"]
  },
  {
    title: "Solutions",
    links: ["Compliances", "Payments", "Taxes", "Enterprises"]
  },
  {
    title: "Resources",
    links: ["FAQ", "Blog", "Open API", "Guide"]
  }
];

const Footer = () => {
  return (
    <footer className="bg-[#F4F6F9] py-10 pb-[40px]">
      <Container>
        <div className="rounded-[24px] border border-[#D9D9D9] bg-white px-4 pt-16 shadow-lg sm:px-8 lg:px-[90px]">
          <div className="text-center">
            <p className="text-3xl font-semibold leading-tight sm:text-[36px] sm:leading-[72px]">
              Get Started <span className="text-[#86BC25]">Today</span>
            </p>
            <p className="text-lg font-semibold leading-8 text-[#1E1E1E] sm:text-[20px] sm:leading-[40px]">
              Streamline your payroll and keep your team{" "}
              <br className="hidden sm:block" /> happy effortlessly.
            </p>
            <Link href="/sign-up">
              <Button className="mt-[40px] rounded-[4px] px-8 py-2.5 text-base font-bold leading-[32px] text-white sm:px-[80px]">
                Create an Account
              </Button>
            </Link>
          </div>

          <div className="mt-20 grid grid-cols-2 gap-8 text-[#9096A2] sm:grid-cols-4 lg:flex lg:justify-between">
            <Image
              src="/landing-page/neptune-logo.png"
              alt="Neptune"
              width={160}
              height={29}
              className="h-auto w-[160px] max-w-full"
            />
            {footerGroups.map((group) => (
              <div key={group.title}>
                <p className="mb-6 text-lg font-semibold text-primary">{group.title}</p>
                <ul className="space-y-4">
                  {group.links.map((link) => (
                    <li key={link}>
                      <Link
                        href="#"
                        className="text-[16px] transition duration-300 ease-in hover:underline"
                      >
                        {link}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-10 flex flex-col gap-6 pb-[48px] text-[#9096A2] sm:flex-row sm:items-center sm:justify-between">
            <ul className="flex flex-wrap items-center gap-4 text-sm">
              <li>©2025. All Rights Reserved.</li>
              <li><Link href="#" className="hover:underline">Privacy Policy</Link></li>
              <li><Link href="#" className="hover:underline">Terms of Service</Link></li>
            </ul>
            <div className="flex items-center gap-4">
              {["instagram", "facebook", "linkedin", "twitter"].map((network) => (
                <Image
                  key={network}
                  src={`/landing-page/${network}.png`}
                  alt={network}
                  width={40}
                  height={40}
                  className="h-8 w-8 cursor-pointer transition-all hover:scale-110"
                />
              ))}
            </div>
          </div>
        </div>
      </Container>
    </footer>
  );
};

export default Footer;
