"use client";

import React from "react";
import Navbar from "./Navbar";
import Image from "next/image";
import Container from "../Elements/Container";
import CustomButton from "../Elements/CustomButton";
import Link from "next/link";
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useMsal
} from "@azure/msal-react";

const Hero = () => {
  const { instance } = useMsal();
  const activeAccount = instance.getActiveAccount();

  console.log("check activeAccount", activeAccount);

  return (
    <header className="relative h-fit">
      <Navbar />
      <div className="relative">
        <Container className="relative z-30">
          <div className="grid grid-cols-1 gap-8 py-[150px] lg:grid-cols-4 lg:gap-x-[100px]">
            <div className="col-span-1 flex items-center lg:col-span-2">
              <div>
                <h1 className="text-3xl font-semibold leading-tight sm:text-[40px] sm:leading-[62px]">
                  HR <span className="text-[#86BC25]">Payroll</span> Customised
                  for You. Loved by Employees
                </h1>
                <p className="mb-10 mt-6 text-[16px] font-semibold leading-[24px] text-[#585860]">
                  Streamline payroll, taxes and compliance with a seamless experience
                </p>
                <div className="flex flex-wrap gap-3 sm:gap-6">
                  <AuthenticatedTemplate>
                    {activeAccount ? (
                      <Link href="/dashboard">
                        <CustomButton
                          classType="primary"
                          className="rounded-[4px] px-8 py-3 sm:px-[80px] sm:py-4"
                        >
                          Go to Dashboard
                        </CustomButton>
                      </Link>
                    ) : null}
                  </AuthenticatedTemplate>
                  {/* <UnauthenticatedTemplate>
                    <Link href="#features">
                      <CustomButton
                        classType="primary"
                        className="rounded-[4px] px-8 py-3 sm:px-[80px] sm:py-4"
                      >
                        Read more
                      </CustomButton>
                    </Link>
                  </UnauthenticatedTemplate> */}
                </div>
              </div>
            </div>
            <div className="col-span-1 lg:col-span-2">
              <Image
                src="/landing-page/Hero-31.png"
                alt="Payroll dashboard illustration"
                width={570}
                height={345}
                className="h-auto w-full max-w-full"
              />
            </div>
          </div>
        </Container>

        <Image
          src="/landing-page/rectangle2.png"
          height={85.85}
          width={85.85}
          alt=""
          aria-hidden="true"
          className="absolute left-[80px] top-24"
        />
        <Image
          src="/landing-page/RectangleSky.png"
          height={120}
          width={120}
          alt=""
          aria-hidden="true"
          className="absolute left-0 top-[170px]"
        />
        <Image
          src="/landing-page/Dotted.png"
          height={70}
          width={70}
          alt=""
          aria-hidden="true"
          className="absolute left-0 top-[580px] z-10"
        />
      </div>
    </header>
  );
};

export default Hero;
