"use client";

import React, { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import Container from "../Elements/Container";
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useMsal
} from "@azure/msal-react";
import { motion } from "motion/react";
import { FaUser } from "react-icons/fa6";

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const { instance } = useMsal();
  const activeAccount = instance.getActiveAccount();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 100);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const login = () => {
    instance
      .loginRedirect({
        scopes: ["openid", "profile", "email"],
        prompt: "create"
      })
      .catch((error: unknown) => console.log(error));
  };

  const logout = () => {
    instance.logoutRedirect().catch((error: unknown) => console.log(error));
  };

  return (
    <nav
      className={`fixed left-0 top-0 z-50 w-full border-b border-b-[#D9D9D9] py-[13.5px] glass-nav ${
        isScrolled ? "bg-white bg-opacity-100" : "bg-[#F4F6F9] bg-opacity-25"
      }`}
    >
      <Container>
        <div className="flex items-center justify-between gap-3">
          <Link href="/">
            <Image
              src="/landing-page/neptune-logo.png"
              alt="logo"
              width={160}
              height={29}
              className="h-auto max-w-full"
            />
          </Link>

          <ul className="hidden items-center space-x-12 text-[#0A112F] lg:flex">
            <li>
              <Link
                href="/#how-it-works"
                className="flex items-center space-x-2 font-medium transition-all duration-100 ease-linear hover:border-b-2 hover:border-b-secondary"
              >
                How it works
              </Link>
            </li>
            <li>
              <Link
                href="#features"
                className="flex items-center space-x-2 font-medium transition-all duration-100 ease-linear hover:border-b-2 hover:border-b-secondary"
              >
                Features
              </Link>
            </li>
          </ul>

          <div className="flex min-w-0 items-center gap-2 sm:gap-6">
            <AuthenticatedTemplate>
              {activeAccount && (
                <div className="flex min-w-0 items-center gap-2">
                  <FaUser className="text-primary" />
                  <span className="hidden max-w-[24vw] truncate text-sm font-medium sm:inline">
                    {activeAccount.username}
                  </span>
                  <motion.button
                    type="button"
                    whileHover={{ scale: 0.95 }}
                    whileTap={{ scale: 0.95 }}
                    className="rounded-[4px] border border-primary px-3 py-1.5 text-[12px]"
                    onClick={logout}
                  >
                    Logout
                  </motion.button>
                </div>
              )}
            </AuthenticatedTemplate>
            <UnauthenticatedTemplate>
              <motion.button
                type="button"
                whileHover={{ scale: 0.95 }}
                whileTap={{ scale: 0.95 }}
                className="flex items-center gap-2 rounded-[4px] border border-primary px-3 py-2 text-[13px]"
                onClick={login}
              >
                <Image
                  src="/microsoft-logo.png"
                  alt="microsoft logo"
                  width={30}
                  height={30}
                />
                <span className="hidden sm:inline">Continue with Microsoft</span>
              </motion.button>
            </UnauthenticatedTemplate>
          </div>
        </div>
      </Container>
    </nav>
  );
};

export default Navbar;
