"use client";

import React, { useState } from "react";

import Container from "../Elements/Container";
import { ChartColumn, CircleCheck, Settings } from "lucide-react";
import Image from "next/image";
import PayrollUnique from "./PayrollUnique";

const PayrollCapabilities = () => {
  const [activeSection, setActiveSection] = useState<number>(0);

  const sections = [
    {
      title: "Customize for your needs",
      description:
        "The ability to tailor the platform to the specific needs and requirements of your business",
      image: "/landing-page/Allowance.png",
      icon: <Settings />,
    },
    {
      title: "Streamline your monthly payroll",
      description:
        "Save time and money. Quickly process employee payroll, avoid delays and keep your employees happy with prompt payments.",
      image: "/landing-page/PayrollImg.png",
      icon: <CircleCheck />,
    },
    {
      title: "Gain insights into your data",
      description:
        "The ability to tailor the platform to the specific needs and requirements of your business",
      image: "/landing-page/Allowance.png",
      icon: <ChartColumn />,
    },
    {
      title: "Automatic data management",
      description:
        "The ability to tailor the platform to the specific needs and requirements of your business",
      image: "/landing-page/Allowance.png",
      icon: <Settings />,
    },
  ];
  return (
    <div id="features" className="relative bg-[#F4F6F9]">
      <Container>
        <section className="relative z-30">
          <div className="py-[120px] text-center">
            <p className="text-3xl font-semibold leading-tight text-[#1E1E1E] sm:text-[40px] sm:leading-[52px]">
              <span className="text-3xl font-semibold leading-tight text-[#86BC25] sm:text-[40px] sm:leading-[52px]">
                Comprehensive
              </span>{" "}
              Payroll Capabilities
            </p>
            <p className="mt-[24px] text-[16px] font-semibold leading-[24px] text-[#1E1E1E]">
              Designed from the ground up with you in mind. Neptune provides
              everything you would need to <br className="hidden sm:block" />
              effectively and efficiently run your payroll
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
            <div className="py-[40px] lg:pr-[70px]">
              {sections.map((section, index) => (
                <div key={index} className="mb-[32px] w-full max-w-[420px]">
                  <button
                    type="button"
                    onClick={() => setActiveSection(index)}
                    className="flex w-full cursor-pointer items-center text-left"
                  >
                    <span
                      className={`mr-[10px] ${
                        activeSection === index
                          ? "text-[#005587]"
                          : "text-[#000000]"
                      }`}
                    >
                      {section.icon}
                    </span>
                    <span
                      className={
                        activeSection === index
                          ? "text-[#005587]"
                          : "text-[#000000]"
                      }
                    >
                      {section.title}
                    </span>
                  </button>

                  {activeSection === index && (
                    <p className="mb-[32px] mt-[8px] text-sm text-[#000000]">
                      {section.description}
                    </p>
                  )}
                  <hr className="mt-[32px] text-[#D9D9D9]" />
                </div>
              ))}
            </div>

            <Image
              src={sections[activeSection].image}
              height={430}
              width={640}
              alt={`${sections[activeSection].title}_image`}
              className="h-auto w-full max-w-full self-start"
            />
          </div>

          <PayrollUnique />
        </section>
      </Container>

      <Image
        src="/landing-page/Rectangle-black.png"
        height={250}
        width={250}
        alt="rectangle-icon"
        className="absolute right-0 top-[150px]"
      />
      <Image
        src="/landing-page/Rectangle-sky.png"
        height={200}
        width={200}
        alt="rectangle-icon"
        className="absolute right-0 top-[580px]"
      />
      <Image
        src="/landing-page/Rectangle-green.png"
        height={120}
        width={120}
        alt="rectangle-icon"
        className="absolute left-0 top-[230px]"
      />
    </div>
  );
};

export default PayrollCapabilities;
