import React from "react";
import Container from "../Elements/Container";
import { BiCustomize } from "react-icons/bi";
import { BsEaselFill } from "react-icons/bs";
import { GrDocumentPerformance } from "react-icons/gr";
import { MdSecurityUpdateGood } from "react-icons/md";
import Image from "next/image";

const features = [
  {
    id: 0,
    title: "Customization",
    description:
      "The ability to tailor the platform to the specific needs and requirements of your business",
    icon: <BiCustomize className="w-[56px] h-[56px] text-primary" />
  },
  {
    id: 1,
    title: "Employee Self-Service",
    description:
      "A portal for employees to access and manage their personal information and get their payslips",
    icon: <BsEaselFill className="w-[56px] h-[56px] text-primary" />
  },
  {
    id: 2,
    title: "Payroll Processing",
    description:
      "Automated payroll processing to ensure accuracy, timeliness and compliance in salary payments",
    icon: <GrDocumentPerformance className="w-[56px] h-[56px] text-primary" />
  },
  {
    id: 3,
    title: "Customizable Payroll",
    description:
      "Customize your payroll to fit your business needs. Set up your payroll to run automatically or manually.",
    icon: <MdSecurityUpdateGood className="w-[56px] h-[56px] text-primary" />
  }
];

const features2 = [
  {
    id: 0,
    title: "We collaborate with You",
    icon: <BiCustomize className="w-[56px] h-[56px] text-primary" />,
    description: `We stand by your side to help you achieve your goals. We consider clients as “co-creators” and prioritize your feedback to deliver on-going enhancements.`
  },
  {
    id: 1,
    title: "Powered by a brand you can trust",
    icon: <BiCustomize className="w-[56px] h-[56px] text-primary" />,
    description: `We are dedicated to making a positive, measurable impact with every client we work with. You an always trust that we’re there to support you.`
  },
  {
    id: 2,
    title: "Innovative at heart",
    icon: <BiCustomize className="w-[56px] h-[56px] text-primary" />,
    description: `We invest in key features that keep you on the cutting edge and experiences that make your work and that of your employees simply enjoyable.`
  }
];

const PayrollFeatures = () => {
  return (
    <div id="features">
      <section  className="py-[120px] bg-primary">
        <Container>
          <h2 className="font-semibold text-[32px] text-white">
            <span className="text-[#86BC25]">Comprehensive</span> Payroll
            Capabilities
          </h2>
          <p className="font-seibold text-white text-[16px] mt-2">
            Designed from the ground up with you in mind. Neptune provides
            everything you would need to effectively and efficiently run your
            payroll
          </p>

          <div className="mt-[56px] grid grid-cols-6 gap-4">
            <div className="col-span-2">
              <Image
                src="/landing-page/features.png"
                alt="feature1"
                width={360}
                height={388}
              />
            </div>

            <div className="col-span-4">
              <div className="grid grid-cols-2 gap-4">
                {features.map((feature) => (
                  <div key={feature.id} className="p-6 bg-white rounded-[8px]">
                    <div>
                      <div>{feature.icon}</div>
                      <p className="text-lg font-semibold mt-2 mb-2.5">
                        {feature.title}
                      </p>
                      <p className="text-sm text-[#0A0A0A]">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Container>
      </section>

      <section className="bg-[#F4F6F9]">
        <Container className="py-[120px]">
          <h2 className="text-[56px] text-center font-semibold ">
            What Makes Neptune{" "}
            <span className="text-primary text-center">Different?</span>
          </h2>

          <div className="mt-[56px] grid grid-cols-3 gap-[90px]">
            {features2.map((feature) => (
              <div
                key={feature.id}
                className=" shadow-md p-6 bg-white rounded-[8px]"
              >
                <div>
                  <div className="flex justify-center">{feature.icon}</div>
                  <p className="text-center text-lg font-semibold mt-2 mb-2.5">
                    {feature.title}
                  </p>
                  <p className="text-center text-sm text-[#0A0A0A]">
                    {feature.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <p className="text-center mt-[56px] text-[#585860]">
            In collaboration with a Global leading brand
          </p>

          <div className="mt-[56px] flex justify-center">
            <Image
              src="/landing-page/deloitte.png"
              alt="deloitte logo"
              width={180}
              height={34}
            />
          </div>
        </Container>
      </section>
    </div>
  );
};

export default PayrollFeatures;
