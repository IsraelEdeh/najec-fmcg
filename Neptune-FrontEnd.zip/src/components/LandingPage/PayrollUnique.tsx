import Image from "next/image";
import React from "react";

const PayrollUnique = () => {
  return (
    <div id="how-it-works" className="relative z-30">
      <div className="relative z-30 grid grid-cols-1 lg:grid-cols-2">
        <div className="px-4 py-16 sm:px-[71px] sm:py-[102.11px]">
          <Image
            src="/landing-page/payroll-unique.png"
            height={516.67}
            width={420}
            alt="payroll img"
            className="h-auto w-full max-w-[420px]"
          />
        </div>

        <div className="px-4 py-16 lg:py-[86.44px] lg:pl-[56px]">
          <div className="">
            <p className="text-3xl leading-tight font-semibold text-[#000000] sm:text-[38px] sm:leading-[52px]">
              <span className="text-[#1E1E1E]">What Makes Neptune </span>
              <span className="text-[#86BC25]">Different</span>?
            </p>
          </div>
          <div className="pt-[24px] my-[20px] w-full">
            <h2 className="text-[16px] leading-[24px] text-[#000000] font-semibold">
              We collaborate with You
            </h2>
            <p className="text-sm text-[#000000] mt-[10px]">
              We stand by your side to help you achieve your goals. We consider
              clients as “co-creators” and prioritize your feedback to deliver
              on-going enhancements.
            </p>
          </div>

          <div className="pt-[24px] my-[20px]">
            <h2 className="text-[16px] leading-[24px] text-[#000000] font-semibold">
              Powered by a brand you can trust
            </h2>
            <p className="text-sm text-[#000000] mt-[10px]">
              We are dedicated to making a positive, measurable impact with
              every client we work with. You can always trust that we’re there
              to support you.
            </p>
          </div>

          <div className="pt-[24px] my-[20px]">
            <h2 className="text-[16px] leading-[24px] text-[#000000] font-semibold">
              Innovative at heart{" "}
            </h2>
            <p className="text-sm text-[#000000] mt-[10px]">
              We invest in key features that keep you on the cutting edge and
              experiences that make your work and that of your employees simply
              enjoyable.
            </p>
          </div>
        </div>
      </div>

      <div>
        <Image
          src="/landing-page/Rec-black.png"
          height={160}
          width={160}
          alt="rectangle-icon"
          className="absolute bottom-[20px] left-[400px]"
        />
      </div>

      <div>
        <Image
          src="/landing-page/Rec-black2.png"
          height={96}
          width={96}
          alt="rectangle-icon"
          className="absolute top-[200px] left-[0px] z-50"
        />
      </div>

      <div>
        <Image
          src="/landing-page/Dotted-square.png"
          height={96}
          width={96}
          alt="rectangle-icon"
          className="absolute top-[50px] left-[450px]"
        />
      </div>
    </div>
  );
};

export default PayrollUnique;
