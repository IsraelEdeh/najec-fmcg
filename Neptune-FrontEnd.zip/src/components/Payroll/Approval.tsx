"use client";

import { Button } from "../ui/button";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { TbLoader3 } from "react-icons/tb";
import { useState } from "react";
import PayrollRunHeader from "./Runs/PayrollRunHeader";
import PayrollActionNotice from "./Runs/PayrollActionNotice";
import { canPerformAction, currentPayrollKey, getCurrentPayroll } from "@/lib/payroll-api";
import useActiveRoles from "@/hooks/Custom-hook/useActiveRoles";
import type { Id } from "@/types/payroll";

const schema = yup
  .object({
    comments: yup.string().min(5, "Comments should be 5 characters or more")
  })
  .required();

const Approval = ({
  threadData,
  setCurrentStep,
  payPeriodId,
  payrollId: selectedPayrollId,
  isClosed = false,
  onReprocess
}: {
  threadData: any;
  setCurrentStep: any;
  payPeriodId?: Id;
  payrollId?: Id;
  isClosed?: boolean;
  onReprocess?: () => void;
}) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm({ resolver: yupResolver(schema) });

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [rejectLoading, setRejectLoading] = useState<boolean>(false);
  const [message, setMessage] = useState<string>("");
  const queryClient = useQueryClient();
  const { roles } = useActiveRoles();

  const { data: currentPayroll } = useQuery({
    queryKey: currentPayrollKey(payPeriodId, selectedPayrollId),
    queryFn: () => getCurrentPayroll({ payPeriodId: payPeriodId as Id, payrollId: selectedPayrollId }),
    enabled: payPeriodId !== undefined && payPeriodId !== null && payPeriodId !== "",
    retry: false
  });

  const payrollId = selectedPayrollId ?? currentPayroll?.id;
  // Once an action succeeds no further action is expected on this screen.
  const isActionDone = Boolean(message);
  const canApprove = !isActionDone && canPerformAction(currentPayroll, "Approve", roles);
  const canReject = !isActionDone && canPerformAction(currentPayroll, "Reject", roles);

  const handleApprovePayroll = async (data: any) => {
    try {
      setIsLoading(true);
      // console.log("data::", data);
      const payload = {
        authorizerComment: data.comments,
        payrollId
      };
      const response = await ApiFetcher.post(
        `/payroll/approve-payroll`,
        payload
      );
      // console.log("respose", response);
      toast.success("Payroll has been approved successfully.");
      setMessage("Payroll has been approved.");
      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error approving payroll";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const approveMutation = useMutation({
    mutationFn: handleApprovePayroll,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onHandleApproval = (data: any) => {
    approveMutation.mutateAsync(data);
    approveMutation.reset();
    reset();
  };

  const handleRejectPayroll = async (data: any) => {
    try {
      setRejectLoading(true);
      // console.log("reject data::", data);
      const payload = {
        status: 4,
        // initiatedBy: "N/A",
        // reviewedBy: "N/A",
        // rejectedBy: "N/A",
        reviewerComment: "N/A",
        authorizerComment: data.comments,
        payrollId
      };
      const response = await ApiFetcher.post(
        `/payroll/reject-payroll`,
        payload
      );

      setMessage("Payroll has been rejected!");
      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error rejecting payroll";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setRejectLoading(false);
    }
  };

  const rejectMutation = useMutation({
    mutationFn: handleRejectPayroll,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onHandleRejection = (data: any) => {
    rejectMutation.mutateAsync(data);
    rejectMutation.reset();
    reset();
  };

  return (
    <div>
      <PayrollRunHeader payroll={currentPayroll} showFinalApprovalNote />
      <div>
        <h2 className="hidden text-[#000000] text-[17px] leading-[28.8px] font-semibold ">
          Review and Approval
        </h2>
      </div>

      {isActionDone ? (
        <p role="status" className="mt-4 mb-[48px] p-4 border border-green-200 bg-green-50 rounded text-sm text-green-900">
          {message}
        </p>
      ) : !isClosed && (canApprove || canReject) ? (
          <div className="mt-4 mb-[48px]">
            <div>
              <div className="mb-4">
                <h2 className="text-sm font-bold">Authorizer</h2>
                <p className="text-xs text-[#63666A] my-[5px]">
                  Approve with comments
                </p>
              </div>
              <div className="space-y-3">
                {message ? (
                  <>
                    <p>{message}</p>
                  </>
                ) : (
                  <div>
                    <textarea
                      placeholder="Comments"
                      aria-label="Comments"
                      disabled={isLoading || rejectLoading}
                      {...register("comments")}
                      className="bg-gray-50 border border-gray-300 py-[9px] px-[12px] text-gray-900 text-sm rounded-lg w-full"
                    ></textarea>

                    <p
                      className="text-red-400 mt-1 text-xs lg:text-sm"
                      role="alert"
                    >
                      {errors.comments?.message}
                    </p>
                  </div>
                )}

                <div className="flex items-center space-x-2">
                  {canApprove && (
                    <Button
                      type="submit"
                      disabled={isLoading || !payrollId}
                      onClick={handleSubmit(onHandleApproval)}
                      className="disabled:bg-secondary disabled:bg-opacity-70 bg-primary text-white text-[13px] font-bold px-[38px] py-1.5 rounded-[4px]"
                    >
                      {isLoading ? (
                        <div className="flex items-center justify-center">
                          <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                        </div>
                      ) : (
                        "Approve"
                      )}
                    </Button>
                  )}

                  {canReject && (
                    <Button
                      onClick={handleSubmit(onHandleRejection)}
                      disabled={rejectLoading || !payrollId}
                      className="bg-red-600 hover:bg-red-400 text-white text-[13px] font-bold px-[38px] py-1.5 rounded-[4px]"
                    >
                      {rejectLoading ? (
                        <div className="flex items-center justify-center">
                          <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                        </div>
                      ) : (
                        "Reject"
                      )}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <PayrollActionNotice payroll={currentPayroll} isClosed={isClosed} onReprocess={onReprocess} />
        )}
    </div>
  );
};

export default Approval;
