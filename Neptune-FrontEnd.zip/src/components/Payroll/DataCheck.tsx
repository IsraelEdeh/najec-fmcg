"use client";

import Image from "next/image";
import Link from "next/link";
import React, { useState } from "react";
import { Button } from "../ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { TbLoader3 } from "react-icons/tb";
import CustomButton from "@/components/Elements/CustomButton";
import { formatCurrency } from "@/lib/helpers";
import ConfirmDialog from "./Runs/ConfirmDialog";
import { PAY_PERIOD_CLOSED_MESSAGE, buildQuery, runPayroll } from "@/lib/payroll-api";
import { getApiErrorMessage } from "@/lib/utils";
import type { Id, OffCycleRun, PayrollScheduleSummary } from "@/types/payroll";

export interface RunPayrollContext {
  payPeriodId?: Id;
  periodName?: string;
  isDefaultPeriod: boolean;
  isClosed: boolean;
  isBackRun: boolean;
  isPastRegular: boolean;
  offCycleRun?: OffCycleRun;
  canProcess: boolean;
  blockedReason?: string;
  hasProcessedPayroll: boolean;
  summary?: PayrollScheduleSummary;
  isSummaryLoading: boolean;
  summaryError?: string;
  onRunComplete?: () => void | Promise<void>;
}

export const NO_SCHEDULE_MESSAGE = "No schedule uploaded for this run yet";

const DataCheck = ({
  payrollSummary,
  setCurrentStep,
  threadData,
  runContext
}: {
  payrollSummary: any;
  setCurrentStep: any;
  threadData: any;
  runContext?: RunPayrollContext;
}) => {
  const queryClient = useQueryClient();
  const [confirmBackRun, setConfirmBackRun] = useState(false);
  const offCycleRun = runContext?.offCycleRun;
  const periodName = runContext?.periodName ?? payrollSummary?.data?.data?.payPeriodName;
  const summary: PayrollScheduleSummary | undefined =
    runContext?.summary ?? payrollSummary?.data?.data;
  const hasSchedule = summary ? summary.hasSchedule ?? Number(summary.totalNoOfEmployees) > 0 : true;

  const mutation = useMutation({
    mutationFn: () =>
      runPayroll({
        payPeriodId: runContext?.payPeriodId,
        offCycleRunId: offCycleRun?.id
      }),
    onSuccess: async () => {
      toast.success(
        offCycleRun ? `${offCycleRun.name} has been processed.` : "Payroll processed successfully."
      );
      setConfirmBackRun(false);
      await queryClient.invalidateQueries();
      await runContext?.onRunComplete?.();
      setCurrentStep(3);
    },
    onError: (error) => {
      setConfirmBackRun(false);
      toast.error(getApiErrorMessage(error, "Error processing payroll"));
    }
  });

  const onHandlerSubmit = () => {
    if (runContext?.isClosed) {
      toast.error(PAY_PERIOD_CLOSED_MESSAGE);
      return;
    }
    if (runContext?.isBackRun) {
      setConfirmBackRun(true);
      return;
    }
    mutation.mutate();
  };

  const canProcessRegular =
    (threadData?.isPayrollRun && threadData?.isPayrollRejected) ||
    (!threadData?.isPayrollRun && !threadData?.isPayrollRejected);
  const blockedReason = runContext?.isClosed
    ? PAY_PERIOD_CLOSED_MESSAGE
    : runContext?.blockedReason ??
      (runContext?.summaryError
        ? runContext.summaryError
        : !hasSchedule
          ? NO_SCHEDULE_MESSAGE
          : undefined);
  // View-only entries (already processed payrolls) have no Process button at all.
  const showProcess = runContext
    ? runContext.canProcess || Boolean(runContext.blockedReason)
    : canProcessRegular;
  const processDisabled =
    mutation.isPending ||
    Boolean(runContext && (!runContext.canProcess || runContext.isSummaryLoading)) ||
    Boolean(blockedReason);
  const canGoNext = Boolean(runContext?.hasProcessedPayroll || threadData?.isPayrollRun);
  const scheduleHref = offCycleRun
    ? `/dashboard/payroll/off-cycle?payPeriodId=${encodeURIComponent(
        String(runContext?.payPeriodId ?? "")
      )}&offCycleRunId=${encodeURIComponent(String(offCycleRun.id))}`
    : `/dashboard/payroll/payroll-schedule${buildQuery({ payPeriodId: runContext?.payPeriodId })}`;

  return (
    <section>
      <div>
        <div className="border border-[#D9D9D9] rounded-[4px] py-[20px] px-[24px]">
          <div className="flex">
            <Image
              height={48}
              width={48}
              alt="payroll img"
              src="/Payroll/Run payroll/Wallet.png"
              className="mr-[9px]"
            />
            <div>
              <p className="text-sm text-[#878787]">Pay Period</p>
              <p className="text-[24px] text-[#191919] leading-[32px] font-bold">
                {periodName}
              </p>
              {offCycleRun && (
                <p className="text-sm text-[#63666A]">Off-cycle run: {offCycleRun.name}</p>
              )}
            </div>
          </div>

          <hr className="my-[16px] text-[#D9D9D9]" />

          {runContext?.summaryError && (
            <p role="alert" className="mb-4 rounded-[4px] border border-red-200 bg-red-50 p-3 text-sm text-red-900">
              {runContext.summaryError}
            </p>
          )}

          <div
            className={`flex justify-between flex-wrap gap-4 ${runContext?.isSummaryLoading ? "opacity-50" : ""}`}
            aria-busy={runContext?.isSummaryLoading}
          >
            {runContext?.isSummaryLoading && (
              <TbLoader3 className="text-primary animate-spin w-5 h-5" aria-label="Loading summary" />
            )}
            <div>
              <h2 className="text-xs text-[#878787]">Number of Employees</h2>
              <p className="text-[16px] leading-[24px] text-[#191919] font-semibold">
                {Number(summary?.totalNoOfEmployees ?? 0) || 0}
              </p>
            </div>
            <div>
              <h2 className="text-xs text-[#878787]">
                Number of Pay Components
              </h2>
              <p className="text-[16px] leading-[24px] text-[#191919] font-semibold">
                {Number(summary?.totalNoOfPayComponents ?? 0) || 0}
              </p>
            </div>
            <div>
              <h2 className="text-xs text-[#878787]">Gross Pay</h2>
              <p className="text-[16px] leading-[24px] text-[#191919] font-semibold">
                {formatCurrency(summary?.totalAllowanceValue)}
              </p>
            </div>
            <div>
              <h2 className="text-xs text-[#878787]">Total Emolument</h2>
              <p className="text-[16px] leading-[24px] text-[#191919] font-semibold">
                {formatCurrency(summary?.totalEmolument)}
              </p>
            </div>

            <div>
              <h2 className="text-xs text-[#878787]">Overall deduction sum</h2>
              <p className="text-[16px] leading-[24px] text-[#191919] font-semibold">
                {formatCurrency(summary?.totalDeductionValue)}
              </p>
            </div>
          </div>

          {runContext?.isPastRegular && (
            <p className="mt-3 text-xs text-[#63666A]">
              Figures reflect the current regular schedule. Update it if this month&apos;s figures were different.
            </p>
          )}

          {!runContext?.summaryError && !runContext?.isSummaryLoading && !hasSchedule && (
            <p role="status" className="mt-4 rounded-[4px] border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
              {NO_SCHEDULE_MESSAGE}.{" "}
              <Link href={scheduleHref} className="font-semibold underline">
                {offCycleRun ? "Upload the off-cycle schedule" : "Upload the payroll schedule"}
              </Link>
            </p>
          )}

          <div className="flex justify-between items-start w-full mt-6 gap-4">
            <div>
              {showProcess && (
                <CustomButton
                  onClick={onHandlerSubmit}
                  disabled={processDisabled}
                  className="bg-secondary text-white text-sm py-[9px] mt-4 px-6 rounded-[4px] disabled:bg-secondary disabled:bg-opacity-50 disabled:cursor-not-allowed"
                >
                  {mutation?.isPending
                    ? "Running . . ."
                    : offCycleRun
                      ? "Process Off-cycle Payroll"
                      : "Process Payroll"}
                </CustomButton>
              )}
              {showProcess && blockedReason && (
                <p id="process-blocked-reason" role="status" className="mt-2 text-xs text-[#63666A]">
                  {blockedReason}
                </p>
              )}
            </div>

            <Button
              onClick={() => setCurrentStep(3)}
              className="text-[#FFFFFF] text-sm font-bold rounded-[4px] mt-4"
              disabled={!canGoNext}
            >
              Next
            </Button>
          </div>
        </div>
      </div>

      <ConfirmDialog
        open={confirmBackRun}
        onOpenChange={setConfirmBackRun}
        title="Run payroll for an earlier period?"
        description={`You are running a Regular payroll for ${periodName}. Neptune uses the CURRENT regular schedule values. Update the schedule first if that month's figures were different.`}
        confirmLabel="Run payroll"
        isPending={mutation.isPending}
        onConfirm={() => mutation.mutate()}
      />
    </section>
  );
};

export default DataCheck;
