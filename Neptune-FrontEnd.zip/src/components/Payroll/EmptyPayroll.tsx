import Link from "next/link";
import React from "react";
import { MdHourglassEmpty } from "react-icons/md";

const EmptyPayroll = () => {
  return (
    <div className="bg-primary w-full rounded-[4px] p-6 flex items-center justify-center">
      <div>
        <div className="text-white">
          <div className="flex items-center justify-center">
            <div className="bg-secondary w-fit rounded-full p-2 ">
              <MdHourglassEmpty className="text-white text-3xl" />
            </div>
          </div>

          <h2 className="mt-2 text-[20px] text-center">
            You have no payroll in progress
          </h2>

          <p className="text-center">
            Click{" "}
            <Link
              href="/dashboard/payroll/settings"
              className="text-secondary underline underline-offset-4"
            >
              here
            </Link>{" "}
            to setup and customize payroll functions
          </p>
        </div>
      </div>
    </div>
  );
};

export default EmptyPayroll;
