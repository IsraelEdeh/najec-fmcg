import { Button } from "@/components/ui/button";
import React from "react";


const Approval = () => {
  return (
    <div>
      <div>
        <h2 className="text-[#000000] text-[24px] leading-[28.8px] font-semibold ">
          Review and Approval
        </h2>
      </div>

      <div className="mt-[48px]">
        <div className="mb-[48px]">
          <h2 className="text-sm font-bold">Reviewer</h2>
          <p className="text-xs text-[#63666A] my-[5px]">
            Search and select who should review this payrun for approval.
          </p>

          <div className="flex gap-[10px]">
            <input
              type="text"
              placeholder="Search for a reviewer"
              id=""
              name=""
              className="bg-gray-50 border border-gray-300 py-[9px] px-[12px] text-gray-900 text-sm rounded-lg w-full"
            />
            <Button className="bg-[#005587] text-white text-sm font-bold px-[38px] py-[11px] rounded-[4px]">
              Submit for review
            </Button>
          </div>
        </div>

        <div className="mb-[48px]">
          <h2 className="text-sm font-bold">Approver</h2>
          <p className="text-xs text-[#63666A] my-[5px]">
            Search and select who should approve this payrun for approval.
          </p>

          <div className="flex gap-[10px]">
            <input
              type="text"
              placeholder="Search for a reviewer"
              id=""
              name=""
              className="bg-gray-50 border border-gray-300 py-[9px] px-[12px] text-gray-900 text-sm rounded-lg w-full"
            />
            <Button disabled className="bg-[#005587] text-white text-sm font-bold px-[38px] py-[11px] rounded-[4px]">
              Submit for approval
            </Button>
          </div>
        </div>

        <div className="mb-[48px]">
          <h2 className="text-sm font-bold">Approve this Payrun</h2>
          <p className="text-xs text-[#63666A] my-[5px]">
            Add comments to approve payroll
          </p>

          <div className="flex gap-[10px]">
            <input
              type="text"
              placeholder="Search for a reviewer"
              id=""
              name=""
              className="bg-gray-50 border border-gray-300 py-[9px] px-[12px] text-gray-900 text-sm rounded-lg w-full"
            />
            <Button disabled className="bg-[#005587] text-white text-sm font-bold px-[38px] py-[11px] rounded-[4px]">
              Approve payrun
            </Button>
          </div>
        </div>

        <div className="mb-[48px]">
          <h2 className="text-sm font-bold">Email Payslips</h2>
          

          <div className="flex justify-between gap-[10px]">
          <div>
          <p className="text-xs text-[#1E1E1E] mt-[4px]">
          Automatically distribute employee payslips via email. 
          </p>
          <p className="text-xs text-[#1E1E1E]">
          Note: Employees without emails will not receive their payslip.
          </p>
          </div>
            <Button disabled className="bg-[#005587] text-white text-sm font-bold px-[38px] py-[11px] rounded-[4px]">
              Send Payslips
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Approval;
