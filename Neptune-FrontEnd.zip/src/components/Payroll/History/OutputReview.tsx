import Image from "next/image";
import Link from "next/link";
import React from "react";
import { IoEyeOutline } from "react-icons/io5";


const OutputReview = () => {
  return (
    <div>
      <div className="border border-[#D9D9D9] rounded-[4px] py-[20px] px-[24px]">
        <div className="flex">
          <Image
            height={48}
            width={48}
            alt="payroll img"
            src="/Payroll/Run payroll/Wallet.png"
            className="mr-[9px]"
          />
          <div>
            <p className="text-sm text-[#878787]">Total Expenditure</p>
            <p className="text-[24px] text-[#191919] leading-[32px] font-bold">
              260,000
            </p>
          </div>
        </div>

        <hr className="my-[16px] text-[#D9D9D9]" />

        <div className="flex justify-between">
          <div>
            <h2 className="text-xs text-[#878787]">Total Gross Pay</h2>
            <p className="text-[16px] leading-[24px] text-[#191919] font-semibold">187,000.00</p>
          </div>
          <div>
            <h2 className="text-xs text-[#878787]">Total Emp. Deductions</h2>
            <p className="text-[16px] leading-[24px] text-[#191919] font-semibold">62,000.00</p>
          </div>
          <div>
            <h2 className="text-xs text-[#878787]">Net Emp. Pay</h2>
            <p className="text-[16px] leading-[24px] text-[#191919] font-semibold">125,000</p>
          </div>
          <div>
                <h2 className="text-xs text-[#878787]">Comp. Contributions</h2>
                <p className="text-[16px] leading-[24px] text-[#191919] font-semibold">55,000.00</p>
          </div>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full mt-[24px]">
          <thead className="bg-[#DDEFE8] py-4">
            <tr className=" w-full">
              <th className="p-4 text-left uppercase text-xs font-semibold ">
                Emp ID
              </th>

              <th className="p-4 text-left uppercase text-xs font-semibold ">
                Name
              </th>

              <th className="p-4 text-left uppercase text-xs font-semibold ">
                Gross Salary
              </th>

              <th className="p-4 text-left uppercase text-xs font-semibold ">
                Taxes
              </th>

              <th className="p-4 text-left uppercase text-xs font-semibold ">
                Net Pay
              </th>
            </tr>
          </thead>

          <tbody className="text-[#1A1A1A]">
            <tr className="border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9]">
              <td className="p-4 text-left text-sm font-normal ">
                <p className="font-bold text-sm ">EM001</p>
              </td>

              <td className="p-4 text-left text-sm font-normal ">
                Richmond Money
              </td>

              <td className="p-4 text-left text-sm font-normal ">5000.00</td>

              <td className="p-4 text-left text-sm font-normal ">5000.00</td>
              <td className="p-4 text-left text-sm font-normal ">4200.00</td>
              <td className="p-4 text-left text-sm font-normal ">
                <Link className="text-[#757577] hover:underline" href="#">
                  <IoEyeOutline className="w-6 h-6" />
                </Link>
              </td>
            </tr>

            <tr className="border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9]">
              <td className="p-4 text-left text-sm font-normal ">
                <p className="font-bold text-sm ">EM001</p>
              </td>

              <td className="p-4 text-left text-sm font-normal ">
                Richmond Money
              </td>

              <td className="p-4 text-left text-sm font-normal ">5000.00</td>

              <td className="p-4 text-left text-sm font-normal ">5000.00</td>
              <td className="p-4 text-left text-sm font-normal ">4200.00</td>
              <td className="p-4 text-left text-sm font-normal ">
                <Link className="text-[#757577] hover:underline" href="#">
                  <IoEyeOutline className="w-6 h-6" />
                </Link>
              </td>
            </tr>

            <tr className="border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9]">
              <td className="p-4 text-left text-sm font-normal ">
                <p className="font-bold text-sm ">EM001</p>
              </td>

              <td className="p-4 text-left text-sm font-normal ">
                Richmond Money
              </td>

              <td className="p-4 text-left text-sm font-normal ">5000.00</td>

              <td className="p-4 text-left text-sm font-normal ">5000.00</td>
              <td className="p-4 text-left text-sm font-normal ">4200.00</td>
              <td className="p-4 text-left text-sm font-normal ">
                <Link className="text-[#757577] hover:underline" href="#">
                  <IoEyeOutline className="w-6 h-6" />
                </Link>
              </td>
            </tr>

            <tr className="border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9]">
              <td className="p-4 text-left text-sm font-normal ">
                <p className="font-bold text-sm ">EM001</p>
              </td>

              <td className="p-4 text-left text-sm font-normal ">
                Richmond Money
              </td>

              <td className="p-4 text-left text-sm font-normal ">5000.00</td>

              <td className="p-4 text-left text-sm font-normal ">5000.00</td>
              <td className="p-4 text-left text-sm font-normal ">4200.00</td>
              <td className="p-4 text-left text-sm font-normal ">
                <Link className="text-[#757577] hover:underline" href="#">
                  <IoEyeOutline className="w-6 h-6" />
                </Link>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default OutputReview;
