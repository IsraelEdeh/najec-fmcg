"use client";

import React from "react";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { TbLoader3 } from "react-icons/tb";
import ClosePeriodButton from "@/components/Payroll/Runs/ClosePeriodButton";
import { PeriodStatusBadge, RunBadge } from "@/components/Payroll/Runs/Badges";
import {
  getPayrollsByPayPeriod,
  normalizeRunType,
  payrollStatusLabel,
  payrollsByPeriodKey
} from "@/lib/payroll-api";
import { PayrollRunType, type Id } from "@/types/payroll";

export interface HistoryPayrollItem {
  id?: Id;
  payPeriodId: Id;
  payPeriod?: { name?: string; startDate?: string };
  totalNetPay?: number | null;
  totalGrossSalary?: number | null;
  totalPensionPayable?: number | null;
}

const COLUMN_COUNT = 7;

const PeriodPayrollGroup = ({
  payPeriodId,
  periodName,
  items,
  formatNumber
}: {
  payPeriodId: Id;
  periodName: string;
  items: HistoryPayrollItem[];
  formatNumber: (value: unknown) => string;
}) => {
  const { data, isPending, isError } = useQuery({
    queryKey: payrollsByPeriodKey(payPeriodId),
    queryFn: () => getPayrollsByPayPeriod(payPeriodId)
  });

  const runs = data?.payrolls ?? [];
  const reviewHref = (payrollId: Id) =>
    `/dashboard/payroll/run?payPeriodId=${encodeURIComponent(String(payPeriodId))}&payrollId=${encodeURIComponent(
      String(payrollId)
    )}`;
  const singleItem = items.length === 1 ? items[0] : undefined;
  const amount = (value: unknown) => (value === null || value === undefined ? "N/A" : `₦${formatNumber(value)}`);

  return (
    <tbody className="text-[#1A1A1A]">
      <tr className="bg-[#F7F9FA] border-t border-t-[#D9D9D9]">
        <th scope="rowgroup" colSpan={COLUMN_COUNT} className="p-4 text-left">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold">{data?.payPeriodName || periodName}</span>
              {data && <PeriodStatusBadge isClosed={data.isClosed} />}
            </div>
            {data && (
              <ClosePeriodButton
                payPeriodId={payPeriodId}
                periodName={data.payPeriodName || periodName}
                isClosed={data.isClosed}
                canClose={data.canClose}
                closeBlockers={data.closeBlockers}
              />
            )}
          </div>
        </th>
      </tr>

      {isPending || isError ? (
        items.map((item, index) => (
          <tr key={`${String(payPeriodId)}-${index}`} className="border-t border-t-[#E5E7EB]">
            <td className="p-4 text-sm">{item.payPeriod?.name || periodName}</td>
            <td className="p-4 text-sm">
              {isPending ? <TbLoader3 className="text-primary animate-spin" aria-label="Loading runs" /> : "—"}
            </td>
            <td className="p-4 text-sm">—</td>
            <td className="p-4 text-sm">₦{formatNumber(item.totalNetPay)}</td>
            <td className="p-4 text-sm">{amount(item.totalGrossSalary)}</td>
            <td className="p-4 text-sm">₦{formatNumber(item.totalPensionPayable)}</td>
            <td className="p-4 text-sm" />
          </tr>
        ))
      ) : runs.length === 0 ? (
        <tr>
          <td colSpan={COLUMN_COUNT} className="p-4 text-sm text-[#63666A]">
            No payroll has been run for this period yet.
          </td>
        </tr>
      ) : (
        runs.map((run) => {
          const isRegular = normalizeRunType(run.runType) === PayrollRunType.Regular;
          // Older payroll list rows only carry period totals, which match the Regular run when it is the only row.
          const fallback = isRegular && singleItem ? singleItem : undefined;
          return (
            <tr key={String(run.id)} className="border-t border-t-[#E5E7EB]">
              <td className="p-4 text-sm">{data?.payPeriodName || periodName}</td>
              <td className="p-4 text-sm">
                <div className="flex flex-col gap-1">
                  <RunBadge runType={run.runType} offCycleType={run.offCycleType} />
                  {!isRegular && run.runName && <span className="text-xs">{run.runName}</span>}
                </div>
              </td>
              <td className="p-4 text-sm">{payrollStatusLabel(run.status)}</td>
              <td className="p-4 text-sm">₦{formatNumber(run.totalNetPay ?? fallback?.totalNetPay)}</td>
              <td className="p-4 text-sm">{amount(run.totalGrossSalary ?? fallback?.totalGrossSalary)}</td>
              <td className="p-4 text-sm">₦{formatNumber(run.totalPensionPayable ?? fallback?.totalPensionPayable)}</td>
              <td className="p-4 text-sm">
                <Link href={reviewHref(run.id)} className="text-primary underline">
                  Review
                </Link>
              </td>
            </tr>
          );
        })
      )}
    </tbody>
  );
};

export const PERIOD_GROUP_COLUMN_COUNT = COLUMN_COUNT;

export default PeriodPayrollGroup;
