"use client";

import React from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { createOffCycleRun } from "@/lib/payroll-api";
import { getApiErrorMessage } from "@/lib/utils";
import { OFF_CYCLE_TYPE_OPTIONS, OffCycleType, type Id } from "@/types/payroll";

interface FormValues {
  name: string;
  offCycleType: string;
}

const schema: yup.ObjectSchema<FormValues> = yup.object({
  name: yup
    .string()
    .trim()
    .required("Name is required")
    .max(100, "Name must be 100 characters or fewer"),
  offCycleType: yup
    .string()
    .required("Type is required")
    .oneOf(OFF_CYCLE_TYPE_OPTIONS.map((option) => String(option.value)), "Type is required")
});

const fieldClassName =
  "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5";

const CreateOffCycleRunDialog = ({
  open,
  onOpenChange,
  payPeriodId,
  periodName
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  payPeriodId: Id;
  periodName?: string;
}) => {
  const queryClient = useQueryClient();
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm<FormValues>({
    resolver: yupResolver(schema),
    defaultValues: { name: "", offCycleType: "" }
  });

  const mutation = useMutation({
    mutationFn: (values: FormValues) =>
      createOffCycleRun({
        payPeriodId,
        name: values.name.trim(),
        offCycleType: Number(values.offCycleType) as OffCycleType
      }),
    onSuccess: async () => {
      toast.success("Off-cycle run created.");
      reset();
      onOpenChange(false);
      await queryClient.invalidateQueries();
    },
    onError: (error) => toast.error(getApiErrorMessage(error, "Unable to create off-cycle run."))
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (mutation.isPending) return;
        if (!next) reset();
        onOpenChange(next);
      }}
    >
      <DialogContent className="bg-white max-w-lg">
        <DialogHeader>
          <DialogTitle>New off-cycle run</DialogTitle>
          <DialogDescription>Pay period: {periodName ?? "—"}</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit((values) => mutation.mutate(values))} className="space-y-4" noValidate>
          <div>
            <label htmlFor="offCycleName" className="block mb-2 text-sm font-medium text-gray-900">
              Name
            </label>
            <input
              id="offCycleName"
              type="text"
              maxLength={100}
              placeholder="13th Month 2026"
              aria-invalid={Boolean(errors.name)}
              {...register("name")}
              className={fieldClassName}
            />
            <p className="text-red-400 mt-1 text-xs" role="alert">
              {errors.name?.message}
            </p>
          </div>

          <div>
            <label htmlFor="offCycleType" className="block mb-2 text-sm font-medium text-gray-900">
              Type
            </label>
            <select
              id="offCycleType"
              aria-invalid={Boolean(errors.offCycleType)}
              {...register("offCycleType")}
              className={fieldClassName}
            >
              <option value="">Select type</option>
              {OFF_CYCLE_TYPE_OPTIONS.map((option) => (
                <option key={option.value} value={String(option.value)}>
                  {option.label}
                </option>
              ))}
            </select>
            <p className="text-red-400 mt-1 text-xs" role="alert">
              {errors.offCycleType?.message}
            </p>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              type="button"
              variant="outline"
              className="bg-white rounded-[4px] border border-primary text-sm"
              onClick={() => onOpenChange(false)}
              disabled={mutation.isPending}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending} className="rounded-[4px] text-sm text-white">
              {mutation.isPending ? "Creating…" : "Create run"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateOffCycleRunDialog;
