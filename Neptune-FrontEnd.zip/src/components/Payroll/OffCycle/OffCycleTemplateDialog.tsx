"use client";

import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { Info } from "lucide-react";
import { TbLoader3 } from "react-icons/tb";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { downloadOffCycleScheduleTemplate, getOffCycleEligibleComponents } from "@/lib/payroll-api";
import { getApiErrorMessage } from "@/lib/utils";
import type { OffCycleRun, PayComponentOption } from "@/types/payroll";

const ComponentGroup = ({
  title,
  items,
  selected,
  onToggle
}: {
  title: string;
  items: PayComponentOption[];
  selected: Set<string>;
  onToggle: (id: string) => void;
}) =>
  items.length === 0 ? null : (
    <fieldset className="space-y-2">
      <legend className="text-sm font-semibold mb-1">{title}</legend>
      {items.map((item) => {
        const key = String(item.id);
        const inputId = `component-${item.kind}-${key}`;
        return (
          <div key={inputId} className="flex items-center gap-2 text-sm">
            <input
              id={inputId}
              type="checkbox"
              checked={selected.has(key)}
              onChange={() => onToggle(key)}
            />
            <label htmlFor={inputId}>{item.name}</label>
          </div>
        );
      })}
    </fieldset>
  );

const OffCycleTemplateDialog = ({
  run,
  onOpenChange
}: {
  run: OffCycleRun | null;
  onOpenChange: (open: boolean) => void;
}) => {
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [error, setError] = useState("");
  const [isDownloading, setIsDownloading] = useState(false);

  const { data: components = [], isPending, isError } = useQuery({
    queryKey: ["offCycleEligibleComponents"],
    queryFn: getOffCycleEligibleComponents,
    enabled: Boolean(run)
  });

  const toggle = (id: string) => {
    setError("");
    setSelected((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const close = (open: boolean) => {
    if (isDownloading) return;
    if (!open) {
      setSelected(new Set());
      setError("");
    }
    onOpenChange(open);
  };

  const handleDownload = async () => {
    if (selected.size === 0) {
      setError("Select at least one pay component.");
      return;
    }
    try {
      setIsDownloading(true);
      await downloadOffCycleScheduleTemplate([...selected], run?.name);
      toast.success("Template downloaded.");
      close(false);
    } catch (downloadError) {
      setError(getApiErrorMessage(downloadError, "Unable to download the template."));
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <Dialog open={Boolean(run)} onOpenChange={close}>
      <DialogContent className="bg-white max-w-lg">
        <DialogHeader>
          <DialogTitle>Download schedule template</DialogTitle>
          <DialogDescription>
            Choose the pay components to include for {run?.name}. The template contains StaffNumber plus one
            column per component.
          </DialogDescription>
        </DialogHeader>

        <p className="flex items-start gap-2 rounded-[4px] border border-blue-200 bg-blue-50 p-3 text-sm text-blue-900">
          <Info className="w-4 h-4 mt-0.5 shrink-0" aria-hidden />
          Annual items such as Rent are paid through annual entitlements, not off-cycle runs.
        </p>

        <div className="max-h-72 overflow-y-auto space-y-4 rounded-[4px] border border-gray-200 p-3">
          {isPending ? (
            <p className="flex items-center gap-2 text-sm">
              <TbLoader3 className="animate-spin" aria-hidden /> Loading pay components…
            </p>
          ) : isError ? (
            <p className="text-sm text-red-700">Unable to load pay components.</p>
          ) : components.length === 0 ? (
            <p className="text-sm">No eligible pay components found.</p>
          ) : (
            <>
              <ComponentGroup
                title="Allowances"
                items={components.filter((item) => item.kind === "Allowance")}
                selected={selected}
                onToggle={toggle}
              />
              <ComponentGroup
                title="Deductions"
                items={components.filter((item) => item.kind === "Deduction")}
                selected={selected}
                onToggle={toggle}
              />
            </>
          )}
        </div>

        {error && (
          <p role="alert" className="text-sm text-red-700">
            {error}
          </p>
        )}

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            type="button"
            variant="outline"
            className="bg-white rounded-[4px] border border-primary text-sm"
            onClick={() => close(false)}
            disabled={isDownloading}
          >
            Cancel
          </Button>
          <Button
            type="button"
            onClick={handleDownload}
            disabled={isDownloading}
            className="rounded-[4px] text-sm text-white"
          >
            {isDownloading ? "Downloading…" : `Download (${selected.size})`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default OffCycleTemplateDialog;
