"use client";

import React, { useId, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { MdErrorOutline } from "react-icons/md";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { parseBulkUploadError, validateBulkUploadFile, type BulkUploadIssue } from "@/lib/bulk-upload";
import { uploadOffCycleSchedule } from "@/lib/payroll-api";
import { getApiErrorMessage } from "@/lib/utils";
import type { OffCycleRun } from "@/types/payroll";

const OffCycleUploadDialog = ({
  run,
  onOpenChange
}: {
  run: OffCycleRun | null;
  onOpenChange: (open: boolean) => void;
}) => {
  const inputId = useId();
  const queryClient = useQueryClient();
  const [file, setFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState("");
  const [confirming, setConfirming] = useState(false);
  const [failure, setFailure] = useState<{ message: string; issues: BulkUploadIssue[] } | null>(null);

  const reset = () => {
    setFile(null);
    setFileError("");
    setConfirming(false);
    setFailure(null);
  };

  const mutation = useMutation({
    mutationFn: () => uploadOffCycleSchedule(run!.id, file as File),
    onSuccess: async () => {
      toast.success(`Schedule uploaded for ${run?.name}.`);
      reset();
      onOpenChange(false);
      await queryClient.invalidateQueries();
    },
    onError: (error) => {
      setConfirming(false);
      setFailure({
        message: getApiErrorMessage(error, "The schedule could not be uploaded. Nothing was saved."),
        issues: parseBulkUploadError(error).issues
      });
    }
  });

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const selected = event.target.files?.[0] ?? null;
    setFailure(null);
    setConfirming(false);
    if (!selected) {
      setFile(null);
      return;
    }
    if (!selected.name.toLowerCase().endsWith(".xlsx")) {
      setFile(null);
      setFileError("Upload the off-cycle schedule as an .xlsx file.");
      return;
    }
    const validationError = await validateBulkUploadFile(selected);
    setFile(validationError ? null : selected);
    setFileError(validationError ?? "");
  };

  return (
    <Dialog
      open={Boolean(run)}
      onOpenChange={(open) => {
        if (mutation.isPending) return;
        if (!open) reset();
        onOpenChange(open);
      }}
    >
      <DialogContent className="bg-white max-w-2xl">
        <DialogHeader>
          <DialogTitle>Upload schedule</DialogTitle>
          <DialogDescription>
            Upload the completed off-cycle template for {run?.name}. Leave a row blank to exclude that
            employee from this run.
          </DialogDescription>
        </DialogHeader>

        <div>
          <label htmlFor={inputId} className="block mb-2 text-sm font-medium text-gray-900">
            Schedule file (.xlsx)
          </label>
          <input
            id={inputId}
            type="file"
            accept=".xlsx"
            onChange={handleFileChange}
            disabled={mutation.isPending}
            className="block w-full text-sm"
          />
          {fileError && (
            <p role="alert" className="mt-2 text-sm text-red-700">
              {fileError}
            </p>
          )}
        </div>

        {confirming && (
          <p role="status" className="rounded-[4px] border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
            This replaces any schedule already uploaded for this run.
          </p>
        )}

        {failure && (
          <div role="alert" className="rounded-[4px] border border-red-200 bg-red-50 p-3 text-sm text-red-900 space-y-2">
            <p className="flex items-start gap-2 font-semibold">
              <MdErrorOutline className="w-5 h-5 shrink-0" aria-hidden />
              {failure.message}
            </p>
            {failure.issues.length > 0 && (
              <ul className="max-h-60 overflow-y-auto space-y-1 rounded-[4px] bg-white/70 p-3">
                {failure.issues.map((issue, index) => (
                  <li key={`${issue.row ?? "general"}-${index}`}>
                    {issue.row !== undefined && <span className="font-semibold">Row {issue.row}: </span>}
                    {issue.field && <span className="font-medium">{issue.field} — </span>}
                    {issue.message}
                  </li>
                ))}
              </ul>
            )}
            <p className="text-xs">Fix the rows above and upload the file again.</p>
          </div>
        )}

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            type="button"
            variant="outline"
            className="bg-white rounded-[4px] border border-primary text-sm"
            onClick={() => (confirming ? setConfirming(false) : onOpenChange(false))}
            disabled={mutation.isPending}
          >
            {confirming ? "Back" : "Cancel"}
          </Button>
          <Button
            type="button"
            disabled={!file || mutation.isPending}
            onClick={() => (confirming ? mutation.mutate() : setConfirming(true))}
            className="rounded-[4px] text-sm text-white"
          >
            {mutation.isPending ? "Uploading…" : confirming ? "Replace and upload" : "Upload"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default OffCycleUploadDialog;
