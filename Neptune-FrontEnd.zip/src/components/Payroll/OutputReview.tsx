"use client";
import { useState } from "react";
import { Button } from "../ui/button";
import { useQuery } from "@tanstack/react-query";
import ApiFetcher from "../Utils/api";
import { toast } from "react-toastify";
import EmptyRecord from "../dashboard/EmptyRecord";
import { TbLoader3 } from "react-icons/tb";
import { formatForNaira } from "@/constants";
import { RiArrowLeftSFill, RiArrowRightSFill } from "react-icons/ri";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import { MdOutlineFileDownload } from "react-icons/md";
import {
  getPayrollsByPayPeriod,
  normalizeRunType,
  payrollsByPeriodKey,
  sameId,
  withPayrollId,
  withRunSuffix
} from "@/lib/payroll-api";
import { PayrollRunType, type Id } from "@/types/payroll";
import { formatPageRange } from "@/lib/utils";

const OutputReview = ({
  payrollSummary,
  setCurrentStep,
  threadData,
  payrollId,
  payPeriod
}: {
  payrollSummary: any;
  setCurrentStep: any;
  threadData: any;
  payrollId?: Id;
  payPeriod?: { id: Id; name: string };
}) => {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [loadingReport, setLoadingReport] = useState<boolean>(false);
  const maxPage = 10;

  const user: any = useSelector((state: RootState) => state?.getUser?.user);
  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const formatAmount = new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN"
  });

  const payPeriodId = payPeriod?.id ?? payrollSummary?.data?.data?.payPeriodId;
  const payPeriodName = payPeriod?.name ?? payrollSummary?.data?.data?.payPeriodName;

  const { data: periodPayrolls } = useQuery({
    queryKey: payrollsByPeriodKey(payPeriodId),
    queryFn: () => getPayrollsByPayPeriod(payPeriodId),
    enabled: Boolean(payPeriodId) && payrollId !== undefined
  });
  const selectedRun = periodPayrolls?.payrolls.find((run) => sameId(run.id, payrollId));
  const offCycleRunName =
    selectedRun && normalizeRunType(selectedRun.runType) === PayrollRunType.OffCycle
      ? selectedRun.runName
      : undefined;

  const getAllPayslips = async (id?: string) => {
    const periodId = id ?? payPeriodId;
    if (!periodId) return [];
    try {
      const response: any = await ApiFetcher.get(
        withPayrollId(`/payroll/get-payroll-by-payperiod/${periodId}`, payrollId)
      );

      return response?.data?.data || [];
    } catch (error: any) {
      // A period without a processed payroll has no payslips yet; that is not an error for the user.
      console.log(error?.response?.data?.message ?? "Error fetching payslips");

      return [];
    }
  };

  const {
    data: allPayslips,
    isPending,
    isLoading,
    error
  } = useQuery({
    queryKey: ["fetchAllPayslips", payPeriodId, payrollId ?? null],
    queryFn: () => getAllPayslips(payPeriodId),
    enabled: Boolean(payPeriodId)
  });

  const getMasterPayrollReport = async (page: number, payPeriodName: any) => {
    try {
      const response: any = await ApiFetcher.get(
        withPayrollId(
          `/report/get-master-payroll-report?PageNumber=${page}&PageSize=${maxPage}&payPeriodName=${encodeURIComponent(payPeriodName ?? "")}`,
          payrollId
        )
      );
      return response || [];
    } catch (error: any) {
      console.log(error?.response?.data?.message ?? "Error fetching master payroll report");

      return [];
    }
  };

  const {
    data: masterReport,
    isPending: isMasterReportPending,
    isLoading: isMasterReportLoading,
    error: masterReportError
  } = useQuery({
    queryKey: ["fetchMasterPayrollReport", currentPage, payPeriodName, payrollId ?? null],
    // Keep rows only while paging the same report; a new period or run starts fresh.
    placeholderData: (previous, previousQuery) =>
      previousQuery?.queryKey[2] === payPeriodName &&
      previousQuery?.queryKey[3] === (payrollId ?? null)
        ? previous
        : undefined,
    queryFn: () => getMasterPayrollReport(currentPage, payPeriodName),
    enabled: Boolean(payPeriodName)
  });

  const handleExportMasterReport = async () => {
    if (!payPeriodId) return;
    try {
      setLoadingReport(true);
      const response = await ApiFetcher.get(
        withPayrollId(
          `/report/export-master-payroll-report?PageSize=1000&payPeriodName=${encodeURIComponent(payPeriodName ?? "")}`,
          payrollId
        ),
        {
          responseType: "blob"
        }
      );

      const blob = new Blob([response.data], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${withRunSuffix("master-report", offCycleRunName)}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success("Export done successfully");
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error exporting master report";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoadingReport(false);
    }
  };

  return (
    <div>
      {/* {
        activeRole?.includes("Initiator") && <div className="flex justify-end w-full mb-4">
          
        </div>
      } */}

      <div className="flex justify-end w-full mb-4">
        <button
          disabled={loadingReport}
          onClick={handleExportMasterReport}
          className="flex  w-fit items-center text-sm space-x-2 border bg-transparent rounded-[4px] py-1 px-4 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <MdOutlineFileDownload className="cursor-pointer w-6 h-6" />
          {loadingReport ? "Exporting..." : "Export Master Report"}
        </button>
      </div>

      <div className="overflow-x-auto ">
        <div className="flex justify-between">
          <div>
            <h2 className="text-xs text-[#878787] text-center">
              Total Gross Salary
            </h2>
            <p className="text-[20px] text-center mt-2 text-[#191919] font-medium">
              {formatAmount.format(allPayslips?.totalGrossSalary ?? 0)}
            </p>
          </div>

          <div>
            <h2 className="text-xs text-[#878787] text-center">
              Total Net Pay
            </h2>
            <p className="text-[20px] text-center mt-2 text-[#191919] font-medium">
              {formatAmount.format(allPayslips?.totalNetPay ?? 0)}
            </p>
          </div>

          <div>
            <h2 className="text-xs text-[#878787] text-center">
              Total tax payable
            </h2>
            <p className="text-[20px] text-center mt-2 text-[#191919] font-medium">
              {formatAmount.format(allPayslips?.totalTaxPayable ?? 0)}
            </p>
          </div>

          <div>
            <h2 className="text-xs text-[#878787] text-center">
              Total Pension Payable
            </h2>
            <p className="text-[20px] text-center mt-2 text-[#191919] font-medium">
              {formatAmount.format(allPayslips?.totalPensionPayable ?? 0)}
            </p>
          </div>

          <div>
            <h2 className="text-xs text-[#878787] text-center">
              Total Company Contributions
            </h2>
            <p className="text-[20px] text-center mt-2 text-[#191919] font-medium">
              {formatAmount.format(allPayslips?.totalCompanyContributions ?? 0)}
            </p>
          </div>
        </div>

        <table className="w-full mt-[24px]">
          <thead className="bg-[#DDEFE8] py-4">
            <tr className=" w-full">
              <th className="p-4 text-left uppercase text-xs font-semibold ">
                Employee
              </th>
              <th className="p-4 text-left uppercase text-xs font-semibold ">
                Net pay
              </th>

              <th className="p-4 text-left uppercase text-xs font-semibold ">
                Paye
              </th>

              <th className="p-4 text-left uppercase text-xs font-semibold ">
                Total allowances
              </th>

              <th className="p-4 text-left uppercase text-xs font-semibold ">
                Total deductions
              </th>

              <th className="p-4 text-left uppercase text-xs font-semibold ">
                Total reliefs
              </th>
            </tr>
          </thead>

          <tbody className="text-[#1A1A1A]">
            {isMasterReportPending ? (
              <div className="mt-6 flex items-center justify-center">
                <TbLoader3 className="text-primary animate-spin w-6 h-6" />
              </div>
            ) : masterReport?.data?.data.length === 0 ? (
              <EmptyRecord />
            ) : (
              masterReport?.data?.data.map((item: any) => (
                <tr
                  key={item.staffName}
                  className="border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9]"
                >
                  <td className="p-4 text-left text-sm font-normal ">
                    <span className="block font-bold text-sm ">
                      {item?.staffName}
                    </span>
                    <span className="block text-xs text-[#0a0a0a] ">
                      {item?.staffNumber || "N/A"}
                    </span>
                  </td>
                  <td className="p-4 text-left text-sm font-normal ">
                    <p className="font-bold text-sm ">
                      ₦{formatForNaira(item?.netPay)}
                    </p>
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">
                    <p className="font-bold text-sm ">
                      ₦{formatForNaira(item?.paye)}
                    </p>
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">
                    ₦{formatForNaira(item?.totalAllowanceValue)}
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">
                    ₦{formatForNaira(item?.totalDeductionValue)}
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">
                    ₦{formatForNaira(item?.totalReliefValue)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        <div className="mt-6 flex justify-between items-center w-full ">
          <div className="flex items-center py-2 px-4 space-x-1">
            <p className="text-[#63666A] text-xs">
              {formatPageRange(masterReport?.data?.meta, maxPage)}
            </p>

            <div className="flex items-center space-x-3">
              <button
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((e: number) => e - 1)}
                className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
              >
                <RiArrowLeftSFill className="w-6 h-6" />
              </button>

              <button
                disabled={currentPage >= (Number(masterReport?.data?.meta?.totalPages) || 1)}
                onClick={() => setCurrentPage((e: number) => e + 1)}
                className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
              >
                <RiArrowRightSFill className="w-6 h-6" />
              </button>
            </div>
          </div>

          {activeRole?.includes("Reviewer") && (
            <div className="flex space-x-4">
              {!activeRole?.includes("Approver") && (
                <Button
                  onClick={() => setCurrentStep(2)}
                  className="text-[#005587] text-sm border border-[#005587] bg-white hover:bg-[#fff] font-bold rounded-[4px]"
                >
                  Back
                </Button>
              )}

              <Button
                onClick={() => setCurrentStep(5)}
                className="text-[#FFFFFF] text-sm font-bold rounded-[4px]"
              >
                Next
              </Button>
            </div>
          )}

          {(activeRole?.includes("Admin") ||
            activeRole?.includes("Approver")) && (
              <div className="flex space-x-4">
                <Button
                  onClick={() => setCurrentStep(4)}
                  className="text-[#FFFFFF] text-sm font-bold rounded-[4px] disabled:bg-primary/75"
                >
                  Next
                </Button>

                {!activeRole?.includes("Approver") && (
                  <Button
                    onClick={() => setCurrentStep(2)}
                    className="text-[#005587] text-sm border border-[#005587] bg-white hover:bg-[#fff] font-bold rounded-[4px]"
                  >
                    Back
                  </Button>
                )}
              </div>
            )}

          {activeRole?.includes("Initiator") && (
            <Button
              onClick={() => setCurrentStep(6)}
              className="text-[#FFFFFF] text-sm font-bold rounded-[4px] disabled:bg-primary/75"
            >
              Next
            </Button>
          )}

          {/* {activeRole?.includes("Approver") && (
            <Button
              onClick={() => setCurrentStep(4)}
              className="text-[#FFFFFF] text-sm font-bold rounded-[4px] disabled:bg-primary/75"
            >
              Next
            </Button>
          )} */}
        </div>
      </div>
    </div>
  );
};

export default OutputReview;
