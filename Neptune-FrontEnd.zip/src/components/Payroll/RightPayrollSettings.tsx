//import Link from "next/link";
import React, { useState } from "react";
//import { Button } from "./ui/button";
import Image from "next/image";
//import BulkUpload from "./BulkUpload";
import { MdCancel } from "react-icons/md";
import { FaXmark } from "react-icons/fa6";
import Link from "next/link";
import { Button } from "../ui/button";
import { Calendar } from "../ui/calendar";

// import {
//   Dialog,
//   DialogContent,
//   DialogDescription,
//   DialogHeader,
//   DialogTitle,
//   DialogTrigger,
// } from "@/components/ui/dialog";

const RightPayrollSettings = ({
  closeRightSidebar,
  setCloseRightSidebar,
}: {
  closeRightSidebar: boolean;
  setCloseRightSidebar: any;
}) => {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleDownload = () => {
    const link = document.createElement("a");
    link.download = "Sample Template";

    link.href = "/SampleTemplate.xlsx";
    link.click();
  };

  return (
    <aside className="fixed top-0 right-0 hidden h-screen w-[290px] border-l bg-[#ffffff] px-[16px] pt-[100px] lg:block">
      <section>
        <div className="mb-20">
          <FaXmark
            className="w-[20px] h-[20px] cursor-pointer"
            onClick={() => setCloseRightSidebar(true)}
          />
        </div>
        <div>
          {/* Active Payrolls Section */}
          <div className="text-[#1E1E1E] text-sm mt-8">
            <h2 className="font-bold mb-4">Upcoming paydays</h2>
            <p className=" mb-2">
              See a preview of upcoming paydays based on your specified
              schedule.
            </p>
          </div>

          <div className="mt-[16px] text-sm">
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              className="rounded-md border w-full"
            />
          </div>
        </div>
      </section>
    </aside>
  );
};

export default RightPayrollSettings;
