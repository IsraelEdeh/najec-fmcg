import React from "react";
import { Badge } from "@/components/ui/badge";
import { normalizeRunType, offCycleTypeLabel } from "@/lib/payroll-api";
import { PayrollRunType, type EnumValue } from "@/types/payroll";

export const RunBadge = ({
  runType,
  offCycleType,
  className = ""
}: {
  runType?: EnumValue | null;
  offCycleType?: EnumValue | null;
  className?: string;
}) =>
  normalizeRunType(runType) === PayrollRunType.Regular ? (
    <Badge className={`border-[#005587] bg-[#E6F0F6] text-[#005587] ${className}`}>Regular</Badge>
  ) : (
    <Badge className={`border-purple-300 bg-purple-50 text-purple-800 ${className}`}>
      Off-cycle: {offCycleTypeLabel(offCycleType)}
    </Badge>
  );

export const PeriodStatusBadge = ({
  isClosed,
  className = ""
}: {
  isClosed?: boolean;
  className?: string;
}) =>
  isClosed ? (
    <Badge className={`border-gray-300 bg-gray-100 text-gray-700 ${className}`}>Closed</Badge>
  ) : (
    <Badge className={`border-green-300 bg-green-50 text-green-800 ${className}`}>Open</Badge>
  );
