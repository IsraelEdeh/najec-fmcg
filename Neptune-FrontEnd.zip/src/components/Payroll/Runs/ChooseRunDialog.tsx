"use client";

import React, { useEffect, useId, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { normalizeRunType, payrollStatusLabel, runDisplayName } from "@/lib/payroll-api";
import { PayrollRunType, type PayrollRunSummary } from "@/types/payroll";
import { RunBadge } from "./Badges";

const ChooseRunDialog = ({
  open,
  periodName,
  runs,
  confirmLabel = "Download",
  onConfirm,
  onOpenChange
}: {
  open: boolean;
  periodName?: string;
  runs: PayrollRunSummary[];
  confirmLabel?: string;
  onConfirm: (run: PayrollRunSummary) => void;
  onOpenChange: (open: boolean) => void;
}) => {
  const groupName = useId();
  const [selectedId, setSelectedId] = useState<string>("");

  useEffect(() => {
    if (!open) return;
    const regular = runs.find((run) => normalizeRunType(run.runType) === PayrollRunType.Regular);
    setSelectedId(String((regular ?? runs[0])?.id ?? ""));
  }, [open, runs]);

  const selectedRun = runs.find((run) => String(run.id) === selectedId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-white max-w-lg">
        <DialogHeader>
          <DialogTitle>Which payroll run?</DialogTitle>
          <DialogDescription>
            {periodName ? `${periodName} has` : "This period has"} more than one payroll. Choose the run to download.
          </DialogDescription>
        </DialogHeader>

        <fieldset className="space-y-2">
          <legend className="sr-only">Payroll run</legend>
          {runs.map((run) => {
            const inputId = `${groupName}-${String(run.id)}`;
            return (
              <div key={inputId} className="flex items-center gap-3 rounded-[4px] border border-gray-200 p-3">
                <input
                  id={inputId}
                  type="radio"
                  name={groupName}
                  value={String(run.id)}
                  checked={selectedId === String(run.id)}
                  onChange={(event) => setSelectedId(event.target.value)}
                />
                <label htmlFor={inputId} className="flex flex-1 items-center justify-between gap-2 text-sm">
                  <span className="flex items-center gap-2">
                    <RunBadge runType={run.runType} offCycleType={run.offCycleType} />
                    {runDisplayName(run)}
                  </span>
                  <span className="text-xs text-[#63666A]">{payrollStatusLabel(run.status)}</span>
                </label>
              </div>
            );
          })}
        </fieldset>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            type="button"
            variant="outline"
            className="bg-white rounded-[4px] border border-primary text-sm"
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
          <Button
            type="button"
            disabled={!selectedRun}
            onClick={() => selectedRun && onConfirm(selectedRun)}
            className="rounded-[4px] text-sm text-white"
          >
            {confirmLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ChooseRunDialog;
