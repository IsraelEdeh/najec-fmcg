"use client";

import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import IconActionButton from "@/components/Elements/IconActionButton";
import useActiveRoles from "@/hooks/Custom-hook/useActiveRoles";
import { closePayPeriod, getErrorList } from "@/lib/payroll-api";
import { getApiErrorMessage } from "@/lib/utils";
import type { Id } from "@/types/payroll";
import ConfirmDialog from "./ConfirmDialog";
import DisabledHint from "./DisabledHint";

interface ClosePeriodButtonProps {
  payPeriodId: Id;
  periodName: string;
  isClosed?: boolean;
  canClose?: boolean;
  closeBlockers?: string[];
  variant?: "button" | "icon";
}

const BlockerList = ({ items }: { items: string[] }) => (
  <ul className="list-disc space-y-1 pl-4 text-left">
    {items.map((item) => (
      <li key={item}>{item}</li>
    ))}
  </ul>
);

const ClosePeriodButton = ({
  payPeriodId,
  periodName,
  isClosed,
  canClose,
  closeBlockers = [],
  variant = "button"
}: ClosePeriodButtonProps) => {
  const { isAdmin } = useActiveRoles();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [failure, setFailure] = useState<{ message: string; blockers: string[] } | null>(null);

  const mutation = useMutation({
    mutationFn: () => closePayPeriod(payPeriodId),
    onSuccess: async () => {
      toast.success(`${periodName} has been closed.`);
      setOpen(false);
      await queryClient.invalidateQueries();
    },
    onError: (error) => {
      setFailure({
        message: getApiErrorMessage(error, "This pay period could not be closed."),
        blockers: getErrorList(error)
      });
    }
  });

  if (!isAdmin || isClosed) return null;

  const blocked = canClose === false;
  const openConfirm = () => {
    setFailure(null);
    setOpen(true);
  };
  const blockerHint = blocked ? (
    <div className="space-y-1">
      <p className="font-semibold">This period cannot be closed yet:</p>
      {closeBlockers.length ? <BlockerList items={closeBlockers} /> : <p>Some runs are not complete.</p>}
    </div>
  ) : undefined;

  const trigger =
    variant === "icon" ? (
      <IconActionButton
        label="Close pay period"
        icon={<Lock />}
        tone="warning"
        onClick={openConfirm}
        disabled={blocked}
        hint={blockerHint}
      />
    ) : (
      <DisabledHint hint={blockerHint}>
        <Button
          type="button"
          onClick={openConfirm}
          disabled={blocked}
          className="text-xs text-white rounded-[4px] py-[6px] px-3 h-auto disabled:opacity-50"
        >
          Close period
        </Button>
      </DisabledHint>
    );

  return (
    <>
      {trigger}

      <ConfirmDialog
        open={open}
        onOpenChange={setOpen}
        title={`Close ${periodName}?`}
        description="After closing, no payroll can be run, uploaded or created for this month. This cannot be undone."
        confirmLabel="Close period"
        destructive
        isPending={mutation.isPending}
        onConfirm={() => {
          setFailure(null);
          mutation.mutate();
        }}
      >
        {failure && (
          <div role="alert" className="rounded-[4px] border border-red-200 bg-red-50 p-3 text-sm text-red-900 space-y-2">
            <p className="font-semibold">{failure.message}</p>
            {failure.blockers.length > 0 && (
              <div className="max-h-48 overflow-y-auto">
                <BlockerList items={failure.blockers.filter((item) => item !== failure.message)} />
              </div>
            )}
          </div>
        )}
      </ConfirmDialog>
    </>
  );
};

export default ClosePeriodButton;
