"use client";

import React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { TbLoader3 } from "react-icons/tb";

interface ConfirmDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: React.ReactNode;
  confirmLabel?: string;
  onConfirm: () => void;
  isPending?: boolean;
  destructive?: boolean;
  children?: React.ReactNode;
}

const ConfirmDialog = ({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel = "Confirm",
  onConfirm,
  isPending = false,
  destructive = false,
  children
}: ConfirmDialogProps) => (
  <Dialog open={open} onOpenChange={(next) => !isPending && onOpenChange(next)}>
    <DialogContent className="bg-white max-w-lg">
      <DialogHeader>
        <DialogTitle>{title}</DialogTitle>
        <DialogDescription className="pt-2 text-[#1e1e1e]">{description}</DialogDescription>
      </DialogHeader>
      {children}
      <DialogFooter className="gap-2 sm:gap-0">
        <Button
          type="button"
          variant="outline"
          className="bg-white rounded-[4px] border border-primary text-sm"
          onClick={() => onOpenChange(false)}
          disabled={isPending}
        >
          Cancel
        </Button>
        <Button
          type="button"
          onClick={onConfirm}
          disabled={isPending}
          className={`rounded-[4px] text-sm text-white flex items-center gap-2 ${
            destructive ? "bg-red-600 hover:bg-red-700" : ""
          }`}
        >
          {isPending && <TbLoader3 className="animate-spin" aria-hidden />}
          {confirmLabel}
        </Button>
      </DialogFooter>
    </DialogContent>
  </Dialog>
);

export default ConfirmDialog;
