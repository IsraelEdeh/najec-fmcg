"use client";

import React from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from "@/components/ui/tooltip";

// Disabled buttons cannot receive focus, so the wrapper is focusable to expose the hint to keyboard users.
const DisabledHint = ({
  hint,
  children
}: {
  hint?: React.ReactNode;
  children: React.ReactNode;
}) => {
  if (!hint) return <>{children}</>;

  return (
    <TooltipProvider delayDuration={100}>
      <Tooltip>
        <TooltipTrigger asChild>
          <span
            tabIndex={0}
            className="inline-flex rounded focus:outline-none focus:ring-2 focus:ring-primary [&>*]:pointer-events-none"
          >
            {children}
          </span>
        </TooltipTrigger>
        <TooltipContent className="bg-white max-w-xs text-xs">{hint}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default DisabledHint;
