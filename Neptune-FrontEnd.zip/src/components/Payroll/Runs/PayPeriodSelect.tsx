"use client";

import React, { useId } from "react";
import type { Id, PayPeriod } from "@/types/payroll";

interface PayPeriodSelectProps {
  periods: PayPeriod[];
  value?: Id;
  onChange: (payPeriodId: Id | undefined) => void;
  isLoading?: boolean;
  disableClosed?: boolean;
  label?: string;
  className?: string;
}

const PayPeriodSelect = ({
  periods,
  value,
  onChange,
  isLoading = false,
  disableClosed = false,
  label = "Pay period",
  className = ""
}: PayPeriodSelectProps) => {
  const selectId = useId();

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      <label htmlFor={selectId} className="text-xs text-[#63666A]">
        {label}
      </label>
      <select
        id={selectId}
        value={value === undefined ? "" : String(value)}
        disabled={isLoading}
        onChange={(event) => {
          const period = periods.find((item) => String(item.id) === event.target.value);
          onChange(period?.id);
        }}
        className="bg-white border border-[#E9EAEC] rounded-[4px] py-2.5 px-3 text-sm min-w-[200px] disabled:opacity-60"
      >
        {isLoading ? (
          <option value="">Loading pay periods…</option>
        ) : periods.length === 0 ? (
          <option value="">No pay period available</option>
        ) : (
          <>
            {value === undefined && <option value="">Select pay period</option>}
            {periods.map((period) => (
              <option
                key={String(period.id)}
                value={String(period.id)}
                disabled={disableClosed && period.isClosed}
              >
                {period.name}
                {period.isClosed ? " (Closed)" : ""}
              </option>
            ))}
          </>
        )}
      </select>
    </div>
  );
};

export default PayPeriodSelect;
