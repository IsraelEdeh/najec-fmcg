"use client";

import React from "react";
import { Info, TriangleAlert } from "lucide-react";
import {
  PAY_PERIOD_CLOSED_MESSAGE,
  allowedActionsOf,
  isApprovedStatus,
  isRejectedStatus,
  payrollStatusLabel
} from "@/lib/payroll-api";
import type { EnumValue } from "@/types/payroll";

export const REJECTED_PAYROLL_MESSAGE =
  "This payroll was rejected. Fix the schedule and run payroll again.";

interface PayrollActionNoticeProps {
  payroll?: { status?: EnumValue | null; allowedActions?: string[] | null } | null;
  isClosed?: boolean;
  onReprocess?: () => void;
}

// Shown in place of action buttons when the selected payroll has nothing the user can do on this step.
const PayrollActionNotice = ({ payroll, isClosed, onReprocess }: PayrollActionNoticeProps) => {
  if (isClosed) {
    return (
      <p role="status" className="flex items-center gap-2 mt-4 mb-[48px] p-4 border border-red-200 bg-red-50 rounded text-sm text-red-900">
        <TriangleAlert className="w-4 h-4 shrink-0" aria-hidden /> {PAY_PERIOD_CLOSED_MESSAGE}
      </p>
    );
  }

  if (!payroll) return null;

  if (isRejectedStatus(payroll.status)) {
    return (
      <div role="status" className="mt-4 mb-[48px] p-4 border border-red-200 bg-red-50 rounded text-sm text-red-900 space-y-3">
        <p className="flex items-center gap-2">
          <TriangleAlert className="w-4 h-4 shrink-0" aria-hidden /> {REJECTED_PAYROLL_MESSAGE}
        </p>
        {onReprocess && (
          <button
            type="button"
            onClick={onReprocess}
            className="bg-primary text-white text-[13px] font-bold px-6 py-1.5 rounded-[4px]"
          >
            Go to Data Check
          </button>
        )}
      </div>
    );
  }

  const actions = allowedActionsOf(payroll);
  const message = isApprovedStatus(payroll.status)
    ? "Approved"
    : `Status: ${payrollStatusLabel(payroll.status)}. ${
        actions.length > 0
          ? `Available actions: ${actions.join(", ")}.`
          : "No actions are available to you for this payroll."
      }`;

  return (
    <p role="status" className="flex items-center gap-2 mt-4 mb-[48px] p-4 border border-yellow-300 bg-yellow-50 rounded text-sm text-gray-700">
      <Info className="w-4 h-4 shrink-0" aria-hidden /> {message}
    </p>
  );
};

export default PayrollActionNotice;
