import React from "react";
import { Info } from "lucide-react";
import { normalizeRunType, runDisplayName } from "@/lib/payroll-api";
import { PayrollRunType, type CurrentPayroll } from "@/types/payroll";
import { RunBadge } from "./Badges";

export const FINAL_APPROVAL_NOTE =
  "Approving does not close the month. Off-cycle payrolls can still be run. An Admin closes the month from the payroll list when all runs are complete.";

const PayrollRunHeader = ({
  payroll,
  showFinalApprovalNote = false
}: {
  payroll?: CurrentPayroll | null;
  showFinalApprovalNote?: boolean;
}) => {
  if (!payroll) return null;
  const isRegular = normalizeRunType(payroll.runType) === PayrollRunType.Regular;

  return (
    <div className="mb-4 space-y-3">
      <div className="flex items-center gap-2 text-sm">
        <RunBadge runType={payroll.runType} offCycleType={payroll.offCycleType} />
        <span className="font-semibold text-[#1e1e1e]">
          {runDisplayName({
            runType: payroll.runType ?? PayrollRunType.Regular,
            runName: payroll.runName,
            offCycleType: payroll.offCycleType
          })}
        </span>
      </div>
      {showFinalApprovalNote && isRegular && (
        <p className="flex items-start gap-2 rounded-[4px] border border-blue-200 bg-blue-50 p-3 text-sm text-blue-900">
          <Info className="w-4 h-4 mt-0.5 shrink-0" aria-hidden />
          {FINAL_APPROVAL_NOTE}
        </p>
      )}
    </div>
  );
};

export default PayrollRunHeader;
