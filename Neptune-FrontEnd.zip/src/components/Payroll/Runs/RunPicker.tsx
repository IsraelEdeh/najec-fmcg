"use client";

import React, { useEffect, useId } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  getPayrollsByPayPeriod,
  normalizeRunType,
  payrollStatusLabel,
  payrollsByPeriodKey,
  runDisplayName,
  sameId
} from "@/lib/payroll-api";
import { PayrollRunType, type Id, type PayrollRunSummary } from "@/types/payroll";

interface RunPickerProps {
  payPeriodId?: Id | null;
  value?: Id;
  // `undefined` means the period's Regular payroll (the API default).
  onChange: (payrollId: Id | undefined, run?: PayrollRunSummary) => void;
  label?: string;
  className?: string;
}

const RunPicker = ({ payPeriodId, value, onChange, label = "Payroll run", className = "" }: RunPickerProps) => {
  const selectId = useId();
  const { data } = useQuery({
    queryKey: payrollsByPeriodKey(payPeriodId),
    queryFn: () => getPayrollsByPayPeriod(payPeriodId as Id),
    enabled: payPeriodId !== undefined && payPeriodId !== null && payPeriodId !== ""
  });

  const payrolls = data?.payrolls ?? [];
  const regular = payrolls.find((run) => normalizeRunType(run.runType) === PayrollRunType.Regular);

  // Drop a selection that no longer belongs to the current period.
  useEffect(() => {
    if (value !== undefined && data && !payrolls.some((run) => sameId(run.id, value))) {
      onChange(undefined);
    }
  }, [data, value, payrolls, onChange]);

  if (payrolls.length <= 1) return null;

  // Option values are the payroll ids, so every run (Regular included) is uniquely selectable.
  const selectedValue = value ?? regular?.id;

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      <label htmlFor={selectId} className="text-xs text-[#63666A]">
        {label}
      </label>
      <select
        id={selectId}
        value={selectedValue === undefined ? "" : `payroll:${selectedValue}`}
        onChange={(event) => {
          const run = payrolls.find((item) => `payroll:${item.id}` === event.target.value);
          onChange(run?.id, run);
        }}
        className="bg-white border border-[#E9EAEC] rounded-[4px] py-2.5 px-3 text-sm"
      >
        {selectedValue === undefined && <option value="">Select a run</option>}
        {payrolls.map((run) => (
          <option key={String(run.id)} value={`payroll:${run.id}`}>
            {runDisplayName(run)} — {payrollStatusLabel(run.status)}
          </option>
        ))}
      </select>
    </div>
  );
};

export default RunPicker;
