"use client";

import React, { useId } from "react";
import { useRouter } from "next/navigation";
import { Info, TriangleAlert } from "lucide-react";
import { PAY_PERIOD_CLOSED_MESSAGE } from "@/lib/payroll-api";
import useActiveRoles from "@/hooks/Custom-hook/useActiveRoles";
import PayPeriodSelect from "./PayPeriodSelect";
import { PeriodStatusBadge, RunBadge } from "./Badges";
import { CREATE_RUN_KEY, type RunEntry, type RunSelection } from "./useRunSelection";

export const OFF_CYCLE_RUN_NOTE =
  "Off-cycle payrolls use only this run's uploaded schedule. They are not prorated, do not pay annual items, and PAYE builds on earlier payrolls in the month.";

const optionLabel = (entry: RunEntry, mode: "run" | "review") => {
  if (mode === "run" && entry.disabledReason) return `${entry.label} — ${entry.disabledReason}`;
  return entry.label;
};

const RunSelectionBar = ({
  selection,
  mode
}: {
  selection: RunSelection;
  mode: "run" | "review";
}) => {
  const runSelectId = useId();
  const router = useRouter();
  const { canManagePayrollRuns } = useActiveRoles();
  const { entries, selectedEntry } = selection;
  const runnableEntries = entries.filter((entry) => entry.kind !== "payroll");
  const processedEntries = entries.filter((entry) => entry.kind === "payroll");
  const regularEntry = entries.find((entry) => entry.kind === "regular");
  const canCreate = mode === "run" && canManagePayrollRuns && !selection.isClosed;

  const handleRunChange = (key: string) => {
    if (key === CREATE_RUN_KEY) {
      router.push(
        `/dashboard/payroll/off-cycle?payPeriodId=${encodeURIComponent(String(selection.payPeriodId ?? ""))}&create=1`
      );
      return;
    }
    selection.selectEntry(key || undefined);
  };

  return (
    <div className="mb-6 space-y-3">
      <div className="flex flex-wrap items-end gap-4">
        <PayPeriodSelect
          periods={selection.periods}
          value={selection.payPeriodId}
          onChange={selection.selectPeriod}
          isLoading={selection.isLoadingPeriods}
        />

        {selection.period && <PeriodStatusBadge isClosed={selection.isClosed} className="mb-3" />}

        <div className="flex flex-col gap-1">
          <label htmlFor={runSelectId} className="text-xs text-[#63666A]">
            Run
          </label>
          <select
            id={runSelectId}
            value={selectedEntry?.key ?? ""}
            onChange={(event) => handleRunChange(event.target.value)}
            disabled={selection.isLoadingRuns}
            className="bg-white border border-[#E9EAEC] rounded-[4px] py-2.5 px-3 text-sm min-w-[260px] disabled:opacity-60"
          >
            {!selectedEntry && <option value="">{selection.isLoadingRuns ? "Loading runs…" : "No run available"}</option>}
            <optgroup label={mode === "run" ? "Run payroll" : "Runs"}>
              {runnableEntries.map((entry) => (
                <option
                  key={entry.key}
                  value={entry.key}
                  disabled={mode === "run" ? !entry.runnable : !entry.payrollId}
                >
                  {optionLabel(entry, mode)}
                </option>
              ))}
            </optgroup>
            {processedEntries.length > 0 && (
              <optgroup label="Processed payrolls (view only)">
                {processedEntries.map((entry) => (
                  <option key={entry.key} value={entry.key}>
                    {entry.label}
                  </option>
                ))}
              </optgroup>
            )}
            {canCreate && <option value={CREATE_RUN_KEY}>+ Create off-cycle run</option>}
          </select>
        </div>

        {selectedEntry && (
          <RunBadge runType={selectedEntry.runType} offCycleType={selectedEntry.offCycleType} className="mb-3" />
        )}
      </div>

      {mode === "run" && regularEntry?.disabledReason && !selection.isClosed && (
        <p className="text-xs text-[#63666A]">Regular payroll: {regularEntry.disabledReason}</p>
      )}

      {mode === "run" && selection.isClosed && (
        <p role="alert" className="flex items-center gap-2 text-sm text-red-700">
          <TriangleAlert className="w-4 h-4" aria-hidden /> {PAY_PERIOD_CLOSED_MESSAGE}
        </p>
      )}

      {mode === "run" && selection.selectedOffCycleRun && (
        <p className="flex items-start gap-2 rounded-[4px] border border-blue-200 bg-blue-50 p-3 text-sm text-blue-900">
          <Info className="w-4 h-4 mt-0.5 shrink-0" aria-hidden />
          {OFF_CYCLE_RUN_NOTE}
        </p>
      )}
    </div>
  );
};

export default RunSelectionBar;
