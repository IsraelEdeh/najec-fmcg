"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useQueries, useQuery } from "@tanstack/react-query";
import usePayPeriods from "@/hooks/Custom-hook/usePayPeriods";
import {
  PAY_PERIOD_CLOSED_MESSAGE,
  getOffCycleRuns,
  getPayrollsByPayPeriod,
  isRejectedStatus,
  normalizeRunType,
  offCycleRunsKey,
  offCycleTypeLabel,
  openPeriodsNewestFirst,
  payrollStatusLabel,
  payrollsByPeriodKey,
  runDisplayName,
  sameId,
  sortNewestFirst
} from "@/lib/payroll-api";
import {
  PayrollRunType,
  type EnumValue,
  type Id,
  type OffCycleRun,
  type PayPeriod,
  type PayrollRunSummary
} from "@/types/payroll";

const startTime = (period?: PayPeriod) => new Date(period?.startDate ?? 0).getTime();

export const findRunPayroll = (run: OffCycleRun, payrolls: PayrollRunSummary[]) =>
  payrolls.find((payroll) => sameId(payroll.offCycleRunId, run.id) || sameId(payroll.id, run.payrollId));

export const isRunLocked = (run: OffCycleRun, payrolls: PayrollRunSummary[]) => {
  const payroll = findRunPayroll(run, payrolls);
  const processed = run.isProcessed ?? Boolean(payroll);
  return processed && !isRejectedStatus(run.payrollStatus ?? payroll?.status);
};

export const CREATE_RUN_KEY = "__create_off_cycle_run__";
export const REGULAR_EXISTS_REASON = "This month already has a Regular payroll.";
export const LATER_REGULAR_REASON =
  "A later month already has a Regular payroll. Use an off-cycle (Arrears) run instead.";

export interface RunEntry {
  key: string;
  kind: "regular" | "offCycle" | "payroll";
  label: string;
  runType: PayrollRunType;
  offCycleType?: EnumValue | null;
  // Runnable entries can be processed; payroll entries are view-only.
  runnable: boolean;
  disabledReason?: string;
  payrollId?: Id;
  offCycleRunId?: Id;
  offCycleRun?: OffCycleRun;
  status?: EnumValue | null;
  allowedActions?: string[] | null;
}

export const REGULAR_KEY = "regular";
export const runKey = (offCycleRunId: Id) => `run:${offCycleRunId}`;
export const payrollKey = (payrollId: Id) => `payroll:${payrollId}`;

const isRegular = (payroll: PayrollRunSummary) =>
  normalizeRunType(payroll.runType) === PayrollRunType.Regular;
const isActiveRegular = (payroll: PayrollRunSummary) =>
  isRegular(payroll) && !isRejectedStatus(payroll.status);

const setQueryParam = (url: URL, name: string, value?: Id | null) => {
  if (value === undefined || value === null || value === "") url.searchParams.delete(name);
  else url.searchParams.set(name, String(value));
};

// Single source of truth for { payPeriodId, payrollId?, offCycleRunId? }, mirrored in the URL query.
const useRunSelection = (summaryPeriodId?: Id, mode: "run" | "review" = "run") => {
  const { periods, currentPeriod, isLoading } = usePayPeriods();
  const [selectedPeriodId, setSelectedPeriodId] = useState<Id>();
  const [selectedKey, setSelectedKey] = useState<string>();
  const [initialStep, setInitialStep] = useState<number>();
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const periodParam = params.get("payPeriodId");
    if (periodParam) setSelectedPeriodId(periodParam);
    const runParam = params.get("offCycleRunId");
    const payrollParam = params.get("payrollId");
    if (payrollParam) setSelectedKey(payrollKey(payrollParam));
    else if (runParam) setSelectedKey(runKey(runParam));
    if (payrollParam) setInitialStep(3);
    else if (periodParam || runParam) setInitialStep(2);
    setIsHydrated(true);
  }, []);

  const sortedPeriods = useMemo(() => sortNewestFirst(periods), [periods]);
  const defaultPeriod =
    periods.find((period) => sameId(period.id, summaryPeriodId)) ??
    (currentPeriod && !currentPeriod.isClosed ? currentPeriod : undefined) ??
    openPeriodsNewestFirst(periods)[0];

  const payPeriodId = selectedPeriodId ?? defaultPeriod?.id ?? summaryPeriodId;
  const period = periods.find((item) => sameId(item.id, payPeriodId));
  const isDefaultPeriod = selectedPeriodId === undefined || sameId(selectedPeriodId, defaultPeriod?.id);
  const hasPeriod = payPeriodId !== undefined && payPeriodId !== null && payPeriodId !== "";

  const { data: periodPayrolls, isPending: isLoadingPayrolls } = useQuery({
    queryKey: payrollsByPeriodKey(payPeriodId),
    queryFn: () => getPayrollsByPayPeriod(payPeriodId as Id),
    enabled: hasPeriod
  });

  const { data: offCycleRuns = [], isPending: isLoadingOffCycleRuns } = useQuery({
    queryKey: offCycleRunsKey(payPeriodId),
    queryFn: () => getOffCycleRuns(payPeriodId as Id),
    enabled: hasPeriod
  });

  // Only later periods can block a Regular run; their results are cached per period.
  const laterPeriods = period ? periods.filter((item) => startTime(item) > startTime(period)) : [];
  const laterPayrolls = useQueries({
    queries: laterPeriods.map((item) => ({
      queryKey: payrollsByPeriodKey(item.id),
      queryFn: () => getPayrollsByPayPeriod(item.id),
      staleTime: 5 * 60 * 1000
    }))
  });
  const laterHasRegular = laterPayrolls.some((query) => query.data?.payrolls.some(isActiveRegular));

  const payrolls = periodPayrolls?.payrolls ?? [];
  const isClosed = Boolean(period?.isClosed ?? periodPayrolls?.isClosed);
  const closedReason = isClosed ? PAY_PERIOD_CLOSED_MESSAGE : undefined;
  const activeRegular = payrolls.find(isActiveRegular);
  const rejectedRegular = payrolls
    .filter((payroll) => isRegular(payroll) && isRejectedStatus(payroll.status))
    .at(-1);

  const regularReason = closedReason ?? (laterHasRegular ? LATER_REGULAR_REASON : undefined);
  const notProcessedLabel = (rejected: boolean) => (rejected ? "rejected, run again" : "not processed yet");

  // A run is listed once: its processed payroll, or its runnable entry when never processed or last Rejected.
  const entries: RunEntry[] = [
    ...(activeRegular
      ? []
      : [
          {
            key: REGULAR_KEY,
            kind: "regular" as const,
            label: `Regular payroll (${notProcessedLabel(Boolean(rejectedRegular))})`,
            runType: PayrollRunType.Regular,
            runnable: !regularReason,
            disabledReason: regularReason,
            payrollId: rejectedRegular?.id,
            status: rejectedRegular?.status,
            allowedActions: rejectedRegular?.allowedActions
          }
        ]),
    ...offCycleRuns
      .filter((run) => !isRunLocked(run, payrolls))
      .map<RunEntry>((run) => {
        const payroll = findRunPayroll(run, payrolls);
        return {
          key: runKey(run.id),
          kind: "offCycle",
          label: `${run.name} (${offCycleTypeLabel(run.offCycleType)}) (${notProcessedLabel(Boolean(payroll))})`,
          runType: PayrollRunType.OffCycle,
          offCycleType: run.offCycleType,
          runnable: !closedReason,
          disabledReason: closedReason,
          payrollId: payroll?.id,
          offCycleRunId: run.id,
          offCycleRun: run,
          status: payroll?.status ?? run.payrollStatus,
          allowedActions: payroll?.allowedActions
        };
      }),
    ...payrolls
      .filter((payroll) => !isRejectedStatus(payroll.status))
      .map<RunEntry>((payroll) => ({
        key: payrollKey(payroll.id),
        kind: "payroll",
        label: `${runDisplayName(payroll)} - ${payrollStatusLabel(payroll.status)}`,
        runType: normalizeRunType(payroll.runType),
        offCycleType: payroll.offCycleType,
        runnable: false,
        payrollId: payroll.id,
        offCycleRunId: payroll.offCycleRunId ?? undefined,
        status: payroll.status,
        allowedActions: payroll.allowedActions
      }))
  ];

  const payrollEntries = entries.filter((entry) => entry.kind === "payroll");
  const latestPayrollKey = payrollEntries.at(-1)?.key;
  const defaultKey =
    mode === "run"
      ? entries.find((entry) => entry.runnable)?.key ?? latestPayrollKey
      : (activeRegular ? payrollKey(activeRegular.id) : undefined) ??
        latestPayrollKey ??
        entries.find((entry) => entry.payrollId !== undefined)?.key;

  // Deep links may point at a run that was processed since, or at a payroll that was rejected.
  const resolveKey = (key?: string) => {
    if (!key) return undefined;
    if (entries.some((entry) => entry.key === key)) return key;
    if (key.startsWith("run:")) {
      const runId = key.slice("run:".length);
      return payrollEntries.find((entry) => sameId(entry.offCycleRunId, runId))?.key;
    }
    if (key.startsWith("payroll:")) {
      const id = key.slice("payroll:".length);
      return entries.find((entry) => sameId(entry.payrollId, id))?.key;
    }
    return undefined;
  };

  const selectedEntry = entries.find((entry) => entry.key === (resolveKey(selectedKey) ?? defaultKey));
  const selectedPayroll = payrolls.find((payroll) => sameId(payroll.id, selectedEntry?.payrollId));
  const isPastPeriod =
    !isDefaultPeriod && Boolean(period && defaultPeriod) && startTime(period) < startTime(defaultPeriod);
  const isRegularEntry = selectedEntry?.runType === PayrollRunType.Regular;
  const isLoadingRuns = hasPeriod && (isLoadingPayrolls || isLoadingOffCycleRuns);
  const urlPayrollId = selectedEntry?.payrollId;
  const urlOffCycleRunId = selectedEntry?.offCycleRunId;

  useEffect(() => {
    if (!isHydrated || !hasPeriod || isLoadingRuns) return;
    const url = new URL(window.location.href);
    setQueryParam(url, "payPeriodId", payPeriodId);
    setQueryParam(url, "payrollId", urlPayrollId);
    setQueryParam(url, "offCycleRunId", urlOffCycleRunId);
    if (url.href !== window.location.href) window.history.replaceState(null, "", url.toString());
  }, [isHydrated, hasPeriod, isLoadingRuns, payPeriodId, urlPayrollId, urlOffCycleRunId]);

  const selectPeriod = useCallback((id: Id | undefined) => {
    setSelectedPeriodId(id);
    setSelectedKey(undefined);
  }, []);

  const selectEntry = useCallback((key: string | undefined) => setSelectedKey(key), []);
  const selectPayroll = useCallback((id: Id) => setSelectedKey(payrollKey(id)), []);

  return {
    periods: sortedPeriods,
    isLoadingPeriods: isLoading,
    isLoadingRuns,
    payPeriodId,
    period,
    periodName: period?.name ?? periodPayrolls?.payPeriodName,
    isDefaultPeriod,
    isClosed,
    payrolls,
    entries,
    selectedEntry,
    selectedPayroll,
    selectEntry,
    selectPayroll,
    selectPeriod,
    selectedOffCycleRun: selectedEntry?.kind === "offCycle" ? selectedEntry.offCycleRun : undefined,
    isPastRegular: isPastPeriod && isRegularEntry,
    isBackRun: isPastPeriod && selectedEntry?.kind === "regular",
    // The schedule summary takes only payPeriodId + offCycleRunId (no payrollId in the API).
    summaryParams: hasPeriod
      ? { payPeriodId, offCycleRunId: selectedEntry?.offCycleRunId }
      : undefined,
    requestPayrollId: selectedEntry?.payrollId,
    hasProcessedPayroll: Boolean(selectedEntry?.payrollId),
    initialStep
  };
};

export type RunSelection = ReturnType<typeof useRunSelection>;

export default useRunSelection;
