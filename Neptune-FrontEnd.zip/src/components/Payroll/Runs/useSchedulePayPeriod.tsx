"use client";

import React, { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import usePayPeriods from "@/hooks/Custom-hook/usePayPeriods";
import { getPayrollScheduleSummary, sameId } from "@/lib/payroll-api";
import type { Id } from "@/types/payroll";
import PayPeriodSelect from "./PayPeriodSelect";

// Pay period a regular schedule change applies to: user choice, then ?payPeriodId=, then the backend default.
export const useSchedulePayPeriod = () => {
  const { openPeriods, isLoading } = usePayPeriods();
  const [selectedId, setSelectedId] = useState<Id>();
  const [urlId, setUrlId] = useState<Id>();

  useEffect(() => {
    setUrlId(new URLSearchParams(window.location.search).get("payPeriodId") ?? undefined);
  }, []);

  const { data: defaultSummary } = useQuery({
    queryKey: ["payrollScheduleSummary", null, null, null],
    queryFn: () => getPayrollScheduleSummary(),
    retry: false
  });

  const period =
    [selectedId, urlId, defaultSummary?.payPeriodId]
      .map((id) => openPeriods.find((item) => sameId(item.id, id)))
      .find(Boolean) ?? openPeriods[0];

  return {
    openPeriods,
    isLoading,
    period,
    payPeriodId: period?.id,
    setPayPeriodId: setSelectedId
  };
};

export type SchedulePayPeriod = ReturnType<typeof useSchedulePayPeriod>;

export const SchedulePeriodPicker = ({ selection }: { selection: SchedulePayPeriod }) => (
  <div className="space-y-1">
    <PayPeriodSelect
      periods={selection.openPeriods}
      value={selection.payPeriodId}
      onChange={selection.setPayPeriodId}
      isLoading={selection.isLoading}
    />
    <p aria-live="polite" className="text-xs text-[#63666A]">
      {selection.period ? (
        <>
          Applies to <span className="font-semibold">{selection.period.name}</span>
        </>
      ) : (
        "No open pay period available."
      )}
    </p>
  </div>
);
