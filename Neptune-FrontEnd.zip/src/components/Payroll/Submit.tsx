"use client";

import { useSelector } from "react-redux";
import { Button } from "../ui/button";
import { RootState } from "@/app/store";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { TbLoader3 } from "react-icons/tb";
import { useState } from "react";
import PayrollRunHeader from "./Runs/PayrollRunHeader";
import PayrollActionNotice from "./Runs/PayrollActionNotice";
import { canPerformAction, currentPayrollKey, getCurrentPayroll } from "@/lib/payroll-api";
import useActiveRoles from "@/hooks/Custom-hook/useActiveRoles";
import type { Id } from "@/types/payroll";

const schema = yup
  .object({
    comments: yup.string().min(5, "Comments should be 5 characters or more"),
    authorizerEmail: yup
      .string()
      .email("Invalid email format")
      .required("Authorizer email is required")
  })
  .required();

const SubmitForReview = ({
  threadData,
  setCurrentStep,
  payPeriodId,
  payrollId: selectedPayrollId,
  isClosed = false,
  onReprocess
}: {
  threadData: any;
  setCurrentStep: any;
  payPeriodId?: Id;
  payrollId?: Id;
  isClosed?: boolean;
  onReprocess?: () => void;
}) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isValid }
  } = useForm({ resolver: yupResolver(schema), mode: "onChange" });

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [rejectLoading, setRejectLoading] = useState<boolean>(false);
  const [message, setMessage] = useState<string>("");
  const user: any = useSelector((state: RootState) => state?.getUser?.user);
  const queryClient = useQueryClient();
  const { roles } = useActiveRoles();

  const { data: currentPayroll, isPending } = useQuery({
    queryKey: currentPayrollKey(payPeriodId, selectedPayrollId),
    queryFn: () => getCurrentPayroll({ payPeriodId: payPeriodId as Id, payrollId: selectedPayrollId }),
    enabled: payPeriodId !== undefined && payPeriodId !== null && payPeriodId !== "",
    retry: false
  });

  const payrollId = selectedPayrollId ?? currentPayroll?.id ?? null;
  // Once review or rejection succeeds no further action is expected on this screen.
  const isActionDone = Boolean(message);
  const canReview = !isClosed && !isActionDone && canPerformAction(currentPayroll, "Review", roles);
  const canReject = !isClosed && !isActionDone && canPerformAction(currentPayroll, "Reject", roles);

  const handleReviewPayroll = async (data: any) => {
    try {
      if (!payrollId) {
        toast.error("No active payroll found to submit for review.");
        return;
      }

      setIsLoading(true);
      const payload = {
        reviewerComment: data.comments,
        payrollId,
        authorizerEmail: data.authorizerEmail
      };
      const response = await ApiFetcher.post(
        `/payroll/review-payroll`,
        payload
      );
      toast.success("Payroll has been submitted for review.");
      setMessage("Payroll has been reviewed and sent for approval.");
      return response;
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error submitting payroll for review";
      console.error(errorMessage);
      toast.error(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const reviewMutation = useMutation({
    mutationFn: handleReviewPayroll,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("review error", error);
    }
  });

  const onHandleReview = (data: any) => {
    reviewMutation.mutate(data);
    reset();
  };

  const handleRejectPayroll = async (data: any) => {
    try {
      if (!payrollId) {
        toast.error("No active payroll found to reject.");
        return;
      }
      setRejectLoading(true);
      // console.log("reject data::", data);
      const payload = {
        reviewerComment: data.comments,
        payrollId,
        authorizerEmail: data.authorizerEmail
      };
      const response = await ApiFetcher.post(
        `/payroll/reject-payroll`,
        payload
      );

      setMessage("Payroll has been rejected!");
      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error approving payroll";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setRejectLoading(false);
    }
  };

  const rejectMutation = useMutation({
    mutationFn: handleRejectPayroll,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onHandleRejection = (data: any) => {
    rejectMutation.mutateAsync(data);
    rejectMutation.reset();
    reset();
  };

  const getAllUsers = async () => {
    try {
      const response = await ApiFetcher.get(
        `/users/get-all-users-in-an-organization`
      );
      // console.log("users::", response);
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching users";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: allUsers,
    isPending: pendingUsers,
    isLoading: loadingUsers,
    error
  } = useQuery({
    queryKey: ["fetchAllUsers"],
    queryFn: getAllUsers
  });

  // const reviewers = allUsers?.data?.data?.filter(
  //   (user: any) => user.roles && user.roles.includes("Approver")
  // );

  let reviewers = allUsers?.data?.data?.filter(
    (user: any) => user.roles && user.roles.includes("Approver")
  );

  if (!reviewers || reviewers.length === 0) {
    reviewers = allUsers?.data?.data?.filter(
      (user: any) => user.roles && user.roles.includes("Admin")
    );
  }

  return (
    <div>
      <PayrollRunHeader payroll={currentPayroll} />
      <div className="mt-4 mb-[48px]">
        <>
            {isActionDone ? (
              <p role="status" className="p-4 border border-green-200 bg-green-50 rounded text-sm text-green-900">
                {message}
              </p>
            ) : canReview || canReject ? (
              <form>
                <div className="mb-4">
                  <h2 className="text-sm font-bold">Submit Payroll</h2>
                  <p className="text-xs text-[#63666A] mt-[5px] mb-[3px]">
                    Review with comments
                  </p>
                </div>

                <div className="mb-4">
                  <select
                    aria-label="Approver"
                    {...register("authorizerEmail")}
                    className="w-full text-base py-[7px] placeholder:text-sm px-4 rounded-[4px] border border-[#D0D0CE] text-gray-900"
                  >
                    <option value="">Select Approver</option>
                    {reviewers &&
                      reviewers.map((reviewer: any) => (
                        <option key={reviewer.id} value={reviewer.email}>
                          {reviewer.email}
                        </option>
                      ))}
                  </select>
                </div>

                <div className="space-y-3">
                  {message ? (
                    <>
                      <p>{message}</p>
                    </>
                  ) : (
                    <div>
                      <textarea
                        placeholder="Comments"
                        aria-label="Comments"
                        {...register("comments")}
                        className="bg-gray-50 border placeholder:text-sm border-gray-300 py-[9px] px-[12px] text-gray-900 text-sm rounded-lg w-full"
                      ></textarea>

                      <p
                        className="text-red-400 mt-1 text-xs lg:text-sm"
                        role="alert"
                      >
                        {errors.comments?.message}
                      </p>
                    </div>
                  )}

                  <div className="flex items-center space-x-2">
                    {canReview && (
                    <Button
                      type="button"
                      disabled={
                        isLoading || !payrollId || isPending || !isValid
                      }
                      onClick={handleSubmit(onHandleReview)}
                      className="disabled:bg-secondary disabled:bg-opacity-70 bg-primary text-white text-[13px] font-bold px-[38px] py-1.5 rounded-[4px]"
                    >
                      {isLoading ? (
                        <div className="flex items-center justify-center">
                          <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                        </div>
                      ) : (
                        "Submit"
                      )}
                    </Button>
                    )}

                    {canReject && (
                    <Button
                      onClick={handleSubmit(onHandleRejection)}
                      disabled={
                        rejectLoading || !payrollId || isPending || !isValid
                      }
                      className="bg-red-600 disabled:bg-red-600/70 hover:bg-red-400 text-white text-[13px] font-bold px-[38px] py-1.5 rounded-[4px]"
                    >
                      Reject
                    </Button>
                    )}
                  </div>
                </div>
              </form>
            ) : (
              <PayrollActionNotice payroll={currentPayroll} isClosed={isClosed} onReprocess={onReprocess} />
            )}
        </>
      </div>
    </div>
  );
};

export default SubmitForReview;
