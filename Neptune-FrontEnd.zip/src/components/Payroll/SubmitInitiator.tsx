"use client";

import { useSelector } from "react-redux";
import { Button } from "../ui/button";
import { RootState } from "@/app/store";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { TbLoader3 } from "react-icons/tb";
import { useState } from "react";
import PayrollRunHeader from "./Runs/PayrollRunHeader";
import PayrollActionNotice from "./Runs/PayrollActionNotice";
import { canPerformAction, currentPayrollKey, getCurrentPayroll } from "@/lib/payroll-api";
import useActiveRoles from "@/hooks/Custom-hook/useActiveRoles";
import type { Id } from "@/types/payroll";

const schema = yup
  .object({
    reviewerEmail: yup
      .string()
      .email("Invalid email format")
      .required("Reviewer email is required")
  })
  .required();

const SubmitInitiator = ({
  threadData,
  setCurrentStep,
  payPeriodId,
  payrollId: selectedPayrollId,
  isClosed = false,
  onReprocess
}: {
  threadData: any;
  setCurrentStep: any;
  payPeriodId?: Id;
  payrollId?: Id;
  isClosed?: boolean;
  onReprocess?: () => void;
}) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isValid }
  } = useForm({ resolver: yupResolver(schema), mode: "onChange" });

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [rejectLoading, setRejectLoading] = useState<boolean>(false);
  const [message, setMessage] = useState<string>("");
  const user: any = useSelector((state: RootState) => state?.getUser?.user);
  const queryClient = useQueryClient();

  const isAdmin = user.roles.some(
    (roleObject: any) => roleObject.role === "Admin"
  );

  const initiatorRole = user.roles.some((roleObject: any) =>
    roleObject.role.toLowerCase().includes("initiator")
  );

  const reviewerRole = user.roles.some((roleObject: any) =>
    roleObject.role.toLowerCase().includes("reviewer")
  );

  // console.log("admin", isAdmin);

  // console.log("admin", initiatorRole);
  // console.log("admin", reviewerRole);

  const approvalRole = user.roles.some((roleObject: any) =>
    roleObject.role.toLowerCase().includes("approver")
  );

  const { roles } = useActiveRoles();

  const { data: currentPayroll, isPending } = useQuery({
    queryKey: currentPayrollKey(payPeriodId, selectedPayrollId),
    queryFn: () => getCurrentPayroll({ payPeriodId: payPeriodId as Id, payrollId: selectedPayrollId }),
    enabled: payPeriodId !== undefined && payPeriodId !== null && payPeriodId !== "",
    retry: false
  });

  const payrollId = selectedPayrollId ?? currentPayroll?.id ?? null;
  const isActionDone = Boolean(message);
  const canSubmit = !isClosed && !isActionDone && canPerformAction(currentPayroll, "Submit", roles);

  const handleReviewPayroll = async (data: any) => {
    try {
      if (!payrollId) {
        toast.error("No active payroll found to submit for review.");
        return;
      }
      setIsLoading(true);
      const payload = {
        payrollId,
        reviewerEmail: data.reviewerEmail
      };
      const response = await ApiFetcher.post(
        `/payroll/submit-payroll`,
        payload
      );
      toast.success("Payroll has been submitted for review.");
      setMessage("Payroll has been submitted for review.");
      return response;
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error submitting payroll for review";
      console.error(errorMessage);
      toast.error(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const reviewMutation = useMutation({
    mutationFn: handleReviewPayroll,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("review error", error);
    }
  });

  const onHandleReview = (data: any) => {
    reviewMutation.mutate(data);
    reset();
  };

  const handleRejectPayroll = async (data: any) => {
    try {
      setRejectLoading(true);
      // console.log("reject data::", data);
      const payload = {
        status: 4,
        reviewerComment: "N/A",
        authorizerComment: data.comments,
        payrollId
      };
      const response = await ApiFetcher.post(
        `/payroll/reject-payroll`,
        payload
      );

      setMessage("Payroll has been rejected!");
      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error approving payroll";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setRejectLoading(false);
    }
  };

  const rejectMutation = useMutation({
    mutationFn: handleRejectPayroll,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onHandleRejection = (data: any) => {
    rejectMutation.mutateAsync(data);
    rejectMutation.reset();
    reset();
  };

  const getAllUsers = async () => {
    try {
      const response = await ApiFetcher.get(
        `/users/get-all-users-in-an-organization`
      );
      // console.log("users::", response);
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching users";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: allUsers,
    isPending: pendingUsers,
    isLoading: loadingUsers,
    error
  } = useQuery({
    queryKey: ["fetchAllUsers"],
    queryFn: getAllUsers
  });

  const reviewers: any = allUsers?.data?.data?.filter(
    (user: any) => user.roles && user.roles.includes("Reviewer")
  );

  return (
    <div>
      <PayrollRunHeader payroll={currentPayroll} />
      <div>
        <h2 className="hidden text-[#000000] text-[17px] leading-[28.8px] font-semibold ">
          Review and Approval
        </h2>
      </div>

      <>
        {
          isActionDone ? (
            <p role="status" className="mt-4 mb-[48px] p-4 border border-green-200 bg-green-50 rounded text-sm text-green-900">
              {message}
            </p>
          ) : !canSubmit ? (
            <PayrollActionNotice payroll={currentPayroll} isClosed={isClosed} onReprocess={onReprocess} />
          ) : (
            <div className="mt-4 mb-[48px]">
              {canSubmit && (
                <form>
                  <div className="mb-4">
                    <h2 className="text-sm font-bold">Submit</h2>
                    {/* <p className="text-xs text-[#63666A] mt-[5px] mb-[3px]">
                Review with comments
              </p> */}
                  </div>

                  <div className="mb-4">
                    <select
                      aria-label="Reviewer"
                      {...register("reviewerEmail")}
                      className="w-full text-base py-[7px] placeholder:text-sm px-4 rounded-[4px] border border-[#D0D0CE] text-gray-900"
                    >
                      <option value="">Select Reviewer</option>
                      {reviewers &&
                        reviewers.map((reviewer: any) => (
                          <option key={reviewer.id} value={reviewer.email}>
                            {reviewer.email}
                          </option>
                        ))}
                    </select>
                    {/* <input
                type="text"
                className="w-full text-base py-[7px] placeholder:text-sm px-4 rounded-[4px] border border-[#D0D0CE] text-gray-900"
                placeholder="Authorizer email"
                {...register("reviewerEmail")}
              /> */}
                  </div>

                  <div className="flex items-center space-x-2">
                    <Button
                      type="button"
                      disabled={isLoading || !payrollId || isPending || !isValid}
                      onClick={handleSubmit(onHandleReview)}
                      className="disabled:bg-secondary disabled:bg-opacity-70 bg-primary text-white text-[13px] font-bold px-[38px] py-1.5 rounded-[4px]"
                    >
                      {isLoading ? (
                        <div className="flex items-center justify-center">
                          <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                        </div>
                      ) : (
                        "Submit"
                      )}
                    </Button>

                    <Button
                      onClick={() => setCurrentStep(3)}
                      className="bg-red-600 hover:bg-red-400 text-white text-[13px] font-bold px-[38px] py-1.5 rounded-[4px]"
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              )}

              {/* {["Admin"].some((roleObject: any) => roleObject.includes("Admin")) && (
          <div className="mt-10">ddjhjjhj</div>
        )} */}
            </div>
          )
        }


      </>

      {/* {threadData?.isPayrollRun ? (
       <></>
      ) : (
        <>
          <div className="flex items-center space-x-2 mt-4 mb-[48px] p-4 border border-yellow-300 bg-yellow-50 rounded">
            <Info className="" />
            <p className="text-sm text-gray-700 mt-2">
              You can now submit the payroll for review. Once submitted, the
              assigned reviewer will be notified to review the payroll details.
            </p>
          </div>
        </>
      )} */}
    </div>
  );
};

export default SubmitInitiator;
