"use client";

import { useSelector } from "react-redux";
import { Button } from "../ui/button";
import { RootState } from "@/app/store";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { TbLoader3 } from "react-icons/tb";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { currentPayrollKey, getCurrentPayroll } from "@/lib/payroll-api";
import type { Id } from "@/types/payroll";

const schema = yup
  .object({
    comments: yup.string().min(5, "Comments should be 5 characters or more")
  })
  .required();

const SubmitToAuthorize = ({
  threadData,
  setCurrentStep,
  payPeriodId
}: {
  threadData: any;
  setCurrentStep: any;
  payPeriodId?: Id;
}) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isValid }
  } = useForm({ resolver: yupResolver(schema) });

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [rejectLoading, setRejectLoading] = useState<boolean>(false);
  const [message, setMessage] = useState<string>("");
  const user: any = useSelector((state: RootState) => state?.getUser?.user);
  const router = useRouter();
  const queryClient = useQueryClient();

  const isAdmin = user.roles.some(
    (roleObject: any) => roleObject.role === "Admin"
  );

  const initiatorRole = user.roles.some((roleObject: any) =>
    roleObject.role.toLowerCase().includes("initiator")
  );

  const approvalRole = user.roles.some((roleObject: any) =>
    roleObject.role.toLowerCase().includes("approver")
  );

  const { data: currentPayroll, isPending, isError } = useQuery({
    queryKey: currentPayrollKey(payPeriodId),
    queryFn: () => getCurrentPayroll({ payPeriodId: payPeriodId as Id }),
    enabled: payPeriodId !== undefined && payPeriodId !== null && payPeriodId !== "",
    retry: false
  });

  const payrollId = currentPayroll?.id ?? null;

  const handleReviewPayroll = async (data: any) => {
    try {
      if (!payrollId) {
        toast.error("No active payroll found to submit for review.");
        return;
      }
      setIsLoading(true);
      const payload = {
        authorizerComment: data.comments,
        payrollId
      };
      const response = await ApiFetcher.post(
        `/payroll/approve-payroll`,
        payload
      );
      toast.success("Payroll has been submitted for review.");
      router.push("/dashboard/payroll");
      setCurrentStep(1);
      return response;
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error submitting payroll for review";
      console.error(errorMessage);
      toast.error(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const reviewMutation = useMutation({
    mutationFn: handleReviewPayroll,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("review error", error);
    }
  });

  const onHandleReview = (data: any) => {
    reviewMutation.mutateAsync(data);
    reviewMutation.reset();
    reset();
  };

  const handleRejectPayroll = async (data: any) => {
    try {
      if (!payrollId) {
        toast.error("No active payroll found to submit for review.");
        return;
      }
      setRejectLoading(true);
      // console.log("reject data::", data);
      const payload = {
        authorizerComment: data.comments,
        payrollId
      };
      const response = await ApiFetcher.post(
        `/payroll/reject-payroll`,
        payload
      );

      setMessage("Payroll has been rejected!");
      router.push("/dashboard/payroll");
      setCurrentStep(1);
      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error approving payroll";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setRejectLoading(false);
    }
  };

  const rejectMutation = useMutation({
    mutationFn: handleRejectPayroll,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onHandleRejection = (data: any) => {
    rejectMutation.mutateAsync(data);
    rejectMutation.reset();
    reset();
  };

  return (
    <div>
      <div>
        <h2 className="hidden text-[#000000] text-[17px] leading-[28.8px] font-semibold ">
          Review and Approval
        </h2>
      </div>

      <div className="mt-4 mb-[48px]">
        {/* Admin approvals*/}
        {isAdmin && (
          <form>
            <div className="mb-4">
              <h2 className="text-sm font-bold">Reviewer</h2>
              <p className="text-xs text-[#63666A] mt-[5px] mb-[3px]">
                Approve with comments
              </p>
            </div>

            <div className="space-y-3">
              {message ? (
                <>
                  <p>{message}</p>
                </>
              ) : (
                <div>
                  <textarea
                    placeholder="Comments"
                    {...register("comments")}
                    className="bg-gray-50 border placeholder:text-sm border-gray-300 py-[9px] px-[12px] text-gray-900 text-sm rounded-lg w-full"
                  ></textarea>

                  <p
                    className="text-red-400 mt-1 text-xs lg:text-sm"
                    role="alert"
                  >
                    {errors.comments?.message}
                  </p>
                </div>
              )}

              <div className="flex items-center space-x-2">
                <Button
                  type="button"
                  disabled={isLoading || !isValid}
                  onClick={handleSubmit(onHandleReview)}
                  className="disabled:bg-secondary disabled:bg-opacity-70 bg-primary text-white text-[13px] font-bold px-[38px] py-1.5 rounded-[4px]"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                    </div>
                  ) : (
                    "Submit"
                  )}
                </Button>

                <Button
                  onClick={() => setCurrentStep(3)}
                  className="bg-red-600 hover:bg-red-400 text-white text-[13px] font-bold px-[38px] py-1.5 rounded-[4px]"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </form>
        )}

        {/* {["Admin"].some((roleObject: any) => roleObject.includes("Admin")) && (
          <div className="mt-10">ddjhjjhj</div>
        )} */}
      </div>
    </div>
  );
};

export default SubmitToAuthorize;
