"use client";

import React from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from "@/components/ui/tooltip";
import { parseComponentName } from "@/lib/report-components";

export const BASIS_ONLY_GROUP_LABEL = "For computation only (not paid)";

const HEADER_HINTS = {
  arrears: "Top-up or arrears for an annual entitlement.",
  basisOnly: "Used to calculate pension, tax, NHF or NSITF. Not paid to the employee."
} as const;

export const basisOnlyCellClassName = "italic text-[#757575] bg-[#F7F7F7]";

export const ComponentHeaderCell = ({
  name,
  className = ""
}: {
  name: string;
  className?: string;
}) => {
  const { kind } = parseComponentName(name);
  const muted = kind === "basisOnly" ? basisOnlyCellClassName : "";

  if (kind === "regular") {
    return <th className={`p-4 text-xs font-semibold ${className}`}>{name}</th>;
  }

  return (
    <th className={`p-4 text-xs font-semibold ${muted} ${className}`}>
      <TooltipProvider delayDuration={100}>
        <Tooltip>
          {/* Focusable trigger so the hint is also available to keyboard users. */}
          <TooltipTrigger asChild>
            <span
              tabIndex={0}
              className="cursor-help underline decoration-dotted underline-offset-4 rounded focus:outline-none focus:ring-2 focus:ring-primary"
            >
              {name}
            </span>
          </TooltipTrigger>
          <TooltipContent className="bg-white max-w-xs text-xs normal-case font-normal not-italic">
            {HEADER_HINTS[kind]}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </th>
  );
};

// Spacer cells keep the group header aligned without restructuring the existing header row.
export const BasisOnlyGroupRow = ({
  leading,
  basisCount,
  trailing
}: {
  leading: number;
  basisCount: number;
  trailing: number;
}) =>
  basisCount === 0 ? null : (
    <tr>
      <td colSpan={leading} aria-hidden />
      <th
        scope="colgroup"
        colSpan={basisCount}
        className={`px-4 pt-3 pb-1 text-[11px] font-semibold text-center border-b border-[#D9D9D9] ${basisOnlyCellClassName}`}
      >
        {BASIS_ONLY_GROUP_LABEL}
      </th>
      {trailing > 0 && <td colSpan={trailing} aria-hidden />}
    </tr>
  );

export const ComponentLegend = () => (
  <p className="mt-3 px-4 text-xs text-[#63666A]">
    <span className="font-semibold">(arrears)</span> = top-up for an annual item;{" "}
    <span className="font-semibold italic">(basis only)</span> = not paid, used in calculations only.
  </p>
);
