import React, { useEffect, useState } from "react";
import {
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import { TbLoader3 } from "react-icons/tb";
import { validateAllowance } from "@/lib/allowance-rules";
import type {
  PayComponent,
  UpdatePayComponentRequest
} from "@/types/backend";

interface AllowanceDialogProps {
  id: string | number;
  setOpenAllowanceItem: React.Dispatch<React.SetStateAction<boolean>>;
}

interface FormData {
  allowanceName: string;
  timesPayable: string | number;
  employerTaxSharePercent: string | number;
  paymentMonth: string;
}

const AllowanceDialog = ({
  id,
  setOpenAllowanceItem,
}: AllowanceDialogProps) => {
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState<FormData>({
    allowanceName: "",
    timesPayable: "",
    employerTaxSharePercent: "100",
    paymentMonth: ""
  });

  const [checkTaxable, setCheckTaxable] = useState<boolean>(false);
  const [checkPensionable, setCheckPensionable] = useState<boolean>(false);
  const [checkNHF, setCheckNHF] = useState<boolean>(false);
  const [includeInGrossPay, setIncludeInGrossPay] = useState(true);
  const [isNSITF, setIsNSITF] = useState(false);
  const [isEmployerTaxBorne, setIsEmployerTaxBorne] = useState(false);
  const [isGrossUp, setIsGrossUp] = useState(false);
  const [trueUpOnChange, setTrueUpOnChange] = useState(false);

  // const handleInputChange = (
  //   e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  // ) => {
  //   const { name, value } = e.target;

  //   setFormData((prev) => ({
  //     ...prev,
  //     value,
  //   }));
  // };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;

    setFormData((prev: any) => ({
      ...prev,
      [name]: value
    }));
  };

  const getAllowanceById = async (id: string | number) => {
    if (!id) return null;

    try {
      const response = await ApiFetcher.get(
        `/tax/get-allowanceitem-by-id/${id}`
      );

      return response?.data?.data;
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message ||
        "Error fetching allowance item by Id";

      toast.error(errorMessage);
      throw error;
    }
  };

  const {
    data: allowanceItemDetail,
    isPending: isAllowanceItemPending,
  } = useQuery({
    queryKey: ["getAllowanceItems", id],
    queryFn: () => getAllowanceById(id),
    enabled: !!id,
    staleTime: 0,
  });

  useEffect(() => {
    if (!allowanceItemDetail) return;

    setFormData({
      allowanceName: allowanceItemDetail?.name || "",
      timesPayable: allowanceItemDetail?.noOfTimesPayable || "",
      employerTaxSharePercent:
        allowanceItemDetail?.employerTaxSharePercent ?? "100",
      paymentMonth: allowanceItemDetail?.paymentMonth
        ? String(allowanceItemDetail.paymentMonth)
        : ""
    });

    setCheckTaxable(allowanceItemDetail?.isTaxable ?? false);
    setCheckPensionable(allowanceItemDetail?.isPension ?? false);
    setCheckNHF(allowanceItemDetail?.isNHF ?? false);
    setIncludeInGrossPay(!(allowanceItemDetail?.isBasisOnly ?? false));
    setIsNSITF(allowanceItemDetail?.isNSITF ?? allowanceItemDetail?.isTaxable ?? false);
    setIsEmployerTaxBorne(allowanceItemDetail?.isEmployerTaxBorne ?? false);
    setIsGrossUp(allowanceItemDetail?.isGrossUp ?? false);
    setTrueUpOnChange(allowanceItemDetail?.trueUpOnChange ?? false);
  }, [allowanceItemDetail]);

  const handleSaveAllowance = async (
    e: React.FormEvent<HTMLFormElement>
  ) => {
    e.preventDefault();

    try {
      const ruleError = validateAllowance({
        name: formData.allowanceName,
        isTaxable: checkTaxable,
        isGrossUp: isGrossUp && includeInGrossPay && !formData.paymentMonth,
        trueUpOnChange: trueUpOnChange && !!formData.paymentMonth,
        paymentMonth: formData.paymentMonth,
        isEmployerTaxBorne,
        employerTaxSharePercent: formData.employerTaxSharePercent,
        timesPayable: formData.timesPayable
      });
      if (ruleError) {
        toast.error(ruleError);
        return;
      }

      const current = allowanceItemDetail as PayComponent;
      const payload: UpdatePayComponentRequest = {};
      const setIfChanged = <K extends keyof UpdatePayComponentRequest>(
        key: K,
        value: UpdatePayComponentRequest[K],
        previous: unknown
      ) => {
        if (value !== previous) payload[key] = value;
      };

      setIfChanged("name", formData.allowanceName.trim(), current.name);
      setIfChanged(
        "noOfTimesPayable",
        Number(formData.timesPayable || 0),
        current.noOfTimesPayable ?? 0
      );
      setIfChanged("isTaxable", checkTaxable, current.isTaxable ?? false);
      setIfChanged("isPension", checkPensionable, current.isPension ?? false);
      setIfChanged("isNHF", checkNHF, current.isNHF ?? false);
      setIfChanged("isBasisOnly", !includeInGrossPay, current.isBasisOnly ?? false);
      setIfChanged("isNSITF", isNSITF, current.isNSITF ?? false);
      setIfChanged(
        "isEmployerTaxBorne",
        isEmployerTaxBorne,
        current.isEmployerTaxBorne ?? false
      );
      setIfChanged(
        "isGrossUp",
        isGrossUp && includeInGrossPay && !formData.paymentMonth,
        current.isGrossUp ?? false
      );
      setIfChanged("trueUpOnChange", trueUpOnChange, current.trueUpOnChange ?? false);

      const employerShare = Number(formData.employerTaxSharePercent || 100);
      if (isEmployerTaxBorne) {
        setIfChanged(
          "employerTaxSharePercent",
          employerShare,
          current.employerTaxSharePercent ?? 100
        );
      } else if (current.employerTaxSharePercent != null) {
        payload.clearEmployerTaxShare = true;
      }

      const paymentMonth = formData.paymentMonth
        ? Number(formData.paymentMonth)
        : null;
      if (paymentMonth == null) {
        if (current.paymentMonth != null) payload.clearPaymentMonth = true;
        if (current.paymentMonth != null || trueUpOnChange) {
          payload.trueUpOnChange = false;
        }
      } else {
        setIfChanged("paymentMonth", paymentMonth, current.paymentMonth ?? null);
      }

      await ApiFetcher.put(
        `/tax/update-allowance-item/${id}`,
        payload
      );

      toast.success("Allowance updated successfully");

      queryClient.invalidateQueries({
        queryKey: ["getAllowanceItems"],
      });

      setOpenAllowanceItem(false);
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message ||
        "Error updating allowance item.";

      toast.error(errorMessage);
    }
  };

  return (
    <DialogContent className="bg-white">
      <DialogHeader>
        <DialogTitle className="text-xl">
          Update allowance items
        </DialogTitle>

        {isAllowanceItemPending ? (
          <div className="py-4 flex items-center justify-center h-full w-full">
            <TbLoader3 className="text-primary animate-spin w-6 h-6" />
          </div>
        ) : (
          <form onSubmit={handleSaveAllowance} className="pt-3">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <input
                  className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                  type="text"
                  placeholder="Allowance title"
                  id="allowanceName"
                  name="allowanceName"
                  value={formData.allowanceName}
                  onChange={handleInputChange}
                />
              </div>

              <div className="col-span-2">
                <input
                  className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                  type="number"
                  placeholder="Number of months payable"
                  name="timesPayable"
                  value={formData.timesPayable}
                  onChange={handleInputChange}
                />
              </div>

              <div className="col-span-2 flex items-center">
                <input
                  type="checkbox"
                  id="isNHF"
                  checked={checkNHF}
                  onChange={(e) => setCheckNHF(e.target.checked)}
                />
                <span className="pl-2">
                  Is this allowance liable to NHF?
                </span>
              </div>

              <div className="col-span-2 flex items-start gap-2">
                <input
                  type="checkbox"
                  checked={includeInGrossPay}
                  onChange={(e) => setIncludeInGrossPay(e.target.checked)}
                />
                <div>
                  <span>Include in gross pay</span>
                  {!includeInGrossPay && (
                    <p className="text-xs text-gray-600">
                      Not paid. Only counts towards the ticked items (taxable,
                      pensionable, NHF, NSITF).
                    </p>
                  )}
                </div>
              </div>

              <div className="col-span-2 flex items-center">
                <input
                  type="checkbox"
                  checked={isNSITF}
                  onChange={(e) => setIsNSITF(e.target.checked)}
                />
                <span className="pl-2">NSITF</span>
              </div>

              <div className="col-span-2 flex items-center">
                <input
                  type="checkbox"
                  checked={isEmployerTaxBorne}
                  disabled={!checkTaxable}
                  onChange={(e) => setIsEmployerTaxBorne(e.target.checked)}
                />
                <span className="pl-2">Employer tax borne</span>
              </div>

              {isEmployerTaxBorne && (
                <div className="col-span-2">
                  <label className="block text-sm mb-1">Employer share %</label>
                  <input
                    className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                    type="number"
                    min={0}
                    max={100}
                    placeholder="100"
                    value={formData.employerTaxSharePercent}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        employerTaxSharePercent: e.target.value
                      }))
                    }
                  />
                </div>
              )}

              {checkTaxable && !formData.paymentMonth && (
                <div className="col-span-2 flex items-center">
                  <input
                    type="checkbox"
                    checked={isGrossUp}
                    disabled={!checkTaxable || !includeInGrossPay}
                    onChange={(e) => setIsGrossUp(e.target.checked)}
                  />
                  <span className="pl-2">Gross up</span>
                </div>
              )}

              <div className="col-span-2">
                <label className="block text-sm mb-1">Payment month</label>
                <select
                  className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                  value={formData.paymentMonth}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      paymentMonth: e.target.value
                    }))
                  }
                >
                  <option value="">None</option>
                  {Array.from({ length: 12 }, (_, index) => (
                    <option key={index + 1} value={index + 1}>
                      {new Date(2000, index, 1).toLocaleString("en", {
                        month: "long"
                      })}
                    </option>
                  ))}
                </select>
              </div>

              {!!formData.paymentMonth && (
                <div className="col-span-2 flex items-center">
                  <input
                    type="checkbox"
                    checked={trueUpOnChange}
                    onChange={(e) => setTrueUpOnChange(e.target.checked)}
                  />
                  <span className="pl-2">Top up on change</span>
                </div>
              )}

              <div className="col-span-2 flex items-center">
                <input
                  type="checkbox"
                  id="isTaxable"
                  checked={checkTaxable}
                  onChange={(e) => {
                    // Same side effects as Create Allowance.
                    const taxable = e.target.checked;
                    setCheckTaxable(taxable);
                    if (taxable) setIsNSITF(true);
                    if (!taxable) {
                      setIsEmployerTaxBorne(false);
                      setIsGrossUp(false);
                    }
                  }}
                />
                <span className="pl-2">
                  Is this allowance item taxable?
                </span>
              </div>

              <div className="col-span-2 flex items-center">
                <input
                  type="checkbox"
                  id="isPension"
                  checked={checkPensionable}
                  onChange={(e) =>
                    setCheckPensionable(e.target.checked)
                  }
                />
                <span className="pl-2">
                  Is this allowance item pensionable?
                </span>
              </div>

              <div className="col-span-2">
                <button
                  type="submit"
                  className="w-full bg-secondary text-white rounded-[4px] py-2.5 px-3"
                >
                  Save allowance
                </button>
              </div>
            </div>
          </form>
        )}
      </DialogHeader>
    </DialogContent>
  );
};

export default AllowanceDialog;