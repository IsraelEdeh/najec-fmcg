"use client";

import React, { act, useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "../ui/table";
import * as yup from "yup";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { formatPageRange } from "@/lib/utils";
import { TbLoader3 } from "react-icons/tb";
import {
  RiArrowLeftSFill,
  RiArrowRightSFill,
  RiDeleteBin2Fill
} from "react-icons/ri";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import { Dialog } from "@/components/ui/dialog";
import EmptyRecord from "../dashboard/EmptyRecord";
import CustomButton from "@/components/Elements/CustomButton";
import { FaEdit } from "react-icons/fa";
import AllowanceDialog from "./AllowanceDialog";
import { Badge } from "@/components/ui/badge";

const schema = yup.object().shape({
  allowances: yup.array().of(
    yup.object().shape({
      name: yup
        .string()
        .min(3, "Name must be at least 3 characters")
        .required("Name is required"),
      isNHF: yup.string().optional(),
      taxRelief: yup.string(),
      amountType: yup.string(),
      frequency: yup.string(),
      timesPayable: yup.string()
    })
  )
});

const Allowances = () => {
  const user: any = useSelector((state: RootState) => state?.getUser.user);
  const queryClient = useQueryClient();

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const [openAllowanceItem, setOpenAllowanceItem] = useState<boolean>(false);
  const [allowanceItem, setAllowanceItem] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [allowances, setAllowances] = useState<any>([
    {
      name: "",
      isNHF: false,
      taxRelief: "0",
      amountType: "",
      frequency: "",
      timesPayable: "",
      isPension: false,
      isTaxable: false
    }
  ]);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const maxPage = 10;
  const getMonthName = (month?: number | null) =>
    month
      ? new Date(2000, month - 1, 1).toLocaleString("en", {
          month: "long"
        })
      : "";

  const handleSaveAllowance = async (index: number) => {
    try {
      const allowanceToSave = allowances[index];
      await schema.validate({ allowances });
      console.log("Saving allowance:", allowanceToSave);

      setLoading(true);
      const payload = {
        organizationId: user?.userOrganizations?.find(
          (item: any) => item.isCurrentLoggedInOrganization
        )?.organizationId,
        payComponents: [
          {
            name: allowanceToSave.name.trim(),
            isNHF: allowanceToSave.isNHF,
            isTaxable: Boolean(allowanceToSave.isTaxable),
            isDeduction: false,
            isPension: Boolean(allowanceToSave.isPension),
            taxRelief: Number(allowanceToSave.taxRelief),
            amountType: Number(allowanceToSave.amountType),
            frequency: Number(allowanceToSave.frequency),
            noOfTimesPayable: Number(allowanceToSave.timesPayable)
          }
        ]
      };

      const response = await ApiFetcher.post(
        "/tax/create-allowance-items",
        payload
      );

      // console.log("rax allowance", response);
      if (response) {
        toast.success("Created successfully");
      }
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding allowance items.";
      console.log(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const mutation = useMutation({
    mutationFn: handleSaveAllowance,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const getAllowanceItems = async (page: number) => {
    try {
      const response: any = await ApiFetcher.get(
        `/tax/get-all-allowanceItems?PageNumber=${page}&PageSize=${maxPage}`
      );


      return response || [];
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching allowance items";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: allowanceItems,
    isPending,
    isLoading,
    error
  } = useQuery({
    queryKey: ["getAllowanceItems", currentPage],
    placeholderData: keepPreviousData,
    queryFn: () => getAllowanceItems(currentPage)
  });

  const handleDeleteAllowanceItem = async (id: any) => {
    try {
      const response = await ApiFetcher.delete(
        `/tax/delete-allowanceItem/${id}`
      );

      // console.log("jargons", id);
      toast.success("Allowance item removed sucessfully");
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error deleting allowance.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const deleteMutation = useMutation({
    mutationFn: handleDeleteAllowanceItem,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  const onHandlerDelete = (id: number) => {
    try {
      deleteMutation.mutateAsync(id);
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding department.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const deleteAllAllowance = async () => {
    try {
      const response = await ApiFetcher.delete(
        "/tax/delete-all-allowanceItems"
      );
      toast.success("Successfully deleted all allowance items");
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error deleting all allowance item.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const allDeleteMutation = useMutation({
    mutationFn: deleteAllAllowance,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  const onHandlerAllDelete = () => {
    try {
      allDeleteMutation.mutateAsync();
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding department.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  return (
    <div className="mt-10">
      <Dialog open={openAllowanceItem} onOpenChange={setOpenAllowanceItem}>
        <div className="flex justify-end mb-4">
          {allowanceItems?.data?.data?.length >= 3 && (
            <CustomButton
              type="button"
              onClick={onHandlerAllDelete}
              classType="primary"
              className="w-fit text-xs px-2 py-[9px] bg-red-600 text-white rounded-[8px]"
            >
              {allDeleteMutation.isPending
                ? "Removing . . ."
                : "Remove all allowances"}
            </CustomButton>
          )}
        </div>

        <Table className="text-[#1E1E1E] overflow-x-scroll">
          <TableHeader className="rounded-[4px] border bg-[#DDEFE8] text-sm">
            <TableRow className=" w-full">
              <TableHead className="font-bold">Name</TableHead>

              <TableHead className="font-bold">Months payable</TableHead>

              <TableHead className="font-bold">Months remaining</TableHead>

              <TableHead className="font-bold">Taxable</TableHead>

              <TableHead className="font-bold">Pension</TableHead>

              <TableHead className="font-bold">NHF</TableHead>

              <TableHead className="font-bold">Configuration</TableHead>

              <TableHead className="font-bold"></TableHead>
            </TableRow>
          </TableHeader>

          <TableBody className="text-[11px] capitalize">
            {isPending ? (
              <TableRow className="flex w-full justify-center py-4">
                <TableCell>
                  <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                </TableCell>
              </TableRow>
            ) : allowanceItems?.data?.data?.length === 0 ? (
              <EmptyRecord />
            ) : (
              allowanceItems?.data?.data?.map((items: any) => (
                <TableRow key={items?.id} className="border-0">
                  <TableCell>
                    <span className="capitalize">{items.name}</span>
                  </TableCell>

                  <TableCell>{items?.noOfTimesPayable}</TableCell>

                  <TableCell>{items?.noOfTimesRemaining}</TableCell>

                  <TableCell>
                    {items.isTaxable ? "Taxable" : "Non-taxable"}
                  </TableCell>

                  <TableCell>
                    {items.isPension ? "Pensionable" : "Non-Pensionable"}
                  </TableCell>

                  <TableCell>{items.isNHF ? "True" : "False"}</TableCell>

                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {items?.isBasisOnly && (
                        <Badge className="border-orange-200 bg-orange-50 text-orange-700">
                          Not Paid
                        </Badge>
                      )}
                      {items?.isEmployerTaxBorne && (
                        <Badge className="border-blue-200 bg-blue-50 text-blue-700">
                          Employer Tax
                        </Badge>
                      )}
                      {items?.isGrossUp && (
                        <Badge className="border-purple-200 bg-purple-50 text-purple-700">
                          Gross Up
                        </Badge>
                      )}
                      {items?.isNSITF && (
                        <Badge className="border-green-200 bg-green-50 text-green-700">
                          NSITF
                        </Badge>
                      )}
                      {items?.paymentMonth && (
                        <Badge className="border-slate-200 bg-slate-50 text-slate-700">
                          Annual ({getMonthName(items.paymentMonth)})
                        </Badge>
                      )}
                    </div>
                  </TableCell>

                  <TableCell className="flex items-center space-x-2">
                    {(activeRole?.includes("Admin") ||
                      activeRole?.includes("Initiator")) && (
                      <>
                        <FaEdit
                          onClick={() => {
                            setOpenAllowanceItem(true);
                            setAllowanceItem(items);
                          }}
                          className="text-lg cursor-pointer"
                        />
                        <RiDeleteBin2Fill
                          onClick={() => onHandlerDelete(items?.id)}
                          className="cursor-pointer text-lg"
                        />
                      </>
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
        <div className="mt-4 flex items-center justify-between py-2 px-4">
          <p className="text-[#63666A] text-xs">
            {formatPageRange(allowanceItems?.data?.meta, maxPage)}
          </p>

          <div className="flex items-center space-x-3">
            <button
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage((e: number) => e - 1)}
              className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
            >
              <RiArrowLeftSFill className="w-6 h-6" />
            </button>

            <button
              disabled={currentPage >= (Number(allowanceItems?.data?.meta?.totalPages) || 1)}
              onClick={() => setCurrentPage((e: number) => e + 1)}
              className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
            >
              <RiArrowRightSFill className="w-6 h-6" />
            </button>
          </div>
        </div>
        <AllowanceDialog
          id={allowanceItem?.id}
          setOpenAllowanceItem={setOpenAllowanceItem}
        />
      </Dialog>
    </div>
  );
};

export default Allowances;
