"use client";

import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "../ui/table";
import { TbLoader3 } from "react-icons/tb";
import { toast } from "react-toastify";
import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { formatPageRange } from "@/lib/utils";
import ApiFetcher from "../Utils/api";
import {
  RiArrowLeftSFill,
  RiArrowRightSFill,
  RiDeleteBin2Fill
} from "react-icons/ri";
import EmptyRecord from "../dashboard/EmptyRecord";
import CustomButton from "@/components/Elements/CustomButton";
import { FaEdit } from "react-icons/fa";
import { Dialog } from "@/components/ui/dialog";
import DeductionDialog from "@/components/Taxes/DeductionDialog";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";

const Deductions = () => {
  const [openDeductionItem, setOpenDeductionItem] = useState<boolean>(false);
  const [selectedDeductionId, setSelectedDeductionId] = useState<number | null>(
    null
  );
  const queryClient = useQueryClient();

  const [currentPage, setCurrentPage] = useState<number>(1);
  const maxPage = 10;

  const user: any = useSelector((state: RootState) => state.getUser.user);

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const getDeductionsItems = async (page: Number) => {
    try {
      const response: any = await ApiFetcher.get(
        `/tax/get-all-deductionsItems?PageNumber=${page}&PageSize=${maxPage}`
      );


      return response || [];
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error fetching allowance items";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const { data: deductionItems, isPending } = useQuery({
    queryKey: ["getDeductionsItems", currentPage],
    placeholderData: keepPreviousData,
    queryFn: () => getDeductionsItems(currentPage)
  });

  const handleDeleteAllowanceItem = async (id: number) => {
    try {
      const response = await ApiFetcher.delete(
        `/tax/delete-deductionItem/${id}`
      );
      toast.success("Deduction items removed sucessfully");
      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error deleting deduction.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const deleteMutation = useMutation({
    mutationFn: handleDeleteAllowanceItem,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  const onHandlerDelete = (id: number) => {
    try {
      deleteMutation.mutateAsync(id);
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error deleting deduction.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const deleteAllDeductions = async () => {
    try {
      const response = await ApiFetcher.delete(
        "/tax/delete-all-deductionItems"
      );
      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error deleting all allowance item.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const allDeleteMutation = useMutation({
    mutationFn: deleteAllDeductions,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  const onHandlerAllDelete = () => {
    try {
      allDeleteMutation.mutateAsync();
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error deleting all deductions.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  // Handler for opening the dialog and setting the selected deduction id
  const handleEditDeduction = (id: number) => {
    setSelectedDeductionId(id);
    setOpenDeductionItem(true);
  };

  // Handler for closing the dialog and clearing the selected id
  const handleDialogClose = () => {
    setOpenDeductionItem(false);
    setSelectedDeductionId(null);
  };

  return (
    <div className="mt-10">
      <Dialog open={openDeductionItem} onOpenChange={handleDialogClose}>
        <div className="flex justify-end mb-4">
          {deductionItems?.length >= 3 && (
            <CustomButton
              type="button"
              onClick={onHandlerAllDelete}
              classType="primary"
              className="w-fit text-xs px-2 py-[9px] bg-red-600 text-white rounded-[8px]"
            >
              {allDeleteMutation.isPending
                ? "Removing . . ."
                : "Remove all deductions"}
            </CustomButton>
          )}
        </div>

        <Table className="text-[#1E1E1E] overflow-x-scroll">
          <TableHeader className="rounded-[4px] border bg-[#DDEFE8] text-sm">
            <TableRow className=" w-full">
              <TableHead className="font-bold">Name</TableHead>
              <TableHead className="font-bold">Months payable</TableHead>
              <TableHead className="font-bold">Months remaining</TableHead>
              <TableHead className="font-bold"></TableHead>
            </TableRow>
          </TableHeader>

          <TableBody className="text-[11px]">
            {isPending ? (
              <TableRow className="flex w-full justify-center py-4">
                <TableCell>
                  <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                </TableCell>
              </TableRow>
            ) : deductionItems?.data?.data?.length === 0 ? (
              <EmptyRecord />
            ) : (
              deductionItems?.data?.data?.map((item: any) => (
                <TableRow key={item.id} className="border-0">
                  <TableCell>{item.name}</TableCell>
                  <TableCell>{item?.noOfTimesPayable}</TableCell>
                  <TableCell>{item?.noOfTimesRemaining}</TableCell>
                  <TableCell className="flex items-center space-x-2">
                    {(activeRole?.includes("Admin") ||
                      activeRole?.includes("Initiator")) && (
                      <>
                        <FaEdit
                          onClick={() => handleEditDeduction(item.id)}
                          className="text-lg cursor-pointer"
                        />
                        <RiDeleteBin2Fill
                          onClick={() => onHandlerDelete(item.id)}
                          className="cursor-pointer text-lg"
                        />
                      </>
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>

        <div className="mt-4 flex items-center justify-between py-2 px-4">
          <p className="text-[#63666A] text-xs">
            {formatPageRange(deductionItems?.data?.meta, maxPage)}
          </p>

          <div className="flex items-center space-x-3">
            <button
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage((e: number) => e - 1)}
              className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
            >
              <RiArrowLeftSFill className="w-6 h-6" />
            </button>

            <button
              disabled={currentPage >= (Number(deductionItems?.data?.meta?.totalPages) || 1)}
              onClick={() => setCurrentPage((e: number) => e + 1)}
              className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
            >
              <RiArrowRightSFill className="w-6 h-6" />
            </button>
          </div>
        </div>

        {selectedDeductionId !== null && (
          <DeductionDialog
            id={selectedDeductionId}
            setOpenDeductionItem={setOpenDeductionItem}
          />
        )}
      </Dialog>
    </div>
  );
};

export default Deductions;
