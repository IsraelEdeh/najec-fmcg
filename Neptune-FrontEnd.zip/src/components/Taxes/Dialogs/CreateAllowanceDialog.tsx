import React from 'react'

const CreateAllowanceDialog = () => {
  return (
    <div>CreateAllowanceDialog</div>
  )
}

export default CreateAllowanceDialog