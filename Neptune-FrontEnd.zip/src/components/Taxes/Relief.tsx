"use client";

import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "../ui/table";
import * as yup from "yup";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { formatPageRange } from "@/lib/utils";
import { TbLoader3 } from "react-icons/tb";
import {
  RiArrowLeftSFill,
  RiArrowRightSFill,
  RiDeleteBin2Fill
} from "react-icons/ri";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import { Dialog } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import EmptyRecord from "../dashboard/EmptyRecord";
import CustomButton from "@/components/Elements/CustomButton";
import { FaEdit } from "react-icons/fa";
import ReliefDialog from "./ReliefDialog";
import { max } from "lodash";

const schema = yup.object().shape({
  allowances: yup.array().of(
    yup.object().shape({
      name: yup
        .string()
        .min(3, "Name must be at least 3 characters")
        .required("Name is required"),
      isNHF: yup.string().optional(),
      taxRelief: yup.string(),
      amountType: yup.string(),
      frequency: yup.string(),
      timesPayable: yup.string()
    })
  )
});

const Relief = () => {
  const user: any = useSelector((state: RootState) => state?.getUser.user);
  const queryClient = useQueryClient();

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const [currentPage, setCurrentPage] = useState<number>(1);
  const maxPage = 10;

  const [openAllowanceItem, setOpenAllowanceItem] = useState<boolean>(false);
  const [reliefItem, setReliefItem] = useState<any>(null);

  const [loading, setLoading] = useState<boolean>(false);
  const [allowances, setAllowances] = useState<any>([
    {
      name: "",
      isNHF: false,
      taxRelief: "0",
      amountType: "",
      frequency: "",
      timesPayable: "",
      isPension: false,
      isTaxable: false
    }
  ]);

  const handleSaveRelief = async (index: number) => {
    try {
      const allowanceToSave = allowances[index];
      await schema.validate({ allowances });

      setLoading(true);
      const payload = {
        organizationId: user?.userOrganizations?.find(
          (item: any) => item.isCurrentLoggedInOrganization
        )?.organizationId,
        payComponents: [
          {
            name: allowanceToSave.name,
            isNHF: allowanceToSave.isNHF,
            isTaxable: Boolean(allowanceToSave.isTaxable),
            isDeduction: false,
            isRelief: true,
            isPension: Boolean(allowanceToSave.isPension),
            taxRelief: Number(allowanceToSave.taxRelief),
            amountType: Number(allowanceToSave.amountType),
            frequency: Number(allowanceToSave.frequency),
            noOfTimesPayable: Number(allowanceToSave.timesPayable)
          }
        ]
      };

      const response = await ApiFetcher.post(
        "/tax/create-relief-items",
        payload
      );

      // console.log("rax relief", response);
      if (response) {
        toast.success("Created successfully");
      }
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding relief items.";
      console.log(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const mutation = useMutation({
    mutationFn: handleSaveRelief,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const getReliefItems = async (page: Number) => {
    try {
      const response: any = await ApiFetcher.get(
        `/tax/get-all-reliefItems?PageNumber=${page}&PageSize=${maxPage}`
      );

      return response || [];
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching relief items";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: reliefItems,
    isPending,
    isLoading,
    error
  } = useQuery({
    queryKey: ["getReliefItems", currentPage],
    placeholderData: keepPreviousData,
    queryFn: () => getReliefItems(currentPage)
  });

  const handleDeleteReliefItem = async (id: any) => {
    try {
      const response = await ApiFetcher.delete(`/tax/delete-reliefItem/${id}`);

      // console.log("jargons", id);
      toast.success("Relief item removed sucessfully");
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error deleting relief.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const deleteMutation = useMutation({
    mutationFn: handleDeleteReliefItem,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  const onHandlerDelete = (id: number) => {
    try {
      deleteMutation.mutateAsync(id);
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding department.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const deleteAllRelief = async () => {
    try {
      const response = await ApiFetcher.delete("/tax/delete-all-reliefItems");
      toast.success("Successfully deleted all relief items");
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error deleting all relief item.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const allDeleteMutation = useMutation({
    mutationFn: deleteAllRelief,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  const onHandlerAllDelete = () => {
    try {
      allDeleteMutation.mutateAsync();
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding department.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };
  return (
    <div className="mt-10">
      <Dialog open={openAllowanceItem} onOpenChange={setOpenAllowanceItem}>
        <div className="flex justify-end mb-4">
          {reliefItems?.length >= 3 && (
            <CustomButton
              type="button"
              onClick={onHandlerAllDelete}
              classType="primary"
              className="w-fit text-xs px-2 py-[9px] bg-red-600 text-white rounded-[8px]"
            >
              {allDeleteMutation.isPending
                ? "Removing . . ."
                : "Remove all relief"}
            </CustomButton>
          )}
        </div>

        <Table className="text-[#1E1E1E] overflow-x-scroll">
          <TableHeader className="rounded-[4px] border bg-[#DDEFE8] text-sm">
            <TableRow className=" w-full">
              <TableHead className="font-bold ">Name</TableHead>
              <TableHead className="font-bold ">Months payable</TableHead>
              <TableHead className="font-bold ">Months remaining</TableHead>
              <TableHead className="font-bold "></TableHead>
            </TableRow>
          </TableHeader>

          <TableBody className="text-[11px]">
            {isPending ? (
              <TableRow className="flex w-full justify-center py-4">
                <TableCell>
                  <TbLoader3 className="text-primary animate-spin w-6 h-6" />
                </TableCell>
              </TableRow>
            ) : reliefItems?.data?.data?.length === 0 ? (
              <EmptyRecord />
            ) : (
              reliefItems?.data?.data?.map((items: any) => (
                <TableRow key={items?.id} className="border-0">
                  <TableCell className="">{items.name}</TableCell>
                  <TableCell className="">{items.noOfTimesPayable}</TableCell>
                  <TableCell className="">{items.noOfTimesRemaining}</TableCell>
                  <TableCell className=" flex items-center space-x-2">
                    {(activeRole?.includes("Admin") ||
                      activeRole?.includes("Initiator")) && (
                      <>
                        <FaEdit
                          onClick={() => {
                            setOpenAllowanceItem(true);
                            setReliefItem(items);
                          }}
                          className="text-lg cursor-pointer"
                        />
                        <RiDeleteBin2Fill
                          onClick={() => onHandlerDelete(items?.id)}
                          className="cursor-pointer text-lg"
                        />
                      </>
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>

        <div className="mt-4 flex items-center justify-between py-2 px-4">
          <p className="text-[#63666A] text-xs">
            {formatPageRange(reliefItems?.data?.meta, maxPage)}
          </p>

          <div className="flex items-center space-x-3">
            <button
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage((e: number) => e - 1)}
              className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
            >
              <RiArrowLeftSFill className="w-6 h-6" />
            </button>

            <button
              disabled={currentPage >= (Number(reliefItems?.data?.meta?.totalPages) || 1)}
              onClick={() => setCurrentPage((e: number) => e + 1)}
              className="disabled:bg-gray-100 cursor-pointer p-2 rounded-[4px] border border-[#d9d9d9] bg-[#DDEFE8]  "
            >
              <RiArrowRightSFill className="w-6 h-6" />
            </button>
          </div>
        </div>

        <ReliefDialog
          id={reliefItem?.id}
          setOpenAllowanceItem={setOpenAllowanceItem}
        />
      </Dialog>
    </div>
  );
};

export default Relief;
