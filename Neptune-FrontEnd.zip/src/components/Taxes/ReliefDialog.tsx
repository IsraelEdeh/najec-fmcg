import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogHeader,
  DialogContent,
  DialogTitle
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as yup from "yup";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import { TbLoader3 } from "react-icons/tb";

const schema = yup.object().shape({
  id: yup.string().optional(),
  name: yup
    .string()
    .min(3, "Name must be at least 3 characters")
    .required("Name is required"),
  code: yup.string().min(3, "Code must be at least 3 characters").optional(),
  taxRelief: yup
    .number()
    .typeError("Tax relief must be a number")
    .transform((value, originalValue) =>
      String(originalValue).trim() === "" ? null : value
    )
    .nullable()
    .required("Tax relief is required"),
  amountType: yup.string().required("Amount type is required"),
  frequency: yup.string().required("Frequency is required"),
  timesPayable: yup
    .number()
    .typeError("Months payable must be a number")
    .transform((value, originalValue) =>
      String(originalValue).trim() === "" ? null : value
    )
    .nullable()
    .required("Months payable is required"),
  isPension: yup.boolean().optional(),
  isTaxable: yup.boolean().optional(),
  isVoluntaryPension: yup.boolean().optional()
});

const ReliefDialog = ({
  id,
  setOpenAllowanceItem
}: {
  id: any;
  setOpenAllowanceItem: any;
}) => {
  const [checkVoluntaryPension, setCheckVoluntaryPension] =
    useState<boolean>(false);

  const queryClient = useQueryClient();

  const getReliefById = async (id: any) => {
    try {
      const response: any = await ApiFetcher.get(
        `/tax/get-reliefitem-by-id/${id}`
      );

      return response?.data?.data || [];
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching relief item by Id";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: allowanceItemDetail,
    isPending: isAllowanceItemPending,
    error: isAllowanceItemError
  } = useQuery({
    queryKey: ["getReliefItems", id],
    queryFn: () => getReliefById(id),
    enabled: !!id,
    staleTime: 0
  });

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, touchedFields }
  } = useForm({
    resolver: yupResolver(schema)
  });

  const handleUpdateRelief = async (data: any) => {
    try {
      const payload: any = {
        name: data?.name || allowanceItemDetail.name,
        isTaxable: data?.isTaxable || allowanceItemDetail.isTaxable,
        isPension: data?.isPension || allowanceItemDetail.isPension,
        isRelief: true,
        isDeduction: false,
        isNHF: false,
        taxRelief:
          Number(data?.taxRelief) || Number(allowanceItemDetail.taxRelief),
        amountType:
          Number(data?.amountType) || Number(allowanceItemDetail.amountType),
        frequency:
          Number(data?.frequency) || Number(allowanceItemDetail.frequency),
        noOfTimesPayable:
          Number(data?.timesPayable) ||
          Number(allowanceItemDetail.noOfTimesPayable),
        isVoluntaryPension:
          data?.isVoluntaryPension || allowanceItemDetail.isVoluntaryPension
      };

      const response = await ApiFetcher.put(
        `/tax/update-relief-item/${id}`,
        payload
      );
      setOpenAllowanceItem(false);
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error updating relief item.";
      console.log(errorMessage);
      toast.error(errorMessage);
    } finally {
      //   setLoading(false);
    }
  };

  const mutation = useMutation({
    mutationFn: handleUpdateRelief,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onHandlerSubmit = (data: any) => {
    mutation.mutateAsync(data);
    mutation.reset();
    reset();
  };

  useEffect(() => {
    if (id && allowanceItemDetail) {
      reset({
        id: allowanceItemDetail.id,
        name: allowanceItemDetail.name,
        code: allowanceItemDetail.code,
        taxRelief: allowanceItemDetail.taxRelief,
        amountType: String(allowanceItemDetail.amountType),
        frequency: String(allowanceItemDetail.frequency),
        timesPayable: allowanceItemDetail.noOfTimesPayable,
        isPension: allowanceItemDetail.isPension,
        isTaxable: allowanceItemDetail.isTaxable,
        isVoluntaryPension: allowanceItemDetail.isVoluntaryPension
      });
    } else if (!id) {
      reset();
    }
  }, [id, allowanceItemDetail, reset]);

  return (
    <>
      <DialogContent className="bg-white">
        <DialogHeader>
          <DialogTitle className="text-xl">Update relief items </DialogTitle>

          {isAllowanceItemPending ? (
            <div className="py-4 flex items-center justify-center h-full w-full">
              <div>
                <TbLoader3 className="text-primary animate-spin w-6 h-6" />
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit(onHandlerSubmit)} className="pt-3">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-1">
                  <input
                    className="w-full disabled:bg-slate-100 disabled:bg-opacity-100 rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                    type="text"
                    placeholder="Relief title"
                    defaultValue={allowanceItemDetail?.name}
                    {...register("name")}
                    // disabled
                  />
                </div>

                <div className="hidden col-span-1">
                  <input
                    className="w-full disabled:bg-slate-100 disabled:bg-opacity-100 rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                    type="text"
                    placeholder="Code"
                    defaultValue={allowanceItemDetail?.code}
                    {...register("code")}
                    disabled
                  />
                </div>

                <div className="hidden col-span-1">
                  <select
                    defaultValue={allowanceItemDetail?.amountType}
                    {...register("amountType")}
                    className="hidden w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                  >
                    <option className="bg-primary text-white" value="" disabled>
                      Select tax relief type
                    </option>
                    <option value="0">Amount</option>
                    <option value="1">Percentage</option>
                  </select>
                </div>

                <div className="hidden col-span-1">
                  <input
                    className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                    type="number"
                    placeholder="Tax relief amount"
                    defaultValue={allowanceItemDetail?.taxRelief}
                    {...register("taxRelief")}
                  />
                </div>

                <div className="hidden col-span-1">
                  <select
                    defaultValue={allowanceItemDetail?.frequency}
                    {...register("frequency")}
                    className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                  >
                    <option className="bg-primary text-white" value="" disabled>
                      Frequency
                    </option>
                    <option value="0">Monthly</option>
                  </select>
                </div>

                <div className="col-span-2">
                  <input
                    className="w-full rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                    type="number"
                    placeholder="Number of months payable"
                    defaultValue={allowanceItemDetail?.noOfTimesPayable}
                    {...register("timesPayable")}
                  />
                </div>

                <div className="hidden col-span-2">
                  <input
                    type="checkbox"
                    id="isTaxable"
                    name="isTaxable"
                    value="true"
                    defaultChecked={allowanceItemDetail?.isTaxable}
                  />
                  <span className="pl-1"> Is this allowance item taxable</span>
                </div>

                <div className="hidden col-span-2">
                  <input
                    type="checkbox"
                    id="isPension"
                    name="isPension"
                    value="true"
                    defaultChecked={allowanceItemDetail?.isPension}
                  />
                  <span className="pl-1">
                    Is this allowance item pensionable
                  </span>
                </div>

                <div className="col-span-2">
                  <input
                    type="checkbox"
                    id="isVoluntaryPension"
                    name="isVoluntaryPension"
                    checked={checkVoluntaryPension}
                    onChange={() => setCheckVoluntaryPension((e) => !e)}
                  />
                  <span className="pl-1">
                    is this a Voluntary Pension item?
                  </span>
                </div>

                <div className="col-span-2">
                  <button
                    type="submit"
                    disabled={mutation.isPending}
                    className="w-full bg-secondary disabled:bg-secondary/70 text-white text-center rounded-[4px] py-2.5 px-3"
                  >
                    {mutation.isPending
                      ? "Updating . . ."
                      : "Update relief item"}
                  </button>
                </div>
              </div>
            </form>
          )}
        </DialogHeader>
      </DialogContent>
    </>
  );
};

export default ReliefDialog;
