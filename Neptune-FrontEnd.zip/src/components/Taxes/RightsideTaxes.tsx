import React from "react";
import Image from "next/image";
import { Button } from "../ui/button";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import { FaXmark } from "react-icons/fa6";
import PayrollScheduleBulkUpload from "../dashboard/payroll/PayrollScheduleBulkUpload";
import { sanitizeFilename } from "@/lib/helpers";

const RightsideTaxes = ({
  setCloseRightSidebar,
  closeRightSidebar
}: {
  setCloseRightSidebar: any;
  closeRightSidebar: any;
}) => {
  const handleTemplateDownload = async () => {
    try {
      const response = await ApiFetcher.get("/tax/download-schedule-template", {
        responseType: "blob"
      });

      const blob = new Blob([response.data], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");

      const fileName = sanitizeFilename("payroll-schedule-template") + ".xlsx";

      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success("Template downloaded successfully");
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error downloading template";
      console.error(errorMessage);
      toast.error(errorMessage);
    }
  };
  return (
    <aside className="fixed right-0 top-0 hidden h-screen w-[290px] overflow-y-auto border-l bg-[#ffffff] px-[24px] pb-[50px] pt-[100px] lg:block">
      <div className="mb-20">
        <FaXmark
          className="w-[20px] h-[20px] cursor-pointer"
          onClick={() => setCloseRightSidebar(true)}
        />
      </div>

      <section>
        <div className="pt-[60px]">
          <Image src="/Taxes/tax.png" width={272} height={248} alt="Tax Img" />

          <div className="text-[#1E1E1E] text-sm mt-[16px]">
            <h2 className="font-bold mb-4">
              Setup your tax schedule in one go.
            </h2>
            <p>
              <span className="block">
                Upload an excel schedule with all your allowances and deductions
                and be ready to jump right into your payroll.
              </span>
              <button
                onClick={handleTemplateDownload}
                className="pt-1 text-secondary font-bold hover:underline underline-offset-4 cursor-pointer "
              >
                Download Template
              </button>
            </p>
          </div>
        </div>
      </section>

      <PayrollScheduleBulkUpload />
    </aside>
  );
};

export default RightsideTaxes;
