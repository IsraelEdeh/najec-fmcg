import React from 'react'

const Paye = () => {
  return (
    <div>Paye</div>
  )
}

export default Paye