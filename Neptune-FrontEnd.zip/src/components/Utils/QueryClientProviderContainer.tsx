"use client"

import React from 'react';
import {
    QueryClient,
    QueryClientProvider,
} from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

const queryClient = new QueryClient();

const QueryClientProviderContainer = ({ children }: { children: React.ReactNode }) => {
    return (
        <QueryClientProvider client={queryClient}>
            {children}
            <ReactQueryDevtools />
            <ToastContainer
                autoClose={7000}
                limit={3}
                newestOnTop
                pauseOnHover
                pauseOnFocusLoss
            />
        </QueryClientProvider>
    )
}

export default QueryClientProviderContainer