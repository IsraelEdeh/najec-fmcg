/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import axios, { AxiosError } from "axios";
import { getAuthToken, logoutAuth } from "./auth";

const ApiFetcher = axios.create({
  baseURL: process.env.NEXT_PUBLIC_BASE_URL,
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json, text/plain, */*"
  }
});

const onRequest = (request: any) => {
  const token = getAuthToken();
  request.headers.Authorization = token ? `Bearer ${token}` : "";
  return request;
};

const onRequestError = (error: AxiosError) => {
  return Promise.reject(error);
};

const onResponse = (response: any) => {
  return response;
};

const onResponseError = (error: any) => {
  console.log("Interceptor error:::", error);
  // console.log("Interceptor error 2:::", error?.status);
  const statusCode = error?.response?.status || error?.status;

  console.log("statuscode", error);
  if (statusCode === 401) {
    console.log("Unauthorized access detected. Logging out.");
    logoutAuth();

    if (typeof window !== "undefined") {
      sessionStorage.clear();
      localStorage.clear();

      window.location.href = "/";
    }
  }

  if (!error.response) {
    error.response = {
      status: 400
    };
  }

  return Promise.reject(error);
};

ApiFetcher.interceptors.request.use(onRequest, onRequestError);
ApiFetcher.interceptors.response.use(onResponse, onResponseError);

export default ApiFetcher;
