export function logoutAuth() {
  document.cookie =
    "jwt=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; Secure; SameSite=Lax";
  localStorage.clear();
}

export function getAuthToken() {
  const cookies = document.cookie.split("; ");
  for (const cookie of cookies) {
    const [field, value] = cookie.split("=");
    if (field === "jwt") return value;
  }
  return null;
}
