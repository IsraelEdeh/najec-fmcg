"use client";

import React, { useCallback, useState } from "react";
import { useDropzone, type FileRejection } from "react-dropzone";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { Button } from "../ui/button";
import CustomButton from "@/components/Elements/CustomButton";
import ApiFetcher from "../Utils/api";
import {
  BULK_UPLOAD_ACCEPTED_EXTENSIONS,
  BULK_UPLOAD_MAX_FILE_SIZE_MB,
  BULK_UPLOAD_TIMEOUT_MS,
  downloadEmployeeTemplate,
  formatFileSize,
  parseBulkUploadError,
  parseBulkUploadResponse,
  validateBulkUploadFile,
  type BulkUploadResult
} from "@/lib/bulk-upload";
import { MdCheckCircle, MdErrorOutline, MdInfoOutline, MdWarningAmber } from "react-icons/md";
import { FiFileText, FiUploadCloud, FiX } from "react-icons/fi";
import { TbLoader3 } from "react-icons/tb";

const TEMPLATE_TOAST_ID = "employee-template-download";

const resultStyles: Record<BulkUploadResult["status"], { container: string; icon: React.ReactNode }> = {
  success: {
    container: "border-green-200 bg-green-50 text-green-900",
    icon: <MdCheckCircle className="w-5 h-5 shrink-0 text-green-600" />
  },
  partial: {
    container: "border-amber-200 bg-amber-50 text-amber-900",
    icon: <MdWarningAmber className="w-5 h-5 shrink-0 text-amber-600" />
  },
  failed: {
    container: "border-red-200 bg-red-50 text-red-900",
    icon: <MdErrorOutline className="w-5 h-5 shrink-0 text-red-600" />
  }
};

const BulkUpload = () => {
  const queryClient = useQueryClient();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState("");
  const [isCheckingFile, setIsCheckingFile] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<BulkUploadResult | null>(null);

  const mutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("File", file);
      const response = await ApiFetcher.post("/employees/bulk-upload-employees", formData, {
        headers: { "Content-Type": "multipart/form-data" },
        timeout: BULK_UPLOAD_TIMEOUT_MS,
        onUploadProgress: (event) => {
          if (event.total) setProgress(Math.round((event.loaded / event.total) * 100));
        }
      });
      return parseBulkUploadResponse(response?.data);
    },
    onSuccess: (uploadResult) => {
      setResult(uploadResult);
      if (uploadResult.status !== "failed") {
        setSelectedFile(null);
        queryClient.invalidateQueries();
      }
    },
    onError: (error) => {
      setResult(parseBulkUploadError(error));
    }
  });

  const isUploading = mutation.isPending;
  const isProcessing = isUploading && progress >= 100;

  const resetState = () => {
    setSelectedFile(null);
    setFileError("");
    setProgress(0);
    setResult(null);
    mutation.reset();
  };

  const handleOpenChange = (open: boolean) => {
    // Keep the dialog open while uploading so the outcome is never missed.
    if (!open && isUploading) return;
    if (!open) resetState();
    setIsModalOpen(open);
  };

  const onDrop = useCallback(async (acceptedFiles: File[], rejections: FileRejection[]) => {
    setResult(null);
    setProgress(0);

    if (rejections.length > 1 || acceptedFiles.length + rejections.length > 1) {
      setSelectedFile(null);
      setFileError("Please upload one file at a time.");
      return;
    }

    const file = acceptedFiles[0] ?? rejections[0]?.file;
    if (!file) return;

    setIsCheckingFile(true);
    const validationError = await validateBulkUploadFile(file);
    setIsCheckingFile(false);
    setSelectedFile(validationError ? null : file);
    setFileError(validationError ?? "");
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: false,
    disabled: isUploading
  });

  const handleTemplateDownload = async () => {
    try {
      await downloadEmployeeTemplate();
    } catch {
      toast.error("We couldn't download the template. Please try again.", {
        toastId: TEMPLATE_TOAST_ID
      });
    }
  };

  const handleUpload = () => {
    if (!selectedFile || isUploading) return;
    setResult(null);
    setProgress(0);
    mutation.mutate(selectedFile);
  };

  const canUpload = Boolean(selectedFile) && !fileError && !isCheckingFile && !isUploading;
  const isComplete = result?.status === "success" || result?.status === "partial";

  return (
    <Dialog open={isModalOpen} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <CustomButton
          classType="primary"
          className="w-full px-4 py-[9px] text-xs rounded-[4px]"
        >
          <span className="inline">Bulk upload</span>
        </CustomButton>
      </DialogTrigger>

      <DialogContent
        className="bg-white max-w-2xl max-h-[90vh] overflow-y-auto overscroll-contain [scrollbar-gutter:stable]"
        onInteractOutside={(event) => isUploading && event.preventDefault()}
        onEscapeKeyDown={(event) => isUploading && event.preventDefault()}
      >
        <DialogHeader>
          <DialogTitle className="mb-4">Employee Upload</DialogTitle>
          <DialogDescription asChild>
            <div className="flex items-start space-x-3">
              <MdInfoOutline className="w-5 h-5 shrink-0" />
              <div>
                <p className="font-semibold">Add Employees in Bulk</p>
                <p className="mt-1">
                  Upload the completed employee template ({BULK_UPLOAD_ACCEPTED_EXTENSIONS.join(", ")}, max{" "}
                  {BULK_UPLOAD_MAX_FILE_SIZE_MB} MB).{" "}
                  <button
                    type="button"
                    onClick={handleTemplateDownload}
                    className="text-secondary font-semibold hover:underline"
                  >
                    Download template
                  </button>
                </p>
                <p className="mt-1">
                  Phone Number, Date of Birth, Date Joined, RSA Pin, Department, Address and Gender can be
                  left blank. On bulk update, a blank cell clears the stored value.
                </p>
              </div>
            </div>
          </DialogDescription>
        </DialogHeader>

        {!isComplete && (
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-[4px] p-8 text-center transition-colors ${
              isUploading ? "cursor-not-allowed opacity-60" : "cursor-pointer"
            } ${
              fileError
                ? "border-red-300 bg-red-50"
                : isDragActive
                  ? "border-primary bg-[#DDEFE8]"
                  : "border-gray-300 hover:border-primary"
            }`}
          >
            <input
              {...getInputProps({ accept: BULK_UPLOAD_ACCEPTED_EXTENSIONS.join(",") })}
              aria-label="Employee upload file"
            />
            <FiUploadCloud className="mx-auto mb-2 w-8 h-8 text-primary" />
            <p className="text-sm">
              {isDragActive ? (
                "Drop the file here"
              ) : (
                <>
                  Drag & drop your file here, or <span className="underline">click to browse</span>
                </>
              )}
            </p>
          </div>
        )}

        {isCheckingFile && (
          <p className="flex items-center gap-2 text-sm text-gray-600">
            <TbLoader3 className="animate-spin" /> Checking file…
          </p>
        )}

        {fileError && (
          <div role="alert" className="flex items-start gap-2 rounded-[4px] border border-red-200 bg-red-50 p-3 text-sm text-red-900">
            <MdErrorOutline className="w-5 h-5 shrink-0 text-red-600" />
            <p>{fileError}</p>
          </div>
        )}

        {selectedFile && !isComplete && (
          <div className="flex items-center justify-between gap-3 rounded-[4px] border border-gray-200 p-3 text-sm">
            <div className="flex items-center gap-2 min-w-0">
              <FiFileText className="w-5 h-5 shrink-0 text-primary" />
              <span className="truncate font-medium">{selectedFile.name}</span>
              <span className="shrink-0 text-gray-500">{formatFileSize(selectedFile.size)}</span>
            </div>
            {!isUploading && (
              <button
                type="button"
                aria-label="Remove file"
                onClick={() => {
                  setSelectedFile(null);
                  setResult(null);
                }}
                className="text-gray-500 hover:text-red-600"
              >
                <FiX className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

        {isUploading && (
          <div aria-live="polite" className="space-y-2">
            <div className="flex justify-between text-xs text-gray-600">
              <span>{isProcessing ? "Processing employee records… this may take a moment." : "Uploading file…"}</span>
              {!isProcessing && <span>{progress}%</span>}
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-gray-200">
              <div
                className={`h-full bg-primary transition-all ${isProcessing ? "animate-pulse" : ""}`}
                style={{ width: `${isProcessing ? 100 : progress}%` }}
              />
            </div>
          </div>
        )}

        {result && (
          <div
            role={result.status === "failed" ? "alert" : "status"}
            className={`rounded-[4px] border p-4 text-sm ${resultStyles[result.status].container}`}
          >
            <div className="flex items-start gap-2">
              {resultStyles[result.status].icon}
              <div className="min-w-0 flex-1 space-y-2">
                <p className="font-semibold">{result.title}</p>
                <p>{result.summary}</p>

                {(result.total !== undefined || result.succeeded !== undefined || result.failed !== undefined) && (
                  <ul className="flex flex-wrap gap-x-4 gap-y-1 font-medium">
                    {result.total !== undefined && <li>{result.total} processed</li>}
                    {result.succeeded !== undefined && <li>{result.succeeded} successful</li>}
                    {result.failed !== undefined && <li>{result.failed} failed</li>}
                  </ul>
                )}

                {result.issues.length > 0 && (
                  <details open={result.status === "failed"} className="group">
                    <summary className="cursor-pointer font-medium underline">
                      {result.status === "failed" ? "Error details" : "View error details"} ({result.issues.length})
                    </summary>
                    <ul className="mt-2 max-h-60 space-y-1 overflow-y-auto overscroll-contain rounded-[4px] bg-white/70 p-3">
                      {result.issues.map((issue, index) => (
                        <li key={`${issue.row ?? "general"}-${index}`} className="flex gap-2">
                          <span aria-hidden>•</span>
                          <span>
                            {issue.row !== undefined && <span className="font-semibold">Row {issue.row}</span>}
                            {issue.employee && <span className="font-semibold"> ({issue.employee})</span>}
                            {(issue.row !== undefined || issue.employee) && ": "}
                            {issue.field && <span className="font-medium">{issue.field} — </span>}
                            {issue.message}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </details>
                )}

                {result.hint && <p className="text-xs opacity-80">{result.hint}</p>}
              </div>
            </div>
          </div>
        )}

        <DialogFooter className="mt-2 gap-2 sm:gap-0">
          {isComplete ? (
            <>
              <Button
                variant="outline"
                className="bg-white rounded-[4px] border border-primary text-sm"
                onClick={() => {
                  resetState();
                }}
              >
                Upload another file
              </Button>
              <CustomButton
                type="button"
                classType="primary"
                onClick={() => handleOpenChange(false)}
                className="w-fit px-6 py-[9px] rounded-[4px]"
              >
                Done
              </CustomButton>
            </>
          ) : (
            <>
              <Button
                variant="outline"
                className="bg-white rounded-[4px] border border-primary text-sm hover:text-white hover:bg-red-600"
                onClick={() => handleOpenChange(false)}
                disabled={isUploading}
              >
                Cancel
              </Button>
              <CustomButton
                type="button"
                onClick={handleUpload}
                classType="primary"
                disabled={!canUpload}
                className="disabled:bg-secondary disabled:bg-opacity-50 disabled:cursor-not-allowed w-fit px-6 py-[9px] rounded-[4px] flex items-center gap-2"
              >
                {isUploading && <TbLoader3 className="animate-spin" />}
                {isUploading ? (isProcessing ? "Processing…" : "Uploading…") : result?.status === "failed" ? "Retry upload" : "Upload"}
              </CustomButton>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default BulkUpload;
