import React, { useId, useState } from "react";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { Button } from "../ui/button";
import { MdInfoOutline } from "react-icons/md";
import { toast } from "react-toastify";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import CustomButton from "@/components/Elements/CustomButton";
import { getPayrollProcessThread, savePayrollScheduleFile } from "@/lib/payroll-api";
import {
  SchedulePeriodPicker,
  useSchedulePayPeriod
} from "@/components/Payroll/Runs/useSchedulePayPeriod";

const getErrorMessages = (error: any, fallback: string): string[] => {
  const data = error?.response?.data;

  if (Array.isArray(data?.errors) && data.errors.length > 0) {
    return data.errors;
  }

  if (data?.message) {
    return [data.message];
  }

  if (error?.message) {
    return [error.message];
  }

  return [fallback];
};

const BulkUploadSchedule = ({ payrollProcessData }: { payrollProcessData: any }) => {
  const queryClient = useQueryClient();
  const fileInputId = useId();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [uploadErrors, setUploadErrors] = useState<string[]>([]);
  const periodSelection = useSchedulePayPeriod();
  const id = periodSelection.payPeriodId;

  const { data: threadData } = useQuery({
    queryKey: ["scheduleUploadThread", id ?? null],
    queryFn: async () => (await getPayrollProcessThread(id as string | number)) as any,
    enabled: id !== undefined
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedFile(event.target.files?.[0] ?? null);
    setUploadErrors([]);
  };

  const saveSchedule = async (mode: "upload" | "update") => {
    if (!selectedFile) return;
    try {
      setUploadErrors([]);
      const response = await savePayrollScheduleFile(selectedFile, id, mode);
      toast.success("File uploaded successfully!");
      setSelectedFile(null);
      setIsModalOpen(false);
      periodSelection.setPayPeriodId(undefined);
      return response;
    } catch (error: any) {
      const errorMessages = getErrorMessages(error, "Error uploading file");
      setUploadErrors(errorMessages);
      errorMessages.forEach((errorMessage: string) => {
        toast.error(errorMessage);
      });
      throw error;
    }
  };

  const handleUpload = () => saveSchedule("upload");
  const handleUpdate = () => saveSchedule("update");

  const isSaving = () => uploadPayrollMutation.isPending || updatePayrollMutation.isPending;

  // Every close path (Cancel, X, Escape, overlay, successful save) clears the modal state.
  const handleOpenChange = (open: boolean) => {
    if (!open && isSaving()) return;
    if (!open) {
      setSelectedFile(null);
      setUploadErrors([]);
      periodSelection.setPayPeriodId(undefined);
    }
    setIsModalOpen(open);
  };

  const uploadPayrollMutation = useMutation({
    mutationFn: handleUpload,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  const onHandlerUploadPayroll = async () => {
    try {
      await uploadPayrollMutation.mutateAsync();
    } catch (error: any) {
      // Errors are already surfaced via toast in handleUpload.
    }
  };

  const onHandlerUpdatePayroll = async () => {
    try {
      await updatePayrollMutation.mutateAsync();
    } catch (error: any) {
      // Errors are already surfaced via toast in handleUpdate.
    }
  };

  const updatePayrollMutation = useMutation({
    mutationFn: handleUpdate,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  return (
    <>
      <Dialog open={isModalOpen} onOpenChange={handleOpenChange}>
        <DialogTrigger asChild>
          <CustomButton
            classType="primary"
            className="w-full px-4 py-[9px] text-xs rounded-[4px] disabled:bg-opacity-60"
            disabled={payrollProcessData?.isPayrollSubmitted}
          >
            <span className="inline">Bulk Upload Schedule</span>
          </CustomButton>
        </DialogTrigger>

        <DialogContent className=" bg-white transform -translate-x-1/2 -translate-y-1/2 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="mb-6">Payroll schedule upload</DialogTitle>
            <DialogDescription>
              <div className="flex items-start space-x-3">
                <MdInfoOutline className="w-5 h-5" />
                <div>
                  <p className="font-semibold">Add Payroll Schedule in Bulk</p>
                  <p className="mt-1">
                    Select your employee schedule file to upload and add them to
                    your account.
                  </p>
                </div>
              </div>
            </DialogDescription>
          </DialogHeader>

          <div className="mt-4">
            <SchedulePeriodPicker selection={periodSelection} />
          </div>

          {uploadErrors.length > 0 && (
            <ul role="alert" className="mt-4 space-y-1 rounded-[4px] border border-red-200 bg-red-50 p-3 text-sm text-red-900">
              {uploadErrors.map((message, index) => (
                <li key={index}>{message}</li>
              ))}
            </ul>
          )}

          <>
            {threadData?.isPayrollScheduleUploaded ? (
              <div className="mt-6">
                <div className="border-2 border-gray-300 rounded-[4px] p-10 text-center cursor-pointer">
                  <label htmlFor={fileInputId} className="sr-only">Payroll schedule file</label>
                  <input id={fileInputId} type="file" onChange={handleFileChange} />
                </div>

                <div className="flex justify-end mt-4">
                  <Button
                    className="text-white"
                    onClick={onHandlerUpdatePayroll}
                    disabled={!selectedFile || id === undefined || updatePayrollMutation.isPending}
                  >
                    {updatePayrollMutation.isPending
                      ? "Updating . . ."
                      : "Update payroll schedule"}
                  </Button>
                </div>
              </div>
            ) : (
              <div className="mt-6">
                <div className="border-2 border-gray-300 rounded-[4px] p-10 text-center cursor-pointer">
                  <label htmlFor={fileInputId} className="sr-only">Payroll schedule file</label>
                  <input id={fileInputId} type="file" onChange={handleFileChange} />
                </div>

                <div className="flex justify-end mt-4">
                  <Button
                    className="text-white"
                    onClick={onHandlerUploadPayroll}
                    disabled={!selectedFile || id === undefined || uploadPayrollMutation.isPending}
                  >
                    {uploadPayrollMutation.isPending
                      ? "Uploading . . ."
                      : "Upload payroll schedule"}
                  </Button>
                </div>
              </div>
            )}
          </>

          <div className="flex justify-end">
            <Button
              type="button"
              variant="outline"
              className="bg-white rounded-[4px] border border-primary text-sm"
              onClick={() => handleOpenChange(false)}
              disabled={uploadPayrollMutation.isPending || updatePayrollMutation.isPending}
            >
              Cancel
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default BulkUploadSchedule;
