import Image from "next/image";
import React, { useState } from "react";
import { IoEyeOutline } from "react-icons/io5";

interface CustomInput {
  label?: string;
  isPhoneInput?: boolean;
  type?: string;
  placeholder?: string;
  className?: string;
  requiredIcon?: boolean;
}

const CustomInput = ({
  label,
  isPhoneInput,
  type,
  placeholder,
  className,
  requiredIcon,
  ...rest
}: CustomInput) => {
  const [showPassword, setShowPassword] = useState(false);

  const handleViewPassword = () => {
    setShowPassword((e) => !e);
  };

  return (
    <div>
      <div className="flex flex-col gap-1.5">
        <label className="flex items-center space-x-1 text-sm w-full max-w-[280px] font-bold text-[#1E1E1E]">
          {label}

          {requiredIcon && (
            <Image
              src="/dashboard/required.png"
              width={8}
              height={20}
              alt="required icon"
            />
          )}
        </label>
        <div className="relative flex w-full flex-col">
          <>
            <input
              type={showPassword ? "text" : type}
              className={`relative text-base py-[7px] px-4 rounded-[4px] border border-[#D0D0CE] text-gray-900 placeholder:text-gray-500 ${className}`}
              placeholder={placeholder}
              {...rest}
            />

            {type === "password" && (
              <IoEyeOutline
                onClick={handleViewPassword}
                className="text-[#999DA3] cursor-pointer w-6 h-6 absolute right-3 top-3"
              />
            )}
          </>
        </div>
      </div>
    </div>
  );
};

export default CustomInput;
