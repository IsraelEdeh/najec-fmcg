import React from "react";
import { PiEmptyBold } from "react-icons/pi";

const EmptyRecord = () => {
  return (
    <section className="pt-[80px] pb-[302px] ">
      <div className="space-y-[8px]">
        <div className="flex justify-center">
          <PiEmptyBold className="w-10 h-10 text-primary" />
        </div>

        <p className="text-center font-semibold text-[17px] text-primary">
          No record found
        </p>

        <p className="text-center font-medium text-[15px] lg:text-base">
          Sorry, we couldn't find any results
        </p>
      </div>
    </section>
  );
};

export default EmptyRecord;
