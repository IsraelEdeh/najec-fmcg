"use client";

import React, { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { HiChevronDown } from "react-icons/hi2";
import { SidebarTrigger } from "../ui/sidebar";
import Link from "next/link";
import CustomButton from "@/components/Elements/CustomButton";
import { logoutAuth } from "../Utils/auth";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@/app/store";
import { FaUser } from "react-icons/fa";
import { useRouter } from "next/navigation";
import ApiFetcher from "../Utils/api";
import { toast } from "react-toastify";
import { fetchUserAsync } from "../widgets/Features/GetUserSlice";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { PiUserSwitchFill } from "react-icons/pi";
import { useMsal } from "@azure/msal-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from "../ui/dialog";

const HeaderBar = () => {
  const router = useRouter();
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [openDropDown, setOpenDropDown] = useState<boolean>(false);

  //state for profile modal
  const [openProfileModal, setOpenProfileModal] = useState<boolean>(false);

  const queryClient = useQueryClient();
  const user: any = useSelector((state: RootState) => state.getUser.user);
  const { instance } = useMsal();

 const getEmailTld = (email?: string) => {
  if (!email) return "";
  const domain = email.split("@")?.[1] || "";
  const parts = domain.split(".");
  return parts.length ? parts[parts.length -1].toLowerCase() : "";
 }

 //map country code to flag in /public/flags/
 const flagImageMap: Record<string, string> ={
  ng: "/flags/ng.png",
  gh: "/flags/gh.png",
  za: "/flags/za.png"
 };

 const emailTld = getEmailTld(user?.email);
 const flagSrc = flagImageMap[emailTld] || "";

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const logout = () => {
    instance.logoutRedirect().catch((error: any) => console.log(error));
  };

  const dispatch = useDispatch();

  const handleSwitchOrganization = async (organizationId: any) => {
    try {
      const payload = {
        userId: user?.userId,
        organizationId: user?.userOrganizations?.find(
          (item: any) => item?.isCurrentLoggedInOrganization
        )?.organizationId,
      };

      const response = await ApiFetcher.post(`/auth/switch/${organizationId}`, payload);
      console.log("success::", response);
      if (response) {
        document.cookie = `jwt=${response.data.data.token}; path=/; Secure`;
        // fetchUserAsync();
      } else {
        toast.error("Login failed. Please check your credentials.");
      }

      const fetchResult = await dispatch(fetchUserAsync() as any);
      console.log("fetchResult::", fetchResult);

      if (fetchResult.payload.error) {
        toast.error(fetchResult.payload.error);
        return;
      }
      router.push("/dashboard");
      toast.success(response?.data?.data?.message);

      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error switching organization";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const mutation = useMutation({
    mutationFn: handleSwitchOrganization,
    onSuccess: async () => {
      queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    },
  });

  const onHandlerSubmit = (id: any) => {
    mutation.mutateAsync(id);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setOpenDropDown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [dropdownRef]);

  //  Extract current organization
  const currentOrg = user?.userOrganizations?.find(
    (org: any) => org?.isCurrentLoggedInOrganization
  );

  return (
    <div className="fixed inset-x-0 top-0 z-40 w-full bg-primary px-3 py-2 sm:px-6">
      <div className="relative flex min-w-0 items-center justify-between gap-3">
        <div>
          <div className="cursor-pointer flex items-center gap-2 bg-bank-gradient">
            <SidebarTrigger className="text-white text-6xl hover:text-white" />
            <Image src="/auth/logo1.png" alt="logo" width={140} height={22} />
          </div>
        </div>

        <div className="relative flex min-w-0 items-center gap-3 sm:gap-6">
          <div className="flex min-w-0 items-center gap-2">
            <p className="max-w-[42vw] truncate text-white font-semibold text-sm sm:text-base">
              {user?.userOrganizations?.find(
                (item: any) => item?.isCurrentLoggedInOrganization
              )?.organizationName || "N/A"}
            </p>

            <HiChevronDown
              onClick={(e) => setOpenDropDown((e) => !e)}
              className="text-white w-4 h-4 "
            />
          </div>

          <div className="bg-white w-[1px] h-[40px]"></div>

          <div className="flex items-center space-x-3">
            <div className="relative">
              <div
                onClick={() => setOpenProfileModal(true)}
                className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 text-xl font-bold cursor-pointer"
              >
                {user?.firstName?.[0]}{user?.lastName?.[0]}
              </div>

              {flagSrc && (
                <div className="absolute -bottom-2.5 -right-1 w-6 h-4 rounded-sm overflow-hidden">
                  <Image
                    src={flagSrc}
                    alt={`${emailTld} flag`}
                    width={24}
                    height={16}
                    className="object-cover"
                    unoptimized={false}
                  />
                </div>
              )}
            </div>
          </div>

          {openDropDown && (
            <div
              ref={dropdownRef}
              className="absolute right-0 top-12 max-h-[calc(100dvh-5rem)] w-[min(14rem,calc(100vw-1rem))] overflow-y-auto overscroll-contain"
            >
              <ul className="bg-white py-4 w-full text-center border border-[#d6d3d3] font-medium rounded-[10px]">
                <li className="px-4 mt-2">
                  {user?.userOrganizations.length >= 2 && (
                    <Link
                      href="/company-select"
                      className="flex justify-center w-full"
                    >
                      <button className="text-primary group text-sm flex items-center space-x-2 opacity-100 underline transition-all ease-linear hover:no-underline underline-offset-4 cursor-pointer">
                        <PiUserSwitchFill className="text-2xl group-hover:text-secondary" />
                        <span>Switch accounts</span>
                      </button>
                    </Link>
                  )}
                </li>

                <li className="text-sm w-full mt-4 px-6">
                  <CustomButton
                    onClick={() => {
                      // logoutAuth();
                      logout();
                      // router.push("/login");
                    }}
                    className="w-full transition-colors ease-in duration-300 py-1.5 px-6 bg-red-500 text-center rounded-[6px]"
                  >
                    <span className="font-medium text-white">Logout</span>
                  </CustomButton>
                </li>

                {activeRole?.includes("Admin") && (
                  <li className="mt-2">
                    <Link href="/create-company" className="block w-full">
                      <button className="underline text-[13px] transition-all ease-linear hover:no-underline underline-offset-4 cursor-pointer">
                        Add new organisation
                      </button>
                    </Link>
                  </li>
                )}
              </ul>
            </div>
          )}

          {/* ✅ Profile Modal */}
          <Dialog open={openProfileModal} onOpenChange={setOpenProfileModal}>
            <DialogContent className="max-w-md bg-white">
              <DialogHeader>
                <DialogTitle>
                  <div className="flex items-center gap-4">
                    <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gray-200 text-xl font-bold text-gray-500">
                      {user?.firstName?.[0]}{user?.lastName?.[0]}
                    </div>
                    <div className="min-w-0 text-left">
                      <h2 className="truncate text-xl font-semibold text-gray-800">
                        {user?.firstName} {user?.lastName}
                      </h2>
                      <p className="truncate text-sm font-normal text-gray-500">
                        {user?.email}
                      </p>
                    </div>
                  </div>
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-3 text-sm text-gray-700">
                <h3 className="text-base font-semibold text-gray-800">
                  Logged-in Organization
                </h3>
                <div className="flex flex-wrap justify-between gap-2">
                  <span className="font-medium">Organization Name:</span>
                  <span className="break-words">{currentOrg?.organizationName}</span>
                </div>
                <div className="flex flex-wrap justify-between gap-2">
                  <span className="font-medium">Country:</span>
                  <span>{user?.country?.name}</span>
                </div>
                <div className="flex flex-wrap justify-between gap-2">
                  <span className="font-medium">Role:</span>
                  <span className="break-words">
                    {currentOrg?.role?.map((r: any) => r.role).join(", ")}
                  </span>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
};

export default HeaderBar;
