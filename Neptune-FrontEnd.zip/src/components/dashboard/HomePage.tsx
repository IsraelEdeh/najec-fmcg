"use client";

import React from "react";
import CustomButton from "@/components/Elements/CustomButton";
import { CiExport } from "react-icons/ci";
import CompanyStats from "./home/CompanyStats";
import PayrollSummary from "./home/PayrollSummary";
import PayrollTrend from "./home/PayrollTrend";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import { formatDate2 } from "@/constants";
import UserActivity from "./home/UserActivity";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import { useQuery } from "@tanstack/react-query";
import Setup from "./home/Setup";

const DashboardHome = () => {
  const user: any = useSelector((state: RootState) => state.getUser.user);
  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const formattedDate2 = formatDate2(new Date());

  const getDashboardAPI = async () => {
    try {
      const response = await ApiFetcher.get(`/dashboard/dashboard-summary`);

      return response?.data;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching dashboard summary";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  const {
    data: dashboardResults,
    isPending,
    isError
  } = useQuery({
    queryKey: ["dashboardResults"],
    queryFn: getDashboardAPI
  });

  const greetingTime = new Date().getHours();
  let greeting = "Good evening";
  if (greetingTime < 12) {
    greeting = "Good morning";
  } else if (greetingTime < 18) {
    greeting = "Good afternoon";
  }

  return (
    <main className=" px-4 py-6">
      <p className="text-sm text-primary mb-6">Home</p>

      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-[40px] font-semibold">
            {greeting}, {user?.firstName}
          </h2>
          <p className="text-[#63666A] mt-2.5 text-sm ">
            It's {formattedDate2} What would you like to do today?
          </p>
        </div>

        <div className="hidden">
          <CustomButton
            classType="secondary"
            className="flex items-center space-x-2 py-[9px] px-4 text-xs rounded-[4px] text-primary"
          >
            <span>Export</span>
            <CiExport className="text-primary w-3 h-3" />
          </CustomButton>
        </div>
      </div>

      {(activeRole?.includes("Admin") || activeRole?.includes("Initiator")) && (
        <Setup />
      )}

      <CompanyStats dashboardResults={dashboardResults} isError={isError} />

      {(activeRole?.includes("Admin") ||
        // activeRole?.includes("Initiator") ||
        activeRole?.includes("Approver") ||
        activeRole?.includes("Reviewer")) && (
        <PayrollSummary
          dashboardResults={dashboardResults?.payrollSummary}
          isError={isError}
        />
      )}

      {(activeRole?.includes("Admin") ||
        // activeRole?.includes("Initiator") ||
        activeRole?.includes("Approver") ||
        activeRole?.includes("Reviewer")) && <PayrollTrend isError={isError} />}

      <UserActivity />
    </main>
  );
};

export default DashboardHome;
