"use client";

import React from "react";

import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { AlignLeft } from "lucide-react";
import Link from "next/link";
import { DashboardLeftsidebarLinks } from "@/constants";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const MobileNav = () => {
  const pathname = usePathname();
  return (
    <section className="w-full max-w-[264px] mt-[4rem]">
      <Sheet>
        <SheetTrigger>
          <AlignLeft />
        </SheetTrigger>
        <SheetContent side="left" className="border-none bg-white">
          <SheetTitle></SheetTitle>
          <Link
            href="/"
            className="cursor-pointer flex items-center gap-1 px-4"
          >
            <h1 className="text-black">Neptune</h1>
          </Link>

          <div className="mobilenav-sheet text-black">
            <SheetClose asChild>
              <nav className="flex h-full flex-col gap-6 pt-16 text-white">
                {DashboardLeftsidebarLinks.map((item) => {
                  const isActive =
                    pathname === item.route ||
                    pathname.startsWith(`${item.route}/`);
                  return (
                    <SheetClose asChild key={item.route}>
                      <Link
                        href={item.route}
                        key={item.label}
                        className={cn("text-black", {
                          "text-blue-500": isActive,
                        })}
                      >
                        <div className="flex w-full relative size-6 gap-3">
                          <span>{item.icon}</span>
                          <p className="">{item.label}</p>
                        </div>
                      </Link>
                    </SheetClose>
                  );
                })}
              </nav>
            </SheetClose>
          </div>
        </SheetContent>
      </Sheet>
    </section>
  );
};

export default MobileNav;
