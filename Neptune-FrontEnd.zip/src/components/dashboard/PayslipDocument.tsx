import React from "react";
import { Page, Text, View, Document, StyleSheet } from "@react-pdf/renderer";

const styles = StyleSheet.create({
  page: {
    padding: 20,
    fontSize: 12
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 10,
    textAlign: "center"
  },
  section: {
    marginBottom: 10
  },
  header: {
    backgroundColor: "#005587",
    color: "white",
    padding: 8,
    marginBottom: 5,
    flexDirection: "row",
    justifyContent: "space-between"
  },
  itemRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 3
  },
  bold: {
    fontWeight: "bold"
  }
});

const PayslipDocument = ({ selectedItem }: { selectedItem: any }) => (
  <Document>
    <Page size="A4" style={styles.page}>
      <Text style={styles.title}>Neptune Payslip</Text>
      <Text style={{ textAlign: "center", marginBottom: 10 }}>
        Preview payslip for {selectedItem?.payPeriodName}
      </Text>

      <View style={styles.section}>
        <View style={styles.header}>
          <Text>Item</Text>
          <Text style={styles.bold}>Value</Text>
        </View>
        <View style={styles.itemRow}>
          <Text>Employee contributions</Text>
          <Text style={styles.bold}>
            {selectedItem?.payslip?.employeeContributions}
          </Text>
        </View>
        <View style={styles.itemRow}>
          <Text>National housing fund</Text>
          <Text style={styles.bold}>
            {selectedItem?.payslip?.nationalHousingFund}
          </Text>
        </View>
        <View style={styles.itemRow}>
          <Text>Nigeria Social Insurance TrustFund</Text>
          <Text style={styles.bold}>
            {selectedItem?.payslip?.nigeriaSocialInsuranceTrustFund}
          </Text>
        </View>
        <View style={styles.itemRow}>
          <Text>Company contributions</Text>
          <Text style={styles.bold}>
            {selectedItem?.payslip?.companyContributions}
          </Text>
        </View>
        <View style={styles.itemRow}>
          <Text style={styles.bold}>Net pay</Text>
          <Text style={styles.bold}>{selectedItem?.payslip?.netPay}</Text>
        </View>
        <View style={styles.itemRow}>
          <Text style={styles.bold}>Gross salary</Text>
          <Text style={styles.bold}>{selectedItem?.payslip?.grossSalary}</Text>
        </View>
      </View>
    </Page>
  </Document>
);

export default PayslipDocument;
