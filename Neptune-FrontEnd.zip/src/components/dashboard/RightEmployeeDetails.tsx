"use client";

import React from "react";
import Image from "next/image";
import BulkUpload from "./BulkUpload";
import { FaXmark } from "react-icons/fa6";
import { toast } from "react-toastify";
import { downloadEmployeeTemplate } from "@/lib/bulk-upload";

const RightEmployeeDetails = ({
  setCloseRightSidebar
}: {
  closeRightSidebar: boolean;
  setCloseRightSidebar: any;
}) => {
  const handleTemplateDownload = async () => {
    try {
      await downloadEmployeeTemplate();
      toast.success("Template downloaded successfully", {
        toastId: "employee-template-download"
      });
    } catch {
      toast.error("We couldn't download the template. Please try again.", {
        toastId: "employee-template-download"
      });
    }
  };

  return (
    <aside className="fixed top-0 right-0 hidden h-screen w-[290px] border-l bg-[#ffffff] px-[16px] pt-[100px] lg:block">
      <section>
        <div className="mb-20">
          <FaXmark
            className="w-[20px] h-[20px] cursor-pointer"
            onClick={() => setCloseRightSidebar(true)}
          />
        </div>
        <div>
          <Image
            src="/employeeLogo.svg"
            width={272}
            height={173.22}
            alt="Employee Img"
          />

          <div className="text-[#1E1E1E] text-sm mt-8">
            <h2 className="font-bold mb-4">Upload employees in bulk</h2>
            <p className=" mb-2">
              Add/Update multiple employees at the same time by uploading a
              single excel file{" "}
              <span
                onClick={handleTemplateDownload}
                className="text-secondary font-bold hover:underline cursor-pointer "
              >
                Download Template
              </span>
            </p>
          </div>
        </div>
      </section>

      <BulkUpload />
    </aside>
  );
};

export default RightEmployeeDetails;
