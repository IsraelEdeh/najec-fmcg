"use client";

import React, { useState } from "react";
import Image from "next/image";
import { FaXmark } from "react-icons/fa6";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import BulkUploadSchedule from "./BulkUploadSchedule";
import { sanitizeFilename } from "@/lib/helpers";
import { useQuery } from "@tanstack/react-query";
import { getOrganizationDetails, getThread } from "@/constants";
import { useSchedulePayPeriod } from "@/components/Payroll/Runs/useSchedulePayPeriod";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";

const RightPayrollScheduleDetails = ({
  setCloseRightSidebar
}: {
  closeRightSidebar: boolean;
  setCloseRightSidebar: any;
}) => {
  const [loading, setLoading] = useState(false);

  const user: any = useSelector((state: RootState) => state?.getUser.user);

  const organizationId = user?.userOrganizations?.find(
    (item: any) => item.isCurrentLoggedInOrganization
  )?.organizationId;

  const {
    error: organizationByIdError,
    data: organizationDetails,
    isPending
  } = useQuery({
    queryKey: ["organizationByIdDetails", organizationId],
    queryFn: () => getOrganizationDetails(organizationId)
  });

  const handleTemplateDownload = async () => {
    try {
      setLoading(true);
      const response = await ApiFetcher.get("/tax/download-schedule-template", {
        responseType: "blob"
      });

      const blob = new Blob([response.data], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");

      const fileName = sanitizeFilename(`${`payroll_schedule_${organizationDetails?.organizationName}_${new Date().toISOString().split("T")[0]}`}`) + ".xlsx";

      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success("Template downloaded successfully");
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error downloading template";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const { payPeriodId: payrollId } = useSchedulePayPeriod();

  const { data: payrollProcessData, isLoading: isPayrollProcessLoading } = useQuery({
    queryKey: ["fetchCurrentPayrollProcess", payrollId],
    queryFn: () => getThread(payrollId),
    enabled: !!payrollId
  });

  return (
    <aside className="fixed right-0 top-0 hidden h-screen w-[290px] overflow-x-hidden overflow-y-auto border-l bg-[#ffffff] px-[16px] py-6 lg:block">
      <section>
        <div className="mb-20">
          <FaXmark
            className="w-[20px] h-[20px] cursor-pointer"
            onClick={() => setCloseRightSidebar(true)}
          />
        </div>
        <div>
          <Image
            className="mb-6"
            src="/dashboard/filing.png"
            alt="filing"
            width={272}
            height={143}
          />

          <div className="text-[#1E1E1E] text-sm mt-8">
            <h2 className="font-bold mb-4">
              Upload payroll schedule template in bulk
            </h2>
            <p className=" mb-2">
              Please download the payroll template before uploading your
              completed file.
              <span
                onClick={handleTemplateDownload}
                className="text-secondary font-bold hover:underline cursor-pointer "
              >
                {loading ? " Downloading..." : "Download Template"}
              </span>
            </p>
          </div>
        </div>
      </section>

      <BulkUploadSchedule payrollProcessData={payrollProcessData} />
    </aside>
  );
};

export default RightPayrollScheduleDetails;
