import React from "react";

const RightsideBar = () => {
  return (
    <aside className="right-sidebar mt-[4rem]">
      <section>
        <div className="">
          {/* Placeholder for top image */}
          <div className="w-full h-32 bg-gray-400 mb-4"></div>

          {/* Search Bar */}
          <div className="mb-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search"
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>

          {/* Active Payrolls Section */}
          <div>
            <h2 className="text-xl font-semibold mb-2">Active payrolls</h2>
            <p className="text-gray-600 mb-2">No payrolls in progress</p>
            <a href="#" className="text-blue-600 hover:underline">
              View payroll history
            </a>
          </div>

          {/* Placeholder for bottom image */}
          <div className="w-full h-32 bg-gray-300 mt-4"></div>
        </div>
      </section>
    </aside>
  );
};

export default RightsideBar;
