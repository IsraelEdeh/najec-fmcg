import React from "react";

const RightsideBarPayroll = () => {
  return (
    <aside className="right-sidebar">
      <section className="">
        <div>
          <h1 className="text-sm font-bold pb-3">Your payroll schedule</h1>

          <p className="text-sm pb-3 text-gray-600">
            Your next payroll is due is 13 days. Update your pay schedule if
            this has changed.
          </p>
        </div>

        <div className="w-[272px] h-[301px] bg-[#D9D9D9] my-3"></div>

        <button className="bg-black w-full text-white text-sm py-[9px]">
          Edit Pay Schedule
        </button>
      </section>
    </aside>
  );
};

export default RightsideBarPayroll;
