import React from "react";

const RightsideRunPayroll = () => {
  const handleDownload = () => {
    const link = document.createElement("a");
    link.download = "Sample Template";

    link.href = "/Payroll.xlsx";
    link.click();
  };
  return (
    <aside className="right-sidebar">
      <section className="">
        <div>
          <h1 className="text-sm font-bold pb-3">Payroll Template</h1>

          <p className="text-sm pb-3 text-gray-600">
            Make sure your payroll schedule is in the correct format to ensure
            successful payrun.
          </p>
        </div>

        <div className="w-full h-[301px] bg-[#D9D9D9] my-3"></div>

        <button
          onClick={handleDownload}
          className="bg-black w-full text-white text-sm py-[9px]"
        >
          Download Template
        </button>
      </section>
    </aside>
  );
};

export default RightsideRunPayroll;
