import React, { useEffect, useState } from "react";
import { Button } from "../ui/button";

const SecurityNotice = () => {
  const initialShow = true; // Set this to false if you want to hide the notice initially
  const [showNotice, setShowNotice] = useState(initialShow);

  useEffect(() => {
    const acknowleged = localStorage.getItem("securityNoticeAcknowledged");
    if(acknowleged) {
        setShowNotice(false);
    return;
    }
    setShowNotice(initialShow);
  }, [initialShow]);

  const handleAcknowledge = () => {
    setShowNotice(false);
    localStorage.setItem("securityNoticeAcknowledged", "true"); 
  };

  if (!showNotice) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-75 p-4 sm:p-6">
      <div className="relative w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl md:p-8">
        <h2 className="mb-6 text-center text-2xl font-bold text-gray-800 md:text-3xl">
          Security Notice
        </h2>

        <ul className="mb-8 space-y-8 text-base text-gray-700 md:text-lg">
          <li className="flex items-start">
            <span className="mr-3 text-blue-600">&#x2022;</span>{" "}
            {/* Bullet point */}
            Usage of this system/solution may be monitored, recorded, or subject
            to an audit.
          </li>
          <li className="flex items-start">
            <span className="mr-3 text-blue-600">&#x2022;</span>{" "}
            {/* Bullet point */}
            Your continued use of this system/solution indicates your explicit
            consent to such monitoring.
          </li>
          <li className="flex items-start">
            <span className="mr-3 text-blue-600">&#x2022;</span>{" "}
            {/* Bullet point */}
            Unauthorized use of this system/solution is strictly prohibited and
            subject to criminal and civil penalties.
          </li>
        </ul>

        <div className="flex justify-center">
          <Button
            onClick={handleAcknowledge}
            className="rounded-xl text-white text-lg"
          >
            Acknowledge & Proceed
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SecurityNotice;
