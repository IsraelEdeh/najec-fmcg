"use client";

import { useQuery } from "@tanstack/react-query";
import { Clock3 } from "lucide-react";
import React from "react";
import { toast } from "react-toastify";
import ApiFetcher from "../Utils/api";
import { TbLoader3 } from "react-icons/tb";

const UpcomingPayroll = () => {
  const todayDate = new Date();

  const handleUpcomingPayroll = async () => {
    try {
      const response = await ApiFetcher.get("/payperiods/get-all-pay-period");

      // console.log("upcoming:::", response);
      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching users";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: allPayPeriods,
    isPending,
    isError
  } = useQuery({
    queryKey: ["upcomingPayrollData"],
    queryFn: handleUpcomingPayroll
  });

  // console.log("dsd::", allPayPeriods);

  if (isPending) {
    return (
      <section>
        <div className="mt-6 p-6 bg-white rounded-[4px] border border-[#D9D9D9] flex justify-center items-center">
          <TbLoader3 className="text-primary animate-spin w-6 h-6" />
          <span className="ml-2">Loading upcoming payroll...</span>
        </div>
      </section>
    );
  }

  if (isError || !allPayPeriods || allPayPeriods.length === 0) {
    return (
      <section>
        <div className="mt-6 p-6 bg-white rounded-[4px] border border-[#D9D9D9] flex flex-col items-center justify-center">
          <Clock3 size={40} className="text-gray-400 mb-2" />
          <h2 className="text-lg font-semibold text-gray-600 mb-1">
            No Upcoming Payroll Scheduled
          </h2>
          <p className="text-sm text-gray-500">Check back later for updates.</p>
        </div>
      </section>
    );
  }

  const upcomingPayroll = allPayPeriods
    .filter((period: any) => new Date(period?.startDate) > new Date())
    ?.sort((a: any, b: any) => a?.startDate - b?.startDate)[0];

  // console.log("upcoming::", upcomingPayroll);

  const startDate = new Date(upcomingPayroll?.startDate);
  const endDate = new Date(upcomingPayroll?.endDate);
  const today = new Date();
  const timeDifference = startDate?.getTime() - today.getTime();
  const daysUntilPayroll = Math.ceil(timeDifference / (1000 * 3600 * 24));

  return (
    <section className={`${upcomingPayroll ? "block" : "hidden"}`}>
      <div className="mt-6 p-6 bg-white rounded-[4px] border border-[#D9D9D9]">
        <div className="flex items-center space-x-6">
          <h2 className="text-xl font-bold mb-3">Upcoming payroll</h2>
          <div className="bg-[#DDEFE8] rounded-[6px] py-1 px-2 flex items-center mb-3 gap-[10px]">
            <Clock3 size={20} className="text-[#404040]" />
            <p className="text-sm">
              Due{" "}
              {daysUntilPayroll > 0 ? `${daysUntilPayroll} days` : "Today/Soon"}
            </p>
          </div>
        </div>

        <div className="flex w-[600px] justify-between text-sm mb-2">
          <h1 className="flex items-center space-x-1">
            <Clock3 size={15} className="text-[#404040]" />
            <span>Pay period</span>
          </h1>
          <h1>Pay day</h1>
        </div>

        <div className="flex w-[600px] justify-between text-sm mb-4">
          <p>
            <span className="font-bold">
              {upcomingPayroll?.startDate?.split("T")[0]}
            </span>{" "}
            -{" "}
            <span className="font-bold">
              {upcomingPayroll?.endDate?.split("T")[0]}
            </span>
          </p>
          <p className="font-bold">
            {upcomingPayroll?.deadLine?.split("T")[0]}
          </p>
        </div>
      </div>
    </section>
  );
};

export default UpcomingPayroll;
