"use client";

import { DashboardLeftsidebarLinks } from "@/constants";
import { cn } from "@/lib/utils";
import Link from "next/link";
import { usePathname } from "next/navigation";
import React, { useState } from "react";

const LeftsideBar = () => {
  const pathname = usePathname();
  const [activeSubMenu, setActiveSubMenu] = useState<string | null>(null);

  const toggleSubMenu = (label: string) => {
    setActiveSubMenu(activeSubMenu === label ? null : label);
  };

  return (
    <section className="pt-24 pb-10">
      <nav className="flex flex-col text-black">
        {DashboardLeftsidebarLinks.map((item) => {
          const isActive = pathname === item.route;
          const hasSubLinks = item.subLinks && item.subLinks.length > 0;
          return (
            <div className="" key={item.label}>
              <Link
                href={item.route}
                onClick={() => hasSubLinks && toggleSubMenu(item.label)}
                className={cn(
                  `left-sidebarlink`,
                  {
                    "text-primary font-bold": isActive
                  }
                )}
              >
                <div className="flex w-full relative size-6 gap-3">
                  <span>{item.icon}</span>
                  <p
                    className={`${
                      isActive ? "text-primary" : "text-[#0A0A0A]"
                    } left-sidebarlabel`}
                  >
                    {item.label}
                  </p>
                </div>
              </Link>

              {hasSubLinks && activeSubMenu === item.label && (
                <div className={`ml-4 `}>
                  {item.subLinks?.map((subItem) => (
                    <Link
                      key={subItem.label}
                      href={subItem.route}
                      className={cn("left-sidebarlink text-sm", {
                        "text-primary": pathname === subItem.route
                      })}
                    >
                      {subItem.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>
    </section>
  );
};

export default LeftsideBar;
