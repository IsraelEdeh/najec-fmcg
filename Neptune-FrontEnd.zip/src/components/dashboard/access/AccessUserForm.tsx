"use client";

import ApiFetcher from "@/components/Utils/api";
import { fetchDeparments } from "@/constants";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Image from "next/image";
import React, { useEffect, useState } from "react";
import { MdInfoOutline } from "react-icons/md";
import { toast } from "react-toastify";
import CustomInput from "../CustomInput";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useSelector } from "react-redux";
import { RootState } from "@/app/store";
import axios from "axios";
import useDebounce from "@/lib/useDebounce";

// New-user fields are only required when the email does not belong to an existing user.
const whenNewUser = (field: yup.StringSchema, message: string) =>
  field.when("$isNewUser", {
    is: true,
    then: (schema) => schema.required(message),
    otherwise: (schema) => schema.notRequired()
  });

const schema = yup
  .object({
    firstName: whenNewUser(
      yup.string().min(3, "First name should be 3 characters or more"),
      "First name is required"
    ),
    lastName: whenNewUser(
      yup.string().min(3, "Last name should be 3 characters or more"),
      "Last name is required"
    ),
    phoneNumber: whenNewUser(
      yup
        .string()
        .min(11, "Phone must be 11 digits or more")
        .max(13, "Phone must be 14 digits or less"),
      "Phone number is required"
    ),
    gender: whenNewUser(yup.string(), "Gender is required"),
    country: whenNewUser(yup.string(), "Country is required"),
    userRole: yup.string().required("Select a user role")
  })
  .required();

const AccessUserForm = ({ setOpenUserDialog }: { setOpenUserDialog: any }) => {
  const [userExists, setUserExists] = useState<boolean>(false);
  const [email, setEmail] = useState<string>("");
  const [debouncedEmailError, setDebouncedEmailError] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const queryClient = useQueryClient();
  const debouncedSearch = useDebounce(email, 1000);
  const user: any = useSelector((state: RootState) => state?.getUser?.user);

  const {
    isLoading: loadingDepartment,
    data: departmentData,
    error: departmentError
  } = useQuery({
    queryKey: ["addEmployeesDepartments"],
    queryFn: fetchDeparments
  });

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isValid }
  } = useForm({
    resolver: yupResolver(schema),
    mode: "onChange",
    context: { isNewUser: Boolean(debouncedEmailError) }
  });

  const getRoles = async () => {
    try {
      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_BASE_URL}/auth/get-all-roles`
      );
      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching roles";
      console.log(errorMessage);
      setUserExists(false);
      errorMessage === "User does not exist" ? null : toast.error(errorMessage);
    }
  };

  const {
    data: rolesData,
    isLoading: rolesLoading,
    isError: getRolesError
  } = useQuery({
    queryKey: ["rolesData"],
    queryFn: getRoles
  });

  const handleAddUserToOrganization = async (data: any) => {
    try {
      setLoading(true);
      let payload;
      if (userExists) {
        payload = {
          userEmail: email,
          userRole: data.userRole,
          organizationId: user?.userOrganizations?.find(
            (item: any) => item.isCurrentLoggedInOrganization
          )?.organizationId
        };
        const response = await ApiFetcher.post(
          `/organization/add-user-to-organization`,
          payload
        );

        toast.success("User added successfully");
        setOpenUserDialog(false);
        reset();
        return response;
      } else {
        payload = {
          email: email,
          firstName: data.firstName,
          lastName: data.lastName,
          otherName: data.otherName,
          phoneNumber: data.phoneNumber,
          gender: Number(data.gender),
          countryId: Number(data.country),
          roles: data.userRole,
          organizationId: Number(
            user?.userOrganizations?.find(
              (item: any) => item.isCurrentLoggedInOrganization
            )?.organizationId
          ),
          isUserProfileCompleted: true
        };
        const response = await ApiFetcher.post(
          `/users/create-user?role=${data.userRole}`,
          payload
        );
        toast.success("User added successfully");

        setOpenUserDialog(false);
        reset();

        return response;
      }
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding user to organization";

      console.log("user Error::", error);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const mutation = useMutation({
    mutationFn: handleAddUserToOrganization,
    onSuccess: async () => {
      await queryClient.invalidateQueries();
    },
    onError: async (error) => {
      console.log("on error", error);
    }
  });

  const onHandlerSubmit = (data: any) => {
    // The handler resets the form only after a successful save, so a failed attempt keeps the input.
    mutation.mutate(data);
  };

  const getUserEmailDebouncedResult = async (email: string) => {
    try {
      if (!email) return null;
      setUserExists(true);
      const response = await ApiFetcher.post(`/users/check-user-by-email`, {
        email
      });
      setDebouncedEmailError("");

      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Email does not exist in the system";
      console.log(errorMessage);
      setDebouncedEmailError(errorMessage);
      setUserExists(false);
      errorMessage === "User does not exist" ? null : toast.info(errorMessage);
    }
  };

  useEffect(() => {
    if (debouncedSearch) {
      getUserEmailDebouncedResult(email);
    }
  }, [debouncedSearch]);

  return (
    <div>
      <form onSubmit={handleSubmit(onHandlerSubmit)} className="pt-3">
        <div className="grid grid-cols-2 gap-4 space-y-2">
          <div className="col-span-2">
            <label className="text-primary text-sm flex items-center space-x-1">
              <span className="font-bold">Email</span>
              <Image
                src="/dashboard/required.png"
                alt="required icon"
                width={8}
                height={20}
              />
            </label>
            <div>
              <input
                type="email"
                className="w-full text-sm rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                placeholder="example@mail.com"
                value={email}
                onChange={(e: any) => setEmail(e.target.value)}
              />
            </div>
          </div>

          {debouncedEmailError && (
            <div className="col-span-2 space-y-6">
              <div className=" rounded-[4px] p-4 bg-[#DDEFE8] flex justify-between space-x-2">
                <MdInfoOutline className="text-3xl text-[#FF3B30]" />

                <div className="text-[#1E1E1E] text-sm">
                  No user with this email was found. Please provide the
                  information below to add a new user. They will receive a link
                  to complete their account via email.
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="flex items-center space-x-1 text-sm w-full max-w-[280px] font-bold text-[#1E1E1E]">
                    <span className="block">First Name</span>
                    <Image
                      src="/dashboard/required.png"
                      width={8}
                      height={20}
                      alt="required icon"
                    />
                  </label>
                  <input
                    type="text"
                    {...register("firstName")}
                    placeholder="Enter first name"
                    className="w-full text-base py-[7px] px-4 rounded-[4px] border border-[#D0D0CE] text-gray-900 placeholder:text-gray-500"
                  />

                  <p
                    className="text-red-400 mt-1 text-xs lg:text-sm"
                    role="alert"
                  >
                    {errors.firstName?.message}
                  </p>
                </div>

                <div>
                  <label className="flex items-center space-x-1 text-sm w-full max-w-[280px] font-bold text-[#1E1E1E]">
                    <span className="block">Last Name</span>
                    <Image
                      src="/dashboard/required.png"
                      width={8}
                      height={20}
                      alt="required icon"
                    />
                  </label>
                  <input
                    type="text"
                    {...register("lastName")}
                    placeholder="Enter last name"
                    className="w-full text-base py-[7px] px-4 rounded-[4px] border border-[#D0D0CE] text-gray-900 placeholder:text-gray-500"
                  />

                  <p
                    className="text-red-400 mt-1 text-xs lg:text-sm"
                    role="alert"
                  >
                    {errors.lastName?.message}
                  </p>
                </div>
              </div>

              <div>
                <div>
                  <label className="flex items-center space-x-1 text-sm w-full max-w-[280px] font-bold text-[#1E1E1E]">
                    <span className="block">Phone Number</span>
                    <Image
                      src="/dashboard/required.png"
                      width={8}
                      height={20}
                      alt="required icon"
                    />
                  </label>
                  <input
                    type="text"
                    {...register("phoneNumber")}
                    placeholder="Enter phone number"
                    className="w-full text-base py-[7px] px-4 rounded-[4px] border border-[#D0D0CE] text-gray-900 placeholder:text-gray-500"
                  />

                  <p
                    className="text-red-400 mt-1 text-xs lg:text-sm"
                    role="alert"
                  >
                    {errors.phoneNumber?.message}
                  </p>
                </div>
              </div>

              <div>
                <label className="text-primary text-sm flex items-center space-x-1">
                  <span className="font-bold">Gender</span>
                  <Image
                    src="/dashboard/required.png"
                    width={8}
                    height={20}
                    alt="required icon"
                  />
                </label>

                <select
                  className="w-full text-sm rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                  aria-label="Gender"
                  {...register("gender")}
                >
                  <option value="">Select a gender</option>
                  <option value="0">Male</option>
                  <option value="1">Female</option>
                </select>
                <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                  {errors.gender?.message}
                </p>
              </div>

              <div>
                <label className="text-primary text-sm flex items-center space-x-1">
                  <span className="font-bold">Country</span>
                  <Image
                    src="/dashboard/required.png"
                    width={8}
                    height={20}
                    alt="required icon"
                  />
                </label>

                <select
                  aria-label="Country"
                  {...register("country")}
                  className="w-full text-sm rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
                >
                  <option value="">Select a country</option>
                  <option value="1">Nigeria</option>
                </select>
                <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                  {errors.country?.message}
                </p>
              </div>

              {/* <div className="col-span-2">
                <div>
                  <label
                    htmlFor="employmentType"
                    className="flex items-center space-x-1 mb-2 text-sm font-medium text-gray-900"
                  >
                    <span>Employment type</span>
                  </label>
                  <select
                    {...register("employmentType", {
                      required: true
                    })}
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                  >
                    <option>Select employment type</option>
                    <option value={0}>Full time</option>
                    <option value={1}>Contract</option>
                  </select>
                  <p
                    className="text-red-400 mt-1 text-xs lg:text-sm"
                    role="alert"
                  >
                    {errors?.employmentType?.message}
                  </p>
                </div>
              </div> */}
            </div>
          )}

          <div className="col-span-2">
            <label className="text-primary text-sm flex items-center space-x-1">
              <span className="font-bold">Select roles</span>
              <Image
                src="/dashboard/required.png"
                width={8}
                height={20}
                alt="required icon"
              />
            </label>
            <select
              aria-label="User role"
              {...register("userRole")}
              className="w-full text-sm rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
            >
              <option value="">Select user role</option>
              {rolesData
                ?.filter((role: string) => role !== "Employee")
                ?.map((role: any) => (
                  <option key={role} value={role}>
                    {role}
                  </option>
                ))}
            </select>
            <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
              {errors.userRole?.message}
            </p>
          </div>

          <div className="col-span-2 w-full flex justify-end">
            <button
              type="submit"
              disabled={!isValid || !email.trim() || mutation.isPending}
              className="w-fit disabled:bg-secondary disabled:bg-opacity-70 text-sm bg-primary text-white text-center rounded-[4px] py-2.5 px-3"
            >
              {mutation.isPending ? "Adding User..." : "Add User"}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default AccessUserForm;
