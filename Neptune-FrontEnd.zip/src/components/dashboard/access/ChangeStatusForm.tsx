"use client";

import ApiFetcher from "@/components/Utils/api";
import { useMutation, useQuery } from "@tanstack/react-query";
import axios from "axios";
import Image from "next/image";
import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { MdInfoOutline } from "react-icons/md";
import { TbLoader3 } from "react-icons/tb";
import { toast } from "react-toastify";

const ChangeStatusForm = ({ userId }: { userId: any }) => {
  console.log("userId::", userId);
  const getRoles = async () => {
    try {
      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_BASE_URL}/auth/get-all-roles`
      );
      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching roles";
      console.log(errorMessage);
      errorMessage === "User does not exist" ? null : toast.error(errorMessage);
    }
  };

  const {
    data: rolesData,
    isLoading: rolesLoading,
    isError: getRolesError
  } = useQuery({
    queryKey: ["rolesData"],
    queryFn: getRoles
  });

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting }
  } = useForm();

  // Fetch user data
  const { data: userData, isLoading } = useQuery({
    queryKey: ["userData", userId],
    queryFn: async () => {
      if (!userId) return null;
      const response = await ApiFetcher.get(`/users/get-user-by-id/${userId}`);
      return response?.data?.data;
    },
    enabled: !!userId
  });

  // Update user mutation
  const mutation = useMutation({
    mutationFn: async (formData: any) => {
      const response = await ApiFetcher.put(
        `/users/update-user/${userId}`,
        formData
      );
      return response?.data;
    },
    onSuccess: () => {
      toast.success("User updated successfully");
    },
    onError: (error: any) => {
      toast.error(error?.response?.data?.message || "Error updating user");
    }
  });

  const onSubmit = (data: any) => {
    mutation.mutate(data);
  };

  // Populate form when userData changes
  useEffect(() => {
    if (userData) {
      reset({
        firstName: userData.firstName || "",
        lastName: userData.lastName || "",
        phoneNumber: userData.phoneNumber || "",
        gender: userData.gender || "",
        country: userData.country || "",
        employmentType: userData.employmentType || "",
        userRole: userData.userRole || ""
      });
    }
  }, [userData, reset]);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <TbLoader3 className="animate-spin w-6 h-6 text-primary" />
      </div>
    );
  }

  return (
    <div>
      <form className="space-y-4">
        <div className="col-span-2 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="flex items-center space-x-1 text-sm w-full max-w-[280px] font-bold text-[#1E1E1E]">
                <span className="block">First Name</span>
                <Image
                  src="/dashboard/required.png"
                  width={8}
                  height={20}
                  alt="required icon"
                />
              </label>
              <input
                type="text"
                {...register("firstName")}
                placeholder="Enter first name"
                className="w-full text-base py-[7px] px-4 rounded-[4px] border border-[#D0D0CE] text-gray-900 placeholder:text-gray-500"
              />

              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {/* {errors.firstName?.message} */}
              </p>
            </div>

            <div>
              <label className="flex items-center space-x-1 text-sm w-full max-w-[280px] font-bold text-[#1E1E1E]">
                <span className="block">Last Name</span>
                <Image
                  src="/dashboard/required.png"
                  width={8}
                  height={20}
                  alt="required icon"
                />
              </label>
              <input
                type="text"
                {...register("lastName")}
                placeholder="Enter last name"
                className="w-full text-base py-[7px] px-4 rounded-[4px] border border-[#D0D0CE] text-gray-900 placeholder:text-gray-500"
              />

              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {/* {errors.lastName?.message} */}
              </p>
            </div>
          </div>

          <div>
            <div>
              <label className="flex items-center space-x-1 text-sm w-full max-w-[280px] font-bold text-[#1E1E1E]">
                <span className="block">Phone Number</span>
                <Image
                  src="/dashboard/required.png"
                  width={8}
                  height={20}
                  alt="required icon"
                />
              </label>
              <input
                type="text"
                {...register("phoneNumber")}
                placeholder="Enter phone number"
                className="w-full text-base py-[7px] px-4 rounded-[4px] border border-[#D0D0CE] text-gray-900 placeholder:text-gray-500"
              />

              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {/* {errors.phoneNumber?.message} */}
              </p>
            </div>
          </div>

          <div>
            <label className="text-primary text-sm flex items-center space-x-1">
              <span className="font-bold">Gender</span>
              <Image
                src="/dashboard/required.png"
                width={8}
                height={20}
                alt="required icon"
              />
            </label>

            <select
              className="w-full text-sm rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
              {...register("gender", {
                required: true
              })}
            >
              <option value="Gender">Select a gender</option>
              <option value="1">Male</option>
              <option value="2">Female</option>
            </select>
          </div>

          <div>
            <label className="text-primary text-sm flex items-center space-x-1">
              <span className="font-bold">Country</span>
              <Image
                src="/dashboard/required.png"
                width={8}
                height={20}
                alt="required icon"
              />
            </label>

            <select
              {...register("country", {
                required: true
              })}
              className="w-full text-sm rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
            >
              <option value="">Select a country</option>
              <option value="1">Nigeria</option>
            </select>
          </div>

          <div className="col-span-2">
            <div>
              <label
                htmlFor="employmentType"
                className="flex items-center space-x-1 mb-2 text-sm font-medium text-gray-900"
              >
                <span>Employment type</span>
                <Image
                  src="/dashboard/required.png"
                  width={8}
                  height={20}
                  alt="required icon"
                />
              </label>
              <select
                {...register("employmentType", {
                  required: true
                })}
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
              >
                <option>Select employment type</option>
                <option value={0}>Full time</option>
                <option value={1}>Contract</option>
              </select>
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {/* {errors?.employmentType?.message} */}
              </p>
            </div>
          </div>
        </div>

        <div className="col-span-2">
          <label className="text-primary text-sm flex items-center space-x-1">
            <span className="font-bold">Select roles</span>
            <Image
              src="/dashboard/required.png"
              width={8}
              height={20}
              alt="required icon"
            />
          </label>
          <select
            {...register("userRole", {
              required: true
            })}
            className="w-full text-sm rounded-[4px] border border-[#D0D0CE] py-[5px] px-[8px]"
          >
            <option value="">Select user role</option>
            {rolesData
              ?.filter((role: string) => role !== "Employee")
              ?.map((role: any) => (
                <option key={role} value={role}>
                  {role}
                </option>
              ))}
          </select>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={mutation.isPending}
            className="w-fit text-sm bg-primary text-white text-center rounded-[4px] py-2.5 px-3"
          >
            {mutation.isPending ? "Updating User..." : "Update User"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ChangeStatusForm;
