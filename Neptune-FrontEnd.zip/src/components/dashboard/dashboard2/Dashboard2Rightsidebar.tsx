import React from "react";
import { FaXmark } from "react-icons/fa6";

import Image from "next/image";

const Dashboard2Rightsidebar = ({
  closeRightSidebar,
  setCloseRightSidebar,
}: {
  closeRightSidebar: boolean;
  setCloseRightSidebar: any;
}) => {
  return (
    <aside className="fixed top-0 right-0 hidden h-screen w-[290px] border-l bg-[#ffffff] px-[16px] pt-[100px] lg:block">
      <div>
        <div className="mt-[]">
          <FaXmark
            className="w-[20px] h-[20px] cursor-pointer"
            onClick={() => setCloseRightSidebar(true)}
          />
        </div>

        <div className="mt-[48px]">
          <div>
            <Image
              src="/dashboard/dashboard2/dashboard-sideimg.png"
              width={272}
              height={277.44}
              alt="sidebar image"
            />
          </div>

          <div className="my-[24px]">
            <p className="text-[#000000] text-2xl font-bold">Active payrolls</p>
            <p className="text-[#000000] text-sm font-normal py-[16px]">
              No payrolls in progress
            </p>
            <p className="text-[#000000] text-sm font-bold underline cursor-pointer">
              View payroll history
            </p>
          </div>

          <div className="my-[24px]">
            <Image
              src="/dashboard/dashboard2/Rectangle.png"
              width={272}
              height={76}
              alt="sidebar image 2"
            />
          </div>

          <div className="">
            <p className="text-[#000000] text-2xl font-bold">Recent activity</p>
            <p className="text-[#000000] text-sm font-normal py-[16px]">No payrolls in progress</p>
            <p className="text-[#000000] text-sm font-bold underline cursor-pointer">View payroll history</p>
        </div>
        </div>
      </div>
    </aside>
  );
};

export default Dashboard2Rightsidebar;
