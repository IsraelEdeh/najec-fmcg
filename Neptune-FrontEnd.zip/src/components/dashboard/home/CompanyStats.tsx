"use client";
import { RootState } from "@/app/store";

import { Grid2x2 } from "lucide-react";
import Link from "next/link";
import React from "react";
import { FiUsers } from "react-icons/fi";
import { IoMdArrowUp } from "react-icons/io";
import { useSelector } from "react-redux";

import {
  Tooltip,
  TooltipContent,
  TooltipTrigger
} from "@/components/ui/tooltip";

const CompanyStats = ({
  dashboardResults,
  isError
}: {
  dashboardResults: any;
  isError: boolean;
}) => {
  const user: any = useSelector((state: RootState) => state.getUser.user);

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  return (
    <section>
      <div className="mt-6 border border-[#D9D9D9] bg-[#F4F6F9] rounded-[4px] p-6 grid grid-cols-2">
        <div className="border-r border-r-[#D9D9D9]">
          <div>
            <Link
              className="w-fit flex items-center space-x-2"
              // href="dashboard/employees"
              href={
                activeRole?.includes("Admin") ||
                activeRole?.includes("Initiator")
                  ? "dashboard/employees"
                  : "#"
              }
            >
              <FiUsers className="text-primary" />

              <p className="font-semibold">Total Employees</p>
              {/* <Tooltip>
                <TooltipTrigger asChild>
                  <FiUsers className="text-primary" />

                  <p className="font-semibold">Total Employees</p>
                </TooltipTrigger>
                <TooltipContent>
                  <p>The total number of employees in the organization</p>
                </TooltipContent>
              </Tooltip> */}
            </Link>
          </div>

          <div>
            <Link
              className="mt-4 w-fit flex items-end space-x-3"
              href="dashboard/employees"
            >
              <span className="text-primary flex text-[32px] font-semibold">
                <span className="block">
                  {dashboardResults?.totalEmployees}
                </span>
              </span>
            </Link>

            <p className="hidden items-center">
              <IoMdArrowUp className="text-secondary pr-1" />
              <span className="text-secondary block">3%</span>{" "}
              <span className="pl-[3px]">last month</span>
            </p>
          </div>
        </div>

        <div className="pl-4">
          <div>
            <Link
              className="w-fit flex items-center space-x-1"
              // href="dashboard/organization"
              href={
                activeRole?.includes("Admin") ||
                activeRole?.includes("Initiator")
                  ? "dashboard/organization"
                  : "#"
              }
            >
              <Grid2x2 className="w-6 h-6 text-primary" />
              <p className="font-semibold">Departments</p>
              {/* <Tooltip>
                <TooltipTrigger asChild>
                  <Grid2x2 className="w-6 h-6 text-primary" />
                  <p className="font-semibold">Departments</p>
                </TooltipTrigger>
                <TooltipContent>
                  <p>
                    The total number of departments within the organization.
                  </p>
                </TooltipContent>
              </Tooltip> */}
            </Link>
          </div>

          <p className="font-semibold text-[32px] mt-4">
            <Link
              // href="dashboard/organization"
              href={
                activeRole?.includes("Admin") ||
                activeRole?.includes("Initiator")
                  ? "dashboard/organization"
                  : "#"
              }
            >
              {dashboardResults?.totalDepartments}
            </Link>
          </p>
        </div>
      </div>
    </section>
  );
};

export default CompanyStats;
