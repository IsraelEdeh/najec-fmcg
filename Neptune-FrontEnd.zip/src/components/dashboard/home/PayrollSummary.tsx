import React from "react";
import CountUp from "react-countup";
import Image from "next/image";
import { IoMdArrowUp } from "react-icons/io";
import Link from "next/link";
import _ from "lodash";
import EmptyRecord from "../EmptyRecord";
import { formatCurrency } from "@/lib/helpers";

const PayrollSummary = ({
  dashboardResults,
  isError
}: {
  dashboardResults: any;
  isError: boolean;
}) => {
  const values = Object.values({
    1: dashboardResults?.netEmployeePay,
    2: dashboardResults?.companyContributions,
    3: dashboardResults?.totalTaxes,
    4: dashboardResults?.employeeDeductions
  });
  // console.log("values::", values);

  const sum = values.reduce((a, b) => a + b, 0);
  // console.log("sum::", sum);

  const getPercentageWidth = (value: number) => {
    return (value / sum) * 100;
  };

  // console.log(getPercentageWidth(dashboardResults?.netEmployeePay) / 100);

  return (
    <section className="mt-6 bg-white rounded-[4px] p-6">
      <div className="flex items-center justify-between">
        <p className="font-semibold text-[23px] mb-5">Payroll Summary</p>

        {/* <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className="flex items-center space-x-2 py-1 px-2 text-sm border-none text-[#1E1E1E] rounded-[8px]"
              type="button"
            >
              <span>Last Month</span>

              <MdOutlineArrowDropDown />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56 bg-white">
            <DropdownMenuGroup>
              <DropdownMenuItem>Department: All</DropdownMenuItem>
              <DropdownMenuItem>Department: Tax</DropdownMenuItem>
              <DropdownMenuItem>Department: Cho</DropdownMenuItem>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
          </DropdownMenuContent>
        </DropdownMenu> */}
      </div>

      <div className="grid grid-cols-10 gap-x-5">
        <div className="col-span-4 p-4 rounded-[4px] border border-[#d9d9d9]">
          <div className="flex items-center space-x-2">
            <Image
              src="/dashboard/payment-icon.png"
              alt="payment icon"
              width={32}
              height={32}
            />

            <p className="text-base">Total Cost to Company</p>

            <div className="text-sm hidden items-center">
              <IoMdArrowUp className="text-secondary pr-1 w-4 h-4" />
              <span className="text-secondary text-sm block">3%</span>{" "}
            </div>
          </div>

          <p className="text-[32px] mt-4 font-semibold text-[#191919] text-wrap">
            <CountUp
              end={dashboardResults?.totalExpenditure}
              duration={1.75}
              decimals={2}
              decimal="."
              prefix="₦"
            />
          </p>
        </div>

        <div className="col-span-6 border border-[#d9d9d9] p-4 rounded-[4px]">
          <p className="font-bold">Cost Breakdown</p>
          {dashboardResults?.netEmployeePay ? (
            <div className="mt-4">
              <div className="relative w-full h-[50px] mx-auto my-12 flex items-center space-x-[2px]">
                <div
                  style={{
                    width: `${getPercentageWidth(
                      dashboardResults?.netEmployeePay
                    )}%`
                  }}
                  className={`h-full bg-primary rounded-l-[16px] rounded-tr-[30px] border border-white`}
                ></div>
                <div
                  style={{
                    width: `${getPercentageWidth(
                      dashboardResults?.employeeDeductions
                    )}%`
                  }}
                  className={`h-full bg-[#62B5E5] rounded-bl-[10px] rounded-tr-[30px] border border-white`}
                ></div>
                <div
                  style={{
                    width: `${getPercentageWidth(
                      dashboardResults?.totalTaxes
                    )}%`
                  }}
                  className={`h-full bg-secondary rounded-bl-[10px] rounded-tr-[30px] border border-white`}
                ></div>
                <div
                  style={{
                    width: `${getPercentageWidth(
                      dashboardResults?.companyContributions
                    )}%`
                  }}
                  className={`h-full bg-[#DDEFE8] rounded-bl-[16px] rounded-tr-[30px] border border-white`}
                ></div>
              </div>
            </div>
          ) : (
            <div className="py-6">
              <p>No records yet</p>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="flex justify-start space-x-1">
              <p className="bg-primary w-4 h-2 rounded-[2px]"></p>
              <div>
                <p className="text-sm text-[#878787]">Net Emp. Pay</p>
                <p className="text-primary mt-1">
                  {formatCurrency(dashboardResults?.netEmployeePay)}
                </p>
              </div>
            </div>

            <div className="flex justify-start  space-x-1">
              <p className="bg-[#62B5E5] w-4 h-2 rounded-[2px]"></p>
              <div>
                <p className="text-sm text-[#878787]">Emp. Deductions</p>
                <p className="text-primary mt-1">
                  {formatCurrency(dashboardResults?.employeeDeductions)}
                </p>
              </div>
            </div>

            <div className="flex justify-start  space-x-1">
              <p className="bg-secondary w-4 h-2 rounded-[2px]"></p>
              <div>
                <p className="text-sm text-[#878787]">Total Taxes</p>
                <p className="text-primary mt-1">
                  {formatCurrency(dashboardResults?.totalTaxes)}
                </p>
              </div>
            </div>

            <div className="flex justify-start  space-x-1">
              <p className="bg-[#DDEFE8] w-4 h-2 rounded-[2px]"></p>
              <div>
                <p className="text-sm text-[#878787]">Comp. Contributions</p>
                <p className="text-primary mt-1">
                  {formatCurrency(dashboardResults?.companyContributions)}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="hidden border border-[#d9d9d9] rounded-[4px] p-4 mt-6">
        <p className="font-semibold text-[23px] mb-2 pt-2">
          Expenditure across organization
        </p>
        {_.isEmpty(dashboardResults?.expenditureByDepartment) ? (
          <EmptyRecord />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full mt-[24px]">
              <thead className="bg-[#DDEFE8] py-4">
                <tr className=" w-full">
                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Department
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Total Expense
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold ">
                    Percentage
                  </th>

                  <th className="p-4 text-left uppercase text-xs font-semibold "></th>
                </tr>
              </thead>

              <tbody className="text-[#1A1A1A]">
                <tr
                  // key={applicant?._id}
                  className="border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9]"
                >
                  <td className="p-4 text-left text-sm font-normal ">
                    <p className="text-sm text-[#1e1e1e]">Employer Services</p>
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">
                    NGN 907,000.00
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">
                    <div className="h-4 w-[89%] bg-primary rounded-2xl"></div>
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">39%</td>
                </tr>

                <tr
                  // key={applicant?._id}
                  className="border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9]"
                >
                  <td className="p-4 text-left text-sm font-normal ">
                    <p className="text-sm text-[#1e1e1e]">Employer Services</p>
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">
                    NGN 437,000.00
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">
                    <div className="h-4 w-[49%] bg-primary rounded-2xl"></div>
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">39%</td>
                </tr>

                <tr
                  // key={applicant?._id}
                  className="border-t border-t-[#E5E7EB] py-4 w-full border-b border-b-[#D9D9D9]"
                >
                  <td className="p-4 text-left text-sm font-normal ">
                    <p className="text-sm text-[#1e1e1e]">Employer Services</p>
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">
                    NGN 237,000.00
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">
                    <div className="h-4 w-[29%] bg-primary rounded-2xl"></div>
                  </td>

                  <td className="p-4 text-left text-sm font-normal ">39%</td>
                </tr>
              </tbody>

              <p className="mt-6">
                <Link
                  className="underline text-primary text-sm mt-4 hover:no-underline duration-300 ease-in"
                  href="#"
                >
                  See all
                </Link>
              </p>
            </table>
          </div>
        )}
      </div>
    </section>
  );
};

export default PayrollSummary;
