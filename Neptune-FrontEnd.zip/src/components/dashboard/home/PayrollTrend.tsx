"use client";

import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

import ApiFetcher from "@/components/Utils/api";
import { toast } from "react-toastify";
import { useQuery } from "@tanstack/react-query";
import { GiBackwardTime } from "react-icons/gi";
import { formatCurrency } from "@/lib/helpers";

const processChartData = (data: any) => {
  return data?.map((item: any) => {
    let totalEmployeePay = 0;
    let totalTaxes = 0;
    let companyContributions = 0;

    item.payPeriodDetails.forEach((period: any) => {
      period.payslips.forEach((payslip: any) => {
        totalEmployeePay += payslip.employeePay;
        totalTaxes += Math.abs(payslip.taxes);
        companyContributions += payslip.companyContributions || 0;
      });
    });

    return {
      monthName: item.monthName,
      employeePay: totalEmployeePay,
      taxes: totalTaxes,
      companyContributions: companyContributions
    };
  });
};

const PayrollTrend = ({ isError }: { isError: boolean }) => {
  const fetchPayrollTrend = async () => {
    try {
      const response = await ApiFetcher.get(
        "/dashboard/dashboard-barchart-summary"
      );
      return response?.data?.data || [];
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error fetching barchart";
      console.error(errorMessage);
      // toast.error(errorMessage);
      return [];
    }
  };

  const {
    isPending,
    data: payrollTrendData,
    isError: payrollTrendError
  } = useQuery({
    queryKey: ["fetchPayrollTrend"],
    queryFn: fetchPayrollTrend
  });

  const chartData = processChartData(
    payrollTrendData?.sort((a: any, b: any) => a.month - b.month)
  );

  if (isPending) {
    return <div>Loading payroll trend data...</div>;
  }

  if (payrollTrendError || isError) {
    return <div>Error loading payroll trend data.</div>;
  }
  return (
    <section className="mt-6 bg-white rounded-[4px] p-6">
      <div className="flex items-center justify-between">
        <p className="font-semibold text-[24px] mb-5">Payroll Trend</p>

        {/* <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className="flex items-center space-x-2 py-1 px-2 text-sm border-none text-[#1E1E1E] rounded-[8px]"
              type="button"
            >
              <span>By month</span>

              <MdOutlineArrowDropDown />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56 bg-white">
            <DropdownMenuGroup>
              <DropdownMenuItem>Department: All</DropdownMenuItem>
              <DropdownMenuItem>Department: Tax</DropdownMenuItem>
              <DropdownMenuItem>Department: Cho</DropdownMenuItem>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
          </DropdownMenuContent>
        </DropdownMenu> */}
      </div>

      {payrollTrendData?.length !== 0 ? (
        <div className="border border-[#d9d9d9] rounded-[4px] p-4">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart
              data={chartData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 5
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="monthName" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="employeePay" fill="#8884d8" name="Employee Pay" />
              <Bar dataKey="taxes" fill="#82ca9d" name="Taxes" />
              <Bar
                dataKey="companyContributions"
                fill="#ffc658"
                name="Company Contributions"
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <div className="flex items-center justify-center">
          <div className="flex items-center space-x-4">
            <GiBackwardTime className="text-secondary text-4xl" />

            <div>
              <p className="font-semibold">No payroll record yet</p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default PayrollTrend;
