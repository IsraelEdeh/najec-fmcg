"use client";

import { Skeleton } from "@/components/ui/skeleton";
import ApiFetcher from "@/components/Utils/api";
import { fetchDeparments } from "@/constants";
import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import React from "react";
import { toast } from "react-toastify";

const Setup = () => {
  const {
    isLoading: loadingDepartment,
    isPending: pendingDepartment,
    data: departmentData,
    error: departmentError
  } = useQuery({
    queryKey: ["setUpDepartments"],
    queryFn: fetchDeparments
  });

  const fetchEmployees = async () => {
    try {
      const response: any = await ApiFetcher.get(
        `/employees/get-all-employees-in-an-organization`
      );

      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching employees";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  const {
    data: EmployeesData,
    isPending,
    isLoading,
    error
  } = useQuery({
    queryKey: ["fetchEmployeesForSetup"],
    queryFn: fetchEmployees
  });

  const fetchPayPeriods = async () => {
    try {
      const response: any = await ApiFetcher.get(
        `/payperiods/get-all-pay-period`
      );

    //   console.log("res::", response);

      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching employees";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  const {
    data: PayPeriod,
    isPending: payPeriodPending,
    isLoading: payPeriodLoading,
    error: payPeriodError
  } = useQuery({
    queryKey: ["fetchPayPeriodForSetup"],
    queryFn: fetchPayPeriods
  });

  return (
    <section>
      <div className="my-[40px]">
        {departmentData?.data?.data.length === 0 &&
          EmployeesData?.length === 1 &&
          PayPeriod?.length === 0 && (
            <p className="text-2xl text-[#000000] font-bold">Things to do</p>
          )}

        {pendingDepartment ? (
          <div className="space-y-2">
            <Skeleton className="h-4 w-[250px]" />
            <Skeleton className="h-4 w-[200px]" />
          </div>
        ) : (
          departmentData?.data?.data.length === 0 &&
          !loadingDepartment && (
            <div className="my-[24px] border border-[#D9D9D9] bg-[#FFFFFF] rounded-[8px] py-[24px] px-[24px]">
              <p className="text-[#000000] text-[16px] leading-[24px] font-semibold">
                Complete setup for your Organisation
              </p>
              <p className="py-[10px] text-[#000000] text-sm">
                Update your organisation profile, add departments and configure
                other settings related to your organisation.
              </p>

              <Link href="/dashboard/organization">
                <button className="px-[24px] py-[11px] text-[#ffffff] bg-primary rounded-[4px]">
                  Go to organisation details
                </button>
              </Link>
            </div>
          )
        )}

        {EmployeesData?.length === 1 && !isPending && (
          <div className="my-[24px] border border-[#D9D9D9] bg-[#FFFFFF] rounded-[8px] py-[24px] px-[24px]">
            <p className="text-[#000000] text-[16px] leading-[24px] font-semibold">
              Add your employees
            </p>
            <p className="py-[10px] text-[#000000] text-sm">
              Add a single employee or multiple employees at once by uploading a
              single Excel file
            </p>

            <Link href="/dashboard/employees">
              <button className="px-[24px] py-[11px] text-[#ffffff] bg-primary rounded-[4px]">
                Add Employees
              </button>
            </Link>
          </div>
        )}

        {PayPeriod?.length === 0 && !payPeriodPending && (
          <div className="my-[24px] border border-[#D9D9D9] bg-[#FFFFFF] rounded-[8px] py-[24px] px-[24px]">
            <p className="text-[#000000] text-[16px] leading-[24px] font-semibold">
              Configure payroll for your needs
            </p>
            <p className="py-[10px] text-[#000000] text-sm">
              Setup your pay schedule, allowances, deductions and other
              important components of payroll to enable Neptune take the load of
              your back with your upcoming payrolls.
            </p>

            <Link href="/dashboard/payroll/settings">
              <button className="px-[24px] py-[11px] text-[#ffffff] bg-primary rounded-[4px]">
                See Payroll settings
              </button>
            </Link>
          </div>
        )}
      </div>
    </section>
  );
};

export default Setup;
