"use client";

import { RootState } from "@/app/store";
import ApiFetcher from "@/components/Utils/api";
import { useQuery } from "@tanstack/react-query";
import React from "react";
import { GiBackwardTime } from "react-icons/gi";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";

const UserActivity = () => {
  const user: any = useSelector((state: RootState) => state?.getUser?.user);

  const getAllUsersActivity = async () => {
    try {
      const response = await ApiFetcher.get(
        `/activity/get-all-user-activity/${user?.userId}`
      );

      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error fetching user activities";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  const {
    data: allActivities,
    isPending,
    isLoading,
    error
  } = useQuery({
    queryKey: ["fetchAllUserActivity"],
    queryFn: getAllUsersActivity
  });

  return (
    <section className="mt-6 bg-white rounded-[4px] p-6">
      <p className="font-semibold text-[24px] mb-5">Recent Activities</p>

      <div className="mt-4 space-y-6">
        {allActivities ? (
          allActivities?.slice(0, 5)?.map((item: any) => (
            <div key={item} className="flex items-center space-x-4">
              <GiBackwardTime className="text-secondary text-4xl" />

              <div>
                <p className="font-semibold">{item}</p>
                {/* <div className="text-sm">
                <span className="font-semibold text-primary">Date: </span>{" "}
                <span>{item?.dateCreated}</span>
              </div> */}
              </div>
            </div>
          ))
        ) : (
          <div className="flex items-center justify-center">
            <div className="flex items-center space-x-4">
              <GiBackwardTime className="text-secondary text-4xl" />

              <div>
                <p className="font-semibold">No recent activity yet</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default UserActivity;
