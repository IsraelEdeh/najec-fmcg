"use client";

import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import { RootState } from "@/app/store";
import CustomButton from "@/components/Elements/CustomButton";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger
} from "@/components/ui/tooltip";
import { payPeriodSchema, toUtcDate } from "@/lib/pay-period-form";
import { updatePayPeriod } from "@/lib/payroll-api";
import { getApiErrorMessage } from "@/lib/utils";
import type { PayPeriod } from "@/types/payroll";

const toFormDate = (value?: string) => value?.split("T")[0] as unknown as Date;

const PayperiodDialog = ({
  payPeriod,
  setOpenPayPeriodDialog
}: {
  payPeriod: PayPeriod | null;
  setOpenPayPeriodDialog: (open: boolean) => void;
}) => {
  const queryClient = useQueryClient();
  const user: any = useSelector((state: RootState) => state?.getUser.user);
  const organizationId = user?.userOrganizations?.find(
    (item: any) => item.isCurrentLoggedInOrganization
  )?.organizationId;

  const {
    register,
    handleSubmit,
    reset,
    trigger,
    formState: { errors, isValid }
  } = useForm({ resolver: yupResolver(payPeriodSchema), mode: "onChange" });

  useEffect(() => {
    if (!payPeriod) return;
    reset({
      dayOfTheMonth: payPeriod.dayOfTheMonth ? String(payPeriod.dayOfTheMonth) : "",
      startDate: toFormDate(payPeriod.startDate),
      endDate: toFormDate(payPeriod.endDate),
      deadLine: toFormDate(payPeriod.deadLine)
    });
    trigger();
  }, [payPeriod, reset, trigger]);

  const mutation = useMutation({
    mutationFn: (data: any) =>
      updatePayPeriod(payPeriod!.id, {
        dayOfTheMont: Number(data.dayOfTheMonth),
        startDate: toUtcDate(data.startDate),
        endDate: toUtcDate(data.endDate),
        deadLine: toUtcDate(data.deadLine),
        organizationId
      }),
    onSuccess: (response: any) => {
      toast.success(
        response?.data?.data?.message || "Pay period updated successfully"
      );
      queryClient.invalidateQueries();
      setOpenPayPeriodDialog(false);
    },
    onError: (error: any) => {
      toast.error(getApiErrorMessage(error, "Error updating pay period."));
    }
  });

  const onHandlerSubmit = (data: any) => {
    if (payPeriod) mutation.mutate(data);
  };

  return (
    <section>
      <div>
        <div>
          <h1 className="text-[40px] text-primary leading-[52px] font-semibold">
            Pay Period
          </h1>
          <p className="text-sm text-[#757575] mb-[24px]">
            Update your pay-period.
          </p>
        </div>

        <form
          onSubmit={handleSubmit(onHandlerSubmit)}
          className="bg-white border border-[#D9D9D9] p-6 rounded-lg mb-4"
        >
          <span className="text-secondary pb-2 border-b-[1.5px] border-b-secondary font-bold ">
            Pay Payperiod
          </span>

          <div className="space-y-6 mt-8">
            <div>
              <label
                htmlFor="dayOfMonth"
                className="block mb-2 text-sm font-bold text-[#1E1E1E]"
              >
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span>Day of the month</span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>
                      Select the day employees should receive their salary each
                      month.
                    </p>
                  </TooltipContent>
                </Tooltip>
              </label>

              <p className="text-sm text-[#63666A] mb-1">
                This is the day of the month you would like your employees to be
                paid.
              </p>
              <input
                id="dayOfMonth"
                type="number"
                {...register("dayOfTheMonth")}
                className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                placeholder="26"
                maxLength={2}
                required
              />
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors.dayOfTheMonth?.message}
              </p>
            </div>

            <div>
              <label
                htmlFor="startDate"
                className="block mb-2 text-sm font-bold text-[#1E1E1E]"
              >
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span>Start date</span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Enter the date when this payroll cycle begins.</p>
                  </TooltipContent>
                </Tooltip>
              </label>
              <p className="text-sm text-[#63666A] mb-1">Payroll start date</p>
              <input
                id="startDate"
                type="date"
                {...register("startDate")}
                className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                required
              />
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors.startDate?.message}
              </p>
            </div>

            <div>
              <label
                htmlFor="deadlineToRunPayroll"
                className="block mb-2 text-sm font-bold text-[#1E1E1E]"
              >
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span>Deadline to run payroll</span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>
                      Specify how many days before payday payroll must be
                      processed.
                    </p>
                  </TooltipContent>
                </Tooltip>
              </label>
              <p className="text-sm text-[#63666A] mb-1">
                The number of days before the pay date by which payroll must be
                processed.
              </p>
              <input
                id="deadlineToRunPayroll"
                type="date"
                {...register("deadLine")}
                className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                required
              />
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors.deadLine?.message}
              </p>
            </div>

            <div>
              <label
                htmlFor="endDate"
                className="block mb-2 text-sm font-bold text-[#1E1E1E]"
              >
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span>End date</span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Enter the date when this payroll cycle ends.</p>
                  </TooltipContent>
                </Tooltip>
              </label>
              <p className="text-sm text-[#63666A] mb-1">Payroll end date</p>
              <input
                id="endDate"
                type="date"
                {...register("endDate", { onChange: () => trigger("deadLine") })}
                className="bg-gray-50 border border-gray-300 py-[11px] px-[16px] text-gray-900 text-sm rounded-lg w-full"
                required
              />
              <p className="text-red-400 mt-1 text-xs lg:text-sm" role="alert">
                {errors.endDate?.message}
              </p>
            </div>

            <div className="flex justify-end">
              <CustomButton
                type="submit"
                disabled={mutation.isPending || !isValid || !payPeriod}
                className={`disabled:bg-secondary disabled:bg-opacity-60 text-white text-sm bg-secondary py-2.5 px-12`}
              >
                {mutation.isPending ? "Updating..." : "Update Payperiod"}
              </CustomButton>
            </div>
          </div>
        </form>
      </div>
    </section>
  );
};

export default PayperiodDialog;
