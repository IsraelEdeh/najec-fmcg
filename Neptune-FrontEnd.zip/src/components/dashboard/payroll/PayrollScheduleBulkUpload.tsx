import React, { useState } from "react";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";

import { MdInfoOutline } from "react-icons/md";
import { toast } from "react-toastify";
import ApiFetcher from "@/components/Utils/api";
import { Button } from "@/components/ui/button";

const PayrollScheduleBulkUpload = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [selectedFile, setSelectedFile] = useState(null);

  const handleFileChange = (event: any) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleUpload = async () => {
    try {
      if (!selectedFile) {
        return;
      }

      const formData = new FormData();
      formData.append("PayrollSchedule", selectedFile);
      formData.append("File", selectedFile);
      const response = await ApiFetcher.post(
        "/payroll/upload-payroll-schedule",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data"
          }
        }
      );

      toast.success("File uploaded successfully!");
      setIsModalOpen(false);

      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error uploading file";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  return (
    <>
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogTrigger asChild>
          <Button className="w-full mt-4 bg-[#005587] text-white hover:bg-[#357aa2]">
            Upload payroll schedule
          </Button>
        </DialogTrigger>

        <DialogContent className=" bg-white transform -translate-x-1/2 -translate-y-1/2 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="mb-6">Payroll Schedule Upload</DialogTitle>
            <DialogDescription>
              <div className="flex items-start space-x-3">
                <MdInfoOutline className="w-5 h-5" />
                <div>
                  <p className="font-semibold">Add Employees in Bulk</p>
                  <p className="mt-1">
                    Upload pay schedule and generate summary for payroll
                    schedule
                  </p>
                </div>
              </div>
            </DialogDescription>
          </DialogHeader>

          <div className="border-2 border-gray-300 rounded-[4px] p-10 text-center cursor-pointer">
            <input type="file" onChange={handleFileChange} />
          </div>

          <div className="mt-6 flex justify-end">
            <Button
              variant="outline"
              className="mr-2 bg-white rounded-[4px] border border-primary text-sm  hover:text-white hover:bg-red-600"
              onClick={() => setIsModalOpen(false)}
            >
              Cancel
            </Button>
            <Button className="rounded-[4px] text-white" onClick={handleUpload}>
              Proceed
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default PayrollScheduleBulkUpload;
