import { Calendar } from "@/components/ui/calendar";
import React, { useState } from "react";
import { FaXmark } from "react-icons/fa6";
import CustomButton from "@/components/Elements/CustomButton";
import Link from "next/link";

const PayrollScheduleSidebar = ({
  closeRightSidebar,
  setCloseRightSidebar
}: {
  closeRightSidebar: boolean;
  setCloseRightSidebar: any;
}) => {
  const [date, setDate] = useState<Date | undefined>(new Date());

  return (
    <aside className="fixed top-0 right-0 hidden h-screen w-[290px] overflow-x-hidden overflow-y-auto border-l bg-[#ffffff] px-[16px] pb-20 pt-[100px] lg:block">
      <div>
        <div>
          <FaXmark
            className="w-[20px] h-[20px] cursor-pointer"
            onClick={() => setCloseRightSidebar(true)}
          />
        </div>

        <div className="mt-[36px]">
          <h2 className="text-sm text-[#1E1E1E] font-bold mb-[16px]">
            Your payroll schedule
          </h2>
          <p className="text-sm text-[#1E1E1E]">
            Update your pay schedule if this has changed.
          </p>

          <div className="mt-[16px] text-sm">
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              className="rounded-md border w-fit text-secondary"
            />
          </div>

          {/* <Link href="/dashboard/payroll/run">
            <CustomButton
              className="w-full py-[9px] rounded-[4px] mt-4 text-sm"
              classType="primary"
            >
              Update Payroll Schedule
            </CustomButton>
          </Link> */}
        </div>
      </div>
    </aside>
  );
};

export default PayrollScheduleSidebar;
