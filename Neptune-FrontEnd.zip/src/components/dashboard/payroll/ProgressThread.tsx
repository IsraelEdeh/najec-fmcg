"use client";
import { RootState } from "@/app/store";
import ApiFetcher from "@/components/Utils/api";
import { useQuery } from "@tanstack/react-query";
import React, { useState } from "react";
import { useSelector } from "react-redux";

const ProgressThread = () => {
  const [objectThread, setObjectThread] = useState({
    isWorkCalendarCreated: false,
    isDepartmentCreated: false,
    payPeriodCreated: false,
    payrollScheduleUploaded: false,
    taxComplianceCompleted: false,
    payrollRun: false,
    isPayrollApproved: false
  });
  const user: any = useSelector((state: RootState) => state?.getUser?.user);
  const organizationId = user?.userOrganizations?.find(
    (item: any) => item.isCurrentLoggedInOrganization
  )?.organizationId;

  const getPayrollSummary = async () => {
    try {
      const response = await ApiFetcher.get(
        "/payroll/get-payroll-schedule-summary"
        // "/payroll/get-current-payroll"
      );

      console.log("use::", response);

      return response;
    } catch (error: any) {
      const errorMessage = error?.response?.data?.message
        ? error?.response?.data?.message
        : "Error fetching payroll summary";
      console.log(errorMessage);
      // toast.error(errorMessage);
    }
  };

  const {
    data: payrollSummary,
    isPending,
    isLoading,
    error
  } = useQuery({
    queryKey: ["fetchPayrollSummary"],
    queryFn: getPayrollSummary
  });

  const id = payrollSummary?.data?.data?.payPeriodId;
  console.log("id for me::", id);

  const getPayrollThread = async (id: any) => {
    // console.log("wahal", id);
    if (!id) return;

    try {
      const response = await ApiFetcher.get(
        `/payroll/payroll-process-thread?payPeriodId=${id}`
      );

      console.log("thread response::", response);
      const threadData = response?.data?.data;

      setObjectThread({
        isWorkCalendarCreated: threadData?.isWorkCalendarCreated,
        isDepartmentCreated: threadData?.isDepartmentCreated,
        payPeriodCreated: threadData?.isPayPeriodCreated,
        payrollScheduleUploaded: threadData?.isPayrollScheduleUploaded,
        taxComplianceCompleted: threadData?.isTaxComplianceCompleted,
        payrollRun: threadData?.isPayrollRun,
        isPayrollApproved: threadData?.isPayrollApproved
      });

      return response;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error getting thread";
      console.error(errorMessage);

      setObjectThread({
        isWorkCalendarCreated: false,
        isDepartmentCreated: false,
        payPeriodCreated: false,
        payrollScheduleUploaded: false,
        taxComplianceCompleted: false,
        payrollRun: false,
        isPayrollApproved: false
      });
    }
  };

  const {
    data: payrollThreadData,
    isPending: isLoadingThread,
    isError
  } = useQuery({
    queryKey: ["getPayrollThread", id],
    queryFn: () => getPayrollThread(id)
  });

  console.log("thread check::", payrollThreadData);

  const steps = [
    // {
    //   label: "1",
    //   description: "Set calendar configuration",
    //   completed: objectThread?.isWorkCalendarCreated
    // },
    // {
    //   label: "2",
    //   description: "Create department",
    //   completed: objectThread?.isDepartmentCreated
    // },
    // {
    //   label: "3",
    //   description: "Payperiod created",
    //   completed: objectThread?.payPeriodCreated
    // },
    // {
    //   label: "4",
    //   description: "Pay components created",
    //   completed: objectThread?.taxComplianceCompleted
    // },
    {
      label: "1",
      description: "Payroll schedule uploaded",
      completed: objectThread?.payrollScheduleUploaded
    },
    {
      label: "2",
      description: "Payroll run",
      completed: objectThread?.payrollRun
    },
    {
      label: "3",
      description: "Payroll approved",
      completed: objectThread?.isPayrollApproved
    }
  ];

  return (
    <section className="bg-white rounded-[12px] p-3 ">
      <div className="flex items-center py-5">
        {steps.map((step, index) => (
          <div key={index} className="flex items-center relative">
            <div
              className={`z-20 w-7 h-7 flex items-center justify-center rounded-full text-white  ${
                step.completed ? "bg-secondary" : "bg-gray-300"
              }`}
            >
              <p className="text-sm">&#10003;</p>
            </div>
            <div className="ml-3">
              <div className="hidden font-bold">{step.label}</div>
              <div className="xl:pb-10 text-xs text-primary w-[200px] text-wrap">
                {step.description}
              </div>
            </div>
            {index < steps.length - 1 && (
              <div
                className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full h-0.5 ${
                  step.completed ? "bg-secondary" : "bg-gray-300"
                }`}
              ></div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
};

export default ProgressThread;
