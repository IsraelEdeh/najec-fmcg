"use client";

import React, { useState } from "react";
import { FaXmark } from "react-icons/fa6";
import CustomButton from "@/components/Elements/CustomButton";
import Image from "next/image";
import ApiFetcher from "@/components/Utils/api";
import { toast } from "react-toastify";
import { sanitizeFilename } from "@/lib/helpers";

const RunPayrollSidebar = ({
  closeRightSidebar,
  setCloseRightSidebar
}: {
  closeRightSidebar: boolean;
  setCloseRightSidebar: any;
}) => {
  const [loading, setLoading] = useState(false);

  const handleTemplateDownload = async () => {
    try {
      setLoading(true);
      const response = await ApiFetcher.get("/tax/download-schedule-template", {
        responseType: "blob"
      });

      const blob = new Blob([response.data], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      const fileName = sanitizeFilename("payroll-schedule-template") + ".xlsx";
      
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success("Template downloaded successfully");
    } catch (error: any) {
      const errorMessage =
        error?.response?.data?.message || "Error downloading template";
      console.error(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };
  return (
    <aside>
      <div className="fixed right-0 top-0 hidden h-screen w-[310px] overflow-x-hidden overflow-y-auto bg-white px-2 pb-10 lg:block">
        <div className="pt-[100px] text-sm">
          <FaXmark
            className="w-[20px] h-[20px] cur cursor-pointer mb-10"
            onClick={() => setCloseRightSidebar(true)}
          />

          <h2 className="font-bold mb-4">Payroll schedule template</h2>
          <p>Please download the payroll template before uploading your completed file.</p>

          <Image
            className="my-6"
            src="/dashboard/filing.png"
            alt="filing"
            width={272}
            height={227}
          />

          <CustomButton
            className="disabled:bg-secondary text-sm disabled:bg-opacity-65 w-full py-[9px] rounded-[4px] mt-4"
            classType="primary"
            onClick={handleTemplateDownload}
            disabled={loading}
          >
            {loading ? "Downloading ..." : "Download Template"}
          </CustomButton>
        </div>
      </div>
    </aside>
  );
};

export default RunPayrollSidebar;
