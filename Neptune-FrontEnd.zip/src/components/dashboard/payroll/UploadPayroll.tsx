"use client";

import React, { useState } from "react";
import { IoWarningOutline } from "react-icons/io5";
import { toast } from "react-toastify";
import ApiFetcher from "@/components/Utils/api";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { savePayrollScheduleFile } from "@/lib/payroll-api";
import type { Id } from "@/types/payroll";

const UploadPayroll = ({
  payPeriodId,
  payrollSummary,
  threadData,
  setCurrentStep,
  currentStep
}: {
  payPeriodId?: Id;
  payrollSummary: any;
  threadData: any;
  setCurrentStep: any;
  currentStep: number;
}) => {
  const queryClient = useQueryClient();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleFileChange = (event: any) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleUpload = async () => {
    try {
      if (!selectedFile) {
        return;
      }

      const response = await savePayrollScheduleFile(selectedFile, payPeriodId, "upload");

      toast.success("File uploaded successfully!");
      setCurrentStep(currentStep + 1);

      return response;
    } catch (error: any) {
      const errorMessages = error.response.data.errors || [
        "Error uploading file"
      ];

      errorMessages.forEach((errorMessage: string) => {
        toast.error(errorMessage);
      });
    }
  };

  const handleUpdate = async () => {
    try {
      if (!selectedFile) {
        return;
      }

      const response = await savePayrollScheduleFile(selectedFile, payPeriodId, "update");

      toast.success("File uploaded successfully!");
      setCurrentStep(currentStep + 1);
      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error uploading file";
      console.log(error);
      toast.error(errorMessage);
    }
  };

  const uploadPayrollMutation = useMutation({
    mutationFn: handleUpload,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  const onHandlerUploadPayroll = () => {
    try {
      uploadPayrollMutation.mutateAsync();
    } catch (error: any) {
      console.log("aca", error);
      const errorMessages = error.response.data.errors || [
        "Error uploading file"
      ];

      errorMessages.forEach((errorMessage: string) => {
        toast.error(errorMessage);
      });
    }
  };

  const onHandlerUpdatePayroll = () => {
    try {
      updatePayrollMutation.mutateAsync();
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error adding department.";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const updatePayrollMutation = useMutation({
    mutationFn: handleUpdate,
    onSuccess: () => {
      queryClient.invalidateQueries();
    }
  });

  return (
    <section className="">
      <div className="flex space-x-4 text-white bg-primary p-6 rounded-[8px] ">
        <div>
          <IoWarningOutline className="text-white w-6 h-6" />
        </div>

        <div>
          <h3 className="font-semibold">How payrun works?</h3>
          <ul className="space-y-1">
            <li>
              1. Complete{" "}
              <Link
                className="underline underline-offset-4 hover:no-underline text-secondary"
                href="/dashboard/organization"
              >
                organisation set up
              </Link>
            </li>
            <li>
              2. Create{" "}
              <Link
                className="underline underline-offset-4 hover:no-underline text-secondary"
                href="/dashboard/payroll/settings"
              >
                pay period
              </Link>{" "}
              for your payroll
            </li>
            <li>
              3. Setup{" "}
              <Link
                className="underline underline-offset-4 hover:no-underline text-secondary"
                href="/dashboard/payroll/taxes"
              >
                allowances and deductions
              </Link>{" "}
              before downloading payschedule template
            </li>
            <li>4. Download payschedule template</li>
            <li>
              5.{" "}
              <Link
                className="underline underline-offset-4 hover:no-underline text-secondary"
                href="/dashboard/payroll/payroll-schedule"
              >
                Download template and upload payroll schedule
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="hidden">
        {threadData?.isPayrollScheduleUploaded ? (
          <div className="mt-6">
            <div className="border-2 border-gray-300 rounded-[4px] p-10 text-center cursor-pointer">
              <input type="file" onChange={handleFileChange} />
            </div>

            <div className="flex justify-end mt-4">
              <Button className="text-white" onClick={onHandlerUpdatePayroll}>
                {updatePayrollMutation.isPending
                  ? "Updating . . ."
                  : "Update payroll schedule"}
              </Button>
            </div>
          </div>
        ) : (
          <div className="mt-6">
            <div className="border-2 border-gray-300 rounded-[4px] p-10 text-center cursor-pointer">
              <input type="file" onChange={handleFileChange} />
            </div>

            <div className="flex justify-end mt-4">
              <Button className="text-white" onClick={onHandlerUploadPayroll}>
                {uploadPayrollMutation.isPending
                  ? "Uploading . . ."
                  : "Upload payroll schedule"}
              </Button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default UploadPayroll;
