"use client";
import React, { useState } from "react";
import { useSelector } from "react-redux";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail
} from "@/components/ui/sidebar";
import Link from "next/link";
import { DashboardLeftsidebarLinks } from "@/constants";
import { RootState } from "@/app/store";

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const pathname = usePathname();
  const [activeSubMenu, setActiveSubMenu] = useState<string | null>(null);
  const user: any = useSelector((state: RootState) => state?.getUser?.user);

  // Extract active organization
  const activeOrganization = user?.userOrganizations?.find(
    (org: any) => org.isCurrentLoggedInOrganization
  );

  // Determine the highest ranked role
  // const highestRankedRole = activeOrganization?.role?.reduce((prev: any, current: any) => {
  //   return prev.rank > current.rank ? prev : current;
  // });
  const highestRankedRole = activeOrganization?.role?.reduce(
    (prev: any, current: any) => {
      return prev.rank > current.rank ? prev : current;
    },
    { rank: 8 }
  );

  const userRoles = user?.roles?.map((role: any) => role?.role);
  // console.log("highest ranked role", highestRankedRole);
  const toggleSubMenu = (label: string) => {
    setActiveSubMenu(activeSubMenu === label ? null : label);
  };

  const labelsToHide = ["Organization", "Employees", "Access Management"];
  const rolesToHideFor = ["Initiator", "Approver", "Authorizer", "Employee"];

  const AdminLabelsToShow = [
    "User Management",
    "Organization",
    "Employees",
    "Payroll",
    "Report",
    "Home"
  ];
  const ApproverLabelsToShow = ["Payroll", "Report", "Home"];
  const InitiatorLabelsToShow = ["Employees", "Payroll", "Home"];
  const ReviewerLabelsToShow = ["Payroll", "Report", "Home", "User Management"];
  const EmployeesLabelsToShow = ["Home"];

  const getLabelsToShow = (role: string) => {
    switch (role) {
      case "Admin":
        return AdminLabelsToShow;
      case "Approver":
        return ApproverLabelsToShow;
      case "Initiator":
        return InitiatorLabelsToShow;
      case "Reviewer":
        return ReviewerLabelsToShow;
      case "Employee":
        return EmployeesLabelsToShow;
      default:
        return AdminLabelsToShow;
    }
  };

  const roleLabelsMap: Record<string, string[]> = {
    Admin: [
      "User Management",
      "Organization",
      "Employees",
      "Payroll",
      "Report",
      "Home"
    ],
    Approver: ["Payroll", "Report", "Home", "Organization"],
    Initiator: ["Employees", "Payroll", "Home", "Organization"],
    Reviewer: ["Payroll", "Report", "Home", "Organization"],
    Employee: ["Home"]
  };

  const activeRole = user?.userOrganizations
    ?.find((org: any) => org.isCurrentLoggedInOrganization)
    ?.role?.map((role: any) => role?.role);

  const activeUserRoles =
    activeOrganization?.role?.map((role: any) => role?.role) || [];

  const allowedLabels = Array.from(
    new Set(
      activeUserRoles.flatMap((role: string) => roleLabelsMap[role] || [])
    )
  );

  const filteredSidebarLinks = DashboardLeftsidebarLinks?.filter((item: any) =>
    allowedLabels.includes(item.label)
  );

  const filterSubLinks = (subLinks: any[]) =>
    subLinks?.filter((subItem: any) => allowedLabels.includes(subItem.label));

  return (
    <Sidebar
      collapsible="icon"
      {...props}
      className="border-none bg-white py-4"
    >
      <SidebarContent className="pt-20">
        <SidebarGroup>
          <SidebarMenu>
            <SidebarMenuItem className="space-y-4">
              {filteredSidebarLinks?.map((Item: any) => {
                const isActive =
                  pathname === Item.route || pathname.includes(Item.name);
                const hasSubLinks = Item.subLinks && Item.subLinks.length > 0;
                const shouldHideLabel =
                  userRoles?.some((role: any) =>
                    rolesToHideFor?.some((hideRole) => role?.includes(hideRole))
                  ) && labelsToHide.includes(Item.label);

                // Check if the user has the highest ranked role
                const hasHighestRankedRole = userRoles?.includes(
                  highestRankedRole?.role
                );

                const labelsToShow = getLabelsToShow(
                  activeRole.includes("Admin") || ""
                );

                // if (hasHighestRankedRole || userRoles?.includes("Admin")) {
                // if (hasHighestRankedRole || userRoles?.includes("Admin")) {
                //   return (
                //     <div key={Item.label}>
                //       <Link
                //         className={`${
                //           isActive
                //             ? "border-r-4 border-r-secondary rounded-r text-secondary"
                //             : ""
                //         } block`}
                //         href={Item.route}
                //         onClick={() => hasSubLinks && toggleSubMenu(Item.label)}
                //       >
                //         <SidebarMenuButton
                //           className={`${
                //             isActive
                //               ? "bg-white text-[#334]"
                //               : "null hover:scale-95"
                //           } `}
                //         >
                //           <Item.icons
                //             className={`${
                //               isActive ? "text-secondary" : "text-[#0A0A0A]"
                //             }  text-3xl`}
                //           />
                //           <span
                //             className={`${
                //               isActive
                //                 ? "font-medium text-secondary"
                //                 : "text-[#0A0A0A]"
                //             } text-base`}
                //           >
                //             {Item.label}
                //           </span>
                //         </SidebarMenuButton>
                //       </Link>
                //       {hasSubLinks && activeSubMenu === Item?.label && (
                //         <div className={`pl-8 space-y-3 mt-2`}>
                //           {Item.subLinks?.map((subItem: any) => {
                //             const subLinkIsActive = pathname === subItem?.route;
                //             return (
                //               <Link
                //                 key={subItem?.label}
                //                 href={subItem?.route}
                //                 className={cn(
                //                   `block text-sm  transition-all ease-in duration-300`,
                //                   {
                //                     "text-secondary": subLinkIsActive,
                //                     "text-primary": !subLinkIsActive
                //                   }
                //                 )}
                //               >
                //                 {subItem?.label}
                //               </Link>
                //             );
                //           })}
                //         </div>
                //       )}
                //     </div>
                //   );
                // }

                // If user is not Admin or doesn't have the highest ranked role, check if label should be hidden
                // if (shouldHideLabel) {
                //   return null;
                // }

                const filteredSubLinks = filterSubLinks(Item.subLinks);

                return (
                  <div key={Item.label}>
                    <Link
                      className={`${
                        isActive
                          ? "border-r-4 border-r-secondary rounded-r text-secondary"
                          : ""
                      } 
                      
                      block`}
                      href={Item.route}
                      onClick={() => hasSubLinks && toggleSubMenu(Item.label)}
                    >
                      <SidebarMenuButton
                        className={`${
                          isActive
                            ? "bg-white text-[#334]"
                            : "null hover:scale-95"
                        } `}
                      >
                        <Item.icons
                          className={`${
                            isActive ? "text-secondary" : "text-[#0A0A0A]"
                          }  text-3xl`}
                        />
                        <span
                          className={`${
                            isActive
                              ? "font-medium text-secondary"
                              : "text-[#0A0A0A]"
                          } text-base`}
                        >
                          {Item.label}
                        </span>
                      </SidebarMenuButton>
                    </Link>
                    {hasSubLinks && activeSubMenu === Item.label && (
                      <div className={`pl-8 space-y-3 mt-2`}>
                        {Item.subLinks?.map((subItem: any) => {
                          const subLinkIsActive = pathname === subItem.route;
                          return (
                            <Link
                              key={subItem.label}
                              href={subItem.route}
                              className={cn(
                                `block text-sm  transition-all ease-in duration-300`,
                                {
                                  "text-secondary": subLinkIsActive,
                                  "text-primary": !subLinkIsActive
                                }
                              )}
                            >
                              {subItem.label}
                            </Link>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter></SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}
