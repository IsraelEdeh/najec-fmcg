"use client";

import ApiFetcher from "@/components/Utils/api";
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import { toast } from "react-toastify";

export interface UserState {
  user: any;
  loading: boolean;
  error: string | null;
}

const initialState: UserState = {
  user: null,
  loading: false,
  error: null
};

export const fetchUserAsync = createAsyncThunk(
  "users/fetchUserAsync",
  async (_, { rejectWithValue }) => {
    try {
      const response = await ApiFetcher.get(
        `/auth/loggedin-user`
      );

      const payload = response?.data?.data;

      // console.log("Dcccb::", response);

      return payload;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error signing up.";
      console.log(errorMessage);
      toast.error(errorMessage);
      

      return rejectWithValue(error.message);
    }
  }
);

export const getUserSlice = createSlice({
  name: "getUser",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchUserAsync.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        fetchUserAsync.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.user = action.payload;
        }
      )
      .addCase(fetchUserAsync.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
        state.user = null;
      });
  }
});

export default getUserSlice.reducer;
