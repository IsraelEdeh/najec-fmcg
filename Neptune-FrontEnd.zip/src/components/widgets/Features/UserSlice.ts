/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import ApiFetcher from "@/components/Utils/api";
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import { toast } from "react-toastify";

interface User {
  uid: any;
}

interface IUSer {
  user: User | null;
  loading: boolean;
  error: string | null;
}

const initialState: IUSer = {
  user: null,
  loading: false,
  error: null
};

const fetchUserAsync = async () => {
  try {
    const response = await ApiFetcher.get(
      // `${process.env.NEXT_PUBLIC_BASE_URL}/auth/loggedin-user`
      `/auth/loggedin-user`
    );

    const payload = response.data;
    return payload;
  } catch (error: any) {
    console.log("error", error.message);
    toast.error(error.message);
  }
};

export const registerUserAsync = createAsyncThunk(
  "auth/registerUserAsync",
  async ({ email, password }: { email: string; password: string }) => {
    try {
      const response = await ApiFetcher.post("/auth/login", {
        email,
        password
      });

      if (response) {
        document.cookie = `jwt=${response.data.data.token}; path=/; Secure`;
        await fetchUserAsync();
      } else {
        toast.error("Login failed. Please check your credentials.");
      }

      toast.success(response?.data?.data?.message);

      return response;
    } catch (error: any) {
      const errorMessage = error.response.data.message
        ? error.response.data.message
        : "Error logging in";
      console.log(errorMessage);
      toast.error(errorMessage);

      return errorMessage;
    }
  }
);

export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    logOut: (state) => {
      state.user = null;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(registerUserAsync.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        registerUserAsync.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.user = action.payload;
        }
      )
      .addCase(registerUserAsync.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
        state.user = null;
      });
  }
});

export const { logOut } = userSlice.actions;
export default userSlice.reducer;
