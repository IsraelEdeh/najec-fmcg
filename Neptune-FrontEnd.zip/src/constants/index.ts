"use client";

import ApiFetcher from "@/components/Utils/api";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import {
  Home,
  Wallet,
  Building2 as Users,
  DollarSign,
  FileText,
  NotebookText,
  School
} from "lucide-react";
import React from "react";
import { toast } from "react-toastify";

export const DashboardLeftsidebarLinks = [
  {
    icon: React.createElement(Home, { size: 20 }),
    icons: Home,
    route: "/dashboard",
    label: "Home",
    name: "home"
  },
  {
    icon: React.createElement(School, { size: 20 }),
    icons: School,
    route: "/dashboard/organization",
    label: "Organization",
    name: "organization"
  },
  {
    icon: React.createElement(Users, { size: 20 }),
    icons: Users,
    route: "/dashboard/employees",
    label: "Employees",
    name: "employees"
    // subLinks: [
    //   {
    //     label: "Employee management",
    //     route: "/dashboard/employees/emanagement",
    //     icon: ""
    //   }
    // ]
  },
  {
    icon: React.createElement(DollarSign, { size: 20 }),
    icons: Wallet,
    route: "/dashboard/payroll",
    label: "Payroll",
    name: "payroll",
    subLinks: [
      {
        label: "Pay periods",
        route: "/dashboard/payroll/payperiod",
        icon: ""
      },
      {
        label: "Pay components",
        route: "/dashboard/payroll/taxes",
        icon: ""
      },
      {
        label: "Pay schedule",
        route: "/dashboard/payroll/payroll-schedule",
        icon: ""
      },
      {
        label: "Run payroll",
        route: "/dashboard/payroll/run",
        icon: ""
      },
      {
        label: "Off-cycle runs",
        route: "/dashboard/payroll/off-cycle",
        icon: ""
      },
      // {
      //   label: "Payroll setting",
      //   route: "/dashboard/payroll/settings",
      //   icon: ""
      // },
      {
        label: "Payroll history",
        route: "/dashboard/payroll/history",
        icon: ""
      }
    ]
  },
  {
    icon: React.createElement(FileText, { size: 20 }),
    icons: FileText,
    route: "/dashboard/report",
    label: "Report",
    name: "report"
  },
  {
    icon: React.createElement(NotebookText, { size: 20 }),
    icons: NotebookText,
    route: "/dashboard/access",
    label: "User Management",
    name: "user management"
  }
];

export interface ICountryDataResponse {
  id: number;
  name: string;
  countryCode: string;
  flag: string;
}

export interface ICountryData {
  message: string;
  errors: boolean;
  data: {
    status: boolean;
    data: ICountryDataResponse[];
    message: string;
  };
}

export interface IDepartmentSchema {
  name: string;
}

interface Department {
  id: number;
  name: string;
  isActive: boolean;
}

interface Country {
  id: number;
  name: string;
}

export interface IEmployeeData {
  id: string;
  firstName: string;
  middleName: string;
  lastName: string;
  email: string;
  phoneNumber: string | null;
  dateOfBirth: string | null;
  gender: string | number | null;
  address: string | null;
  state: string | null;
  staffNumber: string;
  jobTitle: string;
  department: Department | null;
  dateJoined: string | null;
  country: Country;
  taxAuthority: string;
  employmentType: string;
  rsaPin: string | null;
  accountName: string;
  accountNumber: string;
  bankName: string;
  pensionFundAdministrator: string;
  nhfNumber?: string;
  annualGrossSalary: any;
  employeeJobTitle?: { id: number; name: string };
  employeeGrade?: { id: number; name: string };
  costCenter?: { id: number; name: string };
  organizationSubsidiary?: { id: number; name: string };
  isActive?: boolean;
  isPensionExempt?: boolean;
  isDisengaged?: boolean;
  disengagementDate?: string | null;
  nhfExists?: any;
  nhisExists?: any;
  voluntaryPensionExists?: any;
}

export const getNeptuneBusinessCountries = async () => {
  try {
    const response = await axios.get(
      `${process.env.NEXT_PUBLIC_BASE_URL}/auth/countries`
    );

    return response;
  } catch (error: any) {
    const errorMessage = error.response.data.message
      ? error.response.data.message
      : "Error fetching country data";
    console.log(errorMessage);
    toast.error(errorMessage);
  }
};

export const fetchDeparments = async () => {
  try {
    const response = await ApiFetcher.get(
      "/departments/get-all-departments-in-an-organization?PageSize=100"
    );
    return response;
  } catch (error: any) {
    const errorMessage = error.response.data.message
      ? error.response.data.message
      : "Error fetching department";
    console.log(errorMessage);
    // toast.error(errorMessage);
  }
};

export const fetchJobTitles = async () => {
  try {
    const response = await ApiFetcher.get(
      "/employeejobtitles/get-all-employee-job-titles-in-an-organization?PageSize=100"
    );
    return response;
  } catch (error: any) {
    const errorMessage = error.response.data.message
      ? error.response.data.message
      : "Error fetching Job Titles";
    console.log(errorMessage);
    // toast.error(errorMessage);
  }
};

export const fetchEmployeesGrade = async () => {
  try {
    const response = await ApiFetcher.get(
      "/employeegrades/get-all-employee-grades-in-an-organization?PageSize=100"
    );
    return response;
  } catch (error: any) {
    const errorMessage = error.response.data.message
      ? error.response.data.message
      : "Error fetching Employee Grades";
    console.log(errorMessage);
    // toast.error(errorMessage);
  }
};

export const fetchCostCenter = async () => {
  try {
    const response = await ApiFetcher.get(
      "/costcenters/get-all-costcenters-in-an-organization?PageSize=100"
    );
    return response;
  } catch (error: any) {
    const errorMessage = error.response.data.message
      ? error.response.data.message
      : "Error fetching Employee Grades";
    console.log(errorMessage);
    // toast.error(errorMessage);
  }
};

export const fetchSubsidiaries = async () => {
  try {
    const response = await ApiFetcher.get(
      "/organizationsubsidiaries/get-all-organizationsubsidiaries-in-an-organization?PageSize=100"
    );
    return response;
  } catch (error: any) {
    const errorMessage = error.response.data.message
      ? error.response.data.message
      : "Error fetching Employee Grades";
    console.log(errorMessage);
    // toast.error(errorMessage);
  }
};

export function formatDate2(date: Date | null | undefined) {
  if (!date || Number.isNaN(date.getTime()) || date.getUTCFullYear() <= 1) return "-";
  const days = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ];
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];

  const dayOfWeek = days[date.getUTCDay()];
  const day = date.getUTCDate();
  const month = months[date.getUTCMonth()];
  const year = date.getUTCFullYear();

  return `${dayOfWeek}, ${day} ${month} ${year}`;
}

export interface Allowance {
  name: string;
  active: boolean;
  taxRelief: string;
  taxReliefType: string;
  payPeriod: string;
  isNew?: boolean;
  isSaved?: boolean;
}

export type Employee = {
  id: string;
  firstName: string;
  middleName: string | null;
  lastName: string;
  email: string;
  phoneNumber: string | null;
  dateOfBirth: string | null;
  gender: string | number | null;
  address: string | null;
  state: string | null;
  staffNumber: string | null;
  jobTitle: string | null;
  department: {
    id: number;
    name: string;
    isActive: boolean;
  } | null;
  dateJoined: string | null;
  country: {
    id: number;
    name: string;
  };
  taxAuthority: string | null;
  employmentType: string | null;
  pensionPin: string | null;
};

export interface IEmployee {
  id: string;
  firstName: string;
  middleName: string | null;
  lastName: string;
  email: string;
  phoneNumber: string | null;
  dateOfBirth: string | null;
  gender: string | number | null;
  address: string | null;
  state: string | null;
  staffNumber: string | null;
  jobTitle: string | null;
  department: {
    id: number;
    name: string;
    isActive: boolean;
  } | null;
  dateJoined: string | null;
  country: {
    id: number;
    name: string;
  };
  taxAuthority: string | null;
  employmentType: string | null;
  pensionPin: string | null;
}

export const pfas = [
  "Access Pensions Limited",
  "Crusader Sterling Pensions Limited",
  "Fidelity Pension Managers Limited",
  "FCMB Pensions Limited",
  "Guaranty Trust Pension Managers Limited",
  "Nigerian University Pension Management Company (NUPEMCO)",
  "NLPC Pension Fund Administrators Limited",
  "NPF Pensions Fund Administrators Limited",
  "Pensions Alliance Limited",
  "Radix Pension Managers Limited",
  "Stanbic IBTC Pension Managers Limited",
  "Tangerine APT Pensions Limited",
  "Trustfund Pensions Limited",
  "Veritas Glanvills Pensions Limited",
  "Citizens Pensions Limited",
  "CardinalStone Pensions Limited",
  "Leadway Pensure PFA Limited",
  "Oak Pensions Limited"
];

export const slugify = (text: string) => {
  return text?.toLowerCase();
  // .replace(/ /g, "-")
  // .replace(/[^\w-]+/g, "");
};

export const countryCodeToFlag: any = {
  "+234": "NG",
  "+233": "GH",
  default: "ZA"
};

export const convertFileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      if (typeof reader.result === "string") {
        resolve(reader.result);
      } else {
        reject(new Error("Failed to convert file to base64"));
      }
    };
    reader.onerror = (error) => reject(error);
  });
};

export function formatForNaira(price: any) {
  const value = Number(price);
  if (price === null || price === undefined || price === "" || !Number.isFinite(value)) return "0";
  return new Intl.NumberFormat("en-US").format(value);
}

export const msalConfig: any = {
  auth: {
    clientId: "11111111-1111-1111-111111111111",
    authority: "https://login.live.com",
    knownAuthorities: ["login.live.com"]
  }
};

export const getThread = async (id: string | number, payrollId?: number | string) => {
  if (!id) return;

  try {
    const response = await ApiFetcher.get(
      `/payroll/payroll-process-thread?payPeriodId=${id}${
        payrollId !== undefined && payrollId !== ""
          ? `&payrollId=${encodeURIComponent(String(payrollId))}`
          : ""
      }`
    );

    return response?.data?.data;
  } catch (error: any) {
    const errorMessage = error.response.data.message
      ? error.response.data.message
      : "Error fetching data.";
    console.log(errorMessage);
    // toast.error(errorMessage);
  }
};

export const getOrganizationDetails = async (id: any) => {
  if (!id) return;
  try {
    const response = await ApiFetcher.get(
      `organization/get-organization-by-id/${id}`
    );

    console.log("org details:::", response);

    return response?.data?.data[0];
  } catch (error: any) {
    const errorMessage = error.response.data.message
      ? error.response.data.message
      : "Error fetching organization profile data";
    console.log(errorMessage);
    toast.error(errorMessage);
  }
};