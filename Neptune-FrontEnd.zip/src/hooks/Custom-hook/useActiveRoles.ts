"use client";

import { useSelector } from "react-redux";
import type { RootState } from "@/app/store";

type UserOrganization = {
  isCurrentLoggedInOrganization?: boolean;
  role?: { role?: string }[];
};

const useActiveRoles = () => {
  const user = useSelector((state: RootState) => state?.getUser?.user) as
    | { userOrganizations?: UserOrganization[] }
    | undefined;

  const roles =
    user?.userOrganizations
      ?.find((organization) => organization.isCurrentLoggedInOrganization)
      ?.role?.map((item) => item?.role ?? "")
      .filter(Boolean) ?? [];

  const isAdmin = roles.includes("Admin");
  const isInitiator = roles.includes("Initiator");
  const isReviewer = roles.includes("Reviewer");
  const isApprover = roles.includes("Approver");

  return {
    roles,
    isAdmin,
    isInitiator,
    isReviewer,
    isApprover,
    canManagePayrollRuns: isAdmin || isInitiator
  };
};

export default useActiveRoles;
