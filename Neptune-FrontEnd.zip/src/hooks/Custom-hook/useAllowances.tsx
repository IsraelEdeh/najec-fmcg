"use client";

import ApiFetcher from "@/components/Utils/api";
import { useQuery } from "@tanstack/react-query";
import { toast } from "react-toastify";

const useAllowances = () => {
  const getAllAllowances = async () => {
    try {
      const response = await ApiFetcher.get(
        // "/tax/pay-components?PageSize=1000"
        "/tax/get-all-allowance-components"
      );

      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error getting allowances";
      console.error(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: allowances,
    isPending: loadingAllowances,
    isError: getAllowanceError
  } = useQuery({
    queryKey: ["getAllAllowances"],
    queryFn: getAllAllowances
  });

  return { allowances, loadingAllowances, getAllowanceError };
};

export default useAllowances;
