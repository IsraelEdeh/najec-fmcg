"use client";

import ApiFetcher from "@/components/Utils/api";
import { useQuery } from "@tanstack/react-query";
import { toast } from "react-toastify";

const useBank = () => {
  const getAllBanks = async () => {
    try {
      const response = await ApiFetcher.get(`/systeminfo/get-all-banks?PageSize=100`);

      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error getting banks";
      console.log(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: banks,
    isPending: loadingBanks,
    isError: bankError
  } = useQuery({
    queryKey: ["getAllBanks"],
    queryFn: getAllBanks
  });

  return { banks, loadingBanks, bankError };
};

export default useBank;
