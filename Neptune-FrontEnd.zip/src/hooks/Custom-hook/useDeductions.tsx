"use client";

import ApiFetcher from "@/components/Utils/api";
import { useQuery } from "@tanstack/react-query";
import { toast } from "react-toastify";

const useDeductions = () => {
  const getAllDeductions = async () => {
    try {
      const response = await ApiFetcher.get(
        "/tax/get-all-deduction-components"
      );

      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error getting deductions";
      console.error(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: deductions,
    isPending: loadingDeductions,
    isError: getDeductionError
  } = useQuery({
    queryKey: ["getAllDeductions"],
    queryFn: getAllDeductions
  });

  return { deductions, loadingDeductions, getDeductionError };
};

export default useDeductions;
