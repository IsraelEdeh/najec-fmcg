"use client";
import { useMsal } from "@azure/msal-react";
import React from "react";

const useMsalAuth = () => {
  const { instance } = useMsal();

  return {
    instance
  };
};

export default useMsalAuth;
