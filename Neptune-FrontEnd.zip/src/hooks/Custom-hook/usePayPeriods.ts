"use client";

import { useQuery } from "@tanstack/react-query";
import {
  PAY_PERIODS_QUERY_KEY,
  findPeriodContainingToday,
  getAllPayPeriods,
  openPeriodsNewestFirst
} from "@/lib/payroll-api";

const usePayPeriods = () => {
  const { data: periods = [], isPending, isError } = useQuery({
    queryKey: PAY_PERIODS_QUERY_KEY,
    queryFn: getAllPayPeriods
  });

  const openPeriods = openPeriodsNewestFirst(periods);
  const currentPeriod = findPeriodContainingToday(periods);

  return { periods, openPeriods, currentPeriod, isLoading: isPending, isError };
};

export default usePayPeriods;
