"use client";

import ApiFetcher from "@/components/Utils/api";
import { useQuery } from "@tanstack/react-query";
import { toast } from "react-toastify";

const useReliefs = () => {
  const getAllReliefs = async () => {
    try {
      const response = await ApiFetcher.get("/tax/get-all-relief-components");

      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error getting relief";
      console.error(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: reliefs,
    isPending: loadingReliefs,
    isError: getReliefError
  } = useQuery({
    queryKey: ["getAllReliefs"],
    queryFn: getAllReliefs
  });

  return { reliefs, loadingReliefs, getReliefError };
};

export default useReliefs;
