"use client";

import ApiFetcher from "@/components/Utils/api";
import { useQuery } from "@tanstack/react-query";
import { toast } from "react-toastify";

const useStates = () => {
  const getAllStates = async () => {
    try {
      const response = await ApiFetcher.get("/systeminfo/get-all-states?PageSize=100");

      return response?.data?.data;
    } catch (error: any) {
      const errorMessage = error.response?.data?.message
        ? error.response.data.message
        : "Error getting states";
      console.error(errorMessage);
      toast.error(errorMessage);
    }
  };

  const {
    data: states,
    isPending: loadingStates,
    isError: statesError
  } = useQuery({
    queryKey: ["getAllStates"],
    queryFn: getAllStates
  });

  return { states, loadingStates, statesError };
};

export default useStates;
