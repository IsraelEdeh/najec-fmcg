"use client";
import React from "react";
import { PublicClientApplication, EventType } from "@azure/msal-browser";
import { MsalProvider } from "@azure/msal-react";
import { LogLevel } from "@azure/msal-browser";

const clientID = process.env.NEXT_PUBLIC_CLIENTID;
const tenantID = process.env.NEXT_PUBLIC_TENANTID;
const redirectURL = process.env.NEXT_PUBLIC_REDIRECTURL;

export const msalInstance = new PublicClientApplication({
  auth: {
    clientId: `${clientID}`,
    authority: `https://login.microsoftonline.com/${tenantID}`,
    redirectUri: `${redirectURL}`,
    postLogoutRedirectUri: "/",
    navigateToLoginRequestUrl: false
  },
  cache: {
    cacheLocation: "sessionStorage",
    storeAuthStateInCookie: false
  },
  system: {
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) return;
        switch (level) {
          case LogLevel.Error:
            console.error(message);
            return;
          case LogLevel.Info:
            console.info(message);
            return;
          case LogLevel.Verbose:
            console.debug(message);
            return;
          case LogLevel.Warning:
            console.warn(message);
            return;
          default:
            return;
        }
      }
    }
  }
});

const MsalProviderContainer = ({ children }: { children: React.ReactNode }) => {
  if (
    !msalInstance.getActiveAccount() &&
    msalInstance.getAllAccounts().length > 0
  ) {
    msalInstance.setActiveAccount(msalInstance.getAllAccounts()[0]);
  }

  msalInstance.addEventCallback((event: any) => {
    if (event.eventType === EventType.LOGIN_SUCCESS && event.payload.account) {
      msalInstance.setActiveAccount(event.payload.account);
    }
  });
  return <MsalProvider instance={msalInstance}>{children}</MsalProvider>;
};

export default MsalProviderContainer;