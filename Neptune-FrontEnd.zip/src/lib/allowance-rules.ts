// Business rules shared by Create and Update Allowance so both forms validate identically.
export interface AllowanceRuleInput {
  name: string;
  isTaxable: boolean;
  isGrossUp: boolean;
  trueUpOnChange: boolean;
  paymentMonth?: string | number | null;
  isEmployerTaxBorne: boolean;
  employerTaxSharePercent?: string | number | null;
  timesPayable?: string | number | null;
}

const isBlank = (value: unknown) => value === undefined || value === null || String(value).trim() === "";

export const validateAllowance = (input: AllowanceRuleInput): string | undefined => {
  if (input.name.trim().length < 3) return "Name must be at least 3 characters";
  if (input.isGrossUp && !input.isTaxable) return "Gross-up requires the item to be taxable";
  if (input.trueUpOnChange && isBlank(input.paymentMonth)) return "TrueUpOnChange requires PaymentMonth";
  if (input.isEmployerTaxBorne && !input.isTaxable) return "Employer tax borne requires the item to be taxable";
  if (input.isEmployerTaxBorne) {
    const share = Number(isBlank(input.employerTaxSharePercent) ? 100 : input.employerTaxSharePercent);
    if (!Number.isFinite(share) || share < 0 || share > 100) {
      return "Employer share must be between 0 and 100";
    }
  }
  if (!isBlank(input.timesPayable)) {
    const times = Number(input.timesPayable);
    if (!Number.isInteger(times) || times < 0) return "Number of months payable must be a whole number";
  }
  return undefined;
};
