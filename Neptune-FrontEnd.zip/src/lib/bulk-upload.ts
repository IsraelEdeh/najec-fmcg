import ApiFetcher from "@/components/Utils/api";
import { sanitizeFilename } from "@/lib/helpers";

export const BULK_UPLOAD_ACCEPTED_EXTENSIONS = [".xlsx", ".xls", ".csv"];
export const BULK_UPLOAD_MAX_FILE_SIZE_MB = 10;
export const BULK_UPLOAD_TIMEOUT_MS = 180_000;

const MAX_FILE_SIZE_BYTES = BULK_UPLOAD_MAX_FILE_SIZE_MB * 1024 * 1024;

export type BulkUploadStatus = "success" | "partial" | "failed";

export interface BulkUploadIssue {
  row?: number;
  field?: string;
  employee?: string;
  message: string;
}

export interface BulkUploadResult {
  status: BulkUploadStatus;
  title: string;
  summary: string;
  hint?: string;
  issues: BulkUploadIssue[];
  total?: number;
  succeeded?: number;
  failed?: number;
}

type UnknownRecord = Record<string, unknown>;

const isRecord = (value: unknown): value is UnknownRecord =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const GENERIC_RECORD_ERROR =
  "This record could not be processed. Check the values in this row against the template.";

// Stack traces, exception names and SQL fragments are not meaningful to end users.
const TECHNICAL_PATTERN =
  /exception|stack ?trace|system\.|microsoft\.|\bat [\w.]+\(|sql|nullreference|object reference|inner exception|entity framework|ef core|foreign key|constraint/i;

const toFriendlyText = (value: unknown, fallback = GENERIC_RECORD_ERROR) => {
  if (typeof value !== "string") return fallback;
  const text = value.trim();
  if (!text || text.length > 400 || TECHNICAL_PATTERN.test(text)) return fallback;
  return text;
};

const pickValue = (source: UnknownRecord, keys: string[]) => {
  const entry = Object.entries(source).find(
    ([key, value]) =>
      keys.includes(key.toLowerCase()) && value !== null && value !== undefined && value !== ""
  );
  return entry?.[1];
};

const pickNumber = (source: unknown, keys: string[]) => {
  if (!isRecord(source)) return undefined;
  const value = pickValue(source, keys);
  const parsed = typeof value === "string" ? Number(value) : value;
  return typeof parsed === "number" && Number.isFinite(parsed) ? parsed : undefined;
};

const ROW_PATTERN = /\b(?:row|line)\s*(?:no\.?|number|#)?\s*:?\s*(\d+)\b/i;

const issueFromString = (value: string): BulkUploadIssue => {
  const match = ROW_PATTERN.exec(value);
  if (!match) return { message: toFriendlyText(value) };
  const message = value
    .replace(match[0], "")
    .replace(/^[\s:,\-–]+/, "")
    .trim();
  return { row: Number(match[1]), message: toFriendlyText(message || value) };
};

const issueFromRecord = (value: UnknownRecord): BulkUploadIssue[] => {
  const rowValue = pickValue(value, ["row", "rownumber", "rowindex", "rowno", "line", "linenumber"]);
  const row = Number(rowValue);
  const field = pickValue(value, ["field", "column", "columnname", "property", "propertyname", "fieldname"]);
  const employee = pickValue(value, [
    "employee",
    "employeename",
    "staffnumber",
    "staffid",
    "email",
    "name",
    "fullname"
  ]);
  const base: Omit<BulkUploadIssue, "message"> = {
    row: Number.isFinite(row) && rowValue !== undefined ? row : undefined,
    field: typeof field === "string" ? field : undefined,
    employee: typeof employee === "string" || typeof employee === "number" ? String(employee) : undefined
  };

  const nested = pickValue(value, ["errors", "messages", "validationerrors"]);
  if (Array.isArray(nested) && nested.length) {
    return nested.flatMap((item) =>
      extractIssues(item).map((issue) => ({ ...base, ...stripUndefined(issue) }))
    );
  }

  const message = pickValue(value, ["message", "error", "errormessage", "reason", "description", "detail"]);
  return [{ ...base, message: toFriendlyText(message) }];
};

const stripUndefined = (issue: BulkUploadIssue) =>
  Object.fromEntries(
    Object.entries(issue).filter(([, value]) => value !== undefined)
  ) as BulkUploadIssue;

const extractIssues = (value: unknown): BulkUploadIssue[] => {
  if (typeof value === "string") return value.trim() ? [issueFromString(value)] : [];
  if (Array.isArray(value)) return value.flatMap(extractIssues);
  if (!isRecord(value)) return [];

  const looksLikeIssue = pickValue(value, [
    "message",
    "error",
    "errormessage",
    "reason",
    "row",
    "rownumber",
    "errors"
  ]);
  if (looksLikeIssue !== undefined) return issueFromRecord(value);

  // ASP.NET validation problem details: { "Field": ["message"] }
  return Object.entries(value).flatMap(([field, messages]) =>
    extractIssues(messages).map((issue) => ({ field: issue.field ?? field, ...stripUndefined(issue) }))
  );
};

const dedupeIssues = (issues: BulkUploadIssue[]) => {
  const seen = new Set<string>();
  return issues
    .filter((issue) => {
      const key = `${issue.row ?? ""}|${issue.field ?? ""}|${issue.employee ?? ""}|${issue.message}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((left, right) => (left.row ?? Number.MAX_SAFE_INTEGER) - (right.row ?? Number.MAX_SAFE_INTEGER));
};

const collectIssues = (...sources: unknown[]) =>
  dedupeIssues(
    sources.flatMap((source) =>
      isRecord(source)
        ? extractIssues(
            pickValue(source, ["errors", "failedrecords", "failures", "invalidrecords", "rowerrors", "validationerrors"])
          )
        : []
    )
  );

const VALIDATION_SUMMARY =
  "Some employee records contain invalid information. Review the records below, correct them in your file and upload it again.";
const VALIDATION_HINT =
  "Only the listed rows need fixing. Keep the template's column headers unchanged when you edit the file.";

export const parseBulkUploadResponse = (body: unknown): BulkUploadResult => {
  const envelope = isRecord(body) ? body : {};
  const payload = isRecord(envelope.data) ? envelope.data : envelope;

  const issues = collectIssues(payload, envelope);
  let succeeded = pickNumber(payload, [
    "successcount",
    "successfulcount",
    "successfulrecords",
    "successful",
    "createdcount",
    "insertedcount",
    "importedcount"
  ]);
  let failed = pickNumber(payload, ["failedcount", "failurecount", "failed", "errorcount", "invalidcount"]);
  let total = pickNumber(payload, [
    "totalrecords",
    "totalrows",
    "totalcount",
    "total",
    "processedcount",
    "processed"
  ]);

  if (failed === undefined && issues.length && succeeded !== undefined) {
    failed = new Set(issues.map((issue) => issue.row ?? issue.message)).size;
  }
  if (total === undefined && succeeded !== undefined && failed !== undefined) {
    total = succeeded + failed;
  }
  if (succeeded === undefined && total !== undefined && failed !== undefined) {
    succeeded = Math.max(total - failed, 0);
  }

  const explicitFailure = envelope.succeeded === false || envelope.success === false;
  const message = toFriendlyText(envelope.message, "");

  if (explicitFailure && !succeeded) {
    return {
      status: "failed",
      title: "Upload failed",
      summary: issues.length ? VALIDATION_SUMMARY : message || "No employees were uploaded.",
      hint: VALIDATION_HINT,
      issues,
      total,
      succeeded,
      failed
    };
  }

  if ((failed ?? 0) > 0 || issues.length) {
    return {
      status: "partial",
      title: "Upload completed with errors",
      summary: `${succeeded ?? "Some"} employee${succeeded === 1 ? " was" : "s were"} uploaded, but some records could not be processed.`,
      hint: "Correct the failed rows and upload a file containing only those rows to avoid duplicates.",
      issues,
      total,
      succeeded,
      failed
    };
  }

  return {
    status: "success",
    title: "Upload completed",
    summary:
      succeeded !== undefined
        ? `${succeeded} employee${succeeded === 1 ? " was" : "s were"} uploaded successfully.`
        : message || "Your employee file was uploaded successfully.",
    issues: [],
    total,
    succeeded,
    failed
  };
};

export const parseBulkUploadError = (error: unknown): BulkUploadResult => {
  const axiosError = error as {
    code?: string;
    message?: string;
    response?: { status?: number; data?: unknown };
  };
  const code = axiosError?.code;
  const data = axiosError?.response?.data;
  const status = axiosError?.response?.status;
  const failure = (title: string, summary: string, hint?: string, issues: BulkUploadIssue[] = []) => ({
    status: "failed" as const,
    title,
    summary,
    hint,
    issues
  });

  if (code === "ECONNABORTED" || code === "ETIMEDOUT" || /timeout/i.test(axiosError?.message ?? "")) {
    return failure(
      "The upload took too long",
      "The server did not respond in time. Large files can take longer to process.",
      "Your file may still have been processed. Check the employee list before uploading again to avoid duplicates."
    );
  }

  // The shared axios interceptor substitutes `{ status: 400 }` when there is no response, so rely on the code.
  if (code === "ERR_NETWORK" || status === undefined) {
    return failure(
      "Unable to reach the server",
      "We couldn't connect to Neptune. Check your internet connection and try again.",
      "If the problem continues, contact your administrator."
    );
  }

  const envelope = isRecord(data) ? data : {};
  const issues = collectIssues(envelope, isRecord(envelope.data) ? envelope.data : undefined);
  const message = toFriendlyText(typeof data === "string" ? data : envelope.message, "");
  const withMessage = (fallback: string) =>
    message && !issues.some((issue) => issue.message === message) ? message : fallback;

  switch (status) {
    case 401:
      return failure("Session expired", "Your session has expired. Please sign in again and retry the upload.");
    case 403:
      return failure(
        "Permission denied",
        "You don't have permission to upload employees.",
        "Ask an administrator to grant you the Admin or Initiator role."
      );
    case 404:
      return failure(
        "Upload service unavailable",
        "The employee upload service could not be found. Please try again later or contact support."
      );
    case 413:
      return failure(
        "File too large",
        `The server rejected the file because it is too large. Keep files under ${BULK_UPLOAD_MAX_FILE_SIZE_MB} MB or split the employees into smaller files.`
      );
    case 415:
      return failure(
        "Unsupported file type",
        `Upload the employee template as ${BULK_UPLOAD_ACCEPTED_EXTENSIONS.join(", ")}.`,
        "Download the template, fill it in and upload it without changing its format."
      );
    case 400:
    case 409:
    case 422:
      if (issues.length) {
        return failure("Upload failed", VALIDATION_SUMMARY, VALIDATION_HINT, issues);
      }
      return failure(
        "Upload failed",
        withMessage(
          "The file could not be processed. Make sure you are using the latest employee template and that all required columns are filled in."
        ),
        "Download the template again if you are unsure whether your file matches it."
      );
    default:
      if (status !== undefined && status >= 500) {
        return failure(
          "Something went wrong on our side",
          "The server couldn't process your file right now. Please try again in a few minutes.",
          "If the problem continues, contact support and share the file you tried to upload.",
          issues
        );
      }
      return failure(
        "Upload failed",
        withMessage("We couldn't upload your file. Please try again."),
        undefined,
        issues
      );
  }
};

const readHeaderBytes = async (file: File, length: number) =>
  new Uint8Array(await file.slice(0, length).arrayBuffer());

const startsWith = (bytes: Uint8Array, signature: number[]) =>
  signature.every((byte, index) => bytes[index] === byte);

const ZIP_SIGNATURE = [0x50, 0x4b, 0x03, 0x04];
const OLE_SIGNATURE = [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1];

export const formatFileSize = (bytes: number) =>
  bytes >= 1024 * 1024
    ? `${(bytes / (1024 * 1024)).toFixed(1)} MB`
    : `${Math.max(1, Math.round(bytes / 1024))} KB`;

// Returns a user-facing error message, or null when the file can be uploaded.
export const validateBulkUploadFile = async (file: File): Promise<string | null> => {
  const extension = file.name.slice(file.name.lastIndexOf(".")).toLowerCase();

  if (!BULK_UPLOAD_ACCEPTED_EXTENSIONS.includes(extension)) {
    return `"${file.name}" is not a supported file. Upload the employee template as ${BULK_UPLOAD_ACCEPTED_EXTENSIONS.join(", ")}.`;
  }
  if (file.size === 0) {
    return `"${file.name}" is empty. Add your employees to the template and try again.`;
  }
  if (file.size > MAX_FILE_SIZE_BYTES) {
    return `"${file.name}" is ${formatFileSize(file.size)}. The maximum size is ${BULK_UPLOAD_MAX_FILE_SIZE_MB} MB — split your employees into smaller files.`;
  }

  let header: Uint8Array;
  try {
    header = await readHeaderBytes(file, 1024);
  } catch {
    return `"${file.name}" could not be read. It may be open in another program or corrupted.`;
  }

  if (extension === ".xlsx" && !startsWith(header, ZIP_SIGNATURE)) {
    return `"${file.name}" appears to be corrupted or is not a real Excel workbook. Open it in Excel, save it as .xlsx and try again.`;
  }
  if (extension === ".xls" && !startsWith(header, OLE_SIGNATURE) && !startsWith(header, ZIP_SIGNATURE)) {
    return `"${file.name}" appears to be corrupted or is not a real Excel workbook. Open it in Excel, save it as .xlsx and try again.`;
  }
  if (extension === ".csv") {
    if (startsWith(header, ZIP_SIGNATURE) || startsWith(header, OLE_SIGNATURE) || header.includes(0)) {
      return `"${file.name}" is not a valid CSV file. Save the template as .xlsx or "CSV (Comma delimited)" and try again.`;
    }
    const lines = (await file.text()).split(/\r?\n/).filter((line) => line.replace(/[,;\s"]/g, "") !== "");
    if (lines.length < 2) {
      return `"${file.name}" has no employee records. Add at least one employee below the header row.`;
    }
  }

  return null;
};

export const downloadEmployeeTemplate = async () => {
  const response = await ApiFetcher.get("/employees/download-bulk-employee-template", {
    responseType: "blob"
  });
  const blob = new Blob([response.data], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  });
  const url = window.URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${sanitizeFilename("employee_template")}.xlsx`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.URL.revokeObjectURL(url);
};
