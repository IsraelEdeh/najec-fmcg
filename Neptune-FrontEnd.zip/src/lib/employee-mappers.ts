import {
  GENDER_UNSPECIFIED,
  type CreateEmployeeRequest,
  type EmployeeEditFormValues,
  type EmployeeEnum,
  type EmployeeFormModel,
  type EmployeeResponse,
  type GenderValue,
  type UpdateEmployeeRequest
} from "@/types/employee";

const toNumber = (value: unknown, fallback = 0) => {
  if (value === null || value === undefined || value === "") return fallback;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const toEnum = (value: unknown): EmployeeEnum =>
  toNumber(value) === 1 ? 1 : 0;

export const isOptionEnabled = (value: unknown): boolean => {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value === 0;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    return normalized === "yes" || normalized === "true" || normalized === "0";
  }
  return false;
};

const toOption = (value: unknown): EmployeeEnum =>
  isOptionEnabled(value) ? 0 : 1;

const pad = (value: number) => String(value).padStart(2, "0");

const formatLocalDate = (date: Date) =>
  `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;

// Returns "YYYY-MM-DD" without timezone conversion so calendar dates never shift by a day.
// .NET default dates (year 0001) are treated as empty.
export const toDateOnly = (value: unknown): string => {
  if (!value) return "";
  if (value instanceof Date) {
    return Number.isNaN(value.getTime()) || value.getFullYear() <= 1 ? "" : formatLocalDate(value);
  }
  const text = String(value).trim();
  const match = /^(\d{4}-\d{2}-\d{2})/.exec(text);
  if (match) return match[1].startsWith("0001-") ? "" : match[1];
  const parsed = new Date(text);
  return Number.isNaN(parsed.getTime()) || parsed.getFullYear() <= 1 ? "" : formatLocalDate(parsed);
};

export const todayDateOnly = () => formatLocalDate(new Date());

const toIsoDate = (value: unknown, fallback?: string) => {
  const dateOnly = toDateOnly(value);
  return dateOnly
    ? `${dateOnly}T00:00:00.000Z`
    : fallback ?? new Date(0).toISOString();
};

const stringValue = (value: unknown) => String(value ?? "");

const isBlank = (value: unknown) =>
  value === null || value === undefined || String(value).trim() === "";

// Optional fields: blank is sent as null, never "", 0 or a default date.
const nullableString = (value: unknown) => (isBlank(value) ? null : String(value).trim());

const nullableId = (value: unknown) => {
  if (isBlank(value)) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed !== 0 ? parsed : null;
};

const nullableIsoDate = (value: unknown) => {
  const dateOnly = toDateOnly(value);
  return dateOnly ? `${dateOnly}T00:00:00.000Z` : null;
};

export const GENDER_OPTIONS = [
  { value: String(GENDER_UNSPECIFIED), label: "Unspecified" },
  { value: "0", label: "Male" },
  { value: "1", label: "Female" }
];

// The API may return gender as a label ("Male"), an enum number, or null.
export const toGenderFormValue = (value: unknown): string => {
  const normalized = isBlank(value) ? "" : String(value).trim().toLowerCase();
  if (normalized === "0" || normalized === "male") return "0";
  if (normalized === "1" || normalized === "female") return "1";
  return String(GENDER_UNSPECIFIED);
};

const toGender = (value: unknown) => Number(toGenderFormValue(value)) as GenderValue;

export const genderLabel = (value: unknown) =>
  GENDER_OPTIONS.find((option) => option.value === toGenderFormValue(value))?.label ?? "Unspecified";

export const displayValue = (value: unknown) => (isBlank(value) ? "-" : String(value));

export const formatDisplayDate = (value: unknown) => toDateOnly(value) || "-";

const firstFilled = (...values: unknown[]) => {
  const found = values.find((value) => !isBlank(value));
  return found === undefined ? "" : String(found);
};

const lookupId = (value: unknown) =>
  value && typeof value === "object" && "id" in value
    ? (value as { id: unknown }).id
    : undefined;

// The API returns gender/employmentType as labels ("Male", "Contract") or as enum numbers.
const toEnumFormValue = (value: unknown, labelForOne: string) => {
  if (typeof value === "number") return value === 1 ? "1" : "0";
  if (typeof value !== "string" || value.trim() === "") return "";
  const normalized = value.trim().toLowerCase();
  if (normalized === "0" || normalized === "1") return normalized;
  return normalized === labelForOne ? "1" : "0";
};

const commonPayload = (form: EmployeeFormModel) => ({
  staffNumber: stringValue(form.staffNumber),
  firstName: stringValue(form.firstName),
  middleName: stringValue(form.middleName),
  lastName: stringValue(form.lastName),
  phoneNumber: nullableString(form.phoneNumber),
  email: stringValue(form.email),
  dateOfBirth: nullableIsoDate(form.dateOfBirth),
  gender: toGender(form.gender),
  address: nullableString(form.address),
  employmentType: toEnum(form.employmentType),
  departmentId: nullableId(form.departmentId),
  employeeJobTitleId: toNumber(form.employeeJobTitleId),
  employeeGradeId: toNumber(form.employeeGradeId),
  costCenterId: nullableId(form.costCenterId),
  organizationSubsidiaryId: toNumber(
    form.organizationSubsidiaryId ?? form.subsidiaryId
  ),
  payerId: stringValue(form.payerId),
  taxAuthority: stringValue(form.taxAuthority),
  rsaPin: nullableString(form.rsaPin),
  dateJoined: nullableIsoDate(form.dateJoined),
  countryId: toNumber(form.countryId),
  stateId: toNumber(form.stateId),
  pensionFundAdministrator: stringValue(form.pensionFundAdministrator),
  bankName: stringValue(form.bankName),
  accountNumber: stringValue(form.accountNumber),
  accountName: stringValue(form.accountName),
  nhfNumber: stringValue(form.nhfNumber),
  nhfExists: toOption(form.nhfExists),
  nhisExists: toOption(form.nhisExists),
  voluntaryPensionExists: form.isPensionExempt
    ? 1
    : toOption(form.voluntaryPensionExists)
});

export const toCreateEmployeeRequest = (
  form: EmployeeFormModel
): CreateEmployeeRequest => ({
  ...commonPayload(form),
  isPensionExempt: Boolean(form.isPensionExempt)
});

export const toUpdateEmployeeRequest = (
  form: EmployeeFormModel,
  existing?: EmployeeResponse
): UpdateEmployeeRequest => {
  // Blank required lookups fall back to the persisted value so a select that failed to load never sends 0.
  // Department and Cost Center are optional, so clearing them is sent as null.
  const merged: EmployeeFormModel = {
    ...form,
    employeeJobTitleId: firstFilled(
      form.employeeJobTitleId,
      existing?.employeeJobTitleId,
      existing?.employeeJobTitle?.id
    ),
    employeeGradeId: firstFilled(
      form.employeeGradeId,
      existing?.employeeGradeId,
      existing?.employeeGrade?.id
    ),
    organizationSubsidiaryId: firstFilled(
      form.organizationSubsidiaryId,
      form.subsidiaryId,
      existing?.organizationSubsidiaryId,
      existing?.organizationSubsidiary?.id
    ),
    countryId: firstFilled(form.countryId, existing?.countryId, existing?.country?.id),
    stateId: firstFilled(form.stateId, existing?.stateId, lookupId(existing?.state)),
    payerId: firstFilled(form.payerId, existing?.payerId)
  };

  const disengagementDate =
    form.disengagementDate !== undefined
      ? form.disengagementDate
      : form.disEngagementDate !== undefined
        ? form.disEngagementDate
        : existing?.disengagementDate ?? existing?.disEngagementDate;

  return {
    ...commonPayload(merged),
    isActive: form.isActive ?? existing?.isActive ?? true,
    disengagementDate: toDateOnly(disengagementDate)
      ? toIsoDate(disengagementDate)
      : null,
    isPensionExempt: Boolean(form.isPensionExempt ?? existing?.isPensionExempt)
  };
};

export const toEmployeeFormValues = (
  employee: EmployeeResponse
): EmployeeEditFormValues => ({
  staffNumber: stringValue(employee.staffNumber),
  firstName: stringValue(employee.firstName),
  middleName: stringValue(employee.middleName),
  lastName: stringValue(employee.lastName),
  phoneNumber: stringValue(employee.phoneNumber),
  email: stringValue(employee.email),
  dateOfBirth: toDateOnly(employee.dateOfBirth),
  gender: toGenderFormValue(employee.gender),
  address: stringValue(employee.address),
  employmentType: toEnumFormValue(employee.employmentType, "contract"),
  departmentId: firstFilled(employee.departmentId, employee.department?.id),
  employeeJobTitleId: firstFilled(
    employee.employeeJobTitleId,
    employee.employeeJobTitle?.id
  ),
  employeeGradeId: firstFilled(employee.employeeGradeId, employee.employeeGrade?.id),
  costCenterId: firstFilled(employee.costCenterId, employee.costCenter?.id),
  subsidiaryId: firstFilled(
    employee.organizationSubsidiaryId,
    employee.subsidiaryId,
    employee.organizationSubsidiary?.id
  ),
  payerId: stringValue(employee.payerId),
  taxAuthority: stringValue(employee.taxAuthority),
  rsaPin: stringValue(employee.rsaPin),
  dateJoined: toDateOnly(employee.dateJoined),
  disengagementDate: toDateOnly(
    employee.disengagementDate ?? employee.disEngagementDate
  ),
  countryId: firstFilled(employee.countryId, employee.country?.id),
  stateId: firstFilled(employee.stateId, lookupId(employee.state)),
  pensionFundAdministrator: stringValue(employee.pensionFundAdministrator),
  bankName: stringValue(employee.bankName),
  accountNumber: stringValue(employee.accountNumber),
  accountName: stringValue(employee.accountName),
  nhfNumber: stringValue(employee.nhfNumber),
  nhfExists: isOptionEnabled(employee.nhfExists),
  nhisExists: isOptionEnabled(employee.nhisExists),
  voluntaryPensionExists:
    !employee.isPensionExempt && isOptionEnabled(employee.voluntaryPensionExists),
  isPensionExempt: Boolean(employee.isPensionExempt)
});
