import * as yup from "yup";
import { GENDER_OPTIONS, toDateOnly, todayDateOnly } from "@/lib/employee-mappers";

export const isValidDate = (value?: string | null) => !value || toDateOnly(value) !== "";
export const isNotInFuture = (value?: string | null) =>
  !value || toDateOnly(value) <= todayDateOnly();

// Optional employee fields: blank passes, format rules apply only when a value is given.
export const optionalPastDate = (label: string) =>
  yup
    .string()
    .default("")
    .test("valid-date", `${label} must be a valid date`, isValidDate)
    .test("not-in-future", `${label} cannot be in the future`, isNotInFuture);

export const optionalPhone = () =>
  yup
    .string()
    .trim()
    .default("")
    .test("phone-format", "Phone number format is invalid", (value) => !value || /^\+?[0-9\s-]+$/.test(value))
    .test("phone-min", "Phone must be 9 digits or more", (value) => !value || value.length >= 9)
    .test("phone-max", "Phone must be 13 digits or less", (value) => !value || value.length <= 13);

export const optionalMinLength = (min: number, message: string) =>
  yup
    .string()
    .trim()
    .default("")
    .test("min-length", message, (value) => !value || value.length >= min);

export const optionalGender = () =>
  yup
    .string()
    .default("")
    .oneOf(["", ...GENDER_OPTIONS.map((option) => option.value)], "Select a valid gender");
