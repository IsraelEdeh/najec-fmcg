export const countries = [
  {
    name: "Nigeria",
    code: "+234"
  },
  {
    name: "Ghana",
    code: "+234"
  },
  {
    name: "South Africa",
    code: "+809"
  }
];

export const formatCurrency = (val: any) => {
  if (val === null || val === undefined || val === "") return "₦0.00";
  const n = Number(val);
  if (Number.isNaN(n)) return "₦0.00";
  return `₦${n.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })}`;
};

export const sanitizeFilename = (name: string) =>
  name.replace(/[^a-zA-Z0-9._-]/g, "");


