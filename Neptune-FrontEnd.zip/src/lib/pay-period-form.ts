import * as yup from "yup";

const pad = (value: number) => String(value).padStart(2, "0");

export const toInputDate = (date: Date) =>
  `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;

export const parseDate = (value: unknown) => {
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? undefined : value;
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(value ?? ""));
  return match ? new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3])) : undefined;
};

export const lastDayOfMonth = (date: Date) =>
  new Date(date.getFullYear(), date.getMonth() + 1, 0);

export const toUtcDate = (value: unknown) => {
  const date = new Date(value as string | number | Date);
  return new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
};

export const payPeriodSchema = yup
  .object({
    firstPayDate: yup.date().default(new Date()),
    dayOfTheMonth: yup
      .string()
      .matches(
        /^(0?[1-9]|[12][0-9]|3[01])$/,
        "Day of the month must be between 1 and 31"
      )
      .required("Day of the month is required"),
    startDate: yup.date().required("Start date is required"),
    endDate: yup.date().required("End date is required"),
    deadLine: yup
      .date()
      .required("Deadline is required")
      .test("not-after-end", "Deadline cannot be after the end date", function (value) {
        const end = parseDate(this.parent.endDate);
        const deadline = parseDate(value);
        return !end || !deadline || deadline.getTime() <= end.getTime();
      })
  })
  .required();
