import ApiFetcher from "@/components/Utils/api";
import { sanitizeFilename } from "@/lib/helpers";
import {
  OFF_CYCLE_TYPE_LABELS,
  OffCycleType,
  PayrollRunType,
  type CreateOffCycleRunRequest,
  type CurrentPayroll,
  type EnumValue,
  type Id,
  type OffCycleRun,
  type PayComponentOption,
  type PayPeriod,
  type PayrollAction,
  type PayrollRunSummary,
  type PayrollScheduleSummary,
  type PayrollScheduleSummaryParams,
  type PayrollsByPayPeriodResponse,
  type RunPayrollParams,
  type UpdatePayPeriodRequest
} from "@/types/payroll";

type QueryValue = string | number | boolean | null | undefined | Array<string | number>;

const isSet = (value: unknown) => value !== undefined && value !== null && value !== "";

// Unset params are dropped so default calls produce exactly the same URL as before.
export const buildQuery = (params: Record<string, QueryValue>) => {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (Array.isArray(value)) value.forEach((item) => search.append(key, String(item)));
    else if (isSet(value)) search.append(key, String(value));
  });
  const query = search.toString();
  return query ? `?${query}` : "";
};

export const withPayrollId = (url: string, payrollId?: Id | null) =>
  isSet(payrollId)
    ? `${url}${url.includes("?") ? "&" : "?"}payrollId=${encodeURIComponent(String(payrollId))}`
    : url;

const unwrap = <T>(response: { data?: { data?: T } }) => response?.data?.data as T;

const toList = <T>(value: unknown): T[] => {
  if (Array.isArray(value)) return value as T[];
  if (value && typeof value === "object") {
    const nested = (value as { items?: unknown; data?: unknown }).items ??
      (value as { data?: unknown }).data;
    if (Array.isArray(nested)) return nested as T[];
  }
  return [];
};

const normalizeKey = (value: unknown) => String(value ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");

export const normalizeRunType = (value: EnumValue | null | undefined): PayrollRunType => {
  if (typeof value === "number") return value === PayrollRunType.OffCycle ? PayrollRunType.OffCycle : PayrollRunType.Regular;
  const key = normalizeKey(value);
  return key === "offcycle" || key === "1" ? PayrollRunType.OffCycle : PayrollRunType.Regular;
};

const OFF_CYCLE_ALIASES: Record<string, OffCycleType> = {
  thirteenthmonth: OffCycleType.ThirteenthMonth,
  "13thmonth": OffCycleType.ThirteenthMonth,
  bonus: OffCycleType.Bonus,
  midmonth: OffCycleType.MidMonth,
  arrears: OffCycleType.Arrears,
  other: OffCycleType.Other
};

export const normalizeOffCycleType = (value: EnumValue | null | undefined): OffCycleType | undefined => {
  if (value === null || value === undefined || value === "") return undefined;
  const numeric = typeof value === "number" ? value : /^\d+$/.test(String(value)) ? Number(value) : NaN;
  if (numeric in OFF_CYCLE_TYPE_LABELS) return numeric as OffCycleType;
  return OFF_CYCLE_ALIASES[normalizeKey(value)];
};

export const offCycleTypeLabel = (value: EnumValue | null | undefined) => {
  const type = normalizeOffCycleType(value);
  return type === undefined ? "Other" : OFF_CYCLE_TYPE_LABELS[type];
};

// Backend order: Pending, Submitted, Reviewed, Approved, Rejected (Rejected = 4 matches existing requests).
const NUMERIC_STATUS_LABELS: Record<number, string> = {
  0: "Pending",
  1: "Submitted",
  2: "Reviewed",
  3: "Approved",
  4: "Rejected"
};

export const payrollStatusLabel = (status: EnumValue | null | undefined) => {
  if (status === null || status === undefined || status === "") return "Not processed";
  if (typeof status === "number") return NUMERIC_STATUS_LABELS[status] ?? `Status ${status}`;
  return status;
};

export const isRejectedStatus = (status: EnumValue | null | undefined) =>
  status === 4 || normalizeKey(status) === "rejected";

export const isApprovedStatus = (status: EnumValue | null | undefined) =>
  status === 3 || normalizeKey(status) === "approved";

export const allowedActionsOf = (
  payroll?: { allowedActions?: string[] | null; status?: EnumValue | null } | null,
  roles: string[] = []
) => {
  if (!payroll) return [];
  if (Array.isArray(payroll.allowedActions)) return payroll.allowedActions.filter(Boolean);
  // Fallback when the response has no allowedActions: backend transitions per status, gated by role.
  const status = normalizeKey(payrollStatusLabel(payroll.status));
  const has = (...names: string[]) => names.some((name) => roles.includes(name));
  const actions: PayrollAction[] = [];
  if (status === "pending" && has("Admin", "Initiator")) actions.push("Submit");
  if ((status === "pending" || status === "submitted") && has("Admin", "Reviewer")) actions.push("Review");
  if (status === "reviewed" && has("Admin", "Approver")) actions.push("Approve");
  if (
    ((status === "pending" || status === "submitted") && has("Admin", "Reviewer")) ||
    (status === "reviewed" && has("Admin", "Approver"))
  ) {
    actions.push("Reject");
  }
  return actions;
};

export const canPerformAction = (
  payroll: { allowedActions?: string[] | null; status?: EnumValue | null } | null | undefined,
  action: PayrollAction,
  roles: string[] = []
) => allowedActionsOf(payroll, roles).some((item) => normalizeKey(item) === normalizeKey(action));

// payrollId wins on the backend; payPeriodId is kept for endpoints that need the period.
export const selectionQuery = ({
  payPeriodId,
  payrollId,
  offCycleRunId
}: {
  payPeriodId?: Id | null;
  payrollId?: Id | null;
  offCycleRunId?: Id | null;
}) =>
  isSet(payrollId)
    ? { payPeriodId: payPeriodId ?? undefined, payrollId: payrollId ?? undefined }
    : { payPeriodId: payPeriodId ?? undefined, offCycleRunId: offCycleRunId ?? undefined };

export const runDisplayName = (run: Pick<PayrollRunSummary, "runType" | "runName" | "offCycleType">) =>
  normalizeRunType(run.runType) === PayrollRunType.Regular
    ? "Regular"
    : `${run.runName || "Off-cycle run"} (${offCycleTypeLabel(run.offCycleType)})`;

export const withRunSuffix = (baseName: string, runName?: string | null) =>
  runName ? `${baseName}-${sanitizeFilename(runName.trim().replace(/\s+/g, "-"))}` : baseName;

export const downloadBlob = (data: BlobPart, fileName: string, type: string) => {
  const blob = data instanceof Blob ? data : new Blob([data], { type });
  const url = window.URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  anchor.rel = "noopener noreferrer";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.URL.revokeObjectURL(url);
};

// Blob requests return JSON errors as a Blob; parse them so the message can be shown.
export const parseBlobError = async (error: unknown) => {
  const response = (error as { response?: { data?: unknown } })?.response;
  if (response?.data instanceof Blob) {
    try {
      response.data = JSON.parse(await response.data.text());
    } catch {
      response.data = undefined;
    }
  }
  return error;
};

export const getErrorList = (error: unknown): string[] => {
  const data = (error as { response?: { data?: unknown } })?.response?.data as Record<string, unknown> | undefined;
  if (!data || typeof data !== "object") return [];
  const nested = data.data && typeof data.data === "object" ? (data.data as Record<string, unknown>) : {};
  const candidate =
    data.closeBlockers ?? data.blockers ?? nested.closeBlockers ?? nested.blockers ?? data.errors;
  if (Array.isArray(candidate)) return candidate.filter((item): item is string => typeof item === "string");
  if (candidate && typeof candidate === "object") {
    return Object.values(candidate as Record<string, unknown>)
      .flat()
      .filter((item): item is string => typeof item === "string");
  }
  return [];
};

const isOpen = (period: PayPeriod) => !period.isClosed;
const startTime = (period: PayPeriod) => new Date(period.startDate ?? 0).getTime();

export const sortNewestFirst = (periods: PayPeriod[]) =>
  [...periods].sort((left, right) => startTime(right) - startTime(left));

export const openPeriodsNewestFirst = (periods: PayPeriod[]) => sortNewestFirst(periods.filter(isOpen));

export const findPeriodContainingToday = (periods: PayPeriod[]) => {
  const now = Date.now();
  return periods.find((period) => {
    if (!period.startDate || !period.endDate) return false;
    const end = new Date(period.endDate);
    end.setHours(23, 59, 59, 999);
    return startTime(period) <= now && now <= end.getTime();
  });
};

export const sameId = (left?: Id | null, right?: Id | null) =>
  isSet(left) && isSet(right) && String(left) === String(right);

export const getAllPayPeriods = async (): Promise<PayPeriod[]> =>
  toList<PayPeriod>(
    unwrap(await ApiFetcher.get("/payperiods/get-all-pay-period?PageNumber=1&PageSize=100"))
  );

export const closePayPeriod = (payPeriodId: Id) =>
  ApiFetcher.patch(`/payperiods/close-pay-period/${payPeriodId}`);

export const deletePayPeriod = (payPeriodId: Id) =>
  ApiFetcher.delete(`/payperiods/delete-pay-period/${payPeriodId}`);

export const updatePayPeriod = (payPeriodId: Id, payload: UpdatePayPeriodRequest) =>
  ApiFetcher.put(`/payperiods/update-pay-period/${payPeriodId}`, payload);

export const runPayroll = (params: RunPayrollParams = {}) =>
  ApiFetcher.get(`/payroll/run-payroll${buildQuery({ ...params })}`);

export const getPayrollScheduleSummary = async (
  params: PayrollScheduleSummaryParams = {}
): Promise<PayrollScheduleSummary> =>
  unwrap<PayrollScheduleSummary>(
    await ApiFetcher.get(`/payroll/get-payroll-schedule-summary${buildQuery({ ...params })}`)
  );

export const getPayrollsByPayPeriod = async (payPeriodId: Id): Promise<PayrollsByPayPeriodResponse> => {
  const data = unwrap<PayrollsByPayPeriodResponse>(
    await ApiFetcher.get(`/payroll/get-payrolls-by-payperiod${buildQuery({ payPeriodId })}`)
  );
  return {
    ...data,
    closeBlockers: data?.closeBlockers ?? [],
    payrolls: toList<PayrollRunSummary>(data?.payrolls)
  };
};

// payPeriodId is always sent so the payroll returned belongs to the selected period.
export const getCurrentPayroll = async ({
  payPeriodId,
  payrollId
}: {
  payPeriodId: Id;
  payrollId?: Id | null;
}): Promise<CurrentPayroll | undefined> =>
  unwrap<CurrentPayroll>(
    await ApiFetcher.get(`/payroll/get-current-payroll${buildQuery({ payPeriodId, payrollId })}`)
  );

export const currentPayrollKey = (payPeriodId?: Id | null, payrollId?: Id | null) =>
  ["getCurrentPayroll", payPeriodId ?? null, payrollId ?? null] as const;

export const getPayrollProcessThread = async (payPeriodId: Id, payrollId?: Id | null) =>
  unwrap(
    await ApiFetcher.get(
      `/payroll/payroll-process-thread${buildQuery({ payPeriodId, payrollId })}`
    )
  );

export const savePayrollScheduleFile = (
  file: File,
  payPeriodId: Id | undefined,
  mode: "upload" | "update"
) => {
  const formData = new FormData();
  formData.append("PayrollSchedule", file);
  const url = `/payroll/${mode}-payroll-schedule${buildQuery({ payPeriodId })}`;
  const config = { headers: { "Content-Type": "multipart/form-data" } };
  return mode === "upload" ? ApiFetcher.post(url, formData, config) : ApiFetcher.put(url, formData, config);
};

export const createOffCycleRun = (body: CreateOffCycleRunRequest) =>
  ApiFetcher.post("/off-cycle-run/create-off-cycle-run", body);

export const getOffCycleRuns = async (payPeriodId: Id): Promise<OffCycleRun[]> =>
  toList<OffCycleRun>(
    unwrap(await ApiFetcher.get(`/off-cycle-run/get-off-cycle-runs${buildQuery({ payPeriodId })}`))
  );

export const deleteOffCycleRun = (offCycleRunId: Id) =>
  ApiFetcher.delete(`/off-cycle-run/delete-off-cycle-run${buildQuery({ offCycleRunId })}`);

export const downloadOffCycleScheduleTemplate = async (payComponentIds: Id[], runName?: string) => {
  try {
    const response = await ApiFetcher.get(
      `/off-cycle-run/download-off-cycle-schedule-template${buildQuery({
        payComponentIds: payComponentIds.map(String)
      })}`,
      { responseType: "blob" }
    );
    downloadBlob(
      response.data,
      `${withRunSuffix("off-cycle-schedule-template", runName)}.xlsx`,
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
  } catch (error) {
    throw await parseBlobError(error);
  }
};

export const uploadOffCycleSchedule = (offCycleRunId: Id, file: File) => {
  const formData = new FormData();
  formData.append("OffCycleSchedule", file);
  return ApiFetcher.post(
    `/off-cycle-run/upload-off-cycle-schedule${buildQuery({ offCycleRunId })}`,
    formData,
    { headers: { "Content-Type": "multipart/form-data" } }
  );
};

const fetchComponents = async (url: string, kind: PayComponentOption["kind"]) => {
  const response = await ApiFetcher.get(url);
  return toList<{ id?: Id; name?: string; paymentMonth?: number | null }>(response?.data?.data ?? response?.data)
    .filter((item) => isSet(item.id) && (item.paymentMonth === null || item.paymentMonth === undefined))
    .map((item) => ({ id: item.id as Id, name: item.name ?? String(item.id), kind }));
};

// Annual items (paymentMonth set) are excluded because the template endpoint refuses them.
export const getOffCycleEligibleComponents = async (): Promise<PayComponentOption[]> => {
  const [allowances, deductions] = await Promise.all([
    fetchComponents("/tax/get-all-allowanceItems?PageNumber=1&PageSize=1000", "Allowance"),
    fetchComponents("/tax/get-all-deductionsItems?PageNumber=1&PageSize=1000", "Deduction")
  ]);
  return [...allowances, ...deductions];
};

export const PAY_PERIODS_QUERY_KEY = ["payPeriodsAll"] as const;
export const payrollsByPeriodKey = (payPeriodId?: Id | null) => ["payrollsByPayPeriod", payPeriodId ?? null] as const;
export const offCycleRunsKey = (payPeriodId?: Id | null) => ["offCycleRuns", payPeriodId ?? null] as const;
export const PAY_PERIOD_CLOSED_MESSAGE = "Pay period is closed.";
