export type ComponentKind = "regular" | "arrears" | "basisOnly";

const ARREARS_SUFFIX = " (arrears)";
const BASIS_ONLY_SUFFIX = " (basis only)";

export const parseComponentName = (name: string): { baseName: string; kind: ComponentKind } => {
  if (name.endsWith(ARREARS_SUFFIX)) {
    return { baseName: name.slice(0, -ARREARS_SUFFIX.length), kind: "arrears" };
  }
  if (name.endsWith(BASIS_ONLY_SUFFIX)) {
    return { baseName: name.slice(0, -BASIS_ONLY_SUFFIX.length), kind: "basisOnly" };
  }
  return { baseName: name, kind: "regular" };
};

// Paid allowances keep their order, each arrears column follows its base, basis-only columns go last.
export const orderAllowanceColumns = (names: string[]) => {
  const parsed = names.map((name) => ({ name, ...parseComponentName(name) }));
  const regular = parsed.filter((item) => item.kind === "regular").map((item) => item.name);
  const arrears = parsed.filter((item) => item.kind === "arrears");
  const basisOnly = parsed.filter((item) => item.kind === "basisOnly").map((item) => item.name);

  const ordered: string[] = [];
  regular.forEach((name) => {
    ordered.push(name);
    arrears.filter((item) => item.baseName === name).forEach((item) => ordered.push(item.name));
  });
  arrears
    .filter((item) => !regular.includes(item.baseName))
    .forEach((item) => ordered.push(item.name));

  return { paid: ordered, basisOnly };
};

export const hasSpecialComponents = (names: string[]) =>
  names.some((name) => parseComponentName(name).kind !== "regular");
