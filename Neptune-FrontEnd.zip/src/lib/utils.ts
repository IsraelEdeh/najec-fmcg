import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Handles both `{ message }` envelopes and ASP.NET validation problem details (`{ title, errors }`).
export function getApiErrorMessage(error: unknown, fallback: string) {
  const data = (error as { response?: { data?: unknown } })?.response?.data as
    | { message?: unknown; title?: unknown; errors?: unknown }
    | string
    | undefined;

  if (typeof data === "string" && data.trim()) return data;
  if (!data || typeof data !== "object") return fallback;
  if (typeof data.message === "string" && data.message.trim()) return data.message;

  if (data.errors && typeof data.errors === "object") {
    const messages = Object.values(data.errors as Record<string, unknown>)
      .flat()
      .filter((message): message is string => typeof message === "string");
    if (messages.length) return messages.join(" ");
  }

  if (typeof data.title === "string" && data.title.trim()) return data.title;
  return fallback;
}

// "start-end of total items" from the API paging meta (totalCount is the record count, not pages).
export function formatPageRange(
  meta?: { pageNumber?: number; pageSize?: number; totalCount?: number } | null,
  fallbackPageSize = 10
) {
  const total = Number(meta?.totalCount ?? 0) || 0;
  const pageSize = Number(meta?.pageSize ?? fallbackPageSize) || fallbackPageSize;
  const pageNumber = Number(meta?.pageNumber ?? 1) || 1;
  const start = total === 0 ? 0 : (pageNumber - 1) * pageSize + 1;
  const end = Math.min(pageNumber * pageSize, total);
  return `${start}-${end} of ${total} items`;
}

