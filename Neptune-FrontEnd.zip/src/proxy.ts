import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function proxy(request: NextRequest) {
  const response = NextResponse.next();

  response.headers.set(
    "Content-Security-Policy",
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; object-src 'none'; connect-src 'self' https://login.microsoftonline.com https://*.msidentity.com https://*.microsoftonline.com https://neptuneapi.deloitte.com.ng https://devneptuneapi.deloitte.com.ng; img-src 'self' data:; frame-ancestors 'self';"
  );

  // response.headers.set("X-Content-Type-Options", "nosniff");

  // response.headers.delete("X-Powered-By");

  // response.headers.delete("Server");

  return response;
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/company-select",
    "/create-organisation",
    "/create-organisation/success"
  ]
};
