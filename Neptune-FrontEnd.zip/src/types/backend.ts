export interface PayComponent {
  id: number;
  name: string;
  isTaxable?: boolean;
  isPension?: boolean;
  isNHF?: boolean;
  isBasisOnly?: boolean;
  isEmployerTaxBorne?: boolean;
  employerTaxSharePercent?: number | null;
  isGrossUp?: boolean;
  isNSITF?: boolean;
  paymentMonth?: number | null;
  trueUpOnChange?: boolean;
  paymentMonthName?: string;
  noOfTimesPayable?: number;
  noOfTimesRemaining?: number;
}

export interface UpdatePayComponentRequest {
  name?: string;
  isTaxable?: boolean;
  isPension?: boolean;
  isNHF?: boolean;
  isBasisOnly?: boolean;
  isEmployerTaxBorne?: boolean;
  employerTaxSharePercent?: number;
  isGrossUp?: boolean;
  isNSITF?: boolean;
  paymentMonth?: number;
  trueUpOnChange?: boolean;
  noOfTimesPayable?: number;
  clearPaymentMonth?: boolean;
  clearEmployerTaxShare?: boolean;
}

export interface EmployeeEntitlement {
  id: number;
  payComponentId: number;
  payComponentName?: string;
  componentName?: string;
  annualAmount: number;
  effectiveFrom: string;
}

export interface SaveAnnualEntitlementRequest {
  payComponentId: number;
  annualAmount: number;
  effectiveFrom: string;
}

export interface OrganizationRoundingSettings {
  netPayRoundingMode?: number;
  netPayRoundingUnit?: number | null;
}
