export type EmployeeEnum = 0 | 1;

// Confirm against the backend Gender enum: Male = 0, Female = 1, Unspecified = this value.
export const GENDER_UNSPECIFIED = 2 as const;
export type GenderValue = 0 | 1 | typeof GENDER_UNSPECIFIED;

// The API returns Yes/No flags as "Yes"/"No" strings but accepts the EmployeeEnum (0 = Yes, 1 = No).
export type EmployeeOptionValue = boolean | number | string;

export interface EmployeeFormModel {
  staffNumber?: string;
  firstName?: string;
  middleName?: string;
  lastName?: string;
  phoneNumber?: string | null;
  email?: string;
  dateOfBirth?: string | Date | null;
  gender?: string | number | null;
  address?: string | null;
  employmentType?: string | number;
  departmentId?: string | number | null;
  employeeJobTitleId?: string | number;
  employeeGradeId?: string | number;
  costCenterId?: string | number | null;
  organizationSubsidiaryId?: string | number;
  subsidiaryId?: string | number;
  payerId?: string;
  taxAuthority?: string;
  rsaPin?: string | null;
  dateJoined?: string | Date | null;
  countryId?: string | number;
  stateId?: string | number;
  pensionFundAdministrator?: string;
  bankName?: string;
  accountNumber?: string;
  accountName?: string;
  nhfNumber?: string;
  nhfExists?: EmployeeOptionValue;
  nhisExists?: EmployeeOptionValue;
  voluntaryPensionExists?: EmployeeOptionValue;
  isPensionExempt?: boolean;
  isActive?: boolean;
  disengagementDate?: string | Date | null;
  disEngagementDate?: string | Date | null;
}

export interface CreateEmployeeRequest {
  staffNumber: string;
  firstName: string;
  middleName: string;
  lastName: string;
  phoneNumber: string | null;
  email: string;
  dateOfBirth: string | null;
  gender: GenderValue;
  address: string | null;
  employmentType: EmployeeEnum;
  departmentId: number | null;
  employeeJobTitleId: number;
  employeeGradeId: number;
  costCenterId: number | null;
  organizationSubsidiaryId: number;
  payerId: string;
  taxAuthority: string;
  rsaPin: string | null;
  dateJoined: string | null;
  countryId: number;
  stateId: number;
  pensionFundAdministrator: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  nhfNumber: string;
  nhfExists: EmployeeEnum;
  nhisExists: EmployeeEnum;
  voluntaryPensionExists: EmployeeEnum;
  isPensionExempt: boolean;
}

export interface UpdateEmployeeRequest extends Omit<CreateEmployeeRequest, "isPensionExempt"> {
  isActive: boolean;
  disengagementDate: string | null;
  isPensionExempt: boolean;
}

export interface EmployeeLookup {
  id: number;
  name: string;
}

export interface EmployeeResponse extends EmployeeFormModel {
  id: string;
  isDisengaged?: boolean;
  department?: EmployeeLookup | null;
  employeeJobTitle?: EmployeeLookup | null;
  employeeGrade?: EmployeeLookup | null;
  costCenter?: EmployeeLookup | null;
  organizationSubsidiary?: EmployeeLookup | null;
  country?: EmployeeLookup | null;
  state?: EmployeeLookup | string | null;
}

export interface EmployeeEditFormValues {
  staffNumber: string;
  firstName: string;
  middleName: string;
  lastName: string;
  phoneNumber: string;
  email: string;
  dateOfBirth: string;
  gender: string;
  address: string;
  employmentType: string;
  departmentId: string;
  employeeJobTitleId: string;
  employeeGradeId: string;
  costCenterId: string;
  subsidiaryId: string;
  payerId: string;
  taxAuthority: string;
  rsaPin: string;
  dateJoined: string;
  disengagementDate: string;
  countryId: string;
  stateId: string;
  pensionFundAdministrator: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  nhfNumber: string;
  nhfExists: boolean;
  nhisExists: boolean;
  voluntaryPensionExists: boolean;
  isPensionExempt: boolean;
}
