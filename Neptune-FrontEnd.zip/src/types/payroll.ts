export type Id = number | string;

// Responses may serialise enums as names or numbers; requests always send numbers.
export type EnumValue = number | string;

export enum PayrollRunType {
  Regular = 0,
  OffCycle = 1
}

export enum OffCycleType {
  ThirteenthMonth = 0,
  Bonus = 1,
  MidMonth = 2,
  Arrears = 3,
  Other = 4
}

export const PAYROLL_RUN_TYPE_LABELS: Record<PayrollRunType, string> = {
  [PayrollRunType.Regular]: "Regular",
  [PayrollRunType.OffCycle]: "Off-cycle"
};

export const OFF_CYCLE_TYPE_LABELS: Record<OffCycleType, string> = {
  [OffCycleType.ThirteenthMonth]: "13th Month",
  [OffCycleType.Bonus]: "Bonus",
  [OffCycleType.MidMonth]: "Mid-month",
  [OffCycleType.Arrears]: "Arrears",
  [OffCycleType.Other]: "Other"
};

export const OFF_CYCLE_TYPE_OPTIONS = (
  Object.keys(OFF_CYCLE_TYPE_LABELS).map(Number) as OffCycleType[]
).map((value) => ({ value, label: OFF_CYCLE_TYPE_LABELS[value] }));

export interface PayPeriod {
  id: Id;
  name: string;
  startDate?: string;
  endDate?: string;
  deadLine?: string;
  isClosed?: boolean;
  canClose?: boolean;
  closeBlockers?: string[];
  dayOfTheMonth?: number | null;
}

// Mirrors the backend UpdatePayPeriodRequestModel, whose day field is spelled "dayOfTheMont".
export interface UpdatePayPeriodRequest {
  dayOfTheMont: number;
  startDate: Date;
  endDate: Date;
  deadLine: Date;
  organizationId?: number;
}

export interface PayrollRunSummary {
  id: Id;
  runType: EnumValue;
  runName?: string | null;
  offCycleType?: EnumValue | null;
  offCycleRunId?: Id | null;
  status?: EnumValue | null;
  allowedActions?: string[] | null;
  totalNetPay?: number | null;
  totalGrossSalary?: number | null;
  totalTaxPayable?: number | null;
  totalPensionPayable?: number | null;
}

export interface PayrollsByPayPeriodResponse {
  payPeriodId: Id;
  payPeriodName: string;
  isClosed: boolean;
  canClose: boolean;
  closeBlockers: string[];
  payrolls: PayrollRunSummary[];
}

export interface OffCycleRun {
  id: Id;
  payPeriodId?: Id;
  name: string;
  offCycleType: EnumValue;
  isProcessed?: boolean;
  payrollId?: Id | null;
  payrollStatus?: EnumValue | null;
}

export interface CreateOffCycleRunRequest {
  payPeriodId: Id;
  name: string;
  offCycleType: OffCycleType;
}

export interface RunPayrollParams {
  payPeriodId?: Id;
  offCycleRunId?: Id;
}

export interface CurrentPayroll {
  id: Id;
  runType?: EnumValue;
  runName?: string | null;
  offCycleType?: EnumValue | null;
  status?: EnumValue | null;
  allowedActions?: string[] | null;
  [key: string]: unknown;
}

export interface PayComponentOption {
  id: Id;
  name: string;
  kind: "Allowance" | "Deduction";
}

export interface PayrollScheduleSummaryParams {
  payPeriodId?: Id;
  offCycleRunId?: Id;
  payrollId?: Id;
}

export type PayrollAction = "Submit" | "Review" | "Approve" | "Reject";

export interface PayrollScheduleSummary {
  payPeriodId?: Id;
  payPeriodName?: string;
  totalNoOfEmployees: number;
  totalNoOfPayComponents: number;
  totalAllowanceValue: number;
  totalDeductionValue: number;
  totalEmolument: number;
  hasSchedule?: boolean;
}
