# Build: double-click build_app.bat in the tool root (runs tests, builds, swaps in the new exe with a backup).
# Manual: python -m PyInstaller ImmigrationTracker.spec  (run from the app/ folder)
from PyInstaller.utils.hooks import collect_submodules

a = Analysis(
    ["main.py"],
    pathex=["."],
    # No bundled workbook: clients import their own (or drop it next to the .exe for auto-import).
    datas=[],
    hiddenimports=collect_submodules("immigration_tracker") + [
        "PySide6.QtCharts", "win32com.client", "pythoncom", "pywintypes", "win32crypt"],
    excludes=["PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets", "PySide6.QtQuick", "PySide6.QtQml",
              "PySide6.Qt3DCore", "PySide6.QtMultimedia", "PySide6.QtPdf"],
)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name="ImmigrationTracker", console=False)
coll = COLLECT(exe, a.binaries, a.datas, name="ImmigrationTracker")
