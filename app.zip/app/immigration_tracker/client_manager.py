"""Multi-client management and dashboard coordination."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from . import rules as R
from .db import Database, ClientUser, ROLES, STATUS_NOT_STARTED, STATUS_IN_PROGRESS, STATUS_DONE
from .services import TrackerService, ActionItem, Tile


@dataclass
class ClientDashboard:
    """Dashboard data for a specific client."""
    client_id: int
    client_name: str
    users: list[ClientUser]
    action_items: list[ActionItem]
    tiles: list[Tile]
    upcoming_events_count: int
    overdue_count: int
    
    @property
    def owner(self) -> ClientUser | None:
        return next((u for u in self.users if u.role == "Owner"), None)
    
    @property
    def managers(self) -> list[ClientUser]:
        return [u for u in self.users if u.role == "Manager" and u.active]
    
    @property
    def partners(self) -> list[ClientUser]:
        return [u for u in self.users if u.role == "Partner" and u.active]


class ClientManager:
    """Coordinates multi-client operations and reminder routing."""
    
    def __init__(self, db: Database, today: date | None = None):
        self.db = db
        self._today = today
        self.svc = TrackerService(db, today)
    
    @property
    def today(self) -> date:
        return self._today or date.today()
    
    def get_clients(self, active_only: bool = True) -> list:
        """Get list of clients."""
        return self.db.clients(active_only=active_only)
    
    def get_client_dashboard(self, client_id: int) -> ClientDashboard:
        """Build a complete dashboard for a client including users and action items."""
        client = self.db.get_client(client_id)
        if not client:
            raise ValueError(f"Client {client_id} not found")
        
        users = self.db.client_users(client_id, active_only=False)
        svc = TrackerService(self.db, self._today, client_id)

        action_items = svc.action_items()
        tiles = self._build_tiles(svc)

        upcoming_events = svc.upcoming_events(window_days=30)
        upcoming_count = len(upcoming_events)

        # Count overdue items (past alert milestones not yet marked done)
        from .notifications import ALERT_KINDS, matter_key
        all_events = svc.events
        done_matters = {m for m, s in self.db.matter_statuses().items() if s == STATUS_DONE}
        overdue_count = sum(1 for e in all_events
                            if e.when < self.today and e.kind in ALERT_KINDS and matter_key(e) not in done_matters)
        
        return ClientDashboard(
            client_id=client_id,
            client_name=client.name,
            users=users,
            action_items=action_items,
            tiles=tiles,
            upcoming_events_count=upcoming_count,
            overdue_count=overdue_count
        )
    
    def _build_tiles(self, svc: TrackerService | None = None) -> list[Tile]:
        """Build dashboard tiles for all data sources."""
        tiles = []

        # Count action items by source
        action_items = (svc or self.svc).action_items()
        eq_actions = [a for a in action_items if a.source == R.SRC_EQ]
        cerpac_actions = [a for a in action_items if a.source == R.SRC_CERPAC]
        quota_actions = [a for a in action_items if a.source == R.SRC_QUOTA]
        
        for group_key, group_name, group_hint in [
            ("eq", "EQ positions", "FMI approval + 2 years"),
            ("cerpac", "CERPAC", "4-month and 1-month notices"),
            ("eepnl", "EEPNL quotas", "7-month notification"),
        ]:
            actions = {
                "eq": eq_actions,
                "cerpac": cerpac_actions,
                "eepnl": quota_actions,
            }.get(group_key, [])
            
            tiles.append(Tile(
                key=group_key,
                group="actions",
                title=group_name,
                tone="warning" if actions else "default",
                count=len(actions),
                hint=group_hint,
                tooltip=f"{len(actions)} action(s) required" if actions else "All current",
                page={"eq": "eq", "cerpac": "eq", "eepnl": "quotas"}[group_key],
                filters={}
            ))
        
        return tiles
    
    def get_reminder_recipients(self, client_id: int, escalation_stage: int = 0) -> dict[str, list[str]]:
        """Get email recipients for a client based on escalation stage.
        
        stage 0: Owner only
        stage 1: Manager (CC owner)
        stage 2: Partner (CC owner and managers)
        """
        users = self.db.client_users(client_id, active_only=True)
        
        result = {
            "to": [],
            "cc": [],
        }
        
        owners = [u for u in users if u.role == "Owner"]
        managers = [u for u in users if u.role == "Manager"]
        partners = [u for u in users if u.role == "Partner"]
        
        if escalation_stage == 0:
            result["to"] = [u.email for u in owners] if owners else []
        elif escalation_stage == 1:
            result["to"] = [u.email for u in managers] if managers else []
            result["cc"] = [u.email for u in owners]
        elif escalation_stage == 2:
            result["to"] = [u.email for u in partners] if partners else []
            result["cc"] = [u.email for u in owners + managers]
        
        return result
    
    def add_client(self, name: str, industry: str = "") -> int:
        """Create a new client."""
        return self.db.add_client(name, industry)
    
    def add_client_user(self, client_id: int, email: str, name: str, role: str) -> int:
        """Add a user to a client."""
        if role not in ROLES:
            raise ValueError(f"Invalid role: {role}. Must be one of {ROLES}")
        return self.db.add_client_user(client_id, email, name, role)
    
    def update_client_user(self, user_id: int, role: str, name: str = "", active: bool = True) -> None:
        """Update a client user."""
        if role not in ROLES:
            raise ValueError(f"Invalid role: {role}. Must be one of {ROLES}")
        self.db.update_client_user(user_id, role, name, active)
    
    def get_client_settings(self, client_id: int) -> dict:
        """Get reminder rule settings for a client."""
        return self.db.client_settings(client_id)
    
    def set_client_settings(self, client_id: int, settings: dict) -> None:
        """Update reminder rule settings for a client."""
        self.db.set_client_settings(client_id, settings)
