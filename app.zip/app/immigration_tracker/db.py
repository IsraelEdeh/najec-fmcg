"""SQLite persistence. Only user inputs are stored; derived fields come from rules.py."""
from __future__ import annotations

import os
import re
import sqlite3
from dataclasses import dataclass, fields
from datetime import date, datetime
from pathlib import Path

SCHEMA_VERSION = 7
DEFAULT_CLIENT = "Default client"
_CLIENT_TABLES = ("eq_positions", "quotas", "activity_log", "sent_alerts")

MIGRATIONS: dict[int, str] = {
    1: """
    CREATE TABLE quotas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sn INTEGER,
        title TEXT NOT NULL,
        first_grant TEXT,
        expiry TEXT,
        non_renewable_override TEXT,
        current_expat TEXT DEFAULT '',
        previous_incumbent TEXT DEFAULT '',
        category TEXT DEFAULT 'Standard',
        movement TEXT DEFAULT '',
        notes TEXT DEFAULT ''
    );
    CREATE TABLE eq_positions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sn INTEGER,
        title TEXT NOT NULL,
        first_grant TEXT,
        fmi_approval TEXT,
        expat TEXT DEFAULT '',
        cerpac_expiry TEXT,
        quota_id INTEGER REFERENCES quotas(id) ON DELETE SET NULL,
        notes TEXT DEFAULT ''
    );
    CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT);
    """,
    2: """
    CREATE TABLE recipients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL UNIQUE COLLATE NOCASE,
        name TEXT DEFAULT '',
        active INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE sent_alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_key TEXT NOT NULL,
        threshold INTEGER NOT NULL,
        kind TEXT,
        position TEXT,
        person TEXT,
        due_date TEXT,
        sent_at TEXT,
        recipients TEXT,
        UNIQUE(event_key, threshold)
    );
    """,
    3: "",  # settings-only upgrade, handled in _upgrade_settings
    4: """
    CREATE TABLE IF NOT EXISTS activity_log (
        log_id INTEGER PRIMARY KEY AUTOINCREMENT,
        at TEXT NOT NULL,
        action TEXT NOT NULL,
        item_type TEXT,
        item_id TEXT,
        field TEXT,
        old_value TEXT,
        new_value TEXT,
        detail TEXT,
        by_user TEXT
    );
    CREATE INDEX IF NOT EXISTS ix_log_item ON activity_log(item_type, item_id);
    CREATE INDEX IF NOT EXISTS ix_log_action ON activity_log(action);
    """,
    # v5: recipient roles (column added in _migrate so it is safe to re-run) and per-item action status.
    5: """
    CREATE TABLE IF NOT EXISTS matter_status (
        matter TEXT PRIMARY KEY,
        status TEXT NOT NULL,
        updated_at TEXT,
        updated_by TEXT
    );
    """,
    # v6: multi-client support with per-client users and dashboard
    6: """
    CREATE TABLE IF NOT EXISTS clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        industry TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'active',
        created_at TEXT NOT NULL,
        archived_at TEXT
    );
    CREATE TABLE IF NOT EXISTS client_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
        email TEXT NOT NULL,
        name TEXT DEFAULT '',
        role TEXT NOT NULL,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        UNIQUE(client_id, email)
    );
    CREATE INDEX IF NOT EXISTS ix_client_users_client ON client_users(client_id);
    CREATE TABLE IF NOT EXISTS client_settings (
        client_id INTEGER PRIMARY KEY REFERENCES clients(id) ON DELETE CASCADE,
        escalate_owner_days INTEGER DEFAULT 3,
        escalate_manager_days INTEGER DEFAULT 7,
        escalate_partner_days INTEGER DEFAULT 14,
        notify_enabled INTEGER DEFAULT 1,
        notify_thresholds TEXT DEFAULT '7,3,1'
    );
    """,
    7: "",  # every record belongs to a client: handled in _upgrade_clients_v7
}

ROLES = ("Owner", "Manager", "Partner")
STATUS_NOT_STARTED, STATUS_IN_PROGRESS, STATUS_DONE = "Not started", "In progress", "Done"
ACTION_STATUSES = (STATUS_NOT_STARTED, STATUS_IN_PROGRESS, STATUS_DONE)

DEFAULT_NOTIFY_KINDS = ("EQ notification (7 months),CERPAC notification (4 months),CERPAC notification (1 month),"
                        "EEPNL quota notification (7 months),EQ expiry,CERPAC expiry")

# Milestone names used before v3 -> current names (saved in the notify_kinds setting).
_RENAMED_KINDS = {
    "Lead time to blackout": "EQ blackout heads-up",
    "Renewal lead time": "EQ notification (7 months)",
    "System blackout": "EQ blackout starts",
    "CERPAC notification": "CERPAC notification (4 months)",
    "Quota expiry": "EEPNL quota expiry",
    "6-year lifespan ends": "EEPNL quota lifespan ends",
}

DEFAULT_SETTINGS = {
    "theme": "light", "alert_window_days": "90", "quota_lifespan_years": "4",
    "notify_enabled": "0", "notify_method": "outlook", "notify_thresholds": "7,3,1",
    "notify_kinds": DEFAULT_NOTIFY_KINDS,
    "smtp_host": "", "smtp_port": "587", "smtp_security": "starttls", "smtp_user": "",
    "smtp_password": "", "smtp_from": "", "notify_last_run": "", "notify_last_result": "",
    "escalate_enabled": "1", "escalate_owner_days": "3", "escalate_manager_days": "7", "escalate_partner_days": "14",
}


@dataclass
class Recipient:
    id: int | None
    email: str
    name: str = ""
    active: bool = True
    role: str = "Owner"


@dataclass
class EQPosition:
    id: int | None
    sn: int | None
    title: str
    first_grant: date | None
    fmi_approval: date | None
    expat: str = ""
    cerpac_expiry: date | None = None
    quota_id: int | None = None
    notes: str = ""
    client_id: int | None = None


@dataclass
class Quota:
    id: int | None
    sn: int | None
    title: str
    first_grant: date | None
    expiry: date | None
    non_renewable_override: date | None = None
    current_expat: str = ""
    previous_incumbent: str = ""
    category: str = "Standard"
    movement: str = ""
    notes: str = ""
    client_id: int | None = None


@dataclass
class Client:
    id: int | None
    name: str
    industry: str = ""
    status: str = "active"
    created_at: str = ""
    archived_at: str | None = None


@dataclass
class ClientUser:
    id: int | None
    client_id: int
    email: str
    name: str = ""
    role: str = "Manager"
    active: bool = True
    created_at: str = ""



_DATE_FIELDS = {"first_grant", "fmi_approval", "cerpac_expiry", "expiry", "non_renewable_override"}


def _to_db(value):
    return value.isoformat() if isinstance(value, date) else value


def _row_to(cls, row: sqlite3.Row):
    kwargs = {}
    keys = row.keys()
    for f in fields(cls):
        if f.name not in keys:
            continue
        v = row[f.name]
        if f.name in _DATE_FIELDS and v:
            v = date.fromisoformat(v)
        elif f.name in _DATE_FIELDS:
            v = None
        elif v is None and f.type == "str":
            v = ""
        kwargs[f.name] = v
    return cls(**kwargs)


def _matter_client(key: str) -> int | None:
    """Client id from a 'C<id>|…' reminder/status key (keys from before clients have none)."""
    m = re.match(r"(?:ESC\|)?C(\d+)\|", key)
    return int(m.group(1)) if m else None


def default_db_path() -> Path:
    if os.environ.get("IMMIGRATION_TRACKER_DB"):
        return Path(os.environ["IMMIGRATION_TRACKER_DB"])
    base = Path(os.environ.get("APPDATA") or Path.home()) / "ImmigrationTracker"
    base.mkdir(parents=True, exist_ok=True)
    return base / "tracker.db"


class Database:
    def __init__(self, path: Path | str | None = None):
        self.path = str(path or default_db_path())
        self.recovered_from: Path | None = None
        try:
            self._connect()
        except sqlite3.DatabaseError:
            # Damaged database file: set it aside and start fresh rather than refusing to open.
            self.conn.close()
            damaged = Path(self.path).with_name(f"tracker-damaged-{datetime.now():%Y%m%d-%H%M%S}.db")
            Path(self.path).replace(damaged)
            self.recovered_from = damaged
            self._connect()

    def _connect(self) -> None:
        self.conn = sqlite3.connect(self.path, timeout=15)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self._migrate()

    def _migrate(self) -> None:
        current = self.conn.execute("PRAGMA user_version").fetchone()[0]
        for version in range(current + 1, SCHEMA_VERSION + 1):
            with self.conn:
                if MIGRATIONS[version]:
                    self.conn.executescript(MIGRATIONS[version])
                if version == 3 and current >= 1:
                    self._upgrade_settings_v3()
                if version == 5:
                    cols = {r[1] for r in self.conn.execute("PRAGMA table_info(recipients)")}
                    if "role" not in cols:
                        self.conn.execute("ALTER TABLE recipients ADD COLUMN role TEXT NOT NULL DEFAULT 'Owner'")
                    # Emails sent before escalation existed only count from today, so the first run after the
                    # upgrade doesn't escalate weeks-old notices straight to partners.
                    self.conn.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('escalate_since', ?)",
                                      (date.today().isoformat(),))
                if version == 7:
                    self._upgrade_clients_v7()
                self.conn.execute(f"PRAGMA user_version = {version}")
        with self.conn:
            for k, v in DEFAULT_SETTINGS.items():
                self.conn.execute("INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)", (k, v))

    def _upgrade_clients_v7(self) -> None:
        """Add client_id to the data tables and move everything recorded so far into 'Default client'
        (records, reminder history, action statuses, activity, and the old global recipients as its team)."""
        for table in _CLIENT_TABLES:
            cols = {r[1] for r in self.conn.execute(f"PRAGMA table_info({table})")}
            if "client_id" not in cols:
                self.conn.execute(f"ALTER TABLE {table} ADD COLUMN client_id INTEGER REFERENCES clients(id)")
            self.conn.execute(f"CREATE INDEX IF NOT EXISTS ix_{table}_client ON {table}(client_id)")
        has_data = any(self.conn.execute(f"SELECT 1 FROM {t} LIMIT 1").fetchone()
                       for t in ("eq_positions", "quotas", "recipients", "sent_alerts", "matter_status"))
        if not has_data:
            return
        cid = self._ensure_client(DEFAULT_CLIENT)
        for table in _CLIENT_TABLES:
            self.conn.execute(f"UPDATE {table} SET client_id = ? WHERE client_id IS NULL", (cid,))
        # Reminder and status keys gain the client prefix (see notifications.client_prefix) so nothing is resent.
        prefix = f"C{cid}|"
        self.conn.execute("UPDATE sent_alerts SET event_key = CASE WHEN event_key LIKE 'ESC|%' "
                          "THEN 'ESC|' || ? || substr(event_key, 5) ELSE ? || event_key END", (prefix, prefix))
        self.conn.execute("UPDATE matter_status SET matter = ? || matter", (prefix,))
        self.conn.execute("INSERT OR IGNORE INTO client_users(client_id, email, name, role, active, created_at) "
                          "SELECT ?, email, COALESCE(name, ''), COALESCE(role, 'Owner'), active, ? FROM recipients",
                          (cid, datetime.now().isoformat(timespec="seconds")))
        # Open the app on the client that now holds the existing data.
        self.conn.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('current_client', ?)", (str(cid),))

    def _ensure_client(self, name: str) -> int:
        row = self.conn.execute("SELECT id FROM clients WHERE name = ?", (name,)).fetchone()
        if row:
            self.conn.execute("UPDATE clients SET status = 'active', archived_at = NULL WHERE id = ?", (row[0],))
            return row[0]
        return self.conn.execute("INSERT INTO clients(name, industry, status, created_at) VALUES (?, '', 'active', ?)",
                                 (name, datetime.now().isoformat(timespec="seconds"))).lastrowid

    def default_client_id(self) -> int:
        """The first active client (created if there is none); used when a record arrives without a client."""
        row = self.conn.execute("SELECT id FROM clients WHERE status = 'active' ORDER BY id LIMIT 1").fetchone()
        if row:
            return row[0]
        with self.conn:
            return self._ensure_client(DEFAULT_CLIENT)

    @staticmethod
    def _scope(client_id: int | None, column: str = "client_id") -> tuple[str, tuple]:
        """SQL filter: one client, or (None) every active client."""
        if client_id is None:
            return f"{column} IN (SELECT id FROM clients WHERE status = 'active')", ()
        return f"{column} = ?", (client_id,)

    def _upgrade_settings_v3(self) -> None:
        """Rename saved milestone selections and switch on the notices agreed on 11 Nov 2026."""
        row = self.conn.execute("SELECT value FROM settings WHERE key = 'notify_kinds'").fetchone()
        if row is None:
            return
        kinds = [_RENAMED_KINDS.get(k.strip(), k.strip()) for k in (row[0] or "").split(",") if k.strip()]
        for k in DEFAULT_NOTIFY_KINDS.split(","):
            if k not in kinds and "notification" in k:
                kinds.append(k)
        self.conn.execute("UPDATE settings SET value = ? WHERE key = 'notify_kinds'", (",".join(kinds),))

    # settings
    def get_setting(self, key: str) -> str:
        row = self.conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else DEFAULT_SETTINGS.get(key, "")

    def set_setting(self, key: str, value: str) -> None:
        with self.conn:
            self.conn.execute("INSERT OR REPLACE INTO settings(key, value) VALUES (?, ?)", (key, value))

    # generic CRUD
    def _insert(self, table: str, obj) -> int:
        """Insert without committing (caller owns the transaction)."""
        cols = [f.name for f in fields(obj) if f.name != "id"]
        cur = self.conn.execute(
            f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})",
            [_to_db(getattr(obj, c)) for c in cols])
        obj.id = cur.lastrowid
        return obj.id

    def _save(self, table: str, obj) -> int:
        cols = [f.name for f in fields(obj) if f.name != "id"]
        values = [_to_db(getattr(obj, c)) for c in cols]
        with self.conn:
            if obj.id is None:
                self._insert(table, obj)
            else:
                self.conn.execute(
                    f"UPDATE {table} SET {', '.join(c + ' = ?' for c in cols)} WHERE id = ?", [*values, obj.id])
        return obj.id

    def _delete(self, table: str, ids: list[int]) -> None:
        with self.conn:
            self.conn.executemany(f"DELETE FROM {table} WHERE id = ?", [(i,) for i in ids])

    def eq_positions(self, client_id: int | None = None) -> list[EQPosition]:
        where, args = self._scope(client_id)
        rows = self.conn.execute(f"SELECT * FROM eq_positions WHERE {where} ORDER BY sn, id", args).fetchall()
        return [_row_to(EQPosition, r) for r in rows]

    def quotas(self, client_id: int | None = None) -> list[Quota]:
        where, args = self._scope(client_id)
        rows = self.conn.execute(f"SELECT * FROM quotas WHERE {where} ORDER BY sn, id", args).fetchall()
        return [_row_to(Quota, r) for r in rows]

    def save_eq(self, p: EQPosition) -> int:
        if p.client_id is None:
            p.client_id = self.default_client_id()
        return self._save("eq_positions", p)

    def save_quota(self, q: Quota) -> int:
        if q.client_id is None:
            q.client_id = self.default_client_id()
        return self._save("quotas", q)

    def delete_eq(self, ids: list[int]) -> None:
        self._delete("eq_positions", ids)

    def set_fmi_approval(self, ids: list[int], approval: date) -> None:
        with self.conn:
            self.conn.executemany("UPDATE eq_positions SET fmi_approval = ? WHERE id = ?",
                                  [(approval.isoformat(), i) for i in ids])

    def delete_quotas(self, ids: list[int]) -> None:
        self._delete("quotas", ids)

    def next_sn(self, table: str, client_id: int | None = None) -> int:
        if table not in ("eq_positions", "quotas"):
            raise ValueError(table)
        where, args = self._scope(client_id)
        return (self.conn.execute(f"SELECT COALESCE(MAX(sn), 0) FROM {table} WHERE {where}", args).fetchone()[0]) + 1

    # notification recipients
    def recipients(self, active_only: bool = False, role: str | None = None) -> list[Recipient]:
        sql = "SELECT * FROM recipients WHERE 1=1" + (" AND active = 1" if active_only else "")
        args: tuple = ()
        if role:
            sql, args = sql + " AND role = ?", (role,)
        return [Recipient(r["id"], r["email"], r["name"] or "", bool(r["active"]), r["role"] or "Owner")
                for r in self.conn.execute(sql + " ORDER BY role, email", args).fetchall()]

    def add_recipient(self, email: str, name: str = "", role: str = "Owner") -> None:
        with self.conn:
            self.conn.execute("INSERT INTO recipients(email, name, active, role) VALUES (?, ?, 1, ?)",
                              (email, name, role))

    def set_recipient_role(self, rid: int, role: str) -> None:
        with self.conn:
            self.conn.execute("UPDATE recipients SET role = ? WHERE id = ?", (role, rid))

    # action status per item (one expiry of one position/expat); drives escalation
    def matter_statuses(self) -> dict[str, str]:
        return {r[0]: r[1] for r in self.conn.execute("SELECT matter, status FROM matter_status")}

    def set_matter_status(self, matter: str, status: str, label: str = "") -> None:
        old = self.matter_statuses().get(matter, STATUS_NOT_STARTED)
        if old == status:
            return
        with self.conn:
            if status == STATUS_NOT_STARTED:
                self.conn.execute("DELETE FROM matter_status WHERE matter = ?", (matter,))
            else:
                self.conn.execute("INSERT OR REPLACE INTO matter_status(matter, status, updated_at, updated_by) "
                                  "VALUES (?, ?, ?, ?)",
                                  (matter, status, datetime.now().isoformat(timespec="seconds"),
                                   os.environ.get("USERNAME")))
            self._log("Status changed", "milestone", label or matter, "action status", old, status,
                      client_id=_matter_client(matter))

    def set_recipient_active(self, rid: int, active: bool) -> None:
        with self.conn:
            self.conn.execute("UPDATE recipients SET active = ? WHERE id = ?", (int(active), rid))

    def delete_recipients(self, ids: list[int]) -> None:
        self._delete("recipients", ids)

    # clients and client users
    def clients(self, active_only: bool = True) -> list[Client]:
        """Get all clients, optionally filtered to active only."""
        sql = "SELECT * FROM clients"
        if active_only:
            sql += " WHERE status = 'active'"
        sql += " ORDER BY name"
        rows = self.conn.execute(sql).fetchall()
        return [_row_to(Client, r) for r in rows]

    def get_client(self, client_id: int) -> Client | None:
        """Get a client by ID."""
        row = self.conn.execute("SELECT * FROM clients WHERE id = ?", (client_id,)).fetchone()
        return _row_to(Client, row) if row else None

    def add_client(self, name: str, industry: str = "") -> int:
        """Add a new client."""
        with self.conn:
            cur = self.conn.execute(
                "INSERT INTO clients(name, industry, status, created_at) VALUES (?, ?, 'active', ?)",
                (name, industry, datetime.now().isoformat(timespec="seconds"))
            )
            return cur.lastrowid

    def update_client(self, client_id: int, name: str, industry: str) -> None:
        """Update client details."""
        with self.conn:
            self.conn.execute(
                "UPDATE clients SET name = ?, industry = ? WHERE id = ?",
                (name, industry, client_id)
            )

    def archive_client(self, client_id: int) -> None:
        """Archive a client."""
        with self.conn:
            self.conn.execute(
                "UPDATE clients SET status = 'archived', archived_at = ? WHERE id = ?",
                (datetime.now().isoformat(timespec="seconds"), client_id)
            )

    def client_users(self, client_id: int, active_only: bool = True) -> list[ClientUser]:
        """Get users for a specific client."""
        sql = "SELECT * FROM client_users WHERE client_id = ?"
        args: tuple = (client_id,)
        if active_only:
            sql += " AND active = 1"
        sql += " ORDER BY role, email"
        rows = self.conn.execute(sql, args).fetchall()
        return [_row_to(ClientUser, r) for r in rows]

    def add_client_user(self, client_id: int, email: str, name: str, role: str) -> int:
        """Add a user to a client."""
        with self.conn:
            cur = self.conn.execute(
                "INSERT INTO client_users(client_id, email, name, role, active, created_at) "
                "VALUES (?, ?, ?, ?, 1, ?)",
                (client_id, email, name, role, datetime.now().isoformat(timespec="seconds"))
            )
            return cur.lastrowid

    def update_client_user(self, user_id: int, role: str, name: str = "", active: bool = True) -> None:
        """Update client user role and status."""
        with self.conn:
            self.conn.execute(
                "UPDATE client_users SET role = ?, name = ?, active = ? WHERE id = ?",
                (role, name, int(active), user_id)
            )

    def delete_client_user(self, user_id: int) -> None:
        """Delete a client user."""
        with self.conn:
            self.conn.execute("DELETE FROM client_users WHERE id = ?", (user_id,))

    def client_settings(self, client_id: int) -> dict[str, int | str]:
        """Get client-specific reminder settings."""
        row = self.conn.execute("SELECT * FROM client_settings WHERE client_id = ?", (client_id,)).fetchone()
        if not row:
            return {
                "escalate_owner_days": 3,
                "escalate_manager_days": 7,
                "escalate_partner_days": 14,
                "notify_enabled": 1,
                "notify_thresholds": "7,3,1",
            }
        return dict(row)

    def set_client_settings(self, client_id: int, settings: dict[str, int | str]) -> None:
        """Update client-specific reminder settings."""
        with self.conn:
            self.conn.execute(
                "INSERT OR REPLACE INTO client_settings "
                "(client_id, escalate_owner_days, escalate_manager_days, escalate_partner_days, "
                "notify_enabled, notify_thresholds) VALUES (?, ?, ?, ?, ?, ?)",
                (client_id, settings.get("escalate_owner_days", 3),
                 settings.get("escalate_manager_days", 7),
                 settings.get("escalate_partner_days", 14),
                 settings.get("notify_enabled", 1),
                 settings.get("notify_thresholds", "7,3,1"))
            )

    # sent alert log (dedupes reminders per milestone and threshold)
    def sent_alert_keys(self) -> set[tuple[str, int]]:
        return {(r[0], r[1]) for r in self.conn.execute("SELECT event_key, threshold FROM sent_alerts")}

    def claim_alerts(self, rows: list[dict]) -> list[dict]:
        """Atomically reserve alerts; returns only the rows not already claimed by another run."""
        claimed = []
        with self.conn:
            for r in rows:
                cur = self.conn.execute(
                    "INSERT OR IGNORE INTO sent_alerts(event_key, threshold, kind, position, person, due_date, "
                    "sent_at, recipients, client_id) VALUES (:event_key, :threshold, :kind, :position, :person, "
                    ":due_date, :sent_at, :recipients, :client_id)", {"client_id": None, **r})
                if cur.rowcount:
                    claimed.append(r)
        return claimed

    def release_alerts(self, rows: list[dict]) -> None:
        with self.conn:
            self.conn.executemany("DELETE FROM sent_alerts WHERE event_key = ? AND threshold = ?",
                                  [(r["event_key"], r["threshold"]) for r in rows])

    def sent_alerts(self, limit: int = 500, client_id: int | None = None) -> list[sqlite3.Row]:
        where, args = ("1=1", ()) if client_id is None else ("client_id = ?", (client_id,))
        return self.conn.execute(f"SELECT * FROM sent_alerts WHERE {where} ORDER BY sent_at DESC, id DESC LIMIT ?",
                                 (*args, limit)).fetchall()

    def sent_alert_times(self) -> list[tuple[str, int, str]]:
        return [(r[0], r[1], r[2]) for r in self.conn.execute(
            "SELECT event_key, threshold, sent_at FROM sent_alerts WHERE sent_at IS NOT NULL")]

    def replace_all(self, quotas: list[Quota], positions: list[EQPosition], client_id: int | None = None) -> None:
        """Replace one client's records (used by Excel import) in a single transaction: all-or-nothing."""
        cid = client_id if client_id is not None else self.default_client_id()
        title_to_id: dict[str, int] = {}
        with self.conn:
            self.conn.execute("DELETE FROM eq_positions WHERE client_id = ?", (cid,))
            self.conn.execute("DELETE FROM quotas WHERE client_id = ?", (cid,))
            for q in quotas:
                q.id, q.client_id = None, cid
                self._insert("quotas", q)
                title_to_id.setdefault(q.title.strip().upper(), q.id)
            for p in positions:
                p.id, p.client_id = None, cid
                p.quota_id = title_to_id.get(p.title.strip().upper())
                self._insert("eq_positions", p)

    # backups
    @property
    def backup_dir(self) -> Path:
        return Path(self.path).with_name("backups")

    def backup(self, reason: str = "manual", keep: int = 10) -> Path:
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        target = self.backup_dir / f"tracker-{datetime.now():%Y%m%d-%H%M%S}-{reason}.db"
        dest = sqlite3.connect(target)
        try:
            self.conn.backup(dest)
        finally:
            dest.close()
        for old in self.backups()[keep:]:
            old.unlink(missing_ok=True)
        return target

    def backups(self) -> list[Path]:
        if not self.backup_dir.exists():
            return []
        return sorted(self.backup_dir.glob("tracker-*.db"), reverse=True)

    def restore(self, source: Path) -> None:
        src = sqlite3.connect(source)
        try:
            if src.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise sqlite3.DatabaseError("backup file is damaged")
            src.backup(self.conn)
        finally:
            src.close()
        self._migrate()

    # activity logging
    def _log(self, action: str, item_type: str = None, item_id: str = None, field: str = None,
             old_value: str = None, new_value: str = None, detail: str = None, by_user: str = None,
             client_id: int | None = None) -> None:
        """Insert a log row without committing (caller owns the transaction)."""
        self.conn.execute(
            "INSERT INTO activity_log(at, action, item_type, item_id, field, old_value, new_value, detail, by_user, "
            "client_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (datetime.now().isoformat(), action, item_type, item_id, field, old_value, new_value, detail,
             by_user or os.environ.get("USERNAME"), client_id))

    def log_activity(self, action: str, item_type: str = None, item_id: str = None, field: str = None,
                     old_value: str = None, new_value: str = None, detail: str = None, by_user: str = None,
                     client_id: int | None = None) -> None:
        """Log an activity entry."""
        with self.conn:
            self._log(action, item_type, item_id, field, old_value, new_value, detail, by_user, client_id)

    def activity_logs(self, search: str = "", item_type: str = "", limit: int = 2000,
                      client_id: int | None = None) -> list[sqlite3.Row]:
        """Activity entries, newest first; with a client, that client's entries plus app-wide ones."""
        query = "SELECT * FROM activity_log WHERE 1=1"
        params = []
        if client_id is not None:
            query += " AND (client_id = ? OR client_id IS NULL)"
            params.append(client_id)
        if item_type:
            query += " AND item_type = ?"
            params.append(item_type)
        if search:
            query += " AND (item_id LIKE ? OR field LIKE ? OR old_value LIKE ? OR new_value LIKE ? OR detail LIKE ?)"
            search_term = f"%{search}%"
            params.extend([search_term] * 5)
        query += " ORDER BY at DESC LIMIT ?"
        params.append(limit)
        return self.conn.execute(query, params).fetchall()
