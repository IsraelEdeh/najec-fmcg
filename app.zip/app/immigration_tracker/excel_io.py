"""Import from / export to the original Excel workbook layout."""
from __future__ import annotations

import zipfile
from dataclasses import dataclass, field
from datetime import date, datetime

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.utils import get_column_letter
from openpyxl.utils.datetime import from_excel
from openpyxl.utils.exceptions import InvalidFileException

from . import rules as R
from .db import EQPosition, Quota

EQ_SHEET = "EQ & CERPAC Tracker"
QUOTA_SHEET = "EEPNL QUOTAS"

# Theme fill index on the title cell -> legend category (from the Notes column J4:J6).
_THEME_CATEGORY = {5: "Non-renewable", 4: "Exchange Program", 9: "PUR Candidate"}


@dataclass
class ImportReport:
    quotas: list[Quota] = field(default_factory=list)
    positions: list[EQPosition] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    has_quotas: bool = False
    has_eq: bool = False


class ImportFailed(Exception):
    """User-facing import error; the message is shown as-is."""


_DATE_FORMATS = ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d-%b-%Y", "%d %b %Y", "%d-%b-%y", "%d.%m.%Y")


def _as_date(v) -> date | None:
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, (int, float)) and 20000 < v < 80000:  # unformatted Excel serial date
        try:
            return from_excel(v).date()
        except (ValueError, OverflowError):
            return None
    if isinstance(v, str):
        s = v.strip()
        for fmt in _DATE_FORMATS:
            try:
                return datetime.strptime(s, fmt).date()
            except ValueError:
                continue
    return None


def _sn(v) -> int | None:
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v
    if isinstance(v, float) and v.is_integer():
        return int(v)
    if isinstance(v, str) and v.strip().isdigit():
        return int(v.strip())
    return None


def _text(v) -> str:
    return " ".join(str(v).split()) if v is not None else ""


def _norm(v) -> str:
    return _text(v).upper()


def _theme_fill(cell) -> int | None:
    f = cell.fill
    if f is not None and f.fill_type and f.fgColor is not None and f.fgColor.type == "theme":
        return f.fgColor.theme
    return None


def _is_red(cell) -> bool:
    c = cell.font.color if cell.font else None
    return c is not None and c.type == "rgb" and str(c.rgb).upper().endswith("FF0000")


# Header matchers: (field, predicate on normalised header text). First match wins.
_EQ_COLUMNS = [
    ("sn", lambda h: h == "S/N"),
    ("title", lambda h: "EQ POSITION TITLE" in h),
    ("first_grant", lambda h: h.startswith("FIRST GRANT")),
    ("fmi", lambda h: "MOST RECENT FMI" in h),
    ("expat", lambda h: h == "EXPAT"),
    ("cerpac", lambda h: h == "CERPAC EXPIRY"),
]
_QUOTA_COLUMNS = [
    ("sn", lambda h: h == "S/N"),
    ("title", lambda h: "QUOTA POSITION TITLE" in h),
    ("first_grant", lambda h: "FIRST GRANT" in h and "NON-RENEWABLE" not in h),
    ("expiry", lambda h: h.startswith("EXPIRY DATE")),
    ("non_renewable", lambda h: h.startswith("NON-RENEWABLE DATE")),
    ("expat", lambda h: "CURRENT EXPAT" in h),
    ("previous", lambda h: h.startswith("PREVIOUS INCUMBENT")),
    ("category", lambda h: h == "CATEGORY"),
    ("movement", lambda h: h == "MOVEMENT"),
    ("notes", lambda h: h == "NOTES"),
]
_EQ_REQUIRED = {"title": "EQ POSITION TITLE", "first_grant": "FIRST GRANT", "fmi": "MOST RECENT FMI APPROVAL"}
_QUOTA_REQUIRED = {"title": "QUOTA POSITION TITLE", "first_grant": "DATE OF FIRST GRANT", "expiry": "EXPIRY DATE"}


def _find_table(wb, title_marker: str, columns) -> tuple[str, int, dict[str, int]] | None:
    """Locate the sheet/header row containing `title_marker` and map known headers to column numbers."""
    for ws in wb.worksheets:
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 40)):
            if not any(title_marker in _norm(c.value) for c in row):
                continue
            mapping: dict[str, int] = {}
            for c in row:
                h = _norm(c.value)
                for name, match in columns:
                    if name not in mapping and h and match(h):
                        mapping[name] = c.column
                        break
            return ws.title, row[0].row, mapping
    return None


def _open(path: str, data_only: bool):
    try:
        return openpyxl.load_workbook(path, data_only=data_only)
    except FileNotFoundError as exc:
        raise ImportFailed("The file could not be found. It may have been moved or renamed.") from exc
    except PermissionError as exc:
        raise ImportFailed("The file is locked by another program. Close it and try again.") from exc
    except (InvalidFileException, zipfile.BadZipFile) as exc:
        raise ImportFailed("This file can't be read. Save it as an Excel Workbook (.xlsx) without a password "
                           "and try again.") from exc
    except Exception as exc:  # openpyxl raises a wide range of parsing errors for damaged files
        raise ImportFailed(f"The workbook appears to be damaged or uses unsupported content ({exc}).") from exc


def import_workbook(path: str) -> ImportReport:
    wb = _open(path, data_only=False)    # formulas + formatting
    wbv = _open(path, data_only=True)    # cached values for input cells
    rep = ImportReport()

    eq = _find_table(wb, "EQ POSITION TITLE", _EQ_COLUMNS)
    qt = _find_table(wb, "QUOTA POSITION TITLE", _QUOTA_COLUMNS)
    if eq is None and qt is None:
        raise ImportFailed(
            "This doesn't look like an Expatriate Quota & CERPAC tracker: no 'EQ POSITION TITLE' or "
            "'QUOTA POSITION TITLE' column was found in any sheet. Your current data has not been changed.")

    for table, required, label in ((eq, _EQ_REQUIRED, "EQ & CERPAC"), (qt, _QUOTA_REQUIRED, "EEPNL quota")):
        if table is None:
            rep.warnings.append(f"No {label} table found in this workbook; that list will be empty.")
            continue
        missing = [h for k, h in required.items() if k not in table[2]]
        if missing:
            raise ImportFailed(f"The {label} sheet '{table[0]}' is missing required column(s): "
                               f"{', '.join(missing)}. Your current data has not been changed.")

    if qt is not None:
        rep.has_quotas = True
        _read_quotas(wb[qt[0]], wbv[qt[0]], qt[1], qt[2], rep)
    if eq is not None:
        rep.has_eq = True
        _read_positions(wbv[eq[0]], eq[1], eq[2], rep)
    if not rep.positions and not rep.quotas:
        raise ImportFailed("The tracker columns were found but no rows contain a position title. "
                           "Your current data has not been changed.")
    return rep


def _cell(ws, row: int, cols: dict[str, int], name: str):
    col = cols.get(name)
    return ws.cell(row=row, column=col) if col else None


def _val(ws, row: int, cols: dict[str, int], name: str):
    c = _cell(ws, row, cols, name)
    return c.value if c is not None else None


def _read_quotas(ws, wsv, header_row: int, cols: dict[str, int], rep: ImportReport) -> None:
    name = ws.title
    app_cols = "category" in cols  # file written by export_workbook
    for r in range(header_row + 1, ws.max_row + 1):
        title = _text(_val(wsv, r, cols, "title"))
        if not title:
            continue
        first_grant = _as_date(_val(wsv, r, cols, "first_grant"))
        expiry = _as_date(_val(wsv, r, cols, "expiry"))
        raw_nr = _val(ws, r, cols, "non_renewable")
        # Hard-coded dates override the EDATE formula; formula cells are recalculated by the app.
        override = None if isinstance(raw_nr, str) and raw_nr.startswith("=") else _as_date(raw_nr)
        expat_cell = _cell(ws, r, cols, "expat")
        expat = _text(_val(wsv, r, cols, "expat"))
        movement, notes = "", ""
        if app_cols:
            category = _text(_val(wsv, r, cols, "category")) or "Standard"
            movement = _text(_val(wsv, r, cols, "movement"))
            notes = _text(_val(wsv, r, cols, "notes"))
            previous = _text(_val(wsv, r, cols, "previous"))
        else:
            title_cell = _cell(ws, r, cols, "title")
            category = _THEME_CATEGORY.get(_theme_fill(title_cell), "Standard") if title_cell else "Standard"
            if expat.upper().startswith("HOLD FOR"):
                movement, notes, expat = "Hold / Moving In", expat.title(), ""
            elif expat and expat_cell is not None and _is_red(expat_cell):
                movement = "Moving Out"
            expat = expat.title()
            previous = _text(_val(wsv, r, cols, "previous")).title()
        if category not in R.CATEGORIES:
            category = "Standard"
        if movement not in R.MOVEMENTS:
            movement = ""
        if first_grant is None:
            rep.warnings.append(f"{name} row {r} ({title}): missing or unreadable first grant date")
        if expiry is None:
            rep.warnings.append(f"{name} row {r} ({title}): missing or unreadable expiry date")
        rep.quotas.append(Quota(None, _sn(_val(wsv, r, cols, "sn")), title, first_grant, expiry, override,
                                expat, previous, category, movement, notes))


def _read_positions(wsv, header_row: int, cols: dict[str, int], rep: ImportReport) -> None:
    name = wsv.title
    for r in range(header_row + 1, wsv.max_row + 1):
        title = _text(_val(wsv, r, cols, "title"))
        if not title:
            continue
        p = EQPosition(
            id=None, sn=_sn(_val(wsv, r, cols, "sn")), title=title,
            first_grant=_as_date(_val(wsv, r, cols, "first_grant")),
            fmi_approval=_as_date(_val(wsv, r, cols, "fmi")),
            expat=_text(_val(wsv, r, cols, "expat")),
            cerpac_expiry=_as_date(_val(wsv, r, cols, "cerpac")),
        )
        if p.first_grant is None or p.fmi_approval is None:
            rep.warnings.append(f"{name} row {r} ({title}): missing or unreadable first grant / FMI approval date")
        if p.cerpac_expiry is None and not R.is_vacant(p.expat):
            rep.warnings.append(f"{name} row {r} ({p.expat}): no CERPAC expiry date")
        rep.positions.append(p)


# --- Export -----------------------------------------------------------------

_HEADER_FILL = PatternFill("solid", fgColor="1F3A5F")
_HEADER_FONT = Font(bold=True, color="FFFFFF")
_THIN = Side(style="thin", color="D0D5DD")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)
_RED = Font(color="C00000")
_DATE_FMT = "DD-MMM-YYYY"

def eq_headers(lifespan_years: int = R.DEFAULT_LIFESPAN_YEARS) -> list[str]:
    return [
        "S/N", "EQ  POSITION TITLE", "FIRST GRANT ", "MOST RECENT FMI APPROVAL", "EQ EXPIRY\n(FMI approval + 2 years)",
        "VALIDITY  FROM FIRST GRANT - NCDMB", "VALIDITY  FROM FIRST GRANT ",
        f"RENEWABLE - FMI\n({lifespan_years} years from first grant)",
        "BLACK OUT:  OPEN/CLOSED\n(EQ NOT AVAILABLE FOR NEW EXPAT OR CERPAC RENEWAL 6 MONTHS TO EXPIRY - DIGITAL PLATFORM  RESTRICTION)",
        "SYSTEM BLACKOUT DATE\n(6 months to EQ expiry)", "REMAINING SHELF LIFE \n(MONTHS)\n*including renewal",
        "EQ NOTIFICATION\n(7 months to EQ expiry)", "LEAD TIME TO BLACKOUT \n(2 months heads up to Blackout)",
        "EXPAT", "CERPAC EXPIRY", "CERPAC NOTIFICATION #1\n(4 months to expiry)",
        "CERPAC NOTIFICATION #2\n(1 month to expiry)",
    ]


EQ_HEADERS = eq_headers()

# Original layout: columns B..H, header on row 3, data from row 4. L..N hold app-only fields.
QUOTA_HEADERS = {
    "B": "S/N", "C": "QUOTA POSITION TITLE", "D": "DATE OF FIRST GRANT", "E": "EXPIRY DATE",
    "F": "Non-renewable Date (First grant + 6)", "G": "NAME OF CURRENT EXPAT",
    "H": "Previous incumbent name (if different as at 1/1/2025)", "L": "CATEGORY", "M": "MOVEMENT", "N": "NOTES",
}

EQ_HEADER_ROW = 7
QUOTA_HEADER_ROW = 3


def _style_header_cell(c) -> None:
    c.fill, c.font, c.border = _HEADER_FILL, _HEADER_FONT, _BORDER
    c.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")


def export_workbook(path: str, quotas: list[Quota], positions: list[EQPosition],
                    lifespan_years: int = R.DEFAULT_LIFESPAN_YEARS) -> None:
    """Writes inputs + the original Excel formulas in the original layout so the file stays live in Excel."""
    n = lifespan_years
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = EQ_SHEET
    ws["B2"] = "Expatriate Quota & CERPAC Tracker"
    ws["B2"].font = Font(bold=True, size=14)
    for col, h in enumerate(eq_headers(n), start=1):
        _style_header_cell(ws.cell(row=EQ_HEADER_ROW, column=col, value=h))
    ws.row_dimensions[EQ_HEADER_ROW].height = 90
    for i, p in enumerate(positions, start=EQ_HEADER_ROW + 1):
        values = [
            p.sn, p.title, p.first_grant, p.fmi_approval,
            f"=IF(D{i}=\"\",\"\",DATE(YEAR(D{i})+2, MONTH(D{i}), DAY(D{i})))",
            f"=IF(C{i}=\"\",\"\",DATE(YEAR(C{i})+{n}, MONTH(C{i}), DAY(C{i})))",
            f"=IF(C{i}=\"\",\"\",DATE(YEAR(C{i})+{n}, MONTH(C{i}), DAY(C{i})))",
            f"=IF(OR(E{i}=\"\",G{i}=\"\"),\"\",IF(E{i}<G{i}, \"Renewable\", \"Not Renewable\"))",
            f"=IF(E{i}=\"\",\"\",IF(E{i}<=EDATE(TODAY(),6),\"Closed\",\"Open\"))",
            f"=IF(E{i}=\"\",\"\",DATE(YEAR(E{i}), MONTH(E{i})-6, DAY(E{i})))",
            f"=IFERROR(IF(H{i}=\"Not Renewable\", DATEDIF(TODAY(), E{i}, \"M\"), DATEDIF(TODAY(),G{i},\"M\")),\"Expired\")",
            f"=IF(E{i}=\"\",\"\",DATE(YEAR(E{i}), MONTH(E{i})-7, DAY(E{i})))",
            f"=IF(E{i}=\"\",\"\",DATE(YEAR(E{i}), MONTH(E{i})-8, DAY(E{i})))",
            p.expat or "Vacant", p.cerpac_expiry,
            f"=IF(O{i}=\"\",\"\",DATE(YEAR(O{i}), MONTH(O{i})-4, DAY(O{i})))",
            f"=IF(O{i}=\"\",\"\",DATE(YEAR(O{i}), MONTH(O{i})-1, DAY(O{i})))",
        ]
        for col, v in enumerate(values, start=1):
            c = ws.cell(row=i, column=col, value=v)
            c.border = _BORDER
            if col in (3, 4, 5, 6, 7, 10, 12, 13, 15, 16, 17):
                c.number_format = _DATE_FMT
    first = EQ_HEADER_ROW + 1
    last = max(first, EQ_HEADER_ROW + len(positions))
    ws.conditional_formatting.add(f"H{first}:H{last}", CellIsRule(operator="equal", formula=['"Not Renewable"'], font=_RED))
    ws.conditional_formatting.add(f"I{first}:I{last}", CellIsRule(operator="equal", formula=['"Closed"'], font=_RED))
    ws.conditional_formatting.add(f"N{first}:N{last}", CellIsRule(operator="equal", formula=['"Vacant"'], font=_RED))
    for a, b in (("J", "J"), ("L", "M"), ("O", "Q")):
        ws.conditional_formatting.add(
            f"{a}{first}:{b}{last}", FormulaRule(formula=[f"AND({a}{first}<>\"\",{a}{first}<TODAY())"], font=_RED))
    widths = [6, 42, 14, 14, 14, 14, 14, 16, 18, 14, 12, 14, 14, 20, 14, 14, 14]
    for idx, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = w
    ws.freeze_panes = f"C{first}"

    ws2 = wb.create_sheet(QUOTA_SHEET)
    ws2["B2"] = "Existing EEPNL quota positions"
    ws2["B2"].font = Font(bold=True, size=14)
    for col, h in {**QUOTA_HEADERS, "F": f"Non-renewable Date (First grant + {n})"}.items():
        _style_header_cell(ws2[f"{col}{QUOTA_HEADER_ROW}"])
        ws2[f"{col}{QUOTA_HEADER_ROW}"] = h
    ws2.row_dimensions[QUOTA_HEADER_ROW].height = 45
    for i, q in enumerate(quotas, start=QUOTA_HEADER_ROW + 1):
        nr = q.non_renewable_override or f"=IF(D{i}=\"\",\"\",EDATE(D{i},{12 * n}))"
        row = {"B": q.sn, "C": q.title, "D": q.first_grant, "E": q.expiry, "F": nr, "G": q.current_expat,
               "H": q.previous_incumbent, "L": q.category, "M": q.movement, "N": q.notes}
        for col, v in row.items():
            c = ws2[f"{col}{i}"]
            c.value = v
            c.border = _BORDER
            if col in "DEF":
                c.number_format = _DATE_FMT
    for col, w in {"A": 3, "B": 6, "C": 46, "D": 16, "E": 16, "F": 18, "G": 26, "H": 26,
                   "L": 18, "M": 18, "N": 30}.items():
        ws2.column_dimensions[col].width = w
    ws2.freeze_panes = f"D{QUOTA_HEADER_ROW + 1}"
    wb.save(path)
