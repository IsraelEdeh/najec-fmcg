"""Expiry email alerts: due-date logic, digest email, Outlook/SMTP delivery and Windows scheduling."""
from __future__ import annotations

import base64
import html
import logging
import os
import re
import smtplib
import ssl
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from email.message import EmailMessage
from pathlib import Path
from xml.sax.saxutils import escape as xml_escape

from . import rules as R
from .db import ROLES, STATUS_DONE, STATUS_NOT_STARTED, Database
from .services import TrackerService

log = logging.getLogger("immigration_tracker.alerts")

ALERT_KINDS = [R.EV_EQ_NOTIFY, R.EV_CERPAC_NOTIFY, R.EV_CERPAC_FINAL_NOTIFY, R.EV_QUOTA_NOTIFY,
               R.EV_EXPIRY, R.EV_CERPAC_EXPIRY, R.EV_QUOTA_EXPIRY, R.EV_BLACKOUT, R.EV_HEADS_UP,
               R.EV_NON_RENEWABLE]
NOTICE_THRESHOLD = 0  # sent_alerts.threshold value for one-off notices
TASK_NAME = "ImmigrationTracker Expiry Alerts"
_EMAIL_RE = re.compile(r"^[^@\s<>,;\"']+@[^@\s<>,;\"']+\.[A-Za-z]{2,}$")


def valid_email(email: str) -> bool:
    return bool(_EMAIL_RE.match(email.strip()))


def parse_thresholds(text: str) -> list[int]:
    values = sorted({int(p) for p in re.split(r"[,\s]+", text.strip()) if p.isdigit() and 0 < int(p) <= 365})
    return values or [7, 3, 1]


# --- Which alerts are due ---------------------------------------------------

@dataclass
class DueAlert:
    event: R.Event
    threshold: int
    days_left: int  # days until the expiry (notices) or until the milestone (countdown reminders)

    @property
    def key(self) -> str:
        return event_key(self.event)

    @property
    def is_notice(self) -> bool:
        return self.threshold == NOTICE_THRESHOLD

    @property
    def expiry(self) -> date:
        return self.event.anchor or self.event.when

    @property
    def label(self) -> str:
        return "Notice" if self.is_notice else f"{self.threshold}-day reminder"


def client_prefix(e: R.Event) -> str:
    """Keys are per client, so the same position title at two clients never shares reminders or status."""
    return f"C{e.client_id}|" if e.client_id else ""


def event_key(e: R.Event) -> str:
    # Content-based (not row id) so re-importing the workbook doesn't resend reminders;
    # the due date is included so a renewed/edited date starts a fresh reminder cycle.
    return f"{client_prefix(e)}{e.source}|{e.position.upper()}|{e.person.upper()}|{e.kind}|{e.when.isoformat()}"


def matter_key(e: R.Event) -> str:
    """One item to act on: all milestones leading to the same expiry of the same position/expat.
    A renewed expiry date gives a new key, so its status and escalation start afresh."""
    return f"{client_prefix(e)}{e.source}|{e.position.upper()}|{e.person.upper()}|{(e.anchor or e.when).isoformat()}"


def due_alerts(events: list[R.Event], today: date, thresholds: list[int], kinds: set[str],
               already_sent: set[tuple[str, int]], done: set[str] = frozenset()) -> list[DueAlert]:
    """Notices (EQ 7 months, CERPAC 4 and 1 month) go out once from their date until the expiry; the latest
    notice for an expiry supersedes earlier ones. Other milestones get countdown reminders at the tightest
    threshold reached (catches up if a run was missed). Items marked Done get nothing more."""
    ths = sorted(thresholds)
    out: list[DueAlert] = []
    notices: dict[tuple, R.Event] = {}
    for e in events:
        if e.kind not in kinds or matter_key(e) in done:
            continue
        if e.kind in R.NOTICE_KINDS:
            if e.when <= today and e.anchor and e.anchor >= today:
                group = (e.client_id, e.source, e.position.upper(), e.person.upper(), e.anchor)
                if group not in notices or e.when > notices[group].when:
                    notices[group] = e
            continue
        days = (e.when - today).days
        if days < 0 or days > ths[-1]:
            continue
        t = next(t for t in ths if days <= t)
        if (event_key(e), t) not in already_sent:
            out.append(DueAlert(e, t, days))
    for e in notices.values():
        if (event_key(e), NOTICE_THRESHOLD) not in already_sent:
            out.append(DueAlert(e, NOTICE_THRESHOLD, (e.anchor - today).days))
    return sorted(out, key=lambda a: (a.days_left, a.expiry, a.event.position))


# --- Escalation -------------------------------------------------------------------
# Stage n is stored in sent_alerts as threshold -n under the key "ESC|<matter>", so each stage goes out once.
STAGE_ROLE = {1: "Owner", 2: "Manager", 3: "Partner"}
STAGE_SETTING = {1: "escalate_owner_days", 2: "escalate_manager_days", 3: "escalate_partner_days"}
ESC_PREFIX = "ESC|"


@dataclass
class Escalation:
    event: R.Event        # the first milestone emailed for this item
    stage: int
    first_sent: date
    days_waiting: int
    today: date

    @property
    def matter(self) -> str:
        return matter_key(self.event)

    @property
    def key(self) -> str:
        return ESC_PREFIX + self.matter

    @property
    def threshold(self) -> int:
        return -self.stage

    @property
    def role(self) -> str:
        return STAGE_ROLE[self.stage]

    @property
    def expiry(self) -> date:
        return self.event.anchor or self.event.when

    @property
    def days_left(self) -> int:
        return (self.expiry - self.today).days

    @property
    def label(self) -> str:
        return "Second reminder (Owner)" if self.stage == 1 else f"Escalation to {self.role}"


def stage_label(threshold: int) -> str:
    if threshold == NOTICE_THRESHOLD:
        return "Notice"
    if threshold > 0:
        return f"{threshold}-day"
    return "Second reminder (Owner)" if threshold == -1 else f"Escalation to {STAGE_ROLE.get(-threshold, '?')}"


def escalation_days(db: Database) -> dict[int, int]:
    """Days after the first email for each stage; 0 switches a stage off."""
    out = {}
    for stage, key in STAGE_SETTING.items():
        try:
            out[stage] = max(0, int(db.get_setting(key) or 0))
        except ValueError:
            out[stage] = 0
    return out


def due_escalations(events: list[R.Event], sent: list[tuple[str, int, str]], statuses: dict[str, str],
                    today: date, days: dict[int, int], since: date | None = None) -> list[Escalation]:
    """Items still 'Not started' some days after their first notice/reminder (counted from `since` at the
    earliest). Only the highest stage reached is sent (catch-up after the PC was off), and a stage is never
    sent twice."""
    by_key = {event_key(e): e for e in events}
    first: dict[str, tuple[date, R.Event]] = {}
    done_stage: dict[str, int] = {}
    for key, threshold, sent_at in sent:
        if key.startswith(ESC_PREFIX):
            m = key[len(ESC_PREFIX):]
            done_stage[m] = max(done_stage.get(m, 0), -threshold)
            continue
        e = by_key.get(key)
        if e is None or threshold < 0:  # milestone no longer exists (e.g. date renewed)
            continue
        when = date.fromisoformat(sent_at[:10])
        if since and when < since:
            when = since
        m = matter_key(e)
        if m not in first or when < first[m][0]:
            first[m] = (when, e)
    out = []
    for m, (when, e) in first.items():
        if statuses.get(m, STATUS_NOT_STARTED) != STATUS_NOT_STARTED:
            continue
        waited = (today - when).days
        reached = [s for s, d in days.items() if d > 0 and waited >= d]
        if reached and max(reached) > done_stage.get(m, 0):
            out.append(Escalation(e, max(reached), when, waited, today))
    return sorted(out, key=lambda x: (-x.stage, x.days_left, x.event.position))


# --- Email content ------------------------------------------------------------

def _days_text(d: int) -> str:
    if d == 0:
        return "today"
    if d == 1:
        return "tomorrow"
    if d >= 60:
        return f"in {d} days (~{round(d / 30.4)} months)"
    return f"in {d} days"


def build_email(alerts: list[DueAlert], today: date, escalation_note: str = "",
                client: str = "") -> tuple[str, str, str]:
    n = len(alerts)
    soonest = min(a.days_left for a in alerts)
    eq = sum(a.event.source in (R.SRC_EQ, R.SRC_QUOTA) for a in alerts)
    cp = n - eq
    parts = [f"{eq} EQ" if eq else "", f"{cp} CERPAC" if cp else ""]
    subject = (f"Immigration Tracker{' · ' + client if client else ''}: {' + '.join(p for p in parts if p)} "
               f"notification{'s' if n != 1 else ''} (next expiry {_days_text(soonest).split(' (')[0]})")
    rows_html, rows_text = [], []
    for a in alerts:
        e = a.event
        colour = "#D92D20" if a.days_left <= 31 else ("#EF6820" if a.days_left <= 124 else "#B54708")
        cells = [e.source, e.kind, e.position, e.person, a.expiry.strftime("%d-%b-%Y"), _days_text(a.days_left),
                 e.detail]
        rows_html.append(
            "<tr>" + "".join(
                f"<td style='padding:8px 12px;border-bottom:1px solid #EAECF0;vertical-align:top;"
                f"{'color:' + colour + ';font-weight:600;' if i == 5 else ''}'>{html.escape(str(c))}</td>"
                for i, c in enumerate(cells)) + "</tr>")
        rows_text.append(f"- [{e.source}] {e.kind}: {e.position} - {e.person} - expires {cells[4]} "
                         f"({cells[5]}). {e.detail}")
    head = "".join(f"<th style='text-align:left;padding:8px 12px;background:#F2F4F7;color:#475467;"
                   f"font-size:12px'>{h}</th>"
                   for h in ("Type", "Notification", "Position", "Expat", "Expiry date", "Expires", "What to do"))
    body_html = f"""
<div style="font-family:Segoe UI,Arial,sans-serif;color:#101828;font-size:14px">
  <h2 style="margin:0 0 4px;font-size:18px">EQ &amp; CERPAC notifications{(' · ' + html.escape(client)) if client else ''}</h2>
  <p style="margin:0 0 16px;color:#667085">Generated on {today:%d %b %Y} by Immigration Tracker.</p>
  <table style="border-collapse:collapse;min-width:720px">{('<tr>' + head + '</tr>')}{''.join(rows_html)}</table>
  <p style="margin-top:16px;color:#667085;font-size:12px">
    EQ notifications are sent 7 months before EQ expiry (FMI approval + 2 years). CERPAC notifications are sent
    4 months and 1 month before CERPAC expiry. Open Immigration Tracker to review or update records.
  </p>
  {f'<p style="color:#667085;font-size:12px">{html.escape(escalation_note)}</p>' if escalation_note else ''}
</div>"""
    body_text = (f"EQ & CERPAC notifications ({today:%d %b %Y}):\n\n" + "\n".join(rows_text)
                 + "\n\nOpen Immigration Tracker to review or update records."
                 + (f"\n{escalation_note}" if escalation_note else ""))
    return subject, body_html, body_text


def escalation_note(days: dict[int, int]) -> str:
    steps = [f"a second reminder after {d} days" if s == 1 else f"escalation to the {STAGE_ROLE[s].lower()} after {d} days"
             for s, d in sorted(days.items()) if d > 0]
    if not steps:
        return ""
    return ("When you start on an item, open Immigration Tracker > Milestones, select it and click "
            "'Mark in progress' (or 'Mark done' when finished). Items left 'Not started' get "
            + ", then ".join(steps) + ".")


def build_escalation_email(items: list[Escalation], today: date, client: str = "") -> tuple[str, str, str]:
    stage = items[0].stage
    role = STAGE_ROLE[stage]
    n = len(items)
    longest = max(i.days_waiting for i in items)
    tag = f"Immigration Tracker{' · ' + client if client else ''}"
    if stage == 1:
        subject = f"{tag}: reminder - {n} item{'s' if n != 1 else ''} still not started"
        intro = ("These items were emailed to you and have not been marked 'In progress' or 'Done' in "
                 "Immigration Tracker.")
    else:
        subject = (f"{tag}: ESCALATION to {role} - {n} item{'s' if n != 1 else ''} with no action "
                   f"for up to {longest} days")
        intro = (f"You are receiving this as {role}. The owners were notified about these items but nobody has "
                 "marked them 'In progress' or 'Done' in Immigration Tracker. Please follow up with the team.")
    head = "".join(f"<th style='text-align:left;padding:8px 12px;background:#F2F4F7;color:#475467;"
                   f"font-size:12px'>{h}</th>" for h in ("Type", "Notification", "Position", "Expat", "Expiry date",
                                                         "Expires", "First emailed", "Waiting", "What to do"))
    rows_html, rows_text = [], []
    for i in items:
        e = i.event
        cells = [e.source, e.kind, e.position, e.person, i.expiry.strftime("%d-%b-%Y"),
                 _days_text(i.days_left) if i.days_left >= 0 else f"{-i.days_left} days ago",
                 i.first_sent.strftime("%d-%b-%Y"), f"{i.days_waiting} days", e.detail]
        rows_html.append("<tr>" + "".join(
            f"<td style='padding:8px 12px;border-bottom:1px solid #EAECF0;vertical-align:top;"
            f"{'color:#D92D20;font-weight:600;' if k == 7 else ''}'>{html.escape(str(c))}</td>"
            for k, c in enumerate(cells)) + "</tr>")
        rows_text.append(f"- [{e.source}] {e.kind}: {e.position} - {e.person} - expires {cells[4]}; first emailed "
                         f"{cells[6]} ({cells[7]} ago). {e.detail}")
    how = ("To stop these emails, open Immigration Tracker > Milestones, select the item and click "
           "'Mark in progress' or 'Mark done'.")
    body_html = f"""
<div style="font-family:Segoe UI,Arial,sans-serif;color:#101828;font-size:14px">
  <h2 style="margin:0 0 4px;font-size:18px;color:{'#101828' if stage == 1 else '#B42318'}">{html.escape(subject.split(': ', 1)[1])}</h2>
  <p style="margin:0 0 16px;color:#475467">{html.escape(intro)}</p>
  <table style="border-collapse:collapse;min-width:720px"><tr>{head}</tr>{''.join(rows_html)}</table>
  <p style="margin-top:16px;color:#667085;font-size:12px">{html.escape(how)}</p>
</div>"""
    body_text = f"{intro}\n\n" + "\n".join(rows_text) + f"\n\n{how}"
    return subject, body_html, body_text


# --- Secrets ----------------------------------------------------------------

def protect(secret: str) -> str:
    """Encrypt with Windows DPAPI (current user only)."""
    if not secret:
        return ""
    import win32crypt
    return base64.b64encode(win32crypt.CryptProtectData(secret.encode(), None, None, None, None, 0)).decode()


def unprotect(blob: str) -> str:
    if not blob:
        return ""
    import win32crypt
    return win32crypt.CryptUnprotectData(base64.b64decode(blob), None, None, None, 0)[1].decode()


# --- Delivery -------------------------------------------------------------------

class DeliveryError(Exception):
    pass


def send_email(db: Database, to: list[str], subject: str, body_html: str, body_text: str,
               cc: list[str] | None = None) -> None:
    if not to:
        raise DeliveryError("No active recipients. Add at least one email address.")
    cc = [c for c in (cc or []) if c.lower() not in {t.lower() for t in to}]
    method = db.get_setting("notify_method")
    if method == "smtp":
        _send_smtp(db, to, subject, body_html, body_text, cc)
    else:
        _send_outlook(to, subject, body_html, cc)


def _send_outlook(to: list[str], subject: str, body_html: str, cc: list[str] | None = None) -> None:
    try:
        import pythoncom
        import win32com.client
        pythoncom.CoInitialize()
        try:
            outlook = win32com.client.Dispatch("Outlook.Application")
            mail = outlook.CreateItem(0)
            mail.To = "; ".join(to)
            if cc:
                mail.CC = "; ".join(cc)
            mail.Subject = subject
            mail.HTMLBody = body_html
            mail.Send()
        finally:
            pythoncom.CoUninitialize()
    except ImportError as exc:
        raise DeliveryError("Outlook integration is unavailable on this machine.") from exc
    except Exception as exc:
        raise DeliveryError(f"Outlook could not send the email: {exc}") from exc


def _send_smtp(db: Database, to: list[str], subject: str, body_html: str, body_text: str,
               cc: list[str] | None = None) -> None:
    host = db.get_setting("smtp_host").strip()
    sender = db.get_setting("smtp_from").strip() or db.get_setting("smtp_user").strip()
    if not host or not sender:
        raise DeliveryError("SMTP host and sender address are required.")
    port = int(db.get_setting("smtp_port") or 587)
    security = db.get_setting("smtp_security")
    user = db.get_setting("smtp_user").strip()
    msg = EmailMessage()
    msg["Subject"], msg["From"], msg["To"] = subject, sender, ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg.set_content(body_text)
    msg.add_alternative(body_html, subtype="html")
    ctx = ssl.create_default_context()
    try:
        if security == "ssl":
            server = smtplib.SMTP_SSL(host, port, context=ctx, timeout=30)
        else:
            server = smtplib.SMTP(host, port, timeout=30)
            if security == "starttls":
                server.starttls(context=ctx)
        with server:
            if user:
                server.login(user, unprotect(db.get_setting("smtp_password")))
            server.send_message(msg)
    except (OSError, smtplib.SMTPException) as exc:
        raise DeliveryError(f"SMTP error: {exc}") from exc


# --- Run ----------------------------------------------------------------------------

@dataclass
class RunResult:
    sent: int = 0
    recipients: list[str] = field(default_factory=list)
    escalated: int = 0
    error: str = ""
    skipped_reason: str = ""
    warnings: list[str] = field(default_factory=list)

    def summary(self) -> str:
        if self.error:
            return f"Failed: {self.error}"
        if self.skipped_reason:
            return self.skipped_reason
        parts = []
        if self.sent:
            parts.append(f"Sent {self.sent} reminder(s) to {len(self.recipients)} recipient(s).")
        if self.escalated:
            parts.append(f"Sent {self.escalated} follow-up/escalation(s).")
        parts += self.warnings
        return " ".join(parts) or "No reminders due."


def _done_matters(db: Database) -> set[str]:
    return {m for m, s in db.matter_statuses().items() if s == STATUS_DONE}


def pending_alerts(db: Database, svc: TrackerService) -> list[DueAlert]:
    kinds = {k.strip() for k in db.get_setting("notify_kinds").split(",") if k.strip()}
    return due_alerts(svc.events, svc.today, parse_thresholds(db.get_setting("notify_thresholds")),
                      kinds, db.sent_alert_keys(), _done_matters(db))


def pending_escalations(db: Database, svc: TrackerService) -> list[Escalation]:
    if db.get_setting("escalate_enabled") != "1":
        return []
    since = db.get_setting("escalate_since")
    return due_escalations(svc.events, db.sent_alert_times(), db.matter_statuses(), svc.today,
                           escalation_days(db), date.fromisoformat(since) if since else None)


def _team(db: Database, client_id: int | None, role: str) -> list[str]:
    if client_id is None:
        return []
    return [u.email for u in db.client_users(client_id, active_only=True) if u.role == role]


def _row(item, recipients: list[str], now: str) -> dict:
    e = item.event
    return {"event_key": item.key, "threshold": item.threshold, "kind": e.kind, "position": e.position,
            "person": e.person, "due_date": (item.expiry if item.threshold < 0 else e.when).isoformat(),
            "sent_at": now, "recipients": "; ".join(recipients), "client_id": e.client_id}


def _deliver(db: Database, items: list, to: list[str], cc: list[str], build, now: str) -> tuple[int, str]:
    """Claim, send, and release on failure. Returns (number sent, error)."""
    rows = [_row(i, to + cc, now) for i in items]
    claimed = {(r["event_key"], r["threshold"]) for r in db.claim_alerts(rows)}
    items = [i for i in items if (i.key, i.threshold) in claimed]
    if not items:
        return 0, ""
    subject, body_html, body_text = build(items)
    try:
        send_email(db, to, subject, body_html, body_text, cc)
    except DeliveryError as exc:
        db.release_alerts([r for r in rows if (r["event_key"], r["threshold"]) in claimed])
        return 0, str(exc)
    return len(items), ""


def run_alerts(db: Database, svc: TrackerService, require_enabled: bool = True) -> RunResult:
    """Send every client's due reminders and escalations to that client's own team (same rules for all)."""
    res = RunResult()
    if require_enabled and db.get_setting("notify_enabled") != "1":
        res.skipped_reason = "Automatic alerts are turned off."
        return res
    full = TrackerService(db, svc._today)  # every active client, whichever client the screen is showing
    # Stamp with the app's date so escalation waiting time is counted on the same calendar as 'today'.
    now = datetime.combine(full.today, datetime.now().time()).isoformat(timespec="seconds")
    alerts_all, esc_all = pending_alerts(db, full), pending_escalations(db, full)
    note = escalation_note(escalation_days(db)) if db.get_setting("escalate_enabled") == "1" else ""
    recipients: set[str] = set()
    for cid in sorted({a.event.client_id for a in alerts_all} | {x.event.client_id for x in esc_all},
                      key=lambda c: (c is None, c or 0)):
        name = full.client_name(cid) or "Unassigned records"
        owners, managers, partners = (_team(db, cid, r) for r in ROLES)
        alerts = [a for a in alerts_all if a.event.client_id == cid]
        if alerts and not owners:
            res.warnings.append(f"{name}: {len(alerts)} reminder(s) are due but there is no active Owner. "
                                "Add one in Data & Settings → Clients.")
        elif alerts:
            n, res.error = _deliver(db, alerts, owners, [],
                                    lambda items: build_email(items, full.today, note, name), now)
            res.sent += n
            if n:
                recipients.update(owners)
            if res.error:
                break
        targets = {1: (owners, []), 2: (managers, owners), 3: (partners, owners + managers)}
        for stage in (1, 2, 3):
            items = [x for x in esc_all if x.stage == stage and x.event.client_id == cid]
            if not items:
                continue
            to, cc = targets[stage]
            if not to:  # left pending, so it goes out once someone with this role is added
                res.warnings.append(f"{name}: {len(items)} item(s) need escalation to a {STAGE_ROLE[stage]}, but "
                                    f"no active {STAGE_ROLE[stage]} is on the client's team.")
                continue
            n, res.error = _deliver(db, items, to, cc,
                                    lambda its: build_escalation_email(its, full.today, name), now)
            res.escalated += n
            if res.error:
                break
        if res.error:
            break
    res.recipients = sorted(recipients)
    db.set_setting("notify_last_run", datetime.now().isoformat(timespec="seconds"))
    db.set_setting("notify_last_result", res.summary())
    log.info(res.summary())
    return res


def send_test_email(db: Database, client_id: int | None = None) -> None:
    """Test email to the active team of one client (or of every client)."""
    ids = [client_id] if client_id is not None else [c.id for c in db.clients()]
    to = sorted({u.email for cid in ids for u in db.client_users(cid, active_only=True)})
    if not to:
        raise DeliveryError("No active team members. Add them in Data & Settings → Clients.")
    send_email(db, to, "Immigration Tracker: test notification",
               "<div style='font-family:Segoe UI,Arial,sans-serif'><h3>Test notification</h3>"
               "<p>Email alerts from Immigration Tracker are configured correctly.</p></div>",
               "Email alerts from Immigration Tracker are configured correctly.")


# --- Windows Task Scheduler ---------------------------------------------------

def _launch_command() -> tuple[str, str]:
    if getattr(sys, "frozen", False):
        return sys.executable, "--send-alerts"
    pythonw = Path(sys.executable).with_name("pythonw.exe")
    exe = str(pythonw if pythonw.exists() else sys.executable)
    script = Path(__file__).resolve().parent.parent / "main.py"
    return exe, f'"{script}" --send-alerts'


def install_scheduled_task(at: str = "08:00") -> None:
    """Daily run at `at`, at logon, and catch-up when the PC was off (StartWhenAvailable)."""
    exe, args = _launch_command()
    user = f"{os.environ.get('USERDOMAIN', '')}\\{os.environ.get('USERNAME', '')}".lstrip("\\")
    start = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d") + f"T{at}:00"
    xml = f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Description>Sends Immigration Tracker EQ and CERPAC notifications.</Description></RegistrationInfo>
  <Triggers>
    <CalendarTrigger><StartBoundary>{start}</StartBoundary><ScheduleByDay><DaysInterval>1</DaysInterval></ScheduleByDay></CalendarTrigger>
    <LogonTrigger><UserId>{xml_escape(user)}</UserId><Delay>PT5M</Delay></LogonTrigger>
  </Triggers>
  <Principals><Principal id="Author"><UserId>{xml_escape(user)}</UserId><LogonType>InteractiveToken</LogonType><RunLevel>LeastPrivilege</RunLevel></Principal></Principals>
  <Settings>
    <StartWhenAvailable>true</StartWhenAvailable>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <ExecutionTimeLimit>PT10M</ExecutionTimeLimit>
  </Settings>
  <Actions Context="Author"><Exec><Command>{xml_escape(exe)}</Command><Arguments>{xml_escape(args)}</Arguments></Exec></Actions>
</Task>"""
    fd, path = tempfile.mkstemp(suffix=".xml")
    os.close(fd)
    try:
        Path(path).write_text(xml, encoding="utf-16")
        _schtasks(["/Create", "/TN", TASK_NAME, "/XML", path, "/F"])
    finally:
        Path(path).unlink(missing_ok=True)


def remove_scheduled_task() -> None:
    _schtasks(["/Delete", "/TN", TASK_NAME, "/F"])


def scheduled_task_installed() -> bool:
    try:
        _schtasks(["/Query", "/TN", TASK_NAME])
        return True
    except DeliveryError:
        return False


def _schtasks(args: list[str]) -> str:
    proc = subprocess.run(["schtasks", *args], capture_output=True, text=True,
                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if proc.returncode != 0:
        raise DeliveryError((proc.stderr or proc.stdout).strip() or "schtasks failed")
    return proc.stdout


def setup_file_logging() -> None:
    from .db import default_db_path
    logging.basicConfig(filename=str(default_db_path().with_name("alerts.log")), level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
