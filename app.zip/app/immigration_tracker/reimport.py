"""Compare an Excel import with the records already in the app, so a second import updates instead of wiping.

Records are matched by S/N + title, then by title alone when that title is unique on both sides.
Merge rules (file wins, except where a blank cell would erase app data):
- dates: a blank/unreadable date in the file keeps the date already in the app
- expat names: the file wins, including blank (= the position is now vacant)
- notes, movement, non-renewable override: a blank in the file keeps the app's value
- EQ notes and the EQ -> quota link are app-only and are kept
"""
from __future__ import annotations

from dataclasses import dataclass, field, fields, replace

from .db import EQPosition, Quota

NEW, UPDATED, UNCHANGED, NOT_IN_FILE = "New", "Updated", "Unchanged", "Not in file"

_QUOTA_FIELDS = ("sn", "title", "first_grant", "expiry", "non_renewable_override", "current_expat",
                 "previous_incumbent", "category", "movement", "notes")
_EQ_FIELDS = ("sn", "title", "first_grant", "fmi_approval", "expat", "cerpac_expiry")
_KEEP_IF_BLANK = {"first_grant", "expiry", "fmi_approval", "cerpac_expiry", "non_renewable_override",
                  "movement", "notes"}

FIELD_LABELS = {
    "sn": "S/N", "title": "title", "first_grant": "first grant", "expiry": "expiry",
    "non_renewable_override": "non-renewable date", "current_expat": "current expat",
    "previous_incumbent": "previous incumbent", "category": "category", "movement": "movement", "notes": "notes",
    "fmi_approval": "FMI approval", "expat": "expat", "cerpac_expiry": "CERPAC expiry",
}


@dataclass
class Change:
    kind: str                       # "quota" or "eq_position"
    action: str                     # NEW / UPDATED / UNCHANGED / NOT_IN_FILE
    record: Quota | EQPosition      # the record to save (merged), or the existing one for NOT_IN_FILE
    changed: list[tuple[str, object, object]] = field(default_factory=list)  # (field, old, new)

    def describe(self) -> str:
        r = self.record
        head = f"{'Quota' if self.kind == 'quota' else 'EQ'} #{r.sn or '-'} {r.title}"
        if self.action == UPDATED:
            return f"{head}: " + ", ".join(f"{FIELD_LABELS[f]} {_show(o)} -> {_show(n)}" for f, o, n in self.changed)
        return f"{head}: {self.action.lower()}"


@dataclass
class ImportPlan:
    quotas: list[Change] = field(default_factory=list)
    positions: list[Change] = field(default_factory=list)
    has_quotas: bool = True
    has_eq: bool = True

    def count(self, kind: str, action: str) -> int:
        return sum(1 for c in (self.quotas if kind == "quota" else self.positions) if c.action == action)

    @property
    def has_changes(self) -> bool:
        return any(c.action != UNCHANGED for c in self.quotas + self.positions)

    @property
    def not_in_file(self) -> int:
        return self.count("quota", NOT_IN_FILE) + self.count("eq_position", NOT_IN_FILE)


def _show(v) -> str:
    if v in (None, ""):
        return "(blank)"
    return v.strftime("%d-%b-%Y") if hasattr(v, "strftime") else str(v)


def _norm(title: str) -> str:
    return " ".join((title or "").split()).upper()


def _match(existing: list, incoming: list) -> tuple[list[tuple[object, object]], list, list]:
    """Returns (pairs of (existing, incoming), unmatched incoming, unmatched existing)."""
    left = list(existing)
    pairs, rest = [], []
    for rec in incoming:
        hit = next((e for e in left if e.sn == rec.sn and _norm(e.title) == _norm(rec.title)), None)
        if hit is None:
            rest.append(rec)
        else:
            left.remove(hit)
            pairs.append((hit, rec))
    unmatched = []
    for rec in rest:
        t = _norm(rec.title)
        same_left = [e for e in left if _norm(e.title) == t]
        same_rest = [r for r in rest if _norm(r.title) == t]
        if len(same_left) == 1 and len(same_rest) == 1:  # unique title on both sides: S/N was renumbered
            left.remove(same_left[0])
            pairs.append((same_left[0], rec))
        else:
            unmatched.append(rec)
    return pairs, unmatched, left


def _merge(kind: str, old, new, names: tuple[str, ...]) -> Change:
    merged = replace(old)
    changed = []
    for name in names:
        value = getattr(new, name)
        if name in _KEEP_IF_BLANK and value in (None, ""):
            continue
        if getattr(old, name) != value:
            changed.append((name, getattr(old, name), value))
            setattr(merged, name, value)
    return Change(kind, UPDATED if changed else UNCHANGED, merged, changed)


def plan_import(existing_quotas: list[Quota], existing_positions: list[EQPosition], incoming_quotas: list[Quota],
                incoming_positions: list[EQPosition], has_quotas: bool = True, has_eq: bool = True) -> ImportPlan:
    plan = ImportPlan(has_quotas=has_quotas, has_eq=has_eq)
    for kind, existing, incoming, names, out, present in (
            ("quota", existing_quotas, incoming_quotas, _QUOTA_FIELDS, plan.quotas, has_quotas),
            ("eq_position", existing_positions, incoming_positions, _EQ_FIELDS, plan.positions, has_eq)):
        if not present:  # table missing from the workbook: leave the app's records alone
            continue
        pairs, new, gone = _match(existing, incoming)
        out.extend(_merge(kind, old, rec, names) for old, rec in pairs)
        out.extend(Change(kind, NEW, replace(rec, id=None)) for rec in new)
        out.extend(Change(kind, NOT_IN_FILE, old) for old in gone)
    return plan


def apply_import(db, plan: ImportPlan, remove_missing: bool, source: str = "",
                 client_id: int | None = None) -> dict[str, int]:
    """Writes the plan into one client in one transaction (all-or-nothing) and records it in Activity History."""
    cid = client_id if client_id is not None else db.default_client_id()
    counts = {NEW: 0, UPDATED: 0, UNCHANGED: 0, "Removed": 0, "Kept": 0}
    tables = {"quota": "quotas", "eq_position": "eq_positions"}
    with db.conn:
        for change in plan.quotas + plan.positions:
            table, rec = tables[change.kind], change.record
            if change.action == NEW:
                rec.client_id = cid
                db._insert(table, rec)
                db._log("Imported", change.kind, rec.title, detail=f"Added from {source}" if source else "Added",
                        client_id=cid)
            elif change.action == UPDATED:
                cols = [f.name for f in fields(rec) if f.name != "id"]
                db.conn.execute(f"UPDATE {table} SET {', '.join(c + ' = ?' for c in cols)} WHERE id = ?",
                                [_db_value(getattr(rec, c)) for c in cols] + [rec.id])
                for name, old, new in change.changed:
                    db._log("Updated by import", change.kind, rec.title, FIELD_LABELS[name], _show(old), _show(new),
                            source or None, client_id=cid)
            elif change.action == NOT_IN_FILE:
                if remove_missing:
                    db.conn.execute(f"DELETE FROM {table} WHERE id = ?", (rec.id,))
                    db._log("Removed by import", change.kind, rec.title, detail=f"Not in {source or 'the file'}",
                            client_id=cid)
                    counts["Removed"] += 1
                else:
                    counts["Kept"] += 1
                continue
            counts[change.action] += 1
        # Link EQ positions without a valid quota to the same client's quota with the same title (links kept).
        quota_ids = {}
        for qid, title in db.conn.execute("SELECT id, title FROM quotas WHERE client_id = ? ORDER BY sn, id", (cid,)):
            quota_ids.setdefault(_norm(title), qid)
        for pid, title in db.conn.execute(
                "SELECT id, title FROM eq_positions WHERE client_id = ? AND (quota_id IS NULL OR quota_id NOT IN "
                "(SELECT id FROM quotas WHERE client_id = ?))", (cid, cid)).fetchall():
            db.conn.execute("UPDATE eq_positions SET quota_id = ? WHERE id = ?", (quota_ids.get(_norm(title)), pid))
        db._log("Workbook imported", detail=(
            f"{source + ': ' if source else ''}{counts[NEW]} added, {counts[UPDATED]} updated, "
            f"{counts[UNCHANGED]} unchanged, " + (f"{counts['Removed']} removed" if remove_missing
                                                   else f"{counts['Kept']} not in file kept")), client_id=cid)
    return counts


def _db_value(v):
    return v.isoformat() if hasattr(v, "isoformat") else v
