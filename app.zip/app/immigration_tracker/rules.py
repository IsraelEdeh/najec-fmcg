"""Business rules from the Excel tracker plus the rules agreed with the client (11 Nov 2026)."""
from __future__ import annotations

import calendar
from dataclasses import dataclass, field
from datetime import date, timedelta

# --- Excel date primitives -------------------------------------------------

def excel_date(year: int, month: int, day: int) -> date:
    """Excel DATE(): month and day overflow roll forward (30-Feb -> 02-Mar)."""
    year += (month - 1) // 12
    month = (month - 1) % 12 + 1
    return date(year, month, 1) + timedelta(days=day - 1)


def add_years(d: date | None, years: int) -> date | None:
    """DATE(YEAR(d)+n, MONTH(d), DAY(d))."""
    return None if d is None else excel_date(d.year + years, d.month, d.day)


def add_months(d: date | None, months: int) -> date | None:
    """DATE(YEAR(d), MONTH(d)+n, DAY(d))."""
    return None if d is None else excel_date(d.year, d.month + months, d.day)


def edate(d: date | None, months: int) -> date | None:
    """Excel EDATE(): clamps to the last day of the target month."""
    if d is None:
        return None
    total = d.year * 12 + (d.month - 1) + months
    y, m = divmod(total, 12)
    m += 1
    return date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def datedif_months(start: date | None, end: date | None) -> int | None:
    """Excel DATEDIF(start, end, "M"); None where Excel returns #NUM!."""
    if start is None or end is None or end < start:
        return None
    months = (end.year - start.year) * 12 + (end.month - start.month)
    if end.day < start.day:
        months -= 1
    return months


# --- Agreed timing rules (client meeting 11 Nov 2026) ------------------------

EQ_VALIDITY_YEARS = 2          # EQ expiry = most recent FMI approval + 2 years
DEFAULT_LIFESPAN_YEARS = 4     # maximum quota lifespan from first grant (configurable in Data & Settings)
EQ_NOTIFY_MONTHS = 7           # EQ notification: 7 months before EQ expiry
BLACKOUT_MONTHS = 6            # blackout closes 6 months before EQ expiry
HEADS_UP_MONTHS = 8            # heads-up: 2 months before blackout
CERPAC_NOTIFY_MONTHS = 4       # CERPAC notification #1
CERPAC_FINAL_NOTIFY_MONTHS = 1  # CERPAC notification #2


# --- Status vocabulary -----------------------------------------------------

RENEWABLE = "Renewable"
NOT_RENEWABLE = "Not Renewable"
OPEN = "Open"
CLOSED = "Closed"
VACANT = "Vacant"
NOT_SET = "Not Set"

# EQ status (EQ positions and EEPNL quotas share the same progression)
ST_OK = "On Track"
ST_HEADS_UP = "Heads-up"
ST_NOTIFY = "EQ Notify"
ST_BLACKOUT = "EQ Blackout"
ST_EXPIRED = "EQ Expired"
EQ_STATUSES = [ST_OK, ST_HEADS_UP, ST_NOTIFY, ST_BLACKOUT, ST_EXPIRED, NOT_SET]
QUOTA_STATUSES = [ST_OK, ST_NOTIFY, ST_BLACKOUT, ST_EXPIRED, NOT_SET]

# Renewal lifecycle: separates "will become non-renewable" from "expired and cannot be renewed".
LC_RENEWABLE = "Renewable"
LC_FINAL_TERM = "Final term"
LC_EXPIRED_RENEWABLE = "Expired – renewable"
LC_EXPIRED_FINAL = "Expired – non-renewable"
LIFECYCLES = [LC_RENEWABLE, LC_FINAL_TERM, LC_EXPIRED_RENEWABLE, LC_EXPIRED_FINAL]

CERPAC_VALID = "Valid"
CERPAC_NOTIFY = "4-month notice"
CERPAC_FINAL_NOTIFY = "1-month notice"
CERPAC_EXPIRED = "CERPAC Expired"
CERPAC_MISSING = NOT_SET
CERPAC_STATUSES = [CERPAC_VALID, CERPAC_NOTIFY, CERPAC_FINAL_NOTIFY, CERPAC_EXPIRED, CERPAC_MISSING]

CATEGORIES = ["Standard", "Exchange Program", "PUR Candidate", "Non-renewable"]
MOVEMENTS = ["", "Moving Out", "Hold / Moving In"]


def is_vacant(expat: str | None) -> bool:
    return not expat or expat.strip().lower() == "vacant"


def lifecycle(expiry: date | None, lifespan_end: date | None, today: date) -> str | None:
    """Renewal position of a quota: renewable, final term, or expired (renewable or not)."""
    if expiry is None or lifespan_end is None:
        return None
    if expiry < today:
        return LC_EXPIRED_FINAL if expiry >= lifespan_end or today >= lifespan_end else LC_EXPIRED_RENEWABLE
    return LC_FINAL_TERM if expiry >= lifespan_end else LC_RENEWABLE


def eq_status(expiry: date | None, today: date, heads_up: bool = True) -> str:
    if expiry is None:
        return NOT_SET
    if expiry < today:
        return ST_EXPIRED
    if expiry <= edate(today, BLACKOUT_MONTHS):
        return ST_BLACKOUT
    if today >= add_months(expiry, -EQ_NOTIFY_MONTHS):
        return ST_NOTIFY
    if heads_up and today >= add_months(expiry, -HEADS_UP_MONTHS):
        return ST_HEADS_UP
    return ST_OK


def cerpac_status(cerpac_expiry: date | None, today: date) -> str:
    if cerpac_expiry is None:
        return CERPAC_MISSING
    if cerpac_expiry < today:
        return CERPAC_EXPIRED
    if today >= add_months(cerpac_expiry, -CERPAC_FINAL_NOTIFY_MONTHS):
        return CERPAC_FINAL_NOTIFY
    if today >= add_months(cerpac_expiry, -CERPAC_NOTIFY_MONTHS):
        return CERPAC_NOTIFY
    return CERPAC_VALID


# --- Sheet 1: EQ & CERPAC Tracker ------------------------------------------

@dataclass
class EQComputed:
    expiry: date | None = None                 # E  EQ expiry
    validity_ncdmb: date | None = None         # F
    validity: date | None = None               # G  lifespan end (first grant + lifespan)
    renewable: str | None = None               # H
    blackout: str | None = None                # I
    blackout_date: date | None = None          # J
    shelf_life_months: int | None = None       # K
    eq_notification: date | None = None        # L  EQ notification (7 months)
    lead_to_blackout: date | None = None       # M  heads-up (8 months)
    cerpac_notification: date | None = None    # P  CERPAC notification #1 (4 months)
    cerpac_final_notification: date | None = None  # CERPAC notification #2 (1 month)
    status: str = NOT_SET
    lifecycle: str | None = None
    cerpac_status: str = CERPAC_MISSING
    vacant: bool = False


def compute_eq(first_grant: date | None, fmi_approval: date | None,
               expat: str | None, cerpac_expiry: date | None,
               today: date, lifespan_years: int = DEFAULT_LIFESPAN_YEARS) -> EQComputed:
    c = EQComputed(vacant=is_vacant(expat))
    c.expiry = add_years(fmi_approval, EQ_VALIDITY_YEARS)
    c.validity_ncdmb = add_years(first_grant, lifespan_years)
    c.validity = add_years(first_grant, lifespan_years)
    if c.expiry and c.validity:
        c.renewable = RENEWABLE if c.expiry < c.validity else NOT_RENEWABLE
    if c.expiry:
        c.blackout = CLOSED if c.expiry <= edate(today, BLACKOUT_MONTHS) else OPEN
        c.blackout_date = add_months(c.expiry, -BLACKOUT_MONTHS)
        c.eq_notification = add_months(c.expiry, -EQ_NOTIFY_MONTHS)
        c.lead_to_blackout = add_months(c.expiry, -HEADS_UP_MONTHS)
        target = c.expiry if c.renewable == NOT_RENEWABLE or c.validity is None else c.validity
        c.shelf_life_months = datedif_months(today, target)
    c.cerpac_notification = add_months(cerpac_expiry, -CERPAC_NOTIFY_MONTHS)
    c.cerpac_final_notification = add_months(cerpac_expiry, -CERPAC_FINAL_NOTIFY_MONTHS)
    c.status = eq_status(c.expiry, today)
    c.lifecycle = lifecycle(c.expiry, c.validity, today)
    c.cerpac_status = cerpac_status(cerpac_expiry, today)
    return c


# --- Sheet 2: EEPNL QUOTAS --------------------------------------------------

@dataclass
class QuotaComputed:
    non_renewable_date: date | None = None     # lifespan end (first grant + lifespan, unless overridden)
    notification: date | None = None          # EQ notification (7 months before expiry)
    blackout_date: date | None = None
    status: str = NOT_SET
    lifecycle: str | None = None
    days_to_expiry: int | None = None
    vacant: bool = False


def compute_quota(first_grant: date | None, expiry: date | None,
                  non_renewable_override: date | None, current_expat: str | None,
                  today: date, lifespan_years: int = DEFAULT_LIFESPAN_YEARS) -> QuotaComputed:
    q = QuotaComputed(vacant=is_vacant(current_expat))
    q.non_renewable_date = non_renewable_override or edate(first_grant, 12 * lifespan_years)
    q.notification = add_months(expiry, -EQ_NOTIFY_MONTHS)
    q.blackout_date = add_months(expiry, -BLACKOUT_MONTHS)
    if expiry:
        q.days_to_expiry = (expiry - today).days
    q.status = eq_status(expiry, today, heads_up=False)
    q.lifecycle = lifecycle(expiry, q.non_renewable_date, today)
    return q


# --- Milestones ---------------------------------------------------------------

SRC_EQ = "EQ"
SRC_CERPAC = "CERPAC"
SRC_QUOTA = "EEPNL"

EV_HEADS_UP = "EQ blackout heads-up"
EV_EQ_NOTIFY = "EQ notification (7 months)"
EV_BLACKOUT = "EQ blackout starts"
EV_EXPIRY = "EQ expiry"
EV_CERPAC_NOTIFY = "CERPAC notification (4 months)"
EV_CERPAC_FINAL_NOTIFY = "CERPAC notification (1 month)"
EV_CERPAC_EXPIRY = "CERPAC expiry"
EV_QUOTA_NOTIFY = "EEPNL quota notification (7 months)"
EV_QUOTA_EXPIRY = "EEPNL quota expiry"
EV_NON_RENEWABLE = "EEPNL quota lifespan ends"

# Notices are sent once when their date is reached (until the expiry passes).
NOTICE_KINDS = (EV_EQ_NOTIFY, EV_CERPAC_NOTIFY, EV_CERPAC_FINAL_NOTIFY, EV_QUOTA_NOTIFY)
EXPIRY_KINDS = (EV_EXPIRY, EV_CERPAC_EXPIRY, EV_QUOTA_EXPIRY)

STATE_UPCOMING = "Upcoming"
STATE_DUE = "Due now"
STATE_EXPIRED = "Expired"
STATE_PASSED = "Passed"
EVENT_STATES = [STATE_DUE, STATE_UPCOMING, STATE_EXPIRED, STATE_PASSED]


@dataclass(order=True)
class Event:
    when: date
    kind: str = field(compare=False)
    position: str = field(compare=False)
    person: str = field(compare=False)
    source: str = field(compare=False)
    record_id: int = field(compare=False)
    anchor: date | None = field(compare=False, default=None)  # the expiry this milestone leads up to
    detail: str = field(compare=False, default="")
    client_id: int | None = field(compare=False, default=None)

    def state(self, today: date) -> str:
        if self.when > today:
            return STATE_UPCOMING
        if self.anchor and self.anchor >= today:
            return STATE_DUE
        return STATE_EXPIRED if self.kind in EXPIRY_KINDS else STATE_PASSED


