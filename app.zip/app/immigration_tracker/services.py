"""Joins stored records with computed rules for the UI: rows, milestones, action items and dashboard tiles."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

from . import rules as R
from .db import Database, EQPosition, Quota


def fmt(d: date | None) -> str:
    return d.strftime("%d-%b-%Y") if d else "—"


@dataclass
class EQRow:
    rec: EQPosition
    calc: R.EQComputed
    quota: Quota | None


@dataclass
class QuotaRow:
    rec: Quota
    calc: R.QuotaComputed


@dataclass
class ActionItem:
    source: str          # EQ | CERPAC | EEPNL
    position: str
    person: str
    expiry: date | None
    status: str
    trigger: str         # why it is flagged, with the trigger date
    next_step: str
    record_id: int
    page: str            # page key to open the record
    client_id: int | None = None


@dataclass
class Tile:
    key: str
    group: str
    title: str
    tone: str
    count: int
    hint: str
    tooltip: str
    page: str
    filters: dict = field(default_factory=dict)


TILE_GROUPS = [
    ("eq", "Expatriate Quota (EQ) positions", "From the EQ & CERPAC tracker · EQ expiry = FMI approval + 2 years"),
    ("cerpac", "CERPAC", "Notices at 4 months and 1 month before CERPAC expiry"),
    ("eepnl", "EEPNL quota register", "Existing EEPNL quota positions"),
]


class TrackerService:
    """Records, milestones and dashboard figures for one client, or for every active client (client_id None)."""

    def __init__(self, db: Database, today: date | None = None, client_id: int | None = None):
        self.db = db
        self._today = today
        self.client_id = client_id
        self.reload()

    def set_client(self, client_id: int | None) -> None:
        self.client_id = client_id
        self.reload()

    def client_name(self, client_id: int | None) -> str:
        return self.client_names.get(client_id, "")

    @property
    def today(self) -> date:
        return self._today or date.today()

    @property
    def lifespan_years(self) -> int:
        try:
            return max(1, int(self.db.get_setting("quota_lifespan_years")))
        except ValueError:
            return R.DEFAULT_LIFESPAN_YEARS

    def reload(self) -> None:
        t, life = self.today, self.lifespan_years
        self.client_names = {c.id: c.name for c in self.db.clients(active_only=False)}
        self.quota_rows = [
            QuotaRow(q, R.compute_quota(q.first_grant, q.expiry, q.non_renewable_override, q.current_expat, t, life))
            for q in self.db.quotas(self.client_id)
        ]
        by_id = {r.rec.id: r.rec for r in self.quota_rows}
        self.eq_rows = [
            EQRow(p, R.compute_eq(p.first_grant, p.fmi_approval, p.expat, p.cerpac_expiry, t, life),
                  by_id.get(p.quota_id))
            for p in self.db.eq_positions(self.client_id)
        ]
        self.events = self._build_events()

    # --- milestones ------------------------------------------------------------

    def _renewal_note(self, lc: str | None, lifespan_end: date | None) -> str:
        if lc in (R.LC_FINAL_TERM, R.LC_EXPIRED_FINAL):
            return f"Final term: reaches the {self.lifespan_years}-year lifespan ({fmt(lifespan_end)}), cannot be renewed"
        if lc in (R.LC_RENEWABLE, R.LC_EXPIRED_RENEWABLE):
            return f"Renewable until lifespan ends {fmt(lifespan_end)}"
        return ""

    def _build_events(self) -> list[R.Event]:
        ev: list[R.Event] = []
        for r in self.eq_rows:
            p, c = r.rec, r.calc
            person = p.expat or R.VACANT
            if c.expiry:
                renew = self._renewal_note(c.lifecycle, c.validity)
                action = ("start EQ renewal" if c.lifecycle == R.LC_RENEWABLE
                          else "plan replacement or exit (not renewable)")
                ev += [
                    R.Event(c.lead_to_blackout, R.EV_HEADS_UP, p.title, person, R.SRC_EQ, p.id, c.blackout_date,
                            f"Blackout closes {fmt(c.blackout_date)} (2 months away). EQ expires {fmt(c.expiry)}."),
                    R.Event(c.eq_notification, R.EV_EQ_NOTIFY, p.title, person, R.SRC_EQ, p.id, c.expiry,
                            f"EQ expires {fmt(c.expiry)} in 7 months: {action}."),
                    R.Event(c.blackout_date, R.EV_BLACKOUT, p.title, person, R.SRC_EQ, p.id, c.expiry,
                            f"EQ expires {fmt(c.expiry)} in 6 months: no new expat or CERPAC renewal on this EQ."),
                    R.Event(c.expiry, R.EV_EXPIRY, p.title, person, R.SRC_EQ, p.id, c.expiry,
                            f"EQ expires {fmt(c.expiry)}. {renew}."),
                ]
            if p.cerpac_expiry:
                ev += [
                    R.Event(c.cerpac_notification, R.EV_CERPAC_NOTIFY, p.title, person, R.SRC_CERPAC, p.id,
                            p.cerpac_expiry,
                            f"CERPAC expires {fmt(p.cerpac_expiry)} in 4 months: notify expat and start renewal."),
                    R.Event(c.cerpac_final_notification, R.EV_CERPAC_FINAL_NOTIFY, p.title, person, R.SRC_CERPAC,
                            p.id, p.cerpac_expiry,
                            f"CERPAC expires {fmt(p.cerpac_expiry)} in 1 month: confirm renewal is filed."),
                    R.Event(p.cerpac_expiry, R.EV_CERPAC_EXPIRY, p.title, person, R.SRC_CERPAC, p.id, p.cerpac_expiry,
                            f"CERPAC expires {fmt(p.cerpac_expiry)}."),
                ]
        for r in self.quota_rows:
            q, c = r.rec, r.calc
            person = q.current_expat or R.VACANT
            if q.expiry:
                renew = self._renewal_note(c.lifecycle, c.non_renewable_date)
                action = ("start renewal" if c.lifecycle == R.LC_RENEWABLE
                          else "plan replacement or exit (not renewable)")
                ev += [
                    R.Event(c.notification, R.EV_QUOTA_NOTIFY, q.title, person, R.SRC_QUOTA, q.id, q.expiry,
                            f"EEPNL quota expires {fmt(q.expiry)} in 7 months: {action}."),
                    R.Event(q.expiry, R.EV_QUOTA_EXPIRY, q.title, person, R.SRC_QUOTA, q.id, q.expiry,
                            f"EEPNL quota expires {fmt(q.expiry)}. {renew}."),
                ]
            if c.non_renewable_date:
                ev.append(R.Event(c.non_renewable_date, R.EV_NON_RENEWABLE, q.title, person, R.SRC_QUOTA, q.id, None,
                                  f"{self.lifespan_years}-year lifespan from first grant ({fmt(q.first_grant)}) "
                                  "ends: the quota cannot be renewed after this date."))
        self._stamp_clients(ev)
        return sorted(ev)

    def _stamp_clients(self, items) -> None:
        """Give milestones / action items the client of the record they come from."""
        eq = {r.rec.id: r.rec.client_id for r in self.eq_rows}
        qs = {r.rec.id: r.rec.client_id for r in self.quota_rows}
        for it in items:
            it.client_id = (qs if it.source == R.SRC_QUOTA else eq).get(it.record_id)

    def upcoming_events(self, window_days: int) -> list[R.Event]:
        """Milestones from today up to `window_days` ahead."""
        t = self.today
        return [e for e in self.events if 0 <= (e.when - t).days <= window_days]

    # --- action required ---------------------------------------------------------

    def action_items(self) -> list[ActionItem]:
        items: list[ActionItem] = []
        life = self.lifespan_years

        def quota_action(source, title, person, expiry, status, lc, notify_date, blackout_date, rid, page):
            final = lc in (R.LC_FINAL_TERM, R.LC_EXPIRED_FINAL)
            label = "EQ" if source == R.SRC_EQ else "EEPNL quota"
            if status == R.ST_EXPIRED:
                trigger = f"{label} expired on {fmt(expiry)}"
                update = ("update the FMI approval date" if source == R.SRC_EQ else "update the expiry date")
                step = ("Cannot be renewed (past the "
                        f"{life}-year lifespan): close the position or apply for a new quota" if final
                        else f"Renew now (still within lifespan) or {update} if already renewed")
            elif status == R.ST_BLACKOUT:
                trigger = f"Blackout since {fmt(blackout_date)} (6 months to {label} expiry)"
                step = ("Final term: plan replacement or exit before expiry" if final
                        else "Renewal must be in progress; no new expat or CERPAC renewal on this EQ")
            elif status == R.ST_NOTIFY:
                trigger = f"7-month notification reached on {fmt(notify_date)}"
                step = ("Final term (not renewable): plan replacement or exit" if final
                        else "Start the EQ renewal before blackout on " + fmt(blackout_date))
            else:
                return
            items.append(ActionItem(source, title, person, expiry, status, trigger, step, rid, page))

        for r in self.eq_rows:
            p, c = r.rec, r.calc
            person = p.expat or R.VACANT
            quota_action(R.SRC_EQ, p.title, person, c.expiry, c.status, c.lifecycle, c.eq_notification,
                         c.blackout_date, p.id, "eq")
            if c.vacant:
                continue
            if c.cerpac_status == R.CERPAC_EXPIRED:
                items.append(ActionItem(R.SRC_CERPAC, p.title, person, p.cerpac_expiry, c.cerpac_status,
                                        f"CERPAC expired on {fmt(p.cerpac_expiry)}",
                                        "Renew the CERPAC or record the new expiry date", p.id, "eq"))
            elif c.cerpac_status == R.CERPAC_FINAL_NOTIFY:
                items.append(ActionItem(R.SRC_CERPAC, p.title, person, p.cerpac_expiry, c.cerpac_status,
                                        f"1-month notice reached on {fmt(c.cerpac_final_notification)}",
                                        "Confirm the CERPAC renewal has been filed", p.id, "eq"))
            elif c.cerpac_status == R.CERPAC_NOTIFY:
                items.append(ActionItem(R.SRC_CERPAC, p.title, person, p.cerpac_expiry, c.cerpac_status,
                                        f"4-month notice reached on {fmt(c.cerpac_notification)}",
                                        "Notify the expat and start the CERPAC renewal", p.id, "eq"))
        for r in self.quota_rows:
            q, c = r.rec, r.calc
            quota_action(R.SRC_QUOTA, q.title, q.current_expat or R.VACANT, q.expiry, c.status, c.lifecycle,
                         c.notification, c.blackout_date, q.id, "quotas")
        self._stamp_clients(items)
        return sorted(items, key=lambda a: (a.expiry or date.max, a.source, a.position))

    # --- dashboard -----------------------------------------------------------------

    def tiles(self) -> list[Tile]:
        eq, qs = self.eq_rows, self.quota_rows

        def n_eq(pred):
            return sum(1 for r in eq if pred(r.calc))

        def n_q(pred):
            return sum(1 for r in qs if pred(r.calc))

        life = self.lifespan_years
        eq_exp_ren = n_eq(lambda c: c.lifecycle == R.LC_EXPIRED_RENEWABLE)
        eq_exp_fin = n_eq(lambda c: c.lifecycle == R.LC_EXPIRED_FINAL)
        q_exp_ren = n_q(lambda c: c.lifecycle == R.LC_EXPIRED_RENEWABLE)
        q_exp_fin = n_q(lambda c: c.lifecycle == R.LC_EXPIRED_FINAL)
        return [
            Tile("eq_total", "eq", "EQ positions", "blue", len(eq),
                 f"{n_eq(lambda c: c.lifecycle == R.LC_RENEWABLE)} renewable · {n_eq(lambda c: c.vacant)} vacant",
                 "All positions on the EQ & CERPAC tracker", "eq"),
            Tile("eq_notify", "eq", "EQ notification due", "amber", n_eq(lambda c: c.status == R.ST_NOTIFY),
                 "7 months to EQ expiry reached", "EQ notification date (EQ expiry − 7 months) has passed; "
                 "blackout not yet started", "eq", {"status": R.ST_NOTIFY}),
            Tile("eq_blackout", "eq", "EQ in blackout", "orange", n_eq(lambda c: c.status == R.ST_BLACKOUT),
                 "≤ 6 months to EQ expiry", "Blackout closes 6 months before EQ expiry: no new expat or CERPAC "
                 "renewal on this EQ", "eq", {"status": R.ST_BLACKOUT}),
            Tile("eq_expired", "eq", "Expired EQs", "red", n_eq(lambda c: c.status == R.ST_EXPIRED),
                 f"{eq_exp_ren} renewable · {eq_exp_fin} cannot be renewed",
                 "EQ expiry date (FMI approval + 2 years) is in the past", "eq", {"status": R.ST_EXPIRED}),
            Tile("eq_final", "eq", "Final-term EQs", "purple", n_eq(lambda c: c.lifecycle == R.LC_FINAL_TERM),
                 "Active, non-renewable once expired",
                 f"Still active, but the EQ expiry reaches the {life}-year lifespan from first grant",
                 "eq", {"renewal": R.LC_FINAL_TERM}),

            Tile("cerpac_4", "cerpac", "CERPAC 4-month notice", "amber",
                 n_eq(lambda c: c.cerpac_status == R.CERPAC_NOTIFY), "Expires in 1–4 months",
                 "CERPAC expiry − 4 months has passed", "eq", {"cerpac": R.CERPAC_NOTIFY}),
            Tile("cerpac_1", "cerpac", "CERPAC 1-month notice", "orange",
                 n_eq(lambda c: c.cerpac_status == R.CERPAC_FINAL_NOTIFY), "Expires within 1 month",
                 "CERPAC expiry − 1 month has passed", "eq", {"cerpac": R.CERPAC_FINAL_NOTIFY}),
            Tile("cerpac_expired", "cerpac", "Expired CERPACs", "red",
                 n_eq(lambda c: c.cerpac_status == R.CERPAC_EXPIRED), "CERPAC expiry date has passed",
                 "CERPAC expiry is in the past", "eq", {"cerpac": R.CERPAC_EXPIRED}),
            Tile("cerpac_missing", "cerpac", "CERPAC date missing", "grey",
                 n_eq(lambda c: c.cerpac_status == R.CERPAC_MISSING), "No CERPAC expiry recorded",
                 "Add the CERPAC expiry so notices can be sent", "eq", {"cerpac": R.CERPAC_MISSING}),

            Tile("q_total", "eepnl", "EEPNL quotas", "blue", len(qs),
                 f"{n_q(lambda c: c.lifecycle == R.LC_RENEWABLE)} renewable · {n_q(lambda c: c.vacant)} vacant",
                 "All quotas on the EEPNL register", "quotas"),
            Tile("q_notify", "eepnl", "EEPNL notification due", "amber", n_q(lambda c: c.status == R.ST_NOTIFY),
                 "7 months to expiry reached", "Quota expiry − 7 months has passed", "quotas",
                 {"status": R.ST_NOTIFY}),
            Tile("q_blackout", "eepnl", "EEPNL in blackout", "orange", n_q(lambda c: c.status == R.ST_BLACKOUT),
                 "≤ 6 months to expiry", "Quota expiry is 6 months away or less", "quotas",
                 {"status": R.ST_BLACKOUT}),
            Tile("q_expired", "eepnl", "Expired EEPNL quotas", "red", n_q(lambda c: c.status == R.ST_EXPIRED),
                 f"{q_exp_ren} renewable · {q_exp_fin} cannot be renewed", "Quota expiry date is in the past",
                 "quotas", {"status": R.ST_EXPIRED}),
            Tile("q_final", "eepnl", "Final-term EEPNL quotas", "purple",
                 n_q(lambda c: c.lifecycle == R.LC_FINAL_TERM), "Active, non-renewable once expired",
                 f"Still active, but expiry reaches the {life}-year lifespan (or non-renewable override date)",
                 "quotas", {"renewal": R.LC_FINAL_TERM}),
        ]

    def expiries_by_month(self, months: int = 24) -> list[tuple[str, int, int]]:
        """[(label, eq_expiries, cerpac_expiries)] for the next N months."""
        t = self.today
        buckets: list[tuple[int, int]] = []
        for i in range(months):
            m = t.month - 1 + i
            buckets.append((t.year + m // 12, m % 12 + 1))
        index = {b: i for i, b in enumerate(buckets)}
        eq_counts = [0] * months
        cp_counts = [0] * months
        for r in self.eq_rows:
            if r.calc.expiry and (k := index.get((r.calc.expiry.year, r.calc.expiry.month))) is not None:
                eq_counts[k] += 1
            ce = r.rec.cerpac_expiry
            if ce and (k := index.get((ce.year, ce.month))) is not None:
                cp_counts[k] += 1
        return [(date(y, m, 1).strftime("%b %y"), eq_counts[i], cp_counts[i]) for i, (y, m) in enumerate(buckets)]
