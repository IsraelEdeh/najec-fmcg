"""Add/Edit dialogs with validation and a live preview of the computed Excel fields."""
from __future__ import annotations

import re
from datetime import date

from PySide6.QtCore import QDate, Qt
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDateEdit, QDialog, QFormLayout,
                               QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QScrollArea,
                               QSpinBox, QVBoxLayout, QWidget)

from .. import rules as R
from ..db import Client, ClientUser, EQPosition, Quota
from .widgets import fmt_date, make_searchable, role_combo


class OptionalDate(QWidget):
    """A date input that can be left blank (Excel empty cell)."""

    def __init__(self, value: date | None, optional: bool = True):
        super().__init__()
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        self.edit = QDateEdit()
        self.edit.setCalendarPopup(True)
        self.edit.setDisplayFormat("dd-MMM-yyyy")
        self.edit.setMinimumWidth(150)
        self.enabled = QCheckBox("Set")
        self.enabled.setVisible(optional)
        self.enabled.toggled.connect(self.edit.setEnabled)
        lay.addWidget(self.edit, 1)
        lay.addWidget(self.enabled)
        self.set_value(value)
        if not optional:
            self.enabled.setChecked(True)

    def set_value(self, value: date | None) -> None:
        self.edit.setDate(QDate(value.year, value.month, value.day) if value else QDate.currentDate())
        self.enabled.setChecked(value is not None)
        self.edit.setEnabled(value is not None)

    def value(self) -> date | None:
        return self.edit.date().toPython() if self.enabled.isChecked() else None


def _label(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("FormLabel")
    return lbl


class _BaseDialog(QDialog):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(True)
        self.setMinimumWidth(560)
        self.setMinimumHeight(400)
        
        avail = QApplication.primaryScreen().availableGeometry()
        self.resize(560, min(700, int(avail.height() * 0.85)))
        
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; }")
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        
        inner = QWidget()
        inner.setMinimumWidth(540)
        self.root = QVBoxLayout(inner)
        self.root.setContentsMargins(24, 24, 24, 20)
        self.root.setSpacing(16)
        heading = QLabel(title)
        heading.setObjectName("SectionTitle")
        self.root.addWidget(heading)
        self.form = QFormLayout()
        self.form.setLabelAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.form.setHorizontalSpacing(16)
        self.form.setVerticalSpacing(12)
        self.root.addLayout(self.form)
        
        scroll.setWidget(inner)
        outer.addWidget(scroll, 1)
        self._button_layout = QHBoxLayout()
        self._button_layout.setContentsMargins(0, 0, 0, 0)
        outer.addLayout(self._button_layout)

    def add_buttons(self, save_text: str = "Save") -> None:
        row = QHBoxLayout()
        row.addStretch()
        cancel = QPushButton("Cancel")
        save = QPushButton(save_text)
        save.setObjectName("Primary")
        save.setDefault(True)
        cancel.clicked.connect(self.reject)
        save.clicked.connect(self._on_save)
        row.addWidget(cancel)
        row.addWidget(save)
        row.setContentsMargins(24, 20, 24, 24)
        row.setSpacing(8)
        self._button_layout.addLayout(row)

    def _on_save(self) -> None:
        error = self.validate()
        if error:
            QMessageBox.warning(self, "Please check the form", error)
            return
        self.accept()

    def validate(self) -> str | None:
        return None


def _preview_html(items: list[tuple[str, str]], per_row: int = 4) -> str:
    cells = "".join(
        f"<td style='padding:4px 18px 6px 0'><span style='color:#667085;font-size:11px'>{k}</span><br><b>{v}</b></td>"
        + ("</tr><tr>" if i % per_row == per_row - 1 else "")
        for i, (k, v) in enumerate(items))
    return f"<table><tr>{cells}</tr></table>"


def _hint(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("Muted")
    lbl.setWordWrap(True)
    return lbl


class EQDialog(_BaseDialog):
    def __init__(self, rec: EQPosition, quotas: list[Quota], today: date,
                 lifespan_years: int = R.DEFAULT_LIFESPAN_YEARS, parent=None):
        super().__init__("Edit EQ position" if rec.id else "New EQ position", parent)
        self.rec, self.today, self.lifespan = rec, today, lifespan_years
        self.sn = QSpinBox()
        self.sn.setRange(1, 99999)
        self.sn.setValue(rec.sn or 1)
        self.title = QLineEdit(rec.title)
        self.title.setPlaceholderText("e.g. ENGINEERING ADVISOR")
        self.first_grant = OptionalDate(rec.first_grant, optional=False)
        self.fmi = OptionalDate(rec.fmi_approval, optional=False)
        self.expat = QLineEdit(rec.expat)
        self.expat.setPlaceholderText("Leave blank if vacant")
        self.cerpac = OptionalDate(rec.cerpac_expiry)
        self.quota = QComboBox()
        self.quota.addItem("— Not linked to a quota —", None)
        for q in quotas:
            self.quota.addItem(f"{q.sn or ''}  {q.title}  ·  {q.current_expat or 'Vacant'}", q.id)
        idx = self.quota.findData(rec.quota_id)
        self.quota.setCurrentIndex(max(idx, 0))
        make_searchable(self.quota, "Type to search quotas by title, S/N or expat…")
        self.quota.setToolTip("Link this EQ position to its EEPNL quota. Type to search.")
        self.notes = QLineEdit(rec.notes)

        self.form.addRow(_label("S/N"), self.sn)
        self.form.addRow(_label("EQ position title"), self.title)
        self.form.addRow(_label("First grant"), self.first_grant)
        self.form.addRow(_label("Most recent FMI approval"), self.fmi)
        self.form.addRow(_label("Expat"), self.expat)
        self.form.addRow(_label("CERPAC expiry"), self.cerpac)
        self.form.addRow(_label("EEPNL quota"), self.quota)
        self.form.addRow(_label("Notes"), self.notes)
        self.root.addWidget(_hint(
            "EQ expiry = most recent FMI approval + 2 years. Update the FMI approval date whenever a renewal is "
            "approved; every EQ date and notice below recalculates."))

        self.preview = QLabel()
        self.preview.setObjectName("Computed")
        self.preview.setTextFormat(Qt.RichText)
        self.root.addWidget(self.preview)
        for w in (self.first_grant.edit, self.fmi.edit, self.cerpac.edit):
            w.dateChanged.connect(self._refresh)
        self.cerpac.enabled.toggled.connect(self._refresh)
        self.expat.textChanged.connect(self._refresh)
        self._refresh()
        self.add_buttons()

    def _refresh(self) -> None:
        c = R.compute_eq(self.first_grant.value(), self.fmi.value(), self.expat.text(), self.cerpac.value(),
                         self.today, self.lifespan)
        shelf = "Expired" if c.shelf_life_months is None and c.expiry else c.shelf_life_months
        items = [
            ("EQ expiry", fmt_date(c.expiry)), ("EQ notification (7 mo)", fmt_date(c.eq_notification)),
            ("Blackout (6 mo)", fmt_date(c.blackout_date)), ("EQ status", c.status),
            ("Lifespan end", fmt_date(c.validity)), ("Renewal", c.lifecycle or "—"),
            ("Shelf life", f"{shelf} months" if isinstance(shelf, int) else (shelf or "—")),
            ("Heads-up (8 mo)", fmt_date(c.lead_to_blackout)),
            ("CERPAC notice 1 (4 mo)", fmt_date(c.cerpac_notification)),
            ("CERPAC notice 2 (1 mo)", fmt_date(c.cerpac_final_notification)),
            ("CERPAC status", c.cerpac_status),
        ]
        self.preview.setText(_preview_html(items))

    def validate(self) -> str | None:
        if not self.title.text().strip():
            return "Position title is required."
        if self.fmi.value() < self.first_grant.value():
            return "Most recent FMI approval cannot be earlier than the first grant."
        return None

    def result_record(self) -> EQPosition:
        return EQPosition(
            id=self.rec.id, sn=self.sn.value(), title=self.title.text().strip().upper(),
            first_grant=self.first_grant.value(), fmi_approval=self.fmi.value(),
            expat=self.expat.text().strip(), cerpac_expiry=self.cerpac.value(),
            quota_id=self.quota.currentData(), notes=self.notes.text().strip(), client_id=self.rec.client_id,
        )


class FmiUpdateDialog(_BaseDialog):
    """Set the most recent FMI approval date on one or more EQ positions at once."""

    def __init__(self, recs: list[EQPosition], today: date, lifespan_years: int = R.DEFAULT_LIFESPAN_YEARS,
                 parent=None):
        n = len(recs)
        super().__init__(f"Update FMI approval · {n} position{'s' if n != 1 else ''}", parent)
        self.recs, self.today, self.lifespan = recs, today, lifespan_years
        names = ", ".join(r.title for r in recs[:4]) + (f" and {n - 4} more" if n > 4 else "")
        self.root.insertWidget(1, _hint(names))
        current = {r.fmi_approval for r in recs}
        start = current.pop() if len(current) == 1 else None
        self.fmi = OptionalDate(start or today, optional=False)
        self.form.addRow(_label("Most recent FMI approval"), self.fmi)
        self.root.addWidget(_hint("EQ expiry = FMI approval + 2 years. The EQ notification (7 months), blackout "
                                  "(6 months) and renewal state recalculate for every selected position."))
        self.preview = QLabel()
        self.preview.setObjectName("Computed")
        self.preview.setTextFormat(Qt.RichText)
        self.root.addWidget(self.preview)
        self.fmi.edit.dateChanged.connect(self._refresh)
        self._refresh()
        self.add_buttons("Apply")

    def _refresh(self) -> None:
        fmi = self.fmi.value()
        calcs = [R.compute_eq(r.first_grant, fmi, r.expat, r.cerpac_expiry, self.today, self.lifespan)
                 for r in self.recs]
        c = calcs[0]

        def summary(values):
            counts: dict[str, int] = {}
            for v in values:
                counts[v or "—"] = counts.get(v or "—", 0) + 1
            return " · ".join(f"{v} {k}" if len(values) > 1 else k for k, v in counts.items())

        self.preview.setText(_preview_html([
            ("New EQ expiry", fmt_date(c.expiry)), ("EQ notification (7 mo)", fmt_date(c.eq_notification)),
            ("Blackout (6 mo)", fmt_date(c.blackout_date)), ("EQ status", summary([x.status for x in calcs])),
            ("Renewal", summary([x.lifecycle for x in calcs])),
        ], per_row=3))

    def validate(self) -> str | None:
        fmi = self.fmi.value()
        bad = [r.title for r in self.recs if r.first_grant and fmi < r.first_grant]
        if bad:
            return ("The FMI approval cannot be earlier than the first grant of: " + ", ".join(bad[:5])
                    + (f" and {len(bad) - 5} more" if len(bad) > 5 else ""))
        return None

    def value(self) -> date:
        return self.fmi.value()


class QuotaDialog(_BaseDialog):
    def __init__(self, rec: Quota, today: date, lifespan_years: int = R.DEFAULT_LIFESPAN_YEARS, parent=None):
        super().__init__("Edit EEPNL quota" if rec.id else "New EEPNL quota", parent)
        self.rec, self.today, self.lifespan = rec, today, lifespan_years
        self.sn = QSpinBox()
        self.sn.setRange(1, 99999)
        self.sn.setValue(rec.sn or 1)
        self.title = QLineEdit(rec.title)
        self.first_grant = OptionalDate(rec.first_grant, optional=False)
        self.expiry = OptionalDate(rec.expiry, optional=False)
        self.override = OptionalDate(rec.non_renewable_override)
        self.override.setToolTip(f"Leave unset to use first grant + {lifespan_years} years")
        self.expat = QLineEdit(rec.current_expat)
        self.expat.setPlaceholderText("Leave blank if vacant")
        self.previous = QLineEdit(rec.previous_incumbent)
        self.category = QComboBox()
        self.category.addItems(R.CATEGORIES)
        self.category.setCurrentText(rec.category or "Standard")
        self.movement = QComboBox()
        for m in R.MOVEMENTS:
            self.movement.addItem(m or "— None —", m)
        self.movement.setCurrentIndex(max(self.movement.findData(rec.movement or ""), 0))
        self.notes = QLineEdit(rec.notes)
        self.notes.setPlaceholderText("e.g. Hold for <name>")

        self.form.addRow(_label("S/N"), self.sn)
        self.form.addRow(_label("Quota position title"), self.title)
        self.form.addRow(_label("Date of first grant"), self.first_grant)
        self.form.addRow(_label("EQ expiry date"), self.expiry)
        self.form.addRow(_label("Non-renewable date override"), self.override)
        self.form.addRow(_label("Current expat"), self.expat)
        self.form.addRow(_label("Previous incumbent"), self.previous)
        self.form.addRow(_label("Category"), self.category)
        self.form.addRow(_label("Movement"), self.movement)
        self.form.addRow(_label("Notes"), self.notes)

        self.root.addWidget(_hint(
            "All quotas are granted for 2 years (EQ expiry = last renewal or issue date + 2 years). A quota "
            f"becomes non-renewable once it reaches its {lifespan_years}-year lifespan from first grant, unless "
            "a non-renewable override date is set (e.g. Permanent Until Reviewed)."))
        self.preview = QLabel()
        self.preview.setObjectName("Computed")
        self.preview.setTextFormat(Qt.RichText)
        self.root.addWidget(self.preview)
        for w in (self.first_grant.edit, self.expiry.edit, self.override.edit):
            w.dateChanged.connect(self._refresh)
        self.override.enabled.toggled.connect(self._refresh)
        self._refresh()
        self.add_buttons()

    def _refresh(self) -> None:
        c = R.compute_quota(self.first_grant.value(), self.expiry.value(), self.override.value(), "x",
                            self.today, self.lifespan)
        self.preview.setText(_preview_html([
            ("EQ status", c.status), ("Renewal", c.lifecycle or "—"),
            ("EQ notification (7 mo)", fmt_date(c.notification)), ("Lifespan end", fmt_date(c.non_renewable_date)),
        ]))

    def validate(self) -> str | None:
        if not self.title.text().strip():
            return "Quota position title is required."
        if self.expiry.value() < self.first_grant.value():
            return "Expiry date cannot be earlier than the first grant."
        return None

    def result_record(self) -> Quota:
        return Quota(
            id=self.rec.id, sn=self.sn.value(), title=self.title.text().strip().upper(),
            first_grant=self.first_grant.value(), expiry=self.expiry.value(),
            non_renewable_override=self.override.value(), current_expat=self.expat.text().strip(),
            previous_incumbent=self.previous.text().strip(), category=self.category.currentText(),
            movement=self.movement.currentData() or "", notes=self.notes.text().strip(),
            client_id=self.rec.client_id,
        )


INDUSTRIES = [
    "Banking & financial services", "Construction & engineering", "Consumer goods & retail",
    "Energy — oil & gas", "Energy — power & renewables", "Healthcare & life sciences", "Manufacturing",
    "Mining & metals", "Professional services", "Public sector", "Technology & telecoms",
    "Transport & logistics",
]

_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _compact(dialog: QDialog, height: int) -> None:
    dialog.setMinimumHeight(0)
    dialog.resize(560, height)


class ClientDialog(_BaseDialog):
    """Add or edit a client: name (unique) and an optional industry picked from a list or typed."""

    def __init__(self, client: Client | None = None, taken_names: list[str] = (), industries: list[str] = (),
                 parent=None):
        super().__init__("Edit client" if client else "New client", parent)
        self.client = client
        self._taken = {n.strip().lower() for n in taken_names} - {client.name.strip().lower() if client else ""}
        self.name = QLineEdit(client.name if client else "")
        self.name.setPlaceholderText("e.g. Acme Nigeria Ltd")
        self.industry = QComboBox()
        self.industry.addItems(sorted(set(INDUSTRIES) | {i for i in industries if i}))
        make_searchable(self.industry, "Choose from the list or type your own (optional)")
        self.industry.setCurrentIndex(-1)
        self.industry.setEditText(client.industry if client else "")
        self.form.addRow(_label("Client name"), self.name)
        self.form.addRow(_label("Industry"), self.industry)
        self.root.addWidget(_hint("After adding the client, add its team members: an Owner (receives every "
                                  "reminder), then any Managers and Partners for escalations."))
        self.root.addStretch()
        self.add_buttons("Save changes" if client else "Add client")
        _compact(self, 340)
        self.name.setFocus()

    def validate(self) -> str | None:
        name = self.name.text().strip()
        if not name:
            return "Enter the client name."
        if name.lower() in self._taken:
            return f"A client called '{name}' already exists. Pick it from the client dropdown instead."
        return None

    def values(self) -> tuple[str, str]:
        return self.name.text().strip(), self.industry.currentText().strip()


class TeamMemberDialog(_BaseDialog):
    """Add or edit a client team member. The client is a dropdown only when there is more than one client."""

    def __init__(self, clients: list[Client], client_id: int | None, member: ClientUser | None = None,
                 emails_for=lambda client_id: set(), default_role: str = "Owner", parent=None):
        super().__init__("Edit team member" if member else "Add team member", parent)
        self.member, self._emails_for = member, emails_for
        self._fixed_client = member.client_id if member else (clients[0].id if len(clients) == 1 else None)
        self.client = QComboBox()
        for c in clients:
            self.client.addItem(c.name + (f"  ·  {c.industry}" if c.industry else ""), c.id)
        self.client.setCurrentIndex(max(self.client.findData(client_id), 0))
        self.client.setToolTip("The client this person works on")
        if self._fixed_client is None:
            self.form.addRow(_label("Client"), self.client)
        else:
            fixed = next((c for c in clients if c.id == self._fixed_client), None)
            name = QLabel(fixed.name if fixed else "")
            name.setObjectName("ClientName")
            self.form.addRow(_label("Client"), name)

        self.name = QLineEdit(member.name if member else "")
        self.name.setPlaceholderText("Full name")
        self.email = QLineEdit(member.email if member else "")
        self.email.setPlaceholderText("name@company.com")
        if member:
            self.email.setReadOnly(True)
            self.email.setToolTip("To change the email, remove this member and add them again.")
        self.role = role_combo(member.role if member else default_role)
        self.active = QCheckBox("Active — receives reminders for this client")
        self.active.setChecked(member.active if member else True)
        self.form.addRow(_label("Name"), self.name)
        self.form.addRow(_label("Email"), self.email)
        self.form.addRow(_label("Role"), self.role)
        if member:
            self.form.addRow(QLabel(), self.active)
        self.root.addWidget(_hint("The same reminder rules apply to every client: the Owner gets each notice "
                                  "first; if it is still not started, Managers and then Partners are escalated to."))
        self.root.addStretch()
        self.add_buttons("Save changes" if member else "Add team member")
        _compact(self, 420 if member else 400)
        (self.name if member else self.email).setFocus()

    @property
    def client_id(self) -> int:
        return self._fixed_client if self._fixed_client is not None else self.client.currentData()

    def validate(self) -> str | None:
        email = self.email.text().strip()
        if not _EMAIL.match(email):
            return "Enter a valid email address, e.g. name@company.com."
        if not self.member and email.lower() in {e.lower() for e in self._emails_for(self.client_id)}:
            return f"{email} is already a team member on this client."
        return None

    def values(self) -> tuple[str, str, str, bool]:
        """(email, name, role, active)"""
        return self.email.text().strip(), self.name.text().strip(), self.role.currentData(), self.active.isChecked()
