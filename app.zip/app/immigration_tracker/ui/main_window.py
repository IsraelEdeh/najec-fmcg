"""Main window: sidebar navigation, top bar, page stack."""
from __future__ import annotations

from PySide6.QtCore import QDate, Qt, QTimer
from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import (QApplication, QButtonGroup, QComboBox, QFrame, QHBoxLayout, QLabel, QLineEdit,
                               QMainWindow, QPushButton, QStackedWidget, QTabWidget, QVBoxLayout, QWidget)

from ..services import TrackerService
from ..notifications import run_alerts
from .notifications_page import NotificationsPage
from .pages import ActivityHistoryPage, AlertsPage, DashboardPage, DataPage, EQPage, QuotaPage
from .theme import DARK, LIGHT, stylesheet
from .widgets import polish_dropdowns

NAV = [
    ("dashboard", "Dashboard", DashboardPage),
    ("eq", "EQ & CERPAC", EQPage),
    ("quotas", "EEPNL Quotas", QuotaPage),
    ("alerts", "Milestones", AlertsPage),
    ("notifications", "Notifications", NotificationsPage),
    ("activity", "Activity History", ActivityHistoryPage),
    ("data", "Data & Settings", DataPage),
]
ALL_CLIENTS = -1  # client dropdown value for the combined view


class MainWindow(QMainWindow):
    def __init__(self, svc: TrackerService):
        super().__init__()
        polish_dropdowns(QApplication.instance())
        self.svc = svc
        self.tokens = DARK if svc.db.get_setting("theme") == "dark" else LIGHT
        self.setWindowTitle("Immigration Tracker — Expatriate Quota & CERPAC")
        avail = QApplication.primaryScreen().availableGeometry()
        self.resize(min(1440, int(avail.width() * 0.92)), min(900, int(avail.height() * 0.9)))
        self.setMinimumSize(min(1100, avail.width() - 40), min(680, avail.height() - 40))

        root = QWidget()
        h = QHBoxLayout(root)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        self.setCentralWidget(root)

        # sidebar
        side = QFrame()
        side.setObjectName("Sidebar")
        side.setFixedWidth(232)
        sv = QVBoxLayout(side)
        sv.setContentsMargins(16, 24, 16, 16)
        sv.setSpacing(4)
        brand = QLabel("Immigration Tracker")
        brand.setObjectName("Brand")
        sub = QLabel("EQ · CERPAC · EEPNL Quotas")
        sub.setObjectName("BrandSub")
        sv.addWidget(brand)
        sv.addWidget(sub)
        sv.addSpacing(20)
        client_lbl = QLabel("CLIENT")
        client_lbl.setObjectName("SidebarLabel")
        sv.addWidget(client_lbl)
        self.client_switch = QComboBox()
        self.client_switch.setObjectName("ClientSwitch")
        self.client_switch.setToolTip("Every page shows this client's data. Choose 'All clients' for a combined "
                                      "overview. Add clients in Data & Settings → Clients.")
        self.client_switch.currentIndexChanged.connect(self._client_switched)
        sv.addWidget(self.client_switch)
        sv.addSpacing(20)
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.nav_buttons: dict[str, QPushButton] = {}
        for key, label, _ in NAV:
            b = QPushButton(label.replace("&", "&&"))
            b.setObjectName("NavButton")
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=key: self.show_page(k))
            self.nav_group.addButton(b)
            self.nav_buttons[key] = b
            sv.addWidget(b)
        sv.addStretch()
        foot = QLabel("v0.2")
        foot.setObjectName("SidebarFooter")
        foot.setWordWrap(True)
        sv.addWidget(foot)
        h.addWidget(side)

        # content
        content = QWidget()
        content.setObjectName("Content")
        cv = QVBoxLayout(content)
        cv.setContentsMargins(0, 0, 0, 0)
        cv.setSpacing(0)
        top = QFrame()
        top.setObjectName("TopBar")
        top.setFixedHeight(76)
        th = QHBoxLayout(top)
        th.setContentsMargins(32, 12, 32, 12)
        th.setSpacing(16)
        titles = QVBoxLayout()
        titles.setSpacing(2)
        self.page_title = QLabel()
        self.page_title.setObjectName("PageTitle")
        self.page_sub = QLabel()
        self.page_sub.setObjectName("PageSubtitle")
        titles.addWidget(self.page_title)
        titles.addWidget(self.page_sub)
        th.addLayout(titles)
        th.addStretch()
        self.search = QLineEdit()
        self.search.setObjectName("Search")
        self.search.setPlaceholderText("Search positions, expats, statuses…")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._search)
        th.addWidget(self.search)
        self.today_chip = QLabel()
        self.today_chip.setObjectName("TodayChip")
        th.addWidget(self.today_chip)
        self.theme_btn = QPushButton()
        self.theme_btn.setCursor(Qt.PointingHandCursor)
        self.theme_btn.clicked.connect(self._toggle_theme)
        th.addWidget(self.theme_btn)
        cv.addWidget(top)

        self.stack = QStackedWidget()
        cv.addWidget(self.stack, 1)
        h.addWidget(content, 1)

        self.pages: dict[str, object] = {}
        saved = svc.db.get_setting("current_client")
        svc.client_id = int(saved) if saved.isdigit() else None
        svc.client_id = self._valid_client(svc.client_id, prefer_all=saved == "all")
        svc.reload()
        for key, _, cls in NAV:
            page = cls(svc, self.tokens)
            page.data_changed.connect(self.reload)
            self.pages[key] = page
            self.stack.addWidget(page)
        self.pages["dashboard"].navigate.connect(self._navigate)
        self.pages["data"].theme_changed.connect(self.apply_theme)
        self.pages["data"].client_chosen.connect(self.set_client)
        self.pages["notifications"].open_clients.connect(self._open_clients)

        self.apply_theme(svc.db.get_setting("theme"))
        self.reload()
        self.show_page("dashboard")

        # Recompute at midnight so TODAY()-based fields stay correct for long-running sessions.
        self._day = QDate.currentDate()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(60_000)

        # Reminder emails: shortly after launch, then hourly while the app is open.
        QTimer.singleShot(15_000, self._check_alerts)
        self._alert_timer = QTimer(self)
        self._alert_timer.timeout.connect(self._check_alerts)
        self._alert_timer.start(60 * 60_000)

    def _check_alerts(self) -> None:
        if self.svc.db.get_setting("notify_enabled") != "1":
            return
        try:
            res = run_alerts(self.svc.db, self.svc)
        except Exception as exc:  # background check must never interrupt the user
            self.statusBar().showMessage(f"Email reminder check failed: {exc}", 15_000)
            return
        if res.sent or res.error:
            self.statusBar().showMessage(f"Email reminders: {res.summary()}", 15_000)
            self.pages["notifications"].refresh()

    def _tick(self) -> None:
        if QDate.currentDate() != self._day:
            self._day = QDate.currentDate()
            self.reload()

    def reload(self) -> None:
        self.svc.client_id = self._valid_client(self.svc.client_id, prefer_all=self.svc.client_id is None)
        self.svc.reload()
        self._fill_clients()
        self.today_chip.setText(f"Today · {self.svc.today:%d %b %Y}")
        for p in self.pages.values():
            p.refresh()
        self._search(self.search.text())

    # --- current client -------------------------------------------------------------

    def _valid_client(self, cid: int | None, prefer_all: bool = False) -> int | None:
        """An active client id, or None for 'All clients' (only offered when there are several)."""
        ids = [c.id for c in self.svc.db.clients()]
        if cid in ids:
            return cid
        if prefer_all and len(ids) > 1:
            return None
        return ids[0] if ids else None

    def _fill_clients(self) -> None:
        clients = self.svc.db.clients()
        cb = self.client_switch
        cb.blockSignals(True)
        cb.clear()
        if len(clients) > 1:
            cb.addItem(f"All clients ({len(clients)})", ALL_CLIENTS)
        for c in clients:
            cb.addItem(c.name, c.id)
            cb.setItemData(cb.count() - 1, c.industry or c.name, Qt.ToolTipRole)
        cb.setPlaceholderText("No clients yet")
        cb.setCurrentIndex(cb.findData(ALL_CLIENTS if self.svc.client_id is None else self.svc.client_id))
        cb.setEnabled(bool(clients))
        cb.blockSignals(False)

    def _client_switched(self) -> None:
        data = self.client_switch.currentData()
        self.set_client(None if data == ALL_CLIENTS else data)

    def set_client(self, client_id: int | None) -> None:
        """Switch every page to this client (None = all clients) and remember the choice."""
        self.svc.client_id = self._valid_client(client_id, prefer_all=client_id is None)
        self.svc.db.set_setting("current_client", "all" if self.svc.client_id is None else str(self.svc.client_id))
        self.reload()

    def _open_clients(self) -> None:
        self.show_page("data")
        tabs = self.pages["data"].findChild(QTabWidget)
        for i in range(tabs.count()):
            if tabs.tabText(i) == "Clients":
                tabs.setCurrentIndex(i)

    def show_page(self, key: str) -> None:
        page = self.pages[key]
        self.nav_buttons[key].setChecked(True)
        self.stack.setCurrentWidget(page)
        self.page_title.setText(page.title)
        self.page_sub.setText(page.subtitle)
        self.search.setVisible(key not in ("dashboard", "data", "notifications"))
        self._search(self.search.text())

    def _navigate(self, key: str, filters: dict) -> None:
        page = self.pages[key]
        if hasattr(page, "apply_filters"):
            page.apply_filters({k: v for k, v in filters.items() if k != "search"})
        self.show_page(key)
        self.search.setText(filters.get("search", ""))

    def _search(self, text: str) -> None:
        page = self.stack.currentWidget()
        if page is not None:
            page.set_search(text)

    def _toggle_theme(self) -> None:
        new = "light" if self.tokens is DARK else "dark"
        self.svc.db.set_setting("theme", new)
        self.pages["data"].theme.blockSignals(True)
        self.pages["data"].theme.setCurrentText(new.title())
        self.pages["data"].theme.blockSignals(False)
        self.apply_theme(new)

    def apply_theme(self, name: str) -> None:
        self.tokens = DARK if name == "dark" else LIGHT
        app = QApplication.instance()
        palette = app.palette()
        palette.setColor(QPalette.Highlight, QColor(self.tokens["primary"]))
        app.setPalette(palette)
        app.setStyleSheet(stylesheet(self.tokens))
        self.theme_btn.setText("Light mode" if name == "dark" else "Dark mode")
        for p in self.pages.values():
            p.set_tokens(self.tokens)
            p.refresh()
