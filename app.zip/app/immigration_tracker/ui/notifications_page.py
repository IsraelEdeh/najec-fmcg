"""Notifications page: recipients, delivery method, reminder schedule and sent log."""
from __future__ import annotations

from datetime import date, datetime

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
                               QMessageBox, QPushButton, QScrollArea, QSpinBox, QVBoxLayout, QWidget)

from .. import notifications as N
from .. import rules as R
from .pages import Page, _title
from .widgets import Card, Column, DataTable, RowTableModel


def _label(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("FormLabel")
    return lbl


def _muted(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("Muted")
    lbl.setWordWrap(True)
    return lbl


class NotificationsPage(Page):
    title = "Notifications"
    subtitle = "EQ notice 7 months before EQ expiry · CERPAC notices 4 months and 1 month before CERPAC expiry"
    open_clients = Signal()

    def __init__(self, svc, tokens):
        super().__init__(svc, tokens)
        db = svc.db
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        inner.setObjectName("Content")
        scroll.setWidget(inner)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(32, 24, 32, 32)
        lay.setSpacing(16)

        # --- who gets reminders: the selected client's team
        rec = Card()
        head = QHBoxLayout()
        self.rec_title = _title("Who gets reminders")
        head.addWidget(self.rec_title)
        head.addStretch()
        manage = QPushButton("Manage team?")
        manage.setCursor(Qt.PointingHandCursor)
        manage.setToolTip("Add, edit or remove team members in Data & Settings ? Clients")
        manage.clicked.connect(self.open_clients.emit)
        head.addWidget(manage)
        rec.body.addLayout(head)
        rec.body.addWidget(_muted("Each client's reminders go to that client's own team. The Owner receives every "
                                  "notice; Managers and then Partners are escalated to when an item is left "
                                  "'Not started' (see Escalation below)."))
        self.rec_warning = QLabel()
        self.rec_warning.setObjectName("Warning")
        self.rec_warning.setWordWrap(True)
        rec.body.addWidget(self.rec_warning)
        self.rec_model = RowTableModel([
            Column("Client", lambda u: svc.client_name(u.client_id), width=160),
            Column("Name", lambda u: u.name or "?", width=150),
            Column("Email", lambda u: u.email, width=220),
            Column("Role", lambda u: u.role, "pill", width=95),
            Column("Status", lambda u: "Active" if u.active else "Paused", "pill", width=90),
        ], tokens, lambda: svc.today)
        self.rec_table = DataTable(self.rec_model, tokens)
        self.rec_table.setMinimumHeight(220)
        rec.body.addWidget(self.rec_table)

        # --- delivery
        dlv = Card()
        dlv.body.addWidget(_title("Delivery"))
        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(10)
        self.method = QComboBox()
        self.method.addItem("Outlook (this PC's mailbox)", "outlook")
        self.method.addItem("SMTP server", "smtp")
        self.method.setCurrentIndex(max(self.method.findData(db.get_setting("notify_method")), 0))
        self.method.currentIndexChanged.connect(self._method_changed)
        self.smtp_host = QLineEdit(db.get_setting("smtp_host"))
        self.smtp_host.setPlaceholderText("smtp.office365.com")
        self.smtp_port = QSpinBox()
        self.smtp_port.setRange(1, 65535)
        self.smtp_port.setValue(int(db.get_setting("smtp_port") or 587))
        self.smtp_security = QComboBox()
        for label, val in (("STARTTLS", "starttls"), ("SSL/TLS", "ssl"), ("None", "none")):
            self.smtp_security.addItem(label, val)
        self.smtp_security.setCurrentIndex(max(self.smtp_security.findData(db.get_setting("smtp_security")), 0))
        self.smtp_user = QLineEdit(db.get_setting("smtp_user"))
        self.smtp_password = QLineEdit()
        self.smtp_password.setEchoMode(QLineEdit.Password)
        self.smtp_password.setPlaceholderText("•••••• (saved)" if db.get_setting("smtp_password") else "Password")
        self.smtp_from = QLineEdit(db.get_setting("smtp_from"))
        self.smtp_from.setPlaceholderText("alerts@company.com")
        grid.addWidget(_label("Send using"), 0, 0)
        grid.addWidget(self.method, 0, 1, 1, 3)
        self.smtp_widgets = []
        for row, (lbl, w) in enumerate((("SMTP host", self.smtp_host), ("Username", self.smtp_user),
                                        ("Password", self.smtp_password), ("From address", self.smtp_from)), start=1):
            label = _label(lbl)
            grid.addWidget(label, row, 0)
            grid.addWidget(w, row, 1, 1, 3)
            self.smtp_widgets += [label, w]
        port_lbl, sec_lbl = _label("Port"), _label("Security")
        grid.addWidget(port_lbl, 5, 0)
        grid.addWidget(self.smtp_port, 5, 1)
        grid.addWidget(sec_lbl, 5, 2)
        grid.addWidget(self.smtp_security, 5, 3)
        self.smtp_widgets += [port_lbl, self.smtp_port, sec_lbl, self.smtp_security]
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(3, 1)
        dlv.body.addLayout(grid)
        self.outlook_hint = _muted("Emails are sent from the Outlook account signed in on this PC. "
                                   "Outlook must be installed; it does not need to be open.")
        dlv.body.addWidget(self.outlook_hint)
        dlv.body.addStretch()

        top = QHBoxLayout()
        top.setSpacing(16)
        top.addWidget(rec, 1)
        top.addWidget(dlv, 1)
        lay.addLayout(top)

        # --- schedule
        sch = Card()
        sch.body.addWidget(_title("Reminder schedule"))
        self.enabled = QCheckBox("Send notification emails automatically")
        self.enabled.setChecked(db.get_setting("notify_enabled") == "1")
        sch.body.addWidget(self.enabled)

        selected = {k.strip() for k in db.get_setting("notify_kinds").split(",")}
        self.kind_boxes: dict[str, QCheckBox] = {}
        groups = QHBoxLayout()
        groups.setSpacing(32)
        notice_col = QVBoxLayout()
        notice_col.setSpacing(6)
        notice_col.addWidget(_label("Notices · sent once when the notice date is reached"))
        notice_col.addWidget(_muted("If a check was missed, the notice still goes out until the expiry date. "
                                    "The CERPAC 1-month notice replaces a 4-month notice not yet sent."))
        countdown_col = QVBoxLayout()
        countdown_col.setSpacing(6)
        countdown_col.addWidget(_label("Countdown reminders · sent the selected days before the date"))
        th_row = QHBoxLayout()
        th_row.setSpacing(12)
        th_row.addWidget(_muted("Days before:"))
        self.thresholds = QLineEdit(", ".join(str(t) for t in sorted(
            N.parse_thresholds(db.get_setting("notify_thresholds")), reverse=True)))
        self.thresholds.setMaximumWidth(140)
        self.thresholds.setToolTip("Comma-separated, e.g. 7, 3, 1")
        th_row.addWidget(self.thresholds)
        th_row.addStretch()
        countdown_col.addLayout(th_row)
        for k in N.ALERT_KINDS:
            cb = QCheckBox(k)
            cb.setChecked(k in selected)
            self.kind_boxes[k] = cb
            (notice_col if k in R.NOTICE_KINDS else countdown_col).addWidget(cb)
        notice_col.addStretch()
        countdown_col.addStretch()
        groups.addLayout(notice_col, 1)
        groups.addLayout(countdown_col, 1)
        sch.body.addLayout(groups)

        sch.body.addWidget(_label("Escalation · when nobody marks an item 'In progress' or 'Done'"))
        self.escalate = QCheckBox("Escalate items still 'Not started' after their first email")
        self.escalate.setChecked(db.get_setting("escalate_enabled") == "1")
        sch.body.addWidget(self.escalate)
        esc_row = QHBoxLayout()
        esc_row.setSpacing(8)
        self.esc_days: dict[int, QSpinBox] = {}
        current = N.escalation_days(db)
        for stage, text in ((1, "Owners again after"), (2, "Manager after"), (3, "Partner after")):
            spin = QSpinBox()
            spin.setRange(0, 365)
            spin.setSuffix(" days")
            spin.setSpecialValueText("Off")
            spin.setValue(current[stage])
            self.esc_days[stage] = spin
            esc_row.addWidget(_muted(text))
            esc_row.addWidget(spin)
            esc_row.addSpacing(12)
        esc_row.addStretch()
        sch.body.addLayout(esc_row)
        sch.body.addWidget(_muted(
            "Days are counted from the first email about an item. Managers get the Owners in copy; Partners get "
            "Owners and Managers in copy. Mark items on the Milestones page: 'In progress' stops escalation, "
            "'Done' stops all emails for that item. Set a step to Off to skip it."))

        sch.body.addWidget(_label("Background check"))
        self.task_status = _muted("")
        sch.body.addWidget(self.task_status)
        bg = QHBoxLayout()
        bg.setSpacing(8)
        self.task_btn = QPushButton()
        self.task_btn.clicked.connect(self._toggle_task)
        bg.addWidget(self.task_btn)
        bg.addStretch()
        sch.body.addLayout(bg)
        self.last_run = _muted("")
        sch.body.addWidget(self.last_run)

        actions = QHBoxLayout()
        actions.setSpacing(8)
        save = QPushButton("Save settings")
        save.setObjectName("Primary")
        save.clicked.connect(lambda: self._save())
        test = QPushButton("Send test email")
        test.clicked.connect(self._test)
        run = QPushButton("Send due reminders now")
        run.clicked.connect(self._run_now)
        actions.addWidget(save)
        actions.addWidget(test)
        actions.addWidget(run)
        actions.addStretch()
        sch.body.addLayout(actions)
        lay.addWidget(sch)

        # --- pending + log
        pend = Card()
        self.pending_title = _title("Due now")
        pend.body.addWidget(self.pending_title)
        pend.body.addWidget(_muted("Notifications that will go out on the next check (in the app or the background task)."))
        self.pending_model = RowTableModel([
            Column("Client", lambda a: svc.client_name(a.event.client_id), width=160),
            Column("Type", lambda a: a.event.source, "pill", width=95),
            Column("Notification", lambda a: a.event.kind, width=250),
            Column("Sent as", lambda a: a.label, width=170),
            Column("Position", lambda a: a.event.position, width=260),
            Column("Expat", lambda a: a.event.person, width=140),
            Column("Expiry date", lambda a: a.expiry, "date", width=115),
            Column("Days left", lambda a: a.days_left, "int", width=85),
            Column("What to do", lambda a: a.event.detail, width=380),
        ], tokens, lambda: svc.today)
        self.pending_table = DataTable(self.pending_model, tokens)
        self.pending_table.setMinimumHeight(220)
        pend.body.addWidget(self.pending_table)
        lay.addWidget(pend)

        sent = Card()
        sent.body.addWidget(_title("Sent log"))
        self.log_model = RowTableModel([
            Column("Client", lambda r: svc.client_name(r["client_id"]), width=160),
            Column("Sent", lambda r: (r["sent_at"] or "").replace("T", " "), width=160),
            Column("Sent as", lambda r: N.stage_label(r["threshold"]), width=170),
            Column("Notification", lambda r: r["kind"], width=230),
            Column("Position", lambda r: r["position"], width=260),
            Column("Expat", lambda r: r["person"], width=140),
            Column("Date", lambda r: date.fromisoformat(r["due_date"]) if r["due_date"] else None, "date",
                   "Notice or milestone date", width=115),
            Column("Recipients", lambda r: r["recipients"], width=260),
        ], tokens, lambda: svc.today)
        self.log_table = DataTable(self.log_model, tokens)
        self.log_table.setMinimumHeight(240)
        sent.body.addWidget(self.log_table)
        lay.addWidget(sent)

        self._method_changed()

    # --- helpers
    def refresh(self) -> None:
        db, cid = self.svc.db, self.svc.client_id
        ids = [cid] if cid is not None else [c.id for c in db.clients()]
        team = [u for i in ids for u in db.client_users(i, active_only=False)]
        self.rec_model.set_rows(team)
        self.rec_title.setText("Who gets reminders · " + (self.svc.client_name(cid) if cid else "all clients"))
        no_owner = [self.svc.client_name(i) for i in ids
                    if not any(u.role == "Owner" and u.active for u in db.client_users(i))]
        self.rec_warning.setText(("No active Owner for: " + ", ".join(no_owner) + ". Their reminders cannot be "
                                  "sent until one is added (Manage team…).") if no_owner else "")
        self.rec_warning.setVisible(bool(no_owner))
        pending = N.pending_alerts(db, self.svc) + N.pending_escalations(db, self.svc)
        self.pending_model.set_rows(pending)
        self.pending_title.setText(f"Due now · {len(pending)}")
        self.log_model.set_rows(db.sent_alerts(client_id=cid))
        self.log_table.sortByColumn(1, Qt.DescendingOrder)
        for t in (self.rec_table, self.pending_table, self.log_table):
            t.setColumnHidden(0, cid is not None)
        installed = N.scheduled_task_installed()
        self.task_status.setText(
            "Installed: checks daily at 08:00 and 5 minutes after you sign in, even when the app is closed."
            if installed else
            "Not installed: reminders are only checked while the app is open. Install the background check so "
            "emails go out even when the app is closed.")
        self.task_btn.setText("Remove background check" if installed else "Install background check")
        last = db.get_setting("notify_last_run")
        when = datetime.fromisoformat(last).strftime("%d %b %Y %H:%M") if last else "never"
        self.last_run.setText(f"Last check: {when} · {db.get_setting('notify_last_result') or '—'}")

    def set_tokens(self, tokens):
        super().set_tokens(tokens)
        for t in (self.rec_table, self.pending_table, self.log_table):
            t.set_tokens(tokens)

    def _method_changed(self) -> None:
        smtp = self.method.currentData() == "smtp"
        for w in self.smtp_widgets:
            w.setVisible(smtp)
        self.outlook_hint.setVisible(not smtp)

    def _save(self, quiet: bool = False) -> bool:
        db = self.svc.db
        kinds = [k for k, cb in self.kind_boxes.items() if cb.isChecked()]
        if self.enabled.isChecked() and not kinds:
            QMessageBox.warning(self, "Nothing selected", "Select at least one milestone to send reminders for.")
            return False
        if self.method.currentData() == "smtp" and not self.smtp_host.text().strip():
            QMessageBox.warning(self, "SMTP host required", "Enter the SMTP server host.")
            return False
        thresholds = N.parse_thresholds(self.thresholds.text())
        days = {s: spin.value() for s, spin in self.esc_days.items()}
        steps = [d for _, d in sorted(days.items()) if d > 0]
        if self.escalate.isChecked() and steps != sorted(steps):
            QMessageBox.warning(self, "Check escalation days", "Each escalation step should come after the "
                                "previous one (e.g. Owners 3, Manager 7, Partner 14 days).")
            return False
        if self.escalate.isChecked() and not steps:
            QMessageBox.warning(self, "Check escalation days", "Set at least one escalation step, or untick "
                                "escalation.")
            return False
        db.set_setting("escalate_enabled", "1" if self.escalate.isChecked() else "0")
        for stage, d in days.items():
            db.set_setting(N.STAGE_SETTING[stage], str(d))
        self.thresholds.setText(", ".join(str(t) for t in sorted(thresholds, reverse=True)))
        db.set_setting("notify_enabled", "1" if self.enabled.isChecked() else "0")
        db.set_setting("notify_thresholds", ",".join(map(str, thresholds)))
        db.set_setting("notify_kinds", ",".join(kinds))
        db.set_setting("notify_method", self.method.currentData())
        db.set_setting("smtp_host", self.smtp_host.text().strip())
        db.set_setting("smtp_port", str(self.smtp_port.value()))
        db.set_setting("smtp_security", self.smtp_security.currentData())
        db.set_setting("smtp_user", self.smtp_user.text().strip())
        db.set_setting("smtp_from", self.smtp_from.text().strip())
        if self.smtp_password.text():
            db.set_setting("smtp_password", N.protect(self.smtp_password.text()))
            self.smtp_password.clear()
            self.smtp_password.setPlaceholderText("•••••• (saved)")
        self.refresh()
        if not quiet:
            QMessageBox.information(self, "Saved", "Notification settings saved.")
        return True

    def _test(self) -> None:
        if not self._save(quiet=True):
            return
        try:
            N.send_test_email(self.svc.db, self.svc.client_id)
        except N.DeliveryError as exc:
            QMessageBox.critical(self, "Test email failed", str(exc))
            return
        who = self.svc.client_name(self.svc.client_id) if self.svc.client_id else "every client"
        QMessageBox.information(self, "Test email sent", f"A test email was sent to the active team of {who}.")

    def _run_now(self) -> None:
        if not self._save(quiet=True):
            return
        res = N.run_alerts(self.svc.db, self.svc, require_enabled=False)
        self.refresh()
        (QMessageBox.critical if res.error else QMessageBox.information)(self, "Reminders", res.summary())

    def _toggle_task(self) -> None:
        try:
            if N.scheduled_task_installed():
                N.remove_scheduled_task()
            else:
                N.install_scheduled_task()
                if not self.enabled.isChecked():
                    self.enabled.setChecked(True)
                    self._save(quiet=True)
        except N.DeliveryError as exc:
            QMessageBox.critical(self, "Background check", f"Windows Task Scheduler reported an error:\n{exc}")
        self.refresh()
