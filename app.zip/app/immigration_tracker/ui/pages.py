"""Application pages: Dashboard, EQ & CERPAC, EEPNL Quotas, Milestones, Data & Settings."""
from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path

from PySide6.QtCharts import (QBarCategoryAxis, QBarSeries, QBarSet, QChart, QChartView,
                              QHorizontalStackedBarSeries, QLegend, QPieSeries, QValueAxis)
from PySide6.QtCore import QMargins, Qt, Signal
from PySide6.QtGui import QColor, QCursor, QFont, QPainter, QPen
from PySide6.QtWidgets import (QApplication, QButtonGroup, QComboBox, QFileDialog, QGridLayout, QHBoxLayout,
                               QInputDialog, QLabel, QLineEdit, QMessageBox, QPushButton, QScrollArea, QSpinBox,
                               QStackedLayout, QTabWidget, QToolTip, QVBoxLayout, QWidget)

from .. import rules as R
from ..db import ACTION_STATUSES, ROLES, STATUS_DONE, STATUS_IN_PROGRESS, STATUS_NOT_STARTED, EQPosition, Quota
from ..excel_io import ImportFailed, export_workbook, import_workbook
from ..notifications import matter_key
from ..reimport import NEW, NOT_IN_FILE, UNCHANGED, UPDATED, apply_import, plan_import
from ..services import TILE_GROUPS, EQRow, QuotaRow, TrackerService
from .dialogs import ClientDialog, EQDialog, FmiUpdateDialog, QuotaDialog, TeamMemberDialog
from .theme import STATUS_TONE
from .widgets import (ROLE_HELP, BreakdownRow, Card, Column, DataTable, EmptyState, MetricCard, RowTableModel,
                      Visual)


def _shelf(v) -> str:
    if v == "":
        return "—"
    return "Expired" if v is None else str(v)


def _title(text: str, obj: str = "CardTitle") -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName(obj)
    return lbl


def _muted(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("Muted")
    lbl.setWordWrap(True)
    return lbl


class Page(QWidget):
    title = ""
    subtitle = ""
    data_changed = Signal()

    def __init__(self, svc: TrackerService, tokens: dict):
        super().__init__()
        self.svc = svc
        self.tokens = tokens

    def refresh(self) -> None: ...

    def set_search(self, text: str) -> None: ...

    def set_tokens(self, tokens: dict) -> None:
        self.tokens = tokens

    def require_client(self, action: str) -> int | None:
        """The client new records go to; in the 'All clients' view, ask the user to pick one first."""
        if self.svc.client_id is None:
            QMessageBox.information(self, "Choose a client first",
                                    f"You are viewing all clients. To {action}, choose the client in the "
                                    "Client dropdown at the top of the sidebar.")
        return self.svc.client_id


def _client_of(row) -> int | None:
    rec = getattr(row, "rec", row)
    return getattr(rec, "client_id", None)


def _client_column(svc) -> Column:
    return Column("Client", lambda r: svc.client_name(_client_of(r)), width=170,
                  tooltip="The client this record belongs to")


# --- Dashboard --------------------------------------------------------------

SLICER_TYPES = [("All", ""), ("EQ", R.SRC_EQ), ("CERPAC", R.SRC_CERPAC), ("EEPNL", R.SRC_QUOTA)]
WINDOW_CHOICES = [30, 60, 90, 180, 365]


def _chart_view(min_height: int) -> QChartView:
    view = QChartView()
    view.setRenderHint(QPainter.Antialiasing)
    view.setBackgroundBrush(Qt.transparent)
    view.setMinimumHeight(min_height)
    return view


def _show_tip(text: str) -> None:
    QToolTip.showText(QCursor.pos(), text)


class DashboardPage(Page):
    """Power BI style report: header with slicers, card visuals, charts, multi-row cards and table visuals."""
    title = "Dashboard"
    subtitle = "Report view · use the slicers to filter, hover for details, click any visual to drill through"
    navigate = Signal(str, object)  # page key, {filter key: value, "search": text}

    def __init__(self, svc, tokens):
        super().__init__(svc, tokens)
        self._type = ""
        self._window_choice: int | None = None
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        inner = QWidget()
        inner.setObjectName("Canvas")
        self.scroll.setWidget(inner)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(self.scroll)

        lay = QVBoxLayout(inner)
        lay.setContentsMargins(20, 16, 20, 20)
        lay.setSpacing(12)
        lay.addWidget(self._build_header())

        # Card visuals
        row = QHBoxLayout()
        row.setSpacing(12)
        self.metrics: dict[str, MetricCard] = {}
        for key, label, tone, tip in (
            ("records", "Records tracked", "chart1", "EQ positions and EEPNL quotas in scope"),
            ("actions", "Action required", "red", "Records past a notification, blackout or expiry trigger"),
            ("expired", "Expired", "orange", "Expired EQs, CERPACs and EEPNL quotas in scope"),
            ("due", "Milestones in window", "amber", "Milestones falling inside the selected window"),
            ("vacant", "Vacant", "grey", "EQ positions and EEPNL quotas without an expat"),
            ("health", "On track", "green", "Share of records in scope with an On Track / Valid status"),
        ):
            card = MetricCard(label, tone, tokens, tip + "\nClick to drill through.")
            card.clicked.connect(lambda k=key: self._open_metric(k))
            self.metrics[key] = card
            row.addWidget(card, 1)
        lay.addLayout(row)

        # Column chart + action donut
        row = QHBoxLayout()
        row.setSpacing(12)
        self.bar_card = Visual("Expiries by month", "Next 24 months · hover a column for the count")
        self.bar_view = _chart_view(320)
        self.bar_card.body.addWidget(self.bar_view)
        self.type_card = Visual("Action required by type", "Click a slice to filter the report")
        self.type_view = _chart_view(320)
        self.type_card.body.addWidget(self.type_view)
        row.addWidget(self.bar_card, 2)
        row.addWidget(self.type_card, 1)
        lay.addLayout(row)

        # Status visuals
        row = QHBoxLayout()
        row.setSpacing(12)
        self.pie_card = Visual("EQ status", "Click a slice to open those EQ positions")
        self.pie_view = _chart_view(280)
        self.pie_card.body.addWidget(self.pie_view)
        self.cerpac_card = Visual("CERPAC status", "Click a bar to open those records")
        self.cerpac_view = _chart_view(280)
        self.cerpac_card.body.addWidget(self.cerpac_view)
        self.quota_card = Visual("EEPNL quota status", "Click a slice to open those quotas")
        self.quota_view = _chart_view(280)
        self.quota_card.body.addWidget(self.quota_view)
        for w in (self.pie_card, self.cerpac_card, self.quota_card):
            row.addWidget(w, 1)
        lay.addLayout(row)

        # Multi-row cards, grouped so EQ, CERPAC and EEPNL figures are never mixed.
        row = QHBoxLayout()
        row.setSpacing(12)
        self.kpis: dict[str, BreakdownRow] = {}
        self._tile_targets: dict[str, tuple[str, dict]] = {}
        self._groups: dict[str, Visual] = {}
        for key, name, hint in TILE_GROUPS:
            v = Visual(name, hint)
            self._groups[key] = v
            row.addWidget(v, 1)
        for t in svc.tiles():
            item = BreakdownRow(t.title, t.tone, tokens, t.tooltip)
            item.clicked.connect(lambda k=t.key: self._open_tile(k))
            self.kpis[t.key] = item
            self._groups[t.group].body.addWidget(item)
        for v in self._groups.values():
            v.body.addStretch()
        lay.addLayout(row)

        # Table visual: action required
        self.actions_card = Visual("Action required",
                                   "Soonest expiry first · double-click a row to open the record")
        self.actions_badge = QLabel()
        self.actions_badge.setObjectName("Badge")
        self.actions_card.header.insertWidget(1, self.actions_badge)
        self.actions_model = RowTableModel([_client_column(svc)] + _action_columns(svc), tokens, lambda: svc.today)
        self.actions_table = DataTable(self.actions_model, tokens)
        self.actions_table.setMinimumHeight(420)
        self.actions_table.doubleClicked.connect(self._open_action)
        self.actions_empty = EmptyState("All clear", "No record in scope needs action today.")
        self.actions_card.body.addWidget(self.actions_table)
        self.actions_card.body.addWidget(self.actions_empty)
        lay.addWidget(self.actions_card)

        # Table visual: upcoming milestones
        self.ms_card = Visual("Upcoming milestones")
        view_all = QPushButton("View all milestones")
        view_all.setObjectName("Ghost")
        view_all.setCursor(Qt.PointingHandCursor)
        view_all.clicked.connect(lambda: self.navigate.emit("alerts", {}))
        self.ms_card.header.addWidget(view_all)
        self.ms_model = RowTableModel([_client_column(svc)] + _event_columns(svc), tokens, lambda: svc.today)
        self.ms_table = DataTable(self.ms_model, tokens)
        self.ms_table.setMinimumHeight(340)
        self.ms_empty = EmptyState("Nothing coming up", "No milestones in scope fall inside the window.")
        self.ms_card.body.addWidget(self.ms_table)
        self.ms_card.body.addWidget(self.ms_empty)
        lay.addWidget(self.ms_card)

    # --- header & slicers ---------------------------------------------------------

    def _build_header(self) -> QWidget:
        header = QWidget()
        header.setObjectName("ReportHeader")
        header.setAttribute(Qt.WA_StyledBackground, True)
        h = QHBoxLayout(header)
        h.setContentsMargins(20, 14, 20, 14)
        h.setSpacing(24)
        titles = QVBoxLayout()
        titles.setSpacing(2)
        titles.addWidget(_title("Immigration compliance report", "ReportTitle"))
        self.report_sub = QLabel()
        self.report_sub.setObjectName("ReportSub")
        titles.addWidget(self.report_sub)
        h.addLayout(titles)
        h.addStretch()

        type_box = QVBoxLayout()
        type_box.setSpacing(4)
        type_box.addWidget(_title("TYPE", "SlicerLabel"))
        buttons = QHBoxLayout()
        buttons.setSpacing(0)
        self.slicer = QButtonGroup(self)
        self.slicer.setExclusive(True)
        self.slicer_buttons: dict[str, QPushButton] = {}
        for label, value in SLICER_TYPES:
            b = QPushButton(label)
            b.setObjectName("Slicer")
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setChecked(value == "")
            b.clicked.connect(lambda _=False, v=value: self.set_type(v))
            self.slicer.addButton(b)
            self.slicer_buttons[value] = b
            buttons.addWidget(b)
        type_box.addLayout(buttons)
        h.addLayout(type_box)

        win_box = QVBoxLayout()
        win_box.setSpacing(4)
        win_box.addWidget(_title("MILESTONE WINDOW", "SlicerLabel"))
        self.window_combo = QComboBox()
        self.window_combo.setMinimumWidth(130)
        self.window_combo.currentIndexChanged.connect(self._window_changed)
        win_box.addWidget(self.window_combo)
        h.addLayout(win_box)
        return header

    def set_type(self, value: str) -> None:
        self._type = value
        self.slicer_buttons[value].setChecked(True)
        self.refresh()

    def _window_changed(self) -> None:
        if self.window_combo.signalsBlocked():
            return
        self._window_choice = self.window_combo.currentData()
        self.refresh()

    def _window(self) -> int:
        if self._window_choice:
            return self._window_choice
        return int(self.svc.db.get_setting("alert_window_days") or 90)

    def _sync_window_combo(self) -> None:
        window = self._window()
        choices = sorted(set(WINDOW_CHOICES) | {window})
        self.window_combo.blockSignals(True)
        self.window_combo.clear()
        for d in choices:
            self.window_combo.addItem(f"Next {d} days", d)
        self.window_combo.setCurrentIndex(choices.index(window))
        self.window_combo.blockSignals(False)

    def _in_scope(self, source: str) -> bool:
        return not self._type or self._type == source

    # --- drill-through -------------------------------------------------------------

    def _open_tile(self, key: str) -> None:
        page, filters = self._tile_targets[key]
        self.navigate.emit(page, dict(filters))

    def _open_action(self, index) -> None:
        item = self.actions_table.source.row_at(self.actions_table.proxy.mapToSource(index).row())
        self.navigate.emit(item.page, {"search": item.position})

    def _open_metric(self, key: str) -> None:
        if key == "actions":
            self.scroll.ensureWidgetVisible(self.actions_card)
            return
        if key == "due":
            self.navigate.emit("alerts", {})
            return
        page = "quotas" if self._type == R.SRC_QUOTA else "eq"
        filters = {}
        if key == "expired":
            filters = {"cerpac": R.CERPAC_EXPIRED} if self._type == R.SRC_CERPAC else {"status": R.ST_EXPIRED}
        elif key == "health":
            filters = {"cerpac": R.CERPAC_VALID} if self._type == R.SRC_CERPAC else {"status": R.ST_OK}
        self.navigate.emit(page, filters)

    # --- refresh -------------------------------------------------------------------

    def refresh(self) -> None:
        svc = self.svc
        self._sync_window_combo()
        window = self._window()
        scope = svc.client_name(svc.client_id) if svc.client_id else f"All clients ({len(svc.db.clients())})"
        self.report_sub.setText(f"{scope} · data as of {svc.today:%d %b %Y} · {len(svc.eq_rows)} EQ positions · "
                                f"{len(svc.quota_rows)} EEPNL quotas")

        for t in svc.tiles():
            item = self.kpis[t.key]
            item.set(t.count, t.hint)
            item.setToolTip(f"{t.tooltip}\nClick to open the list.")
            self._tile_targets[t.key] = (t.page, t.filters)
        self._groups["eq"].setVisible(self._in_scope(R.SRC_EQ))
        self._groups["cerpac"].setVisible(self._in_scope(R.SRC_CERPAC))
        self._groups["eepnl"].setVisible(self._in_scope(R.SRC_QUOTA))

        all_items = svc.action_items()
        items = [a for a in all_items if self._in_scope(a.source)]
        self.actions_model.set_rows(all_items)
        self.actions_table.proxy.set_column_filter(1, self._type)
        self.actions_table.sortByColumn(5, Qt.AscendingOrder)
        self.actions_table.setColumnHidden(0, svc.client_id is not None)
        self.actions_badge.setText(str(len(items)))
        self.actions_badge.setVisible(bool(items))
        self.actions_table.setVisible(bool(items))
        self.actions_empty.setVisible(not items)

        all_events = svc.upcoming_events(window)
        events = [e for e in all_events if self._in_scope(e.source)]
        self.ms_card.title.setText(f"Upcoming milestones · next {window} days")
        self.ms_model.set_rows(all_events)
        self.ms_table.proxy.set_column_filter(3, self._type)
        self.ms_table.sortByColumn(1, Qt.AscendingOrder)
        self.ms_table.setColumnHidden(0, svc.client_id is not None)
        self.ms_table.setVisible(bool(events))
        self.ms_empty.setVisible(not events)

        self._update_metrics(items, events)
        self._bar_chart()
        self._type_chart(all_items)
        self.pie_card.setVisible(self._in_scope(R.SRC_EQ))
        self.cerpac_card.setVisible(self._in_scope(R.SRC_CERPAC))
        self.quota_card.setVisible(self._in_scope(R.SRC_QUOTA))
        self._pie_chart()
        self._cerpac_chart()
        self._quota_chart()

    def _update_metrics(self, items, events) -> None:
        eq, qs = self.svc.eq_rows, self.svc.quota_rows
        use_eq = self._in_scope(R.SRC_EQ) or self._in_scope(R.SRC_CERPAC)
        use_q = self._in_scope(R.SRC_QUOTA)
        n_eq = len(eq) if use_eq else 0
        n_q = len(qs) if use_q else 0
        self.metrics["records"].set(n_eq + n_q, f"{n_eq} EQ · {n_q} EEPNL")

        by_type = {s: sum(1 for a in items if a.source == s) for s in (R.SRC_EQ, R.SRC_CERPAC, R.SRC_QUOTA)}
        self.metrics["actions"].set(len(items), " · ".join(f"{v} {k}" for k, v in by_type.items() if v)
                                    or "Nothing to action")

        exp = {
            R.SRC_EQ: sum(1 for r in eq if r.calc.status == R.ST_EXPIRED) if self._in_scope(R.SRC_EQ) else 0,
            R.SRC_CERPAC: sum(1 for r in eq if r.calc.cerpac_status == R.CERPAC_EXPIRED)
            if self._in_scope(R.SRC_CERPAC) else 0,
            R.SRC_QUOTA: sum(1 for r in qs if r.calc.status == R.ST_EXPIRED) if use_q else 0,
        }
        self.metrics["expired"].set(sum(exp.values()), " · ".join(f"{v} {k}" for k, v in exp.items() if v)
                                    or "None expired")

        self.metrics["due"].set(len(events), f"Next {self._window()} days")

        vac_eq = sum(1 for r in eq if r.calc.vacant) if use_eq else 0
        vac_q = sum(1 for r in qs if r.calc.vacant) if use_q else 0
        self.metrics["vacant"].set(vac_eq + vac_q, f"{vac_eq} EQ · {vac_q} EEPNL")

        if self._type == R.SRC_CERPAC:
            ok, total = sum(1 for r in eq if r.calc.cerpac_status == R.CERPAC_VALID), len(eq)
        else:
            ok = (sum(1 for r in eq if r.calc.status == R.ST_OK) if use_eq else 0) + \
                 (sum(1 for r in qs if r.calc.status == R.ST_OK) if use_q else 0)
            total = n_eq + n_q
        self.metrics["health"].set(f"{round(100 * ok / total) if total else 0}%", f"{ok} of {total} records")

    # --- charts --------------------------------------------------------------------

    def _style_chart(self, chart: QChart, legend_at=Qt.AlignTop) -> None:
        t = self.tokens
        chart.setBackgroundVisible(False)
        chart.setPlotAreaBackgroundVisible(False)
        chart.setMargins(QMargins(0, 0, 0, 0))
        chart.layout().setContentsMargins(0, 0, 0, 0)
        chart.setAnimationOptions(QChart.SeriesAnimations)
        legend = chart.legend()
        legend.setAlignment(legend_at)
        legend.setMarkerShape(QLegend.MarkerShapeCircle)
        legend.setLabelColor(QColor(t["text_muted"]))
        f = QFont()
        f.setPointSize(9)
        legend.setFont(f)

    def _style_axes(self, *axes) -> None:
        t = self.tokens
        f = QFont()
        f.setPointSize(8)
        grid = QPen(QColor(t["border"]))
        grid.setStyle(Qt.DashLine)
        for axis in axes:
            axis.setLabelsColor(QColor(t["text_muted"]))
            axis.setLabelsFont(f)
            axis.setGridLinePen(grid)
            axis.setLinePenColor(QColor(t["border"]))

    @staticmethod
    def _set_chart(view: QChartView, chart: QChart) -> None:
        old = view.chart()
        view.setChart(chart)
        if old is not None and old is not chart:
            old.deleteLater()

    def _value_axis(self, peak: int) -> QValueAxis:
        ay = QValueAxis()
        ay.setRange(0, peak + 1)
        ay.setTickCount(min(peak + 2, 6))
        ay.setLabelFormat("%d")
        return ay

    def _bar_chart(self) -> None:
        t = self.tokens
        data = self.svc.expiries_by_month(24)
        labels = [d[0] for d in data]
        index = {lbl: i for i, lbl in enumerate(labels)}
        quota = [0] * len(labels)
        for r in self.svc.quota_rows:
            if r.rec.expiry and (k := index.get(r.rec.expiry.strftime("%b %y"))) is not None:
                quota[k] += 1
        all_series = [
            (R.SRC_EQ, "EQ expiry", [d[1] for d in data], t["chart1"]),
            (R.SRC_CERPAC, "CERPAC expiry", [d[2] for d in data], t["chart2"]),
            (R.SRC_QUOTA, "EEPNL quota expiry", quota, t["chart3"]),
        ]
        series = QBarSeries()
        series.setBarWidth(0.75)
        peak = 1
        for src, name, values, color in all_series:
            if not self._in_scope(src):
                continue
            s = QBarSet(name)
            s.append(values)
            s.setColor(QColor(color))
            s.setBorderColor(QColor(color))
            s.hovered.connect(lambda on, i, n=name, v=values: on and _show_tip(f"{labels[i]}\n{n}: {v[i]}"))
            series.append(s)
            peak = max([peak] + values)
        chart = QChart()
        chart.addSeries(series)
        self._style_chart(chart)
        ax = QBarCategoryAxis()
        ax.append(labels)
        ay = self._value_axis(peak)
        self._style_axes(ax, ay)
        ax.setGridLineVisible(False)
        ax.setTruncateLabels(False)
        ax.setLabelsAngle(-45)
        chart.addAxis(ax, Qt.AlignBottom)
        chart.addAxis(ay, Qt.AlignLeft)
        series.attachAxis(ax)
        series.attachAxis(ay)
        self._set_chart(self.bar_view, chart)

    def _donut(self, view: QChartView, card: Visual, counts: list[tuple[str, int, str]], noun: str,
               on_click) -> None:
        """counts: [(label, value, colour)]; on_click(label) is the drill-through for a slice."""
        t = self.tokens
        total = sum(v for _, v, _ in counts)
        card.set_subtitle(f"{total} {noun} · click a slice to drill through" if total else f"No {noun} yet")
        series = QPieSeries()
        series.setHoleSize(0.6)
        series.setPieSize(0.85)
        for label, value, color in counts:
            if not value:
                continue
            pct = round(100 * value / total)
            sl = series.append(f"{label}  {value} ({pct}%)", value)
            sl.setColor(QColor(color))
            sl.setBorderColor(QColor(t["surface"]))
            sl.setBorderWidth(2)
            sl.hovered.connect(lambda on, s=sl, txt=f"{label}: {value} of {total} ({pct}%)":
                               (s.setExploded(on), on and _show_tip(txt)))
            sl.clicked.connect(lambda lbl=label: on_click(lbl))
        chart = QChart()
        chart.addSeries(series)
        self._style_chart(chart, Qt.AlignRight)
        self._set_chart(view, chart)

    def _type_chart(self, items) -> None:
        t = self.tokens
        colors = {R.SRC_EQ: t["chart1"], R.SRC_CERPAC: t["chart2"], R.SRC_QUOTA: t["chart3"]}
        counts = [(s, sum(1 for a in items if a.source == s), colors[s]) for s in colors]
        self._donut(self.type_view, self.type_card, counts, "records need action",
                    lambda s: self.set_type("" if self._type == s else s))
        if self._type:
            for sl in self.type_view.chart().series()[0].slices():
                sl.setExploded(sl.label().startswith(self._type + " "))

    def _pie_chart(self) -> None:
        t = self.tokens
        counts = [(s, sum(1 for r in self.svc.eq_rows if r.calc.status == s), t[STATUS_TONE.get(s, "grey")])
                  for s in R.EQ_STATUSES]
        self._donut(self.pie_view, self.pie_card, counts, "EQ positions",
                    lambda s: self.navigate.emit("eq", {"status": s}))

    def _quota_chart(self) -> None:
        t = self.tokens
        counts = [(s, sum(1 for r in self.svc.quota_rows if r.calc.status == s), t[STATUS_TONE.get(s, "grey")])
                  for s in R.QUOTA_STATUSES]
        self._donut(self.quota_view, self.quota_card, counts, "EEPNL quotas",
                    lambda s: self.navigate.emit("quotas", {"status": s}))

    def _cerpac_chart(self) -> None:
        t = self.tokens
        statuses = list(R.CERPAC_STATUSES)
        counts = [sum(1 for r in self.svc.eq_rows if r.calc.cerpac_status == s) for s in statuses]
        self.cerpac_card.set_subtitle(f"{sum(counts)} CERPAC records · click a bar to drill through")
        # One set per status (zero elsewhere) so every bar gets its own status colour.
        series = QHorizontalStackedBarSeries()
        series.setBarWidth(0.6)
        for i, s in enumerate(statuses):
            bs = QBarSet(s)
            bs.append([counts[i] if j == i else 0 for j in range(len(statuses))])
            color = QColor(t[STATUS_TONE.get(s, "grey")])
            bs.setColor(color)
            bs.setBorderColor(color)
            bs.setLabelColor(QColor(t["text"]))
            bs.hovered.connect(lambda on, _i, s=s, n=counts[i]: on and _show_tip(f"{s}: {n}"))
            bs.clicked.connect(lambda _i, s=s: self.navigate.emit("eq", {"cerpac": s}))
            series.append(bs)
        series.setLabelsVisible(True)
        series.setLabelsFormat("@value")
        series.setLabelsPosition(QHorizontalStackedBarSeries.LabelsInsideEnd)
        chart = QChart()
        chart.addSeries(series)
        self._style_chart(chart)
        chart.legend().setVisible(False)
        ay = QBarCategoryAxis()
        ay.append(statuses)
        ax = self._value_axis(max(counts + [1]))
        self._style_axes(ax, ay)
        ay.setGridLineVisible(False)
        chart.addAxis(ay, Qt.AlignLeft)
        chart.addAxis(ax, Qt.AlignBottom)
        series.attachAxis(ay)
        series.attachAxis(ax)
        self._set_chart(self.cerpac_view, chart)

    def set_tokens(self, tokens):
        super().set_tokens(tokens)
        for c in list(self.kpis.values()) + list(self.metrics.values()):
            c.apply_tokens(tokens)
        self.actions_table.set_tokens(tokens)
        self.ms_table.set_tokens(tokens)


def _days_left(svc: TrackerService, d) -> int | None:
    return (d - svc.today).days if d else None


def _days_text(v) -> str:
    if v is None or v == "":
        return "—"
    if v == 0:
        return "Today"
    return f"{v} days" if v > 0 else f"{-v} days ago"


def _action_columns(svc: TrackerService) -> list[Column]:
    return [
        Column("Type", lambda a: a.source, "pill", "EQ position, CERPAC or EEPNL quota", 100),
        Column("Status", lambda a: a.status, "pill", width=150),
        Column("Position", lambda a: a.position, width=280),
        Column("Expat", lambda a: a.person, width=150),
        Column("Expiry date", lambda a: a.expiry, "date", "EQ, CERPAC or EEPNL expiry date", 115, True),
        Column("Expires in", lambda a: _days_left(svc, a.expiry), "int", width=105, fmt=_days_text),
        Column("Why it is flagged", lambda a: a.trigger, width=300),
        Column("Next step", lambda a: a.next_step, width=380),
    ]


def _event_columns(svc: TrackerService) -> list[Column]:
    return [
        Column("Date", lambda e: e.when, "date", "Date the milestone is reached", 115),
        Column("In (days)", lambda e: (e.when - svc.today).days, "int", width=105, fmt=_days_text),
        Column("Type", lambda e: e.source, "pill", width=100),
        Column("Milestone", lambda e: e.kind, width=240),
        Column("Position", lambda e: e.position, width=260),
        Column("Expat", lambda e: e.person, width=140),
        Column("Expiry date", lambda e: e.anchor, "date", "The EQ, CERPAC or EEPNL expiry this milestone leads to", 115),
        Column("State", lambda e: e.state(svc.today), "pill",
               "Upcoming · Due now (trigger passed, expiry ahead) · Expired · Passed", 110),
        Column("Details", lambda e: e.detail, width=420),
    ]


# --- Record pages -----------------------------------------------------------

class TablePage(Page):
    # (filter key, "All …" label, column header, [value or (label, value)])
    filter_specs: list[tuple[str, str, str, list]] = []
    empty_message = ""

    def __init__(self, svc, tokens, columns: list[Column]):
        super().__init__(svc, tokens)
        columns = [_client_column(svc)] + columns
        self.columns = columns
        lay = QVBoxLayout(self)
        lay.setContentsMargins(32, 24, 32, 32)
        lay.setSpacing(16)

        bar = QHBoxLayout()
        bar.setSpacing(8)
        self.filters: dict[str, QComboBox] = {}
        self._filter_data: dict[str, list] = {}
        for key, all_label, header, values in self.filter_specs:
            cb = QComboBox()
            cb.addItem(all_label)
            data_list: list = [""]
            for v in values:
                label, data = v if isinstance(v, tuple) else (v, v)
                cb.addItem(label)
                data_list.append(data)
            cb.setMinimumWidth(170)
            cb.setToolTip(f"Show only rows with this {header}")
            col = self._col(header)
            cb.currentIndexChanged.connect(
                lambda i, c=col, k=key: self._filter_changed(c, self._filter_data[k][max(i, 0)]))
            self.filters[key] = cb
            self._filter_data[key] = data_list
            bar.addWidget(cb)
        self.clear_btn = QPushButton("Clear filters")
        self.clear_btn.setObjectName("Ghost")
        self.clear_btn.setCursor(Qt.PointingHandCursor)
        self.clear_btn.clicked.connect(lambda: self.apply_filters({}))
        self.clear_btn.setVisible(False)
        self.count = QLabel()
        self.count.setObjectName("Muted")
        bar.addWidget(self.clear_btn)
        bar.addWidget(self.count)
        bar.addStretch()
        self._buttons(bar)
        lay.addLayout(bar)

        card = Card(padding=0)
        self.model = RowTableModel(columns, tokens, lambda: svc.today)
        self.table = DataTable(self.model, tokens)
        self.table.doubleClicked.connect(lambda _: self.edit())
        self.stack = QStackedLayout()
        self.stack.addWidget(self.table)
        self.stack.addWidget(EmptyState("No records yet", self.empty_message))
        card.body.addLayout(self.stack)
        lay.addWidget(card, 1)
        self._update_count()

    def _col(self, header: str) -> int:
        return next(i for i, c in enumerate(self.columns) if c.header == header)

    def _filter_changed(self, column: int, value) -> None:
        self.table.proxy.set_column_filter(column, value)
        for cb in self.filters.values():
            # Highlight dropdowns that are narrowing the list so active filters are obvious.
            active = cb.currentIndex() > 0
            if cb.property("active") != active:
                cb.setProperty("active", active)
                cb.style().unpolish(cb)
                cb.style().polish(cb)
        self.clear_btn.setVisible(any(cb.currentIndex() > 0 for cb in self.filters.values()))
        self._update_count()

    def apply_filters(self, filters: dict) -> None:
        for key, cb in self.filters.items():
            wanted, options = filters.get(key, ""), self._filter_data[key]
            cb.setCurrentIndex(options.index(wanted) if wanted in options else 0)

    def _buttons(self, bar: QHBoxLayout) -> None:
        delete = QPushButton("Delete")
        delete.setObjectName("Danger")
        delete.clicked.connect(self.delete)
        edit = QPushButton("Edit")
        edit.clicked.connect(self.edit)
        add = QPushButton("+  Add")
        add.setObjectName("Primary")
        add.clicked.connect(self.add)
        for b in (delete, edit, add):
            b.setCursor(Qt.PointingHandCursor)
            bar.addWidget(b)

    def rows(self) -> list: return []

    def refresh(self) -> None:
        rows = self.rows()
        self.model.set_rows(rows)
        self.table.setColumnHidden(0, self.svc.client_id is not None)
        self.stack.setCurrentIndex(0 if rows else 1)
        self._update_count()

    def _update_count(self) -> None:
        if not hasattr(self, "table"):
            return
        shown, total = self.table.proxy.rowCount(), self.model.rowCount()
        self.count.setText(f"{shown} of {total} records")
        self.clear_btn.setVisible(any(cb.currentIndex() > 0 for cb in self.filters.values()))

    def set_search(self, text: str) -> None:
        self.table.proxy.set_text(text)
        self._update_count()

    def set_tokens(self, tokens):
        super().set_tokens(tokens)
        self.table.set_tokens(tokens)

    def _confirm_delete(self, n: int) -> bool:
        return QMessageBox.question(self, "Delete records", f"Delete {n} selected record(s)? This cannot be undone.",
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No) == QMessageBox.Yes

    def add(self): ...
    def edit(self): ...
    def delete(self): ...


class EQPage(TablePage):
    title = "EQ & CERPAC Tracker"
    subtitle = "EQ positions: EQ expiry = FMI approval + 2 years · EQ notice 7 months before · CERPAC notices 4 and 1 month before"
    filter_specs = [
        ("status", "All EQ statuses", "EQ status", R.EQ_STATUSES),
        ("renewal", "All renewal states", "Renewal", R.LIFECYCLES),
        ("cerpac", "All CERPAC statuses", "CERPAC status", R.CERPAC_STATUSES),
    ]
    empty_message = "Import the Excel tracker from Data & Settings or add a position."

    def __init__(self, svc, tokens):
        cols = [
            Column("S/N", lambda r: r.rec.sn, "int", width=60),
            Column("EQ position title", lambda r: r.rec.title, width=300),
            Column("EQ status", lambda r: r.calc.status, "pill",
                   "On Track → Heads-up (8 mo) → EQ Notify (7 mo) → EQ Blackout (6 mo) → EQ Expired", 130),
            Column("Renewal", lambda r: r.calc.lifecycle, "pill",
                   "Renewable · Final term (active, cannot be renewed once expired) · "
                   "Expired – renewable · Expired – non-renewable", 180),
            Column("Expat", lambda r: r.rec.expat or R.VACANT, width=130),
            Column("First grant", lambda r: r.rec.first_grant, "date", width=115),
            Column("FMI approval", lambda r: r.rec.fmi_approval, "date",
                   "Most recent FMI approval. Use 'Update FMI approval' to change it for selected rows", 120),
            Column("EQ expiry", lambda r: r.calc.expiry, "date", "FMI approval + 2 years", 115, True),
            Column("EQ notification", lambda r: r.calc.eq_notification, "date", "EQ expiry − 7 months", 125, True),
            Column("Blackout date", lambda r: r.calc.blackout_date, "date",
                   "EQ expiry − 6 months: EQ unavailable for new expat or CERPAC renewal", 120, True),
            Column("Blackout", lambda r: r.calc.blackout, "pill", "Closed when EQ expiry ≤ today + 6 months", 100),
            Column("Heads-up", lambda r: r.calc.lead_to_blackout, "date",
                   "EQ expiry − 8 months (2 months before blackout)", 115, True),
            Column("Lifespan end", lambda r: r.calc.validity, "date",
                   "First grant + maximum quota lifespan (Data & Settings)", 120),
            Column("Shelf life (mo)", lambda r: r.calc.shelf_life_months if r.calc.expiry else "", "int",
                   "Remaining whole months incl. renewal (to EQ expiry if final term, else to lifespan end)", 115,
                   fmt=lambda v: _shelf(v)),
            Column("CERPAC expiry", lambda r: r.rec.cerpac_expiry, "date", width=120, red_if_past=True),
            Column("CERPAC notice 1", lambda r: r.calc.cerpac_notification, "date", "CERPAC expiry − 4 months",
                   130, True),
            Column("CERPAC notice 2", lambda r: r.calc.cerpac_final_notification, "date",
                   "CERPAC expiry − 1 month", 130, True),
            Column("CERPAC status", lambda r: r.calc.cerpac_status, "pill", width=140),
            Column("Name of expat", lambda r: (r.quota.current_expat or R.VACANT) if r.quota else "",
                   width=170, tooltip="Current expat on the linked EEPNL quota"),
        ]
        super().__init__(svc, tokens, cols)
        self.table.horizontalHeader().setStretchLastSection(False)

    def _buttons(self, bar):
        fmi = QPushButton("Update FMI approval…")
        fmi.setToolTip("Set the most recent FMI approval date for the selected positions; EQ expiry and "
                       "notices recalculate automatically")
        fmi.setCursor(Qt.PointingHandCursor)
        fmi.clicked.connect(self.update_fmi)
        bar.addWidget(fmi)
        super()._buttons(bar)

    def rows(self) -> list[EQRow]:
        return self.svc.eq_rows

    def add(self):
        cid = self.require_client("add an EQ position")
        if cid is None:
            return
        self._open(EQPosition(None, self.svc.db.next_sn("eq_positions", cid), "", None, None, client_id=cid))

    def edit(self):
        sel = self.table.selected_rows()
        if sel:
            self._open(sel[0].rec)

    def _open(self, rec: EQPosition):
        dlg = EQDialog(rec, self.svc.db.quotas(rec.client_id), self.svc.today, self.svc.lifespan_years, self)
        if dlg.exec():
            self.svc.db.save_eq(dlg.result_record())
            self.data_changed.emit()

    def update_fmi(self):
        sel = self.table.selected_rows()
        if not sel:
            QMessageBox.information(self, "Select positions", "Select one or more EQ positions first "
                                    "(Ctrl+click or Shift+click to select several).")
            return
        dlg = FmiUpdateDialog([r.rec for r in sel], self.svc.today, self.svc.lifespan_years, self)
        if dlg.exec():
            self.svc.db.set_fmi_approval([r.rec.id for r in sel], dlg.value())
            self.data_changed.emit()

    def delete(self):
        sel = self.table.selected_rows()
        if sel and self._confirm_delete(len(sel)):
            self.svc.db.delete_eq([r.rec.id for r in sel])
            self.data_changed.emit()


class QuotaPage(TablePage):
    title = "EEPNL Quotas"
    subtitle = "EEPNL quota register · 2-year grants · notice 7 months before expiry · non-renewable after lifespan"
    filter_specs = [
        ("status", "All quota statuses", "EQ status", R.QUOTA_STATUSES),
        ("renewal", "All renewal states", "Renewal", R.LIFECYCLES),
        ("category", "All categories", "Category", R.CATEGORIES),
    ]
    empty_message = "Import the Excel tracker from Data & Settings or add a quota."

    def __init__(self, svc, tokens):
        cols = [
            Column("S/N", lambda r: r.rec.sn, "int", width=60),
            Column("Quota position title", lambda r: r.rec.title, width=320),
            Column("EQ status", lambda r: r.calc.status, "pill",
                   "On Track → EQ Notify (7 mo) → EQ Blackout (6 mo) → EQ Expired", 130),
            Column("Renewal", lambda r: r.calc.lifecycle, "pill",
                   "Renewable · Final term (active, cannot be renewed once expired) · "
                   "Expired – renewable · Expired – non-renewable", 180),
            Column("Current expat", lambda r: r.rec.current_expat or R.VACANT, width=170),
            Column("Previous incumbent", lambda r: r.rec.previous_incumbent, width=160,
                   tooltip="Previous incumbent name (if different as at 1/1/2025)"),
            Column("First grant", lambda r: r.rec.first_grant, "date", width=115),
            Column("EQ expiry", lambda r: r.rec.expiry, "date", "Last renewal or issue date + 2 years", 115, True),
            Column("Expires in", lambda r: r.calc.days_to_expiry, "int", width=105, fmt=_days_text),
            Column("EQ notification", lambda r: r.calc.notification, "date", "EQ expiry − 7 months", 125, True),
            Column("Lifespan end", lambda r: r.calc.non_renewable_date, "date",
                   "Non-renewable date: first grant + maximum lifespan, unless overridden on the record", 120, True),
            Column("Category", lambda r: r.rec.category, "pill", width=150),
            Column("Movement", lambda r: r.rec.movement, "pill", width=140),
            Column("Notes", lambda r: r.rec.notes, width=220),
        ]
        super().__init__(svc, tokens, cols)

    def rows(self) -> list[QuotaRow]:
        return self.svc.quota_rows

    def add(self):
        cid = self.require_client("add an EEPNL quota")
        if cid is None:
            return
        self._open(Quota(None, self.svc.db.next_sn("quotas", cid), "", None, None, client_id=cid))

    def edit(self):
        sel = self.table.selected_rows()
        if sel:
            self._open(sel[0].rec)

    def _open(self, rec: Quota):
        dlg = QuotaDialog(rec, self.svc.today, self.svc.lifespan_years, self)
        if dlg.exec():
            self.svc.db.save_quota(dlg.result_record())
            self.data_changed.emit()

    def delete(self):
        sel = self.table.selected_rows()
        if sel and self._confirm_delete(len(sel)):
            self.svc.db.delete_quotas([r.rec.id for r in sel])
            self.data_changed.emit()


class AlertsPage(TablePage):
    title = "Milestones"
    subtitle = "Every EQ, CERPAC and EEPNL milestone with its trigger, expiry date and what to do"
    filter_specs = [
        ("state", "All states", "State",
         [("Due now + upcoming", (R.STATE_DUE, R.STATE_UPCOMING))] + R.EVENT_STATES),
        ("type", "All types", "Type", [("EQ positions", R.SRC_EQ), ("CERPAC", R.SRC_CERPAC),
                                       ("EEPNL quotas", R.SRC_QUOTA)]),
        ("milestone", "All milestones", "Milestone",
         [R.EV_EQ_NOTIFY, R.EV_HEADS_UP, R.EV_BLACKOUT, R.EV_EXPIRY, R.EV_CERPAC_NOTIFY, R.EV_CERPAC_FINAL_NOTIFY,
          R.EV_CERPAC_EXPIRY, R.EV_QUOTA_NOTIFY, R.EV_QUOTA_EXPIRY, R.EV_NON_RENEWABLE]),
        ("action", "All actions", "Action", list(ACTION_STATUSES)),
    ]
    empty_message = "No milestones. Add EQ positions or quotas first."

    def __init__(self, svc, tokens):
        statuses: dict[str, str] = {}
        columns = _event_columns(svc)
        columns.insert(2, Column(
            "Action", lambda e: statuses.get(matter_key(e), STATUS_NOT_STARTED), "pill",
            "Not started · In progress (stops escalation) · Done (stops all emails). Applies to every milestone "
            "of the same expiry.", 110))
        super().__init__(svc, tokens, columns)
        self._statuses = statuses
        self.apply_filters({"state": (R.STATE_DUE, R.STATE_UPCOMING)})

    def apply_filters(self, filters: dict) -> None:
        super().apply_filters(filters or {"state": (R.STATE_DUE, R.STATE_UPCOMING)})

    def _buttons(self, bar):
        for text, status, name in (("Reset", STATUS_NOT_STARTED, "Ghost"),
                                   ("Mark in progress", STATUS_IN_PROGRESS, ""),
                                   ("Mark done", STATUS_DONE, "Primary")):
            b = QPushButton(text)
            if name:
                b.setObjectName(name)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, s=status: self._set_status(s))
            bar.addWidget(b)

    def _set_status(self, status: str) -> None:
        sel = self.table.selected_rows()
        if not sel:
            QMessageBox.information(self, "Select milestones", "Select one or more milestones first "
                                    "(Ctrl+click or Shift+click to select several).")
            return
        done = set()
        for e in sel:
            m = matter_key(e)
            if m not in done:
                done.add(m)
                expiry = (e.anchor or e.when).strftime("%d-%b-%Y")
                self.svc.db.set_matter_status(m, status, f"{e.source} {e.position} / {e.person} (expires {expiry})")
        self.refresh()

    def rows(self):
        return self.svc.events

    def refresh(self):
        self._statuses.clear()
        self._statuses.update(self.svc.db.matter_statuses())
        super().refresh()
        self.table.sortByColumn(0, Qt.AscendingOrder)


# --- Data & settings --------------------------------------------------------

class DataPage(Page):
    title = "Data & Settings"
    subtitle = "Clients, team members, settings, backups, and business rules"
    theme_changed = Signal(str)
    client_chosen = Signal(object)  # client id: the whole app switches to it

    def __init__(self, svc, tokens):
        super().__init__(svc, tokens)
        self.svc = svc
        self.tokens = tokens
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        inner.setObjectName("Content")
        scroll.setWidget(inner)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(32, 24, 32, 32)
        lay.setSpacing(16)

        tabs = QTabWidget()
        tabs.addTab(self._create_clients_tab(svc), "Clients")
        tabs.addTab(self._create_reminder_rules_tab(svc), "Reminder rules")
        tabs.addTab(self._create_backups_tab(svc), "Backups")
        tabs.addTab(self._create_preferences_tab(svc), "Preferences")
        tabs.addTab(self._create_rules_tab(svc), "Rules")
        lay.addWidget(tabs)
        lay.addStretch()

    def _create_clients_tab(self, svc) -> QWidget:
        """Clients tab: pick a client (dropdown when there are several), then manage its team."""
        from ..client_manager import ClientManager

        tab = QWidget()
        lay = QVBoxLayout(tab)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        self.client_mgr = ClientManager(svc.db)
        self._client_id: int | None = None

        card = Card()
        head = QHBoxLayout()
        head.setSpacing(10)
        head.addWidget(_title("Client"))
        self.client_picker = QComboBox()
        self.client_picker.setMinimumWidth(340)
        self.client_picker.setPlaceholderText("Select a client…")
        self.client_picker.setToolTip("Choose the client whose team you want to see and manage")
        self.client_picker.currentIndexChanged.connect(self._client_selected)
        self.client_single = QLabel()
        self.client_single.setObjectName("ClientName")
        head.addWidget(self.client_picker)
        head.addWidget(self.client_single)
        head.addStretch()
        new_btn = QPushButton("+  New client")
        new_btn.setObjectName("Primary")
        new_btn.clicked.connect(self._add_client)
        self.edit_client_btn = QPushButton("Edit client")
        self.edit_client_btn.clicked.connect(self._edit_client)
        self.archive_client_btn = QPushButton("Archive client")
        self.archive_client_btn.setObjectName("Danger")
        self.archive_client_btn.clicked.connect(self._archive_client)
        for b in (self.edit_client_btn, self.archive_client_btn, new_btn):
            b.setCursor(Qt.PointingHandCursor)
            head.addWidget(b)
        card.body.addLayout(head)
        self.client_summary = _muted("")
        self.client_warning = QLabel()
        self.client_warning.setObjectName("Warning")
        self.client_warning.setWordWrap(True)
        card.body.addWidget(self.client_summary)
        card.body.addWidget(self.client_warning)
        self.clients_empty = EmptyState("No clients yet",
                                        "Click “+ New client” to add your first client, then add its team members.")
        card.body.addWidget(self.clients_empty)
        lay.addWidget(card)

        self.team_card = Card()
        head = QHBoxLayout()
        head.setSpacing(8)
        self.team_title = _title("Team members")
        head.addWidget(self.team_title)
        head.addStretch()
        self.edit_member_btn = QPushButton("Edit")
        self.edit_member_btn.clicked.connect(self._edit_client_user)
        self.remove_member_btn = QPushButton("Remove")
        self.remove_member_btn.setObjectName("Danger")
        self.remove_member_btn.clicked.connect(self._remove_client_user)
        add_member = QPushButton("+  Add team member")
        add_member.setObjectName("Primary")
        add_member.clicked.connect(self._add_client_user)
        for b in (self.edit_member_btn, self.remove_member_btn, add_member):
            b.setCursor(Qt.PointingHandCursor)
            head.addWidget(b)
        self.team_card.body.addLayout(head)
        self.team_card.body.addWidget(_muted(
            "The reminder rules apply to every client: the Owner gets each notice first; if it is still not "
            "started, Managers and then Partners are escalated to. Double-click a member to edit."))
        self.users_model = RowTableModel([
            Column("Name", lambda u: u.name or "—", width=200),
            Column("Email", lambda u: u.email, width=260),
            Column("Role", lambda u: u.role, "pill", width=110),
            Column("Receives", lambda u: ROLE_HELP.get(u.role, ""), width=330),
            Column("Status", lambda u: "Active" if u.active else "Paused", "pill", width=100),
        ], self.tokens, lambda: svc.today)
        self.users_table = DataTable(self.users_model, self.tokens)
        self.users_table.setMinimumHeight(260)
        self.users_table.doubleClicked.connect(lambda _: self._edit_client_user())
        self.users_empty = EmptyState("No team members yet",
                                      "Click “+ Add team member”. Start with the Owner — they receive every "
                                      "reminder for this client.")
        self.team_card.body.addWidget(self.users_table)
        self.team_card.body.addWidget(self.users_empty)
        lay.addWidget(self.team_card)
        lay.addStretch()
        self._reload_clients()
        return tab

    def _reload_clients(self, select_id: int | None = None) -> None:
        """Refill the client dropdown (keeping or moving the selection) and the team list."""
        clients = self.client_mgr.get_clients()
        keep = select_id if select_id is not None else self._client_id
        self.client_picker.blockSignals(True)
        self.client_picker.clear()
        for c in clients:
            n = len(self.client_mgr.db.client_users(c.id, active_only=False))
            label = c.name + (f"  ·  {c.industry}" if c.industry else "")
            self.client_picker.addItem(f"{label}  ·  {n} member{'s' if n != 1 else ''}", c.id)
        idx = self.client_picker.findData(keep)
        self.client_picker.setCurrentIndex(idx if idx >= 0 else (0 if clients else -1))
        self.client_picker.blockSignals(False)

        has = bool(clients)
        self.client_picker.setVisible(len(clients) > 1)
        self.client_single.setVisible(len(clients) == 1)
        if len(clients) == 1:
            c = clients[0]
            self.client_single.setText(c.name + (f"  ·  {c.industry}" if c.industry else ""))
        self.edit_client_btn.setEnabled(has)
        self.archive_client_btn.setEnabled(has)
        self.clients_empty.setVisible(not has)
        self.client_summary.setVisible(has)
        self.team_card.setVisible(has)
        self._client_id = self.client_picker.currentData() if has else None
        self._refresh_users_table()

    def _client_selected(self) -> None:
        self._client_id = self.client_picker.currentData()
        self._refresh_users_table()
        self.client_chosen.emit(self._client_id)

    def _current_client(self):
        return self.client_mgr.db.get_client(self._client_id) if self._client_id is not None else None

    def _refresh_users_table(self) -> None:
        client = self._current_client()
        users = self.client_mgr.db.client_users(client.id, active_only=False) if client else []
        self.users_model.set_rows(users)
        self.users_table.setVisible(bool(users))
        self.users_empty.setVisible(not users)
        self.edit_member_btn.setEnabled(bool(users))
        self.remove_member_btn.setEnabled(bool(users))
        if not client:
            self.client_warning.setVisible(False)
            return
        self.team_title.setText(f"Team members · {client.name}")
        active = [u for u in users if u.active]
        counts = {r: sum(1 for u in active if u.role == r) for r in ROLES}
        self.client_summary.setText("Active team: " + " · ".join(
            f"{n} {r}{'s' if n != 1 else ''}" for r, n in counts.items()))
        self.client_warning.setText("" if counts["Owner"] else
                                    "No active Owner yet — reminders for this client have no first recipient. "
                                    "Add an Owner in Team members below.")
        self.client_warning.setVisible(not counts["Owner"])

    def _client_names_and_industries(self) -> tuple[list[str], list[str]]:
        all_clients = self.client_mgr.get_clients(active_only=False)
        return [c.name for c in all_clients], [c.industry for c in all_clients if c.industry]

    def _add_client(self) -> None:
        names, industries = self._client_names_and_industries()
        dlg = ClientDialog(None, names, industries, self)
        if not dlg.exec():
            return
        name, industry = dlg.values()
        try:
            new_id = self.client_mgr.add_client(name, industry)
        except sqlite3.Error as e:
            QMessageBox.critical(self, "Could not add client", str(e))
            return
        self._reload_clients(select_id=new_id)
        self.client_chosen.emit(new_id)
        if QMessageBox.question(self, "Add team members",
                                f"'{name}' was added. Add its Owner now?") == QMessageBox.StandardButton.Yes:
            self._add_client_user()

    def _edit_client(self) -> None:
        client = self._current_client()
        if not client:
            return
        names, industries = self._client_names_and_industries()
        dlg = ClientDialog(client, names, industries, self)
        if not dlg.exec():
            return
        name, industry = dlg.values()
        try:
            self.client_mgr.db.update_client(client.id, name, industry)
        except sqlite3.Error as e:
            QMessageBox.critical(self, "Could not update client", str(e))
            return
        self._reload_clients()
        self.client_chosen.emit(client.id)

    def _archive_client(self) -> None:
        client = self._current_client()
        if not client:
            return
        if QMessageBox.question(self, "Archive client",
                                f"Archive '{client.name}'?\n\nIt is removed from the client dropdown together with "
                                f"its team list.") != QMessageBox.StandardButton.Yes:
            return
        self.client_mgr.db.archive_client(client.id)
        self._client_id = None
        self._reload_clients()
        self.client_chosen.emit(self._client_id)

    def _add_client_user(self) -> None:
        clients = self.client_mgr.get_clients()
        if not clients:
            QMessageBox.information(self, "Add a client first",
                                    "Team members belong to a client. Click “+ New client” first.")
            return
        db = self.client_mgr.db
        current = self._client_id
        has_owner = current is not None and any(u.role == "Owner" and u.active for u in db.client_users(current))
        dlg = TeamMemberDialog(clients, current, None,
                               lambda cid: {u.email for u in db.client_users(cid, active_only=False)},
                               "Manager" if has_owner else "Owner", self)
        if not dlg.exec():
            return
        email, name, role, _ = dlg.values()
        try:
            self.client_mgr.add_client_user(dlg.client_id, email, name, role)
        except (sqlite3.Error, ValueError) as e:
            QMessageBox.critical(self, "Could not add team member", str(e))
            return
        self._reload_clients(select_id=dlg.client_id)
        self.client_chosen.emit(dlg.client_id)

    def _selected_member(self, action: str):
        rows = self.users_table.selected_rows()
        if not rows:
            QMessageBox.information(self, "Select a team member", f"Click a team member in the list to {action}.")
            return None
        return rows[0]

    def _edit_client_user(self) -> None:
        member = self._selected_member("edit")
        if not member:
            return
        dlg = TeamMemberDialog(self.client_mgr.get_clients(), member.client_id, member, parent=self)
        if not dlg.exec():
            return
        _, name, role, active = dlg.values()
        self.client_mgr.update_client_user(member.id, role, name, active)
        self._refresh_users_table()
        self.data_changed.emit()

    def _remove_client_user(self) -> None:
        member = self._selected_member("remove")
        if not member:
            return
        who = member.name or member.email
        if QMessageBox.question(self, "Remove team member",
                                f"Remove {who} ({member.role}) from this client?") != QMessageBox.StandardButton.Yes:
            return
        self.client_mgr.db.delete_client_user(member.id)
        self._reload_clients()
        self.data_changed.emit()

    def _create_reminder_rules_tab(self, svc) -> QWidget:
        """Create Reminder rules tab."""
        tab = QWidget()
        lay = QVBoxLayout(tab)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        info = _muted("When reminders fire and who receives them. Double-click to edit.")
        lay.addWidget(info)

        card = Card()
        self.rules_model = RowTableModel([
            Column("For", lambda r: getattr(r, 'for', ''), width=90),
            Column("Stage", lambda r: getattr(r, 'stage', ''), width=150),
            Column("Fires", lambda r: getattr(r, 'fires', ''), width=170),
            Column("Not started: to", lambda r: getattr(r, 'not_started_to', ''), width=150),
            Column("Not started: copy", lambda r: getattr(r, 'not_started_copy', ''), width=150),
            Column("In progress: to", lambda r: getattr(r, 'in_progress_to', ''), width=150),
            Column("In progress: copy", lambda r: getattr(r, 'in_progress_copy', ''), width=150),
            Column("Active", lambda r: getattr(r, 'active', ''), width=70),
        ], self.tokens, lambda: svc.today)
        self.rules_table = DataTable(self.rules_model, self.tokens)
        card.body.addWidget(self.rules_table)
        lay.addWidget(card)
        lay.addStretch()
        return tab

    def _create_backups_tab(self, svc) -> QWidget:
        """Create Backups & Import/Export tab."""
        tab = QWidget()
        lay = QVBoxLayout(tab)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)
        row = QHBoxLayout()
        row.setSpacing(16)

        imp = Card()
        imp.body.addWidget(_title("Import Excel tracker"))
        msg = QLabel("Loads the 'EQ & CERPAC Tracker' and 'EEPNL QUOTAS' tables from a workbook into the client "
                     "selected in the sidebar. If that client already has data, you'll see what will change first, "
                     "then choose to update and add, or replace. A backup is taken first so you can restore the "
                     "previous data at any time.")
        msg.setObjectName("Muted")
        msg.setWordWrap(True)
        imp.body.addWidget(msg)
        btns = QHBoxLayout()
        btns.setSpacing(8)
        b = QPushButton("Choose workbook…")
        b.setObjectName("Primary")
        b.clicked.connect(self.import_excel)
        restore = QPushButton("Restore previous data…")
        restore.clicked.connect(self.restore_backup)
        btns.addWidget(b)
        btns.addWidget(restore)
        btns.addStretch()
        imp.body.addLayout(btns)
        imp.body.addStretch()

        exp = Card()
        exp.body.addWidget(_title("Export to Excel"))
        msg2 = QLabel("Writes the selected client's records to both sheets with the original column layout and live "
                      "Excel formulas, so the file keeps recalculating in Excel.")
        msg2.setObjectName("Muted")
        msg2.setWordWrap(True)
        exp.body.addWidget(msg2)
        b2 = QPushButton("Export workbook…")
        b2.clicked.connect(self.export_excel)
        exp.body.addWidget(b2, 0, Qt.AlignLeft)
        exp.body.addStretch()
        row.addWidget(imp)
        row.addWidget(exp)
        lay.addLayout(row)
        lay.addStretch()
        return tab

    def _create_preferences_tab(self, svc) -> QWidget:
        """Create Preferences tab."""
        tab = QWidget()
        lay = QVBoxLayout(tab)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        st = Card()
        st.body.addWidget(_title("General"))
        form = QGridLayout()
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(12)
        
        lbl = QLabel("Theme")
        lbl.setObjectName("FormLabel")
        self.theme = QComboBox()
        self.theme.addItems(["Light", "Dark"])
        self.theme.setCurrentText(svc.db.get_setting("theme").title())
        self.theme.currentTextChanged.connect(self._theme)
        
        lbl2 = QLabel("Alert window (days)")
        lbl2.setObjectName("FormLabel")
        self.window_spin = QSpinBox()
        self.window_spin.setRange(7, 730)
        self.window_spin.setValue(int(svc.db.get_setting("alert_window_days") or 90))
        self.window_spin.valueChanged.connect(self._window)
        
        lbl4 = QLabel("Maximum quota lifespan (years)")
        lbl4.setObjectName("FormLabel")
        self.lifespan_spin = QSpinBox()
        self.lifespan_spin.setRange(2, 10)
        self.lifespan_spin.setValue(svc.lifespan_years)
        self.lifespan_spin.setToolTip("Counted from the first grant date. A quota whose expiry reaches this "
                                      "lifespan is in its final term and cannot be renewed.")
        self.lifespan_spin.valueChanged.connect(self._lifespan)
        lifespan_hint = _muted("From first grant. Drives the Renewal column (final term / non-renewable) on both "
                               "registers. An EEPNL non-renewable override date still takes priority.")
        lbl3 = QLabel("Database")
        lbl3.setObjectName("FormLabel")
        path = QLabel(svc.db.path)
        path.setObjectName("Muted")
        path.setTextInteractionFlags(Qt.TextSelectableByMouse)
        
        form.addWidget(lbl, 0, 0)
        form.addWidget(self.theme, 0, 1)
        form.addWidget(lbl2, 1, 0)
        form.addWidget(self.window_spin, 1, 1)
        form.addWidget(lbl4, 2, 0)
        form.addWidget(self.lifespan_spin, 2, 1)
        form.addWidget(lifespan_hint, 2, 2)
        form.addWidget(lbl3, 3, 0)
        form.addWidget(path, 3, 1, 1, 2)
        form.setColumnStretch(2, 1)
        st.body.addLayout(form)
        lay.addWidget(st)
        lay.addStretch()
        return tab

    def _create_rules_tab(self, svc) -> QWidget:
        """Create Rules tab."""
        tab = QWidget()
        lay = QVBoxLayout(tab)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        rules = Card()
        rules.body.addWidget(_title("Business rules"))
        self.rules_text = QLabel()
        self.rules_text.setObjectName("Muted")
        self.rules_text.setWordWrap(True)
        self.rules_text.setTextFormat(Qt.RichText)
        rules.body.addWidget(self.rules_text)
        lay.addWidget(rules)
        lay.addStretch()
        return tab

    def _theme(self, text: str) -> None:
        self.svc.db.set_setting("theme", text.lower())
        self.theme_changed.emit(text.lower())

    def _window(self, value: int) -> None:
        self.svc.db.set_setting("alert_window_days", str(value))
        self.data_changed.emit()

    def _lifespan(self, value: int) -> None:
        self.svc.db.set_setting("quota_lifespan_years", str(value))
        self.data_changed.emit()

    def refresh(self) -> None:
        n = self.svc.lifespan_years
        if self.lifespan_spin.value() != n:
            self.lifespan_spin.blockSignals(True)
            self.lifespan_spin.setValue(n)
            self.lifespan_spin.blockSignals(False)
        rows = [
            ("EQ expiry", "Most recent FMI approval + 2 years"),
            ("EQ notification", "7 months before EQ expiry (email notice)"),
            ("EQ blackout", "Closes 6 months before EQ expiry: no new expat or CERPAC renewal on the EQ"),
            ("Heads-up", "8 months before EQ expiry (2 months before blackout)"),
            ("CERPAC notifications", "4 months and 1 month before CERPAC expiry (email notices)"),
            ("Lifespan end", f"First grant + {n} years (EEPNL: unless a non-renewable override date is set)"),
            ("Renewal", "Renewable if EQ expiry is before the lifespan end; otherwise Final term (active, "
                        "cannot be renewed once expired). Expired records show Expired – renewable or "
                        "Expired – non-renewable"),
            ("Shelf life", "Whole months to the lifespan end (renewable) or to EQ expiry (final term)"),
        ]
        self.rules_text.setText("<table cellspacing='0' cellpadding='3'>" + "".join(
            f"<tr><td style='padding-right:16px'><b>{k}</b></td><td>{v}</td></tr>" for k, v in rows) + "</table>")
        # Keep the Clients tab on the client chosen in the sidebar (and refresh member counts).
        self._reload_clients(select_id=self.svc.client_id)

    def import_excel(self) -> None:
        cid = self.require_client("import a workbook")
        if cid is None:
            return
        client = self.svc.client_name(cid)
        path, _ = QFileDialog.getOpenFileName(self, f"Import Excel tracker into {client}", "",
                                              "Excel workbook (*.xlsx *.xlsm)")
        if not path:
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            rep = import_workbook(path)
        except ImportFailed as exc:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Import not completed", str(exc))
            return
        except Exception as exc:  # unexpected parser failure: keep the app running, data untouched
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Import failed", "The workbook could not be read. Your current data has not "
                                 f"been changed.\n\nDetails: {exc}")
            return
        QApplication.restoreOverrideCursor()

        db = self.svc.db
        source = Path(path).name
        plan = plan_import(db.quotas(cid), db.eq_positions(cid), rep.quotas, rep.positions, rep.has_quotas,
                           rep.has_eq)
        has_data = bool(db.eq_positions(cid) or db.quotas(cid))
        remove_missing = False
        if has_data:
            if not plan.has_changes:
                QMessageBox.information(self, "Already up to date",
                                        f"Every record in {source} already matches {client}. Nothing was changed.")
                return
            lines = [f"Importing into {client}.",
                     f"{source} contains {len(rep.positions)} EQ positions and {len(rep.quotas)} EEPNL quotas.", ""]
            for kind, label, present in (("eq_position", "EQ positions", rep.has_eq),
                                         ("quota", "EEPNL quotas", rep.has_quotas)):
                if not present:
                    lines.append(f"{label}: not in this workbook, so yours will not be touched.")
                    continue
                lines.append(f"{label}: {plan.count(kind, NEW)} new, {plan.count(kind, UPDATED)} updated, "
                             f"{plan.count(kind, UNCHANGED)} unchanged, {plan.count(kind, NOT_IN_FILE)} in the app "
                             "but not in this file.")
            lines += ["", "Update and add: apply changes and add new records. Records that are only in the app are "
                          "kept, and notes and links added in the app are kept."]
            if plan.not_in_file:
                lines.append(f"Replace: the same, but also remove the {plan.not_in_file} record(s) that are not in "
                             "this file.")
            lines += ["", "A backup is saved first, so you can undo this with 'Restore previous data'. "
                          "Click 'Show Details' to see every change."]
            box = QMessageBox(QMessageBox.Question, "Import into existing data", "\n".join(lines), parent=self)
            update_btn = box.addButton("Update and add", QMessageBox.AcceptRole)
            replace_btn = box.addButton("Replace", QMessageBox.DestructiveRole) if plan.not_in_file else None
            box.addButton(QMessageBox.Cancel)
            box.setDefaultButton(update_btn)
            box.setDetailedText("\n".join(c.describe() for c in plan.positions + plan.quotas
                                          if c.action != UNCHANGED))
            box.exec()
            clicked = box.clickedButton()
            if clicked not in (update_btn, replace_btn) or clicked is None:
                return
            remove_missing = clicked is replace_btn
            if remove_missing and QMessageBox.warning(
                    self, "Remove records?", f"{plan.not_in_file} record(s) that are not in {source} will be removed "
                    "from the app. Continue?", QMessageBox.Yes | QMessageBox.Cancel,
                    QMessageBox.Cancel) != QMessageBox.Yes:
                return
        try:
            if has_data:
                db.backup("before-import")
            counts = apply_import(db, plan, remove_missing, source, client_id=cid)
        except (sqlite3.Error, OSError) as exc:
            QMessageBox.critical(self, "Import failed", "The data could not be saved, so nothing was changed."
                                 f"\n\nDetails: {exc}")
            return
        self.data_changed.emit()
        summary = (f"{counts[NEW]} added, {counts[UPDATED]} updated, {counts[UNCHANGED]} unchanged"
                   + (f", {counts['Removed']} removed" if remove_missing else "")
                   + (f", {counts['Kept']} kept that are not in the file" if counts["Kept"] else "") + ".")
        done = QMessageBox(QMessageBox.Information, "Import complete",
                           f"Imported {source} into {client}: {summary}\nEvery change is listed in Activity History."
                           + (f"\n\n{len(rep.warnings)} row(s) need attention — see details." if rep.warnings else ""),
                           parent=self)
        if rep.warnings:
            done.setDetailedText("\n".join(rep.warnings))
        done.exec()

    def restore_backup(self) -> None:
        db = self.svc.db
        backups = db.backups()
        if not backups:
            QMessageBox.information(self, "No backups yet", "A backup is created automatically before each import.")
            return
        labels = []
        for p in backups:
            parts = p.stem.split("-")  # tracker-YYYYMMDD-HHMMSS-reason
            try:
                when = datetime.strptime(parts[1] + parts[2], "%Y%m%d%H%M%S").strftime("%d %b %Y %H:%M:%S")
            except (IndexError, ValueError):
                when = p.stem
            labels.append(f"{when}  ·  {' '.join(parts[3:]) or 'backup'}")
        choice, ok = QInputDialog.getItem(self, "Restore previous data", "Restore the data saved at:", labels, 0, False)
        if not ok:
            return
        source = backups[labels.index(choice)]
        if QMessageBox.question(self, "Restore data?", "Current records will be replaced by this backup. "
                                "A backup of the current data is saved first.") != QMessageBox.Yes:
            return
        try:
            db.backup("before-restore")
            db.restore(source)
        except (sqlite3.Error, OSError) as exc:
            QMessageBox.critical(self, "Restore failed", f"The backup could not be restored. Nothing was changed."
                                 f"\n\nDetails: {exc}")
            return
        self.data_changed.emit()
        QMessageBox.information(self, "Restored", "Previous data restored.")

    def export_excel(self) -> None:
        cid = self.require_client("export a workbook")
        if cid is None:
            return
        client = self.svc.client_name(cid)
        safe = "".join(ch for ch in client if ch not in '\\/:*?"<>|').strip()
        name = f"Expatriate Quota & CERPAC Tracker - {safe} {self.svc.today:%Y-%m-%d}.xlsx"
        path, _ = QFileDialog.getSaveFileName(self, f"Export {client} to Excel", name, "Excel workbook (*.xlsx)")
        if not path:
            return
        try:
            export_workbook(path, self.svc.db.quotas(cid), self.svc.db.eq_positions(cid), self.svc.lifespan_years)
        except PermissionError:
            QMessageBox.critical(self, "Export failed", "The file is open in another program. Close it and try again.")
            return
        except OSError as exc:
            QMessageBox.critical(self, "Export failed", f"The file could not be saved.\n\nDetails: {exc}")
            return
        QMessageBox.information(self, "Export complete", f"Saved to:\n{path}")


# --- Activity History -------------------------------------------------------

class ActivityHistoryPage(Page):
    title = "Activity History"
    subtitle = "Every change, import, and backup restore · newest first · read-only"

    def __init__(self, svc, tokens):
        super().__init__(svc, tokens)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(32, 24, 32, 32)
        lay.setSpacing(16)

        bar = QHBoxLayout()
        bar.setSpacing(8)
        
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search by ID, field, or value…")
        self.search.textChanged.connect(self._on_search_changed)
        bar.addWidget(self.search)

        self.kind = QComboBox()
        self.kind.addItem("All changes", "")
        self.kind.addItem("EQ & CERPAC", "eq_position")
        self.kind.addItem("EEPNL quotas", "quota")
        self.kind.addItem("Milestone status", "milestone")
        self.kind.currentIndexChanged.connect(self._on_filter_changed)
        bar.addWidget(self.kind)

        self.count = QLabel()
        self.count.setObjectName("Muted")
        bar.addWidget(self.count)
        bar.addStretch()
        lay.addLayout(bar)

        columns = [
            Column("Client", lambda r: svc.client_name(r["client_id"]) or "All clients", width=160),
            Column("When", lambda r: _format_timestamp(r["at"]), width=160),
            Column("By", lambda r: r["by_user"] or "—", width=100),
            Column("Action", lambda r: r["action"], "pill", width=130),
            Column("Type", lambda r: r["item_type"] or "—", width=90),
            Column("Item", lambda r: r["item_id"] or "—", width=90),
            Column("Field", lambda r: (r["field"] or "").replace("_", " "), width=150),
            Column("Old value", lambda r: r["old_value"] or "—", width=160),
            Column("New value", lambda r: r["new_value"] or "—", width=160),
            Column("Detail", lambda r: r["detail"] or "—", width=300),
        ]

        card = Card(padding=0)
        self.model = RowTableModel(columns, tokens, lambda: svc.today)
        self.table = DataTable(self.model, tokens)
        card.body.addWidget(self.table)
        lay.addWidget(card, 1)
        self.refresh()

    def refresh(self) -> None:
        logs = self.svc.db.activity_logs(self.search.text().strip(), self.kind.currentData() or "",
                                         client_id=self.svc.client_id)
        self.model.set_rows(list(logs))
        self.table.setColumnHidden(0, self.svc.client_id is not None)
        self.count.setText(f"{len(logs)} entries" + (" (latest 2000)" if len(logs) >= 2000 else ""))

    def set_search(self, text: str) -> None:
        if self.search.text() != text:
            self.search.blockSignals(True)
            self.search.setText(text)
            self.search.blockSignals(False)
            self.refresh()

    def _on_search_changed(self, text: str) -> None:
        self.refresh()

    def _on_filter_changed(self, index: int) -> None:
        self.refresh()


def _format_timestamp(ts: str) -> str:
    """Format ISO timestamp to readable format."""
    try:
        dt = datetime.fromisoformat(ts)
        return dt.strftime("%d-%b %H:%M")
    except (ValueError, TypeError):
        return ts or "—"
