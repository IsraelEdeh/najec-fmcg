"""Design tokens and the application stylesheet."""
from __future__ import annotations

import tempfile
from pathlib import Path

from .. import rules as R

FONT_FAMILIES = ["Segoe UI Variable Text", "Segoe UI", "Inter"]

LIGHT = {
    "bg": "#F5F7FA", "surface": "#FFFFFF", "surface_alt": "#F9FAFB", "border": "#E4E7EC",
    "text": "#101828", "text_muted": "#667085", "primary": "#2E5BFF", "primary_hover": "#2149D9",
    "primary_soft": "#EEF2FF", "sidebar": "#0F1E36", "sidebar_text": "#B7C3D7", "sidebar_active": "#1E3A66",
    "row_hover": "#F2F5FF", "selection": "#DCE5FF", "shadow": "#1018281A",
    "green": "#12B76A", "green_bg": "#ECFDF3", "amber": "#F79009", "amber_bg": "#FFFAEB",
    "orange": "#EF6820", "orange_bg": "#FEF6EE", "red": "#D92D20", "red_bg": "#FEF3F2",
    "grey": "#667085", "grey_bg": "#F2F4F7", "blue": "#2E90FA", "blue_bg": "#EFF8FF",
    "purple": "#7A5AF8", "purple_bg": "#F4F3FF",
    "canvas": "#EAECF0", "header": "#0F1E36",
    "chart1": "#118DFF", "chart2": "#12239E", "chart3": "#E66C37", "chart4": "#6B007B",
}

DARK = {
    "bg": "#0B1220", "surface": "#121A2B", "surface_alt": "#162036", "border": "#24314A",
    "text": "#E6EAF2", "text_muted": "#8A97AD", "primary": "#5B7FFF", "primary_hover": "#7593FF",
    "primary_soft": "#1B2848", "sidebar": "#080E1A", "sidebar_text": "#8A97AD", "sidebar_active": "#1B2848",
    "row_hover": "#18233A", "selection": "#22325A", "shadow": "#00000066",
    "green": "#32D583", "green_bg": "#0F2A1E", "amber": "#FDB022", "amber_bg": "#2E230B",
    "orange": "#F38744", "orange_bg": "#2E1A0E", "red": "#F97066", "red_bg": "#33140F",
    "grey": "#98A2B3", "grey_bg": "#1D2639", "blue": "#53B1FD", "blue_bg": "#0F2238",
    "purple": "#9B8AFB", "purple_bg": "#1E1A3A",
    "canvas": "#070C16", "header": "#121A2B",
    "chart1": "#3AA0FF", "chart2": "#7C8CFF", "chart3": "#FF8A5C", "chart4": "#C86DD7",
}

# status text -> tone
STATUS_TONE = {
    R.ST_OK: "green", R.RENEWABLE: "green", R.OPEN: "green", R.CERPAC_VALID: "green", "Active": "green",
    R.STATE_UPCOMING: "blue", "Notice": "blue",
    R.ST_HEADS_UP: "amber", R.ST_NOTIFY: "amber", R.CERPAC_NOTIFY: "amber",
    R.ST_BLACKOUT: "orange", R.CERPAC_FINAL_NOTIFY: "orange", R.STATE_DUE: "orange",
    R.LC_EXPIRED_RENEWABLE: "orange",
    R.CLOSED: "red", R.ST_EXPIRED: "red", R.NOT_RENEWABLE: "red", R.CERPAC_EXPIRED: "red",
    R.LC_EXPIRED_FINAL: "red", R.STATE_EXPIRED: "red",
    R.LC_FINAL_TERM: "purple",
    R.VACANT: "grey", R.NOT_SET: "grey", R.STATE_PASSED: "grey", "Paused": "grey",
    R.SRC_EQ: "blue", R.SRC_CERPAC: "purple", R.SRC_QUOTA: "grey",
    "Exchange Program": "blue", "PUR Candidate": "purple", "Non-renewable": "red", "Standard": "grey",
    "Moving Out": "orange", "Hold / Moving In": "purple",
    "Owner": "blue", "Manager": "amber", "Partner": "purple",
    "Not started": "grey", "In progress": "blue", "Done": "green",
}


def tone_colors(tokens: dict, status: str) -> tuple[str, str]:
    tone = STATUS_TONE.get(status, "grey")
    return tokens[tone], tokens[f"{tone}_bg"]


def _arrow(color: str) -> str:
    """Path to a small chevron PNG in `color`, drawn once and cached in the temp folder."""
    path = Path(tempfile.gettempdir()) / f"immigration_tracker_chevron_{color.lstrip('#')}.png"
    if not path.exists():
        from PySide6.QtCore import QPointF, Qt
        from PySide6.QtGui import QColor, QImage, QPainter, QPen
        img = QImage(24, 24, QImage.Format_ARGB32)
        img.fill(Qt.transparent)
        p = QPainter(img)
        p.setRenderHint(QPainter.Antialiasing)
        pen = QPen(QColor(color), 2.6)
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        p.setPen(pen)
        p.drawPolyline([QPointF(6, 9), QPointF(12, 15), QPointF(18, 9)])
        p.end()
        img.save(str(path))
    return path.as_posix()


def stylesheet(t: dict) -> str:
    return f"""
* {{ font-size: 13px; color: {t['text']}; }}
QMainWindow, #Content {{ background: {t['bg']}; }}
QToolTip {{ background: {t['sidebar']}; color: #FFFFFF; border: none; padding: 6px 8px; border-radius: 6px; }}

#Sidebar {{ background: {t['sidebar']}; }}
#Brand {{ color: #FFFFFF; font-size: 16px; font-weight: 600; padding: 0 8px; }}
#BrandSub {{ color: {t['sidebar_text']}; font-size: 11px; padding: 0 8px; }}
#NavButton {{
    background: transparent; color: {t['sidebar_text']}; border: none; text-align: left;
    padding: 10px 14px; border-radius: 8px; font-size: 13px; font-weight: 500;
}}
#NavButton:hover {{ background: {t['sidebar_active']}; color: #FFFFFF; }}
#NavButton:checked {{ background: {t['primary']}; color: #FFFFFF; }}
#SidebarFooter {{ color: {t['sidebar_text']}; font-size: 11px; }}
#SidebarLabel {{ color: {t['sidebar_text']}; font-size: 11px; font-weight: 700; padding: 0 8px; }}
QComboBox#ClientSwitch {{
    background: {t['sidebar_active']}; color: #FFFFFF; border: 1px solid #2E4A78; border-radius: 8px;
    padding: 8px 12px; padding-right: 28px; font-size: 13px; font-weight: 600;
}}
QComboBox#ClientSwitch:hover {{ border: 1px solid {t['primary']}; }}
QComboBox#ClientSwitch:disabled {{ color: {t['sidebar_text']}; background: transparent; }}
QComboBox#ClientSwitch::down-arrow {{ image: url("{_arrow('#B7C3D7')}"); width: 12px; height: 12px; }}

#TopBar {{ background: {t['surface']}; border-bottom: 1px solid {t['border']}; }}
#PageTitle {{ font-size: 20px; font-weight: 600; }}
#PageSubtitle, #Muted {{ color: {t['text_muted']}; font-size: 12px; }}
#TodayChip {{
    background: {t['primary_soft']}; color: {t['primary']}; border-radius: 14px;
    padding: 4px 12px; font-weight: 600; font-size: 12px;
}}

#Card {{ background: {t['surface']}; border: 1px solid {t['border']}; border-radius: 12px; }}
#KpiCard {{ background: {t['surface']}; border: 1px solid {t['border']}; border-radius: 12px; }}
#KpiCard:hover {{ border: 1px solid {t['primary']}; background: {t['row_hover']}; }}
#CardTitle {{ font-size: 14px; font-weight: 600; }}
#KpiLabel {{ color: {t['text_muted']}; font-size: 12px; font-weight: 500; }}
#KpiValue {{ font-size: 28px; font-weight: 600; }}
#KpiHint {{ color: {t['text_muted']}; font-size: 12px; }}
#SectionTitle {{ font-size: 16px; font-weight: 600; }}
#GroupTitle {{ font-size: 13px; font-weight: 700; color: {t['text']}; }}
#GroupHint {{ color: {t['text_muted']}; font-size: 12px; }}
#Badge {{
    background: {t['red_bg']}; color: {t['red']}; border-radius: 10px; padding: 2px 10px;
    font-weight: 700; font-size: 12px;
}}

#Canvas {{ background: {t['canvas']}; }}
#ReportHeader {{ background: {t['header']}; border-radius: 4px; }}
#ReportTitle {{ color: #FFFFFF; font-size: 18px; font-weight: 600; }}
#ReportSub {{ color: #B7C3D7; font-size: 12px; }}
#SlicerLabel {{ color: #B7C3D7; font-size: 11px; font-weight: 600; }}
QPushButton#Slicer {{
    background: transparent; color: #FFFFFF; border: 1px solid #3A4A66; border-radius: 0;
    padding: 5px 14px; font-size: 12px;
}}
QPushButton#Slicer:hover {{ background: #22324F; border-color: #5B6E8F; }}
QPushButton#Slicer:checked {{ background: {t['chart1']}; border-color: {t['chart1']}; font-weight: 600; }}
#ReportHeader QComboBox {{
    background: transparent; color: #FFFFFF; border: 1px solid #3A4A66; border-radius: 0; padding: 4px 10px;
}}
#Visual {{ background: {t['surface']}; border: 1px solid {t['border']}; border-radius: 4px; }}
#VisualTitle {{ font-size: 13px; font-weight: 600; }}
#VisualSub {{ color: {t['text_muted']}; font-size: 11px; }}
#Metric {{ background: {t['surface']}; border: 1px solid {t['border']}; border-radius: 4px; }}
#Metric:hover {{ border: 1px solid {t['chart1']}; }}
#MetricValue {{ font-size: 32px; font-weight: 600; }}
#MetricLabel {{ color: {t['text']}; font-size: 12px; font-weight: 600; }}
#MetricHint {{ color: {t['text_muted']}; font-size: 11px; }}
#BreakdownRow {{ background: transparent; border-radius: 4px; }}
#BreakdownRow:hover {{ background: {t['row_hover']}; }}
#BreakdownLabel {{ font-size: 12px; font-weight: 600; }}
#BreakdownHint {{ color: {t['text_muted']}; font-size: 11px; }}
#BreakdownValue {{ font-size: 20px; font-weight: 600; }}

QLineEdit, QComboBox, QDateEdit, QSpinBox, QPlainTextEdit {{
    background: {t['surface']}; border: 1px solid {t['border']}; border-radius: 8px;
    padding: 6px 10px; min-height: 22px; selection-background-color: {t['selection']};
}}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QSpinBox:focus, QPlainTextEdit:focus {{
    border: 1px solid {t['primary']};
}}
QComboBox::drop-down, QDateEdit::drop-down {{
    subcontrol-origin: padding; subcontrol-position: center right; border: none; width: 28px;
}}
QComboBox::down-arrow, QDateEdit::down-arrow {{ image: url("{_arrow(t['text_muted'])}"); width: 12px; height: 12px; }}
QComboBox::down-arrow:on {{ image: url("{_arrow(t['primary'])}"); }}
QComboBox {{ combobox-popup: 0; padding-right: 28px; }}
QComboBox:hover, QDateEdit:hover {{ border: 1px solid {t['primary']}; }}
QComboBox:disabled {{ color: {t['text_muted']}; background: {t['surface_alt']}; }}
QComboBox QAbstractItemView {{
    background: {t['surface']}; border: 1px solid {t['border']}; selection-background-color: {t['selection']};
    selection-color: {t['text']}; outline: 0; padding: 4px;
}}
QComboBox QAbstractItemView::item {{ min-height: 30px; padding: 2px 10px; border-radius: 6px; }}
QComboBox QAbstractItemView::item:hover {{ background: {t['row_hover']}; }}
QComboBox QAbstractItemView::item:selected {{ background: {t['selection']}; color: {t['text']}; }}
QComboBox[active="true"] {{
    border: 1px solid {t['primary']}; background: {t['primary_soft']}; color: {t['primary']}; font-weight: 600;
}}
#ClientName {{ font-size: 15px; font-weight: 600; }}
#Warning {{ color: {t['orange']}; font-size: 12px; font-weight: 600; }}
#Search {{ min-width: 280px; padding-left: 12px; border-radius: 18px; background: {t['surface_alt']}; }}

QPushButton {{
    background: {t['surface']}; border: 1px solid {t['border']}; border-radius: 8px;
    padding: 7px 14px; font-weight: 500;
}}
QPushButton:hover {{ background: {t['surface_alt']}; border-color: {t['primary']}; }}
QPushButton:disabled {{ color: {t['text_muted']}; }}
QPushButton#Primary {{ background: {t['primary']}; color: #FFFFFF; border: 1px solid {t['primary']}; }}
QPushButton#Primary:hover {{ background: {t['primary_hover']}; }}
QPushButton#Danger {{ color: {t['red']}; }}
QPushButton#Danger:hover {{ background: {t['red_bg']}; border-color: {t['red']}; }}
QPushButton#Ghost {{ border: none; background: transparent; color: {t['primary']}; }}

QTableView {{
    background: {t['surface']}; alternate-background-color: {t['surface_alt']};
    border: none; gridline-color: transparent; selection-background-color: {t['selection']};
    selection-color: {t['text']}; outline: 0;
}}
QTableView::item {{ padding: 0 10px; border-bottom: 1px solid {t['border']}; }}
QTableView::item:hover {{ background: {t['row_hover']}; }}
QHeaderView::section {{
    background: {t['surface_alt']}; color: {t['text_muted']}; border: none;
    border-bottom: 1px solid {t['border']}; padding: 8px 10px; font-size: 12px; font-weight: 600;
}}
QTableCornerButton::section {{ background: {t['surface_alt']}; border: none; }}

QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {t['border']}; border-radius: 4px; min-height: 30px; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {t['border']}; border-radius: 4px; min-width: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: none; }}
QScrollArea {{ background: transparent; border: none; }}
QChartView {{ background: transparent; border: none; }}

QDialog {{ background: {t['surface']}; }}
QLabel#FormLabel {{ color: {t['text_muted']}; font-size: 12px; font-weight: 600; }}
QLabel#Computed {{ background: {t['surface_alt']}; border-radius: 8px; padding: 10px; }}
QCheckBox {{ spacing: 8px; }}
QMessageBox {{ background: {t['surface']}; }}
"""
