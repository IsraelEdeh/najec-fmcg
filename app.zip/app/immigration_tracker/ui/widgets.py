"""Reusable UI building blocks: cards, KPI tiles, pill delegate, column-driven table model."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Any, Callable

from PySide6.QtCore import (QAbstractTableModel, QEvent, QModelIndex, QObject, QRectF, QSize,
                            QSortFilterProxyModel, Qt, Signal)
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPen
from PySide6.QtWidgets import (QComboBox, QCompleter, QFrame, QGraphicsDropShadowEffect, QHBoxLayout, QHeaderView,
                               QLabel, QStyle, QStyledItemDelegate, QStyleOptionViewItem, QTableView, QVBoxLayout,
                               QWidget, QAbstractItemView)

from ..db import ROLES
from .theme import tone_colors

SORT_ROLE = Qt.UserRole + 1
KIND_ROLE = Qt.UserRole + 2

ROLE_HELP = {
    "Owner": "Receives every notice and reminder first",
    "Manager": "Escalation if still not started · Owner copied",
    "Partner": "Final escalation · Owner and Managers copied",
}


def role_combo(current: str = "Owner") -> QComboBox:
    """Role dropdown whose items explain who receives what."""
    cb = QComboBox()
    for role in ROLES:
        cb.addItem(f"{role}  —  {ROLE_HELP[role]}", role)
        cb.setItemData(cb.count() - 1, ROLE_HELP[role], Qt.ToolTipRole)
    cb.setCurrentIndex(max(cb.findData(current), 0))
    cb.setToolTip("Owner gets every reminder; Managers then Partners are escalated to if it is still not started.")
    return cb


def make_searchable(cb: QComboBox, placeholder: str) -> None:
    """Let the user type to filter a long dropdown (matches anywhere in the item text)."""
    cb.setEditable(True)
    cb.setInsertPolicy(QComboBox.NoInsert)
    cb.lineEdit().setPlaceholderText(placeholder)
    comp = cb.completer()
    comp.setCompletionMode(QCompleter.PopupCompletion)
    comp.setFilterMode(Qt.MatchContains)
    comp.setCaseSensitivity(Qt.CaseInsensitive)


class _DropdownPolish(QObject):
    """App-wide: styled list items (so the stylesheet's item height/hover apply) and a hand cursor on every dropdown."""

    def eventFilter(self, obj, event) -> bool:
        if event.type() == QEvent.Polish and isinstance(obj, QComboBox) and not obj.property("_polished"):
            obj.setProperty("_polished", True)
            obj.setItemDelegate(QStyledItemDelegate(obj))
            obj.setCursor(Qt.PointingHandCursor)
        return False


def polish_dropdowns(app) -> None:
    if getattr(app, "_dropdown_polish", None) is None:
        app._dropdown_polish = _DropdownPolish(app)
        app.installEventFilter(app._dropdown_polish)


def fmt_date(d: date | None) -> str:
    return d.strftime("%d-%b-%Y") if d else "—"


class Card(QFrame):
    def __init__(self, parent: QWidget | None = None, padding: int = 20, spacing: int = 12):
        super().__init__(parent)
        self.setObjectName("Card")
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(padding, padding, padding, padding)
        self.body.setSpacing(spacing)


class KpiCard(Card):
    clicked = Signal()

    def __init__(self, label: str, tone: str, tokens: dict, tooltip: str = ""):
        super().__init__(padding=16, spacing=4)
        self.setObjectName("KpiCard")
        self.setCursor(Qt.PointingHandCursor)
        self.tone = tone
        # Shadow only on light-weight tiles; effects on table/chart parents are slow.
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(24)
        shadow.setOffset(0, 2)
        shadow.setColor(QColor(16, 24, 40, 18))
        self.setGraphicsEffect(shadow)
        self.setMinimumHeight(112)
        self.setToolTip(tooltip)
        top = QHBoxLayout()
        top.setSpacing(8)
        self.dot = QLabel()
        self.dot.setFixedSize(10, 10)
        lbl = QLabel(label)
        lbl.setObjectName("KpiLabel")
        top.addWidget(self.dot)
        top.addWidget(lbl)
        top.addStretch()
        self.value = QLabel("0")
        self.value.setObjectName("KpiValue")
        self.hint = QLabel("")
        self.hint.setObjectName("KpiHint")
        self.hint.setWordWrap(True)
        lbl.setWordWrap(True)
        self.body.addLayout(top)
        self.body.addWidget(self.value)
        self.body.addWidget(self.hint)
        self.body.addStretch()
        self.apply_tokens(tokens)

    def apply_tokens(self, tokens: dict) -> None:
        self.dot.setStyleSheet(f"background:{tokens[self.tone]}; border-radius:5px;")

    def set(self, value: int | str, hint: str = "") -> None:
        self.value.setText(str(value))
        self.hint.setText(hint)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(event)


class Visual(QFrame):
    """Power BI style visual container: flat tile with a small title, optional subtitle and a body."""

    def __init__(self, title: str = "", subtitle: str = "", padding: int = 14):
        super().__init__()
        self.setObjectName("Visual")
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(padding, padding - 2, padding, padding)
        self.body.setSpacing(6)
        self.header = QHBoxLayout()
        self.header.setSpacing(8)
        self.title = QLabel(title)
        self.title.setObjectName("VisualTitle")
        self.header.addWidget(self.title)
        self.header.addStretch()
        self.body.addLayout(self.header)
        self.subtitle = QLabel(subtitle)
        self.subtitle.setObjectName("VisualSub")
        self.subtitle.setWordWrap(True)
        self.subtitle.setVisible(bool(subtitle))
        self.body.addWidget(self.subtitle)

    def set_subtitle(self, text: str) -> None:
        self.subtitle.setText(text)
        self.subtitle.setVisible(bool(text))


class MetricCard(QFrame):
    """Power BI card visual: coloured accent strip, large value, category label underneath."""
    clicked = Signal()

    def __init__(self, label: str, tone: str, tokens: dict, tooltip: str = ""):
        super().__init__()
        self.setObjectName("Metric")
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(tooltip)
        self.setMinimumHeight(118)
        self.tone = tone
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        self.accent = QFrame()
        self.accent.setFixedHeight(4)
        outer.addWidget(self.accent)
        inner = QVBoxLayout()
        inner.setContentsMargins(16, 10, 16, 12)
        inner.setSpacing(2)
        self.value = QLabel("0")
        self.value.setObjectName("MetricValue")
        self.value.setAlignment(Qt.AlignCenter)
        self.label = QLabel(label)
        self.label.setObjectName("MetricLabel")
        self.label.setAlignment(Qt.AlignCenter)
        self.hint = QLabel("")
        self.hint.setObjectName("MetricHint")
        self.hint.setAlignment(Qt.AlignCenter)
        self.hint.setWordWrap(True)
        inner.addStretch()
        inner.addWidget(self.value)
        inner.addWidget(self.label)
        inner.addWidget(self.hint)
        inner.addStretch()
        outer.addLayout(inner)
        self.apply_tokens(tokens)

    def apply_tokens(self, tokens: dict) -> None:
        self.accent.setStyleSheet(f"background:{tokens[self.tone]}; border-top-left-radius:4px;"
                                  "border-top-right-radius:4px;")

    def set(self, value: int | str, hint: str = "") -> None:
        self.value.setText(str(value))
        self.hint.setText(hint)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(event)


class BreakdownRow(QFrame):
    """One line of a Power BI multi-row card: colour marker, label, hint and value; clickable for drill-through."""
    clicked = Signal()

    def __init__(self, label: str, tone: str, tokens: dict, tooltip: str = ""):
        super().__init__()
        self.setObjectName("BreakdownRow")
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(tooltip)
        self.tone = tone
        lay = QHBoxLayout(self)
        lay.setContentsMargins(8, 6, 10, 6)
        lay.setSpacing(10)
        self.marker = QFrame()
        self.marker.setFixedSize(4, 30)
        text = QVBoxLayout()
        text.setSpacing(0)
        self.label = QLabel(label)
        self.label.setObjectName("BreakdownLabel")
        self.hint = QLabel("")
        self.hint.setObjectName("BreakdownHint")
        text.addWidget(self.label)
        text.addWidget(self.hint)
        self.value = QLabel("0")
        self.value.setObjectName("BreakdownValue")
        self.value.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        lay.addWidget(self.marker)
        lay.addLayout(text, 1)
        lay.addWidget(self.value)
        self.apply_tokens(tokens)

    def apply_tokens(self, tokens: dict) -> None:
        self.marker.setStyleSheet(f"background:{tokens[self.tone]}; border-radius:2px;")

    def set(self, value: int | str, hint: str = "") -> None:
        self.value.setText(str(value))
        self.hint.setText(hint)
        self.hint.setVisible(bool(hint))

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(event)


class EmptyState(QWidget):
    def __init__(self, title: str, message: str):
        super().__init__()
        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignCenter)
        t = QLabel(title)
        t.setObjectName("SectionTitle")
        t.setAlignment(Qt.AlignCenter)
        m = QLabel(message)
        m.setObjectName("Muted")
        m.setAlignment(Qt.AlignCenter)
        m.setWordWrap(True)
        lay.addWidget(t)
        lay.addWidget(m)


@dataclass
class Column:
    header: str
    get: Callable[[Any], Any]
    kind: str = "text"            # text | date | int | pill
    tooltip: str = ""
    width: int = 120
    red_if_past: bool = False
    fmt: Callable[[Any], str] | None = None


RED_VALUES = {"Vacant", "Not Renewable", "Expired", "EQ Expired", "CERPAC Expired"}


class RowTableModel(QAbstractTableModel):
    def __init__(self, columns: list[Column], tokens: dict, today_fn: Callable[[], date]):
        super().__init__()
        self.columns = columns
        self.rows: list[Any] = []
        self.tokens = tokens
        self.today_fn = today_fn

    def set_rows(self, rows: list[Any]) -> None:
        self.beginResetModel()
        self.rows = rows
        self.endResetModel()

    def row_at(self, r: int) -> Any:
        return self.rows[r]

    def rowCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self.columns)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation != Qt.Horizontal:
            return None
        col = self.columns[section]
        if role == Qt.DisplayRole:
            return col.header
        if role == Qt.ToolTipRole:
            return col.tooltip or None
        if role == Qt.TextAlignmentRole:
            return int((Qt.AlignRight if col.kind == "int" else Qt.AlignLeft) | Qt.AlignVCenter)
        return None

    def data(self, index: QModelIndex, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        col = self.columns[index.column()]
        value = col.get(self.rows[index.row()])
        if role == Qt.DisplayRole:
            if col.fmt is not None:
                return col.fmt(value)
            if col.kind == "date":
                return fmt_date(value)
            if value is None or value == "":
                return "—"
            return str(value)
        if role == SORT_ROLE:
            if value is None or value == "":
                return float("inf") if col.kind in ("date", "int") else "~"
            return value.toordinal() if col.kind == "date" else value
        if role == KIND_ROLE:
            return col.kind
        if role == Qt.TextAlignmentRole:
            return int((Qt.AlignRight if col.kind == "int" else Qt.AlignLeft) | Qt.AlignVCenter)
        if role == Qt.ForegroundRole:
            if col.kind == "date" and col.red_if_past and value and value < self.today_fn():
                return QColor(self.tokens["red"])
            if value is None or value == "":
                return QColor(self.tokens["text_muted"])
            if col.kind == "text" and value in RED_VALUES:
                return QColor(self.tokens["red"])
        if role == Qt.ToolTipRole and col.tooltip:
            return f"{col.header}: {self.data(index)}\n{col.tooltip}"
        if role == Qt.ToolTipRole and isinstance(value, str) and len(value) > 30:
            return value
        return None


class FilterProxy(QSortFilterProxyModel):
    def __init__(self):
        super().__init__()
        self.setSortRole(SORT_ROLE)
        self.setFilterCaseSensitivity(Qt.CaseInsensitive)
        self.text = ""
        self.column_filters: dict[int, tuple[str, ...]] = {}

    def set_text(self, text: str) -> None:
        self.text = text.strip().lower()
        self.invalidateFilter()

    def set_column_filter(self, column: int, value) -> None:
        """`value` is one display value or a tuple of accepted values; empty clears the filter."""
        if value:
            self.column_filters[column] = tuple(value) if isinstance(value, (tuple, list)) else (value,)
        else:
            self.column_filters.pop(column, None)
        self.invalidateFilter()

    def filterAcceptsRow(self, source_row: int, source_parent: QModelIndex) -> bool:
        m = self.sourceModel()
        for col, wanted in self.column_filters.items():
            if m.data(m.index(source_row, col, source_parent)) not in wanted:
                return False
        if not self.text:
            return True
        return any(self.text in str(m.data(m.index(source_row, c, source_parent))).lower()
                   for c in range(m.columnCount()))

    def lessThan(self, left: QModelIndex, right: QModelIndex) -> bool:
        a, b = left.data(SORT_ROLE), right.data(SORT_ROLE)
        try:
            return a < b
        except TypeError:
            return str(a) < str(b)


class PillDelegate(QStyledItemDelegate):
    def __init__(self, tokens: dict, parent=None):
        super().__init__(parent)
        self.tokens = tokens

    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index: QModelIndex) -> None:
        if index.data(KIND_ROLE) != "pill" or index.data() in (None, "—"):
            super().paint(painter, option, index)
            return
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        opt.text = ""
        opt.widget.style().drawControl(QStyle.CE_ItemViewItem, opt, painter, opt.widget)
        text = index.data()
        fg, bg = tone_colors(self.tokens, text)
        font = QFont(option.font)
        font.setPixelSize(12)
        font.setWeight(QFont.Weight.DemiBold)
        fm = QFontMetrics(font)
        w = fm.horizontalAdvance(text) + 26
        h = 22
        rect = QRectF(option.rect.x() + 10, option.rect.center().y() - h / 2 + 1, w, h)
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(bg))
        painter.drawRoundedRect(rect, h / 2, h / 2)
        painter.setBrush(QColor(fg))
        painter.drawEllipse(QRectF(rect.x() + 8, rect.center().y() - 3, 6, 6))
        painter.setPen(QPen(QColor(fg)))
        painter.setFont(font)
        painter.drawText(rect.adjusted(18, 0, -4, 0), Qt.AlignVCenter | Qt.AlignLeft, text)
        painter.restore()

    def sizeHint(self, option, index) -> QSize:
        s = super().sizeHint(option, index)
        return QSize(s.width() + 30, max(s.height(), 44))


class DataTable(QTableView):
    def __init__(self, model: RowTableModel, tokens: dict):
        super().__init__()
        self.source = model
        self.proxy = FilterProxy()
        self.proxy.setSourceModel(model)
        self.setModel(self.proxy)
        self.delegate = PillDelegate(tokens, self)
        self.setItemDelegate(self.delegate)
        self.setSortingEnabled(True)
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.setShowGrid(False)
        self.setWordWrap(False)
        self.setMouseTracking(True)
        self.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.verticalHeader().setVisible(False)
        self.verticalHeader().setDefaultSectionSize(44)
        hh = self.horizontalHeader()
        hh.setHighlightSections(False)
        hh.setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        hh.setSectionResizeMode(QHeaderView.Interactive)
        hh.setStretchLastSection(True)
        hh.setMinimumHeight(40)
        for i, c in enumerate(model.columns):
            self.setColumnWidth(i, c.width)
        self.sortByColumn(0, Qt.AscendingOrder)

    def set_tokens(self, tokens: dict) -> None:
        self.delegate.tokens = tokens
        self.source.tokens = tokens
        self.viewport().update()

    def selected_rows(self) -> list[Any]:
        rows = {self.proxy.mapToSource(i).row() for i in self.selectionModel().selectedRows()}
        return [self.source.row_at(r) for r in sorted(rows)]
