"""Entry point for the Immigration Tracker desktop app."""
from __future__ import annotations

import logging
import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication, QMessageBox

from immigration_tracker.db import Database, default_db_path
from immigration_tracker.excel_io import import_workbook
from immigration_tracker.services import TrackerService
from immigration_tracker.ui.main_window import MainWindow
from immigration_tracker.ui.theme import FONT_FAMILIES

WORKBOOK_NAME = "Expatriate Quota & CERPAC Tracker.xlsx"


def _seed_if_empty(db: Database) -> None:
    """First run: load the Excel tracker sitting next to the app, if present."""
    if db.eq_positions() or db.quotas():
        return
    base = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent.parent
    bundled = Path(getattr(sys, "_MEIPASS", base))
    for candidate in (base / WORKBOOK_NAME, bundled / WORKBOOK_NAME, Path.cwd() / WORKBOOK_NAME):
        if candidate.exists():
            try:
                rep = import_workbook(str(candidate))
                db.replace_all(rep.quotas, rep.positions)
            except Exception:  # first-run convenience only; the user can still import manually
                logging.getLogger(__name__).exception("Auto-import of %s failed", candidate)
            return


def _install_error_handler() -> None:
    """Log unexpected errors and show a friendly message instead of silently failing."""
    log_file = default_db_path().with_name("error.log")
    logging.basicConfig(filename=str(log_file), level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    def handler(exc_type, exc, tb):
        logging.getLogger("immigration_tracker").error("Unhandled error", exc_info=(exc_type, exc, tb))
        if QApplication.instance() is not None:
            QMessageBox.critical(None, "Something went wrong",
                                 "The last action could not be completed, but your data is safe.\n\n"
                                 f"Details: {exc}\n\nA log was written to:\n{log_file}")

    sys.excepthook = handler


def run_headless_alerts() -> int:
    """Invoked by the Windows scheduled task: send due reminders without opening the UI."""
    from immigration_tracker.notifications import run_alerts, setup_file_logging
    setup_file_logging()
    db = Database()
    return 1 if run_alerts(db, TrackerService(db)).error else 0


def main() -> int:
    if "--send-alerts" in sys.argv:
        return run_headless_alerts()
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(sys.argv)
    app.setApplicationName("Immigration Tracker")
    app.setStyle("Fusion")
    font = QFont()
    font.setFamilies(FONT_FAMILIES)
    font.setPointSizeF(9.75)
    app.setFont(font)
    _install_error_handler()

    db = Database()
    if db.recovered_from:
        QMessageBox.warning(None, "Data file was damaged",
                            "The tracker's data file could not be opened, so a fresh one was created. "
                            "Use Data & Settings → Restore previous data, or re-import your Excel tracker.\n\n"
                            f"The damaged file was kept at:\n{db.recovered_from}")
    _seed_if_empty(db)
    window = MainWindow(TrackerService(db))
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
