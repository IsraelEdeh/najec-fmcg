"""Converts 'Client Guide - Immigration Tracker.md' into a single self-contained HTML page.

Run from anywhere:  python app\\make_guide_html.py
The HTML (no external files) is written next to the Markdown and can be opened in any browser,
emailed, or uploaded to SharePoint / an intranet page.
"""
from __future__ import annotations

import html
import re
import sys
from datetime import date
from pathlib import Path

import markdown

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "Client Guide - Immigration Tracker.md"
TARGET = SOURCE.with_suffix(".html")

CSS = """
:root { --brand:#1f3a5f; --accent:#2e6bd6; --text:#1d2939; --muted:#667085; --line:#e4e7ec; --bg:#f6f8fb; }
* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body { margin:0; font:15px/1.6 "Segoe UI", system-ui, -apple-system, Roboto, Arial, sans-serif; color:var(--text);
       background:var(--bg); }
header { background:var(--brand); color:#fff; padding:28px 32px; }
header h1 { margin:0; font-size:26px; font-weight:600; }
header p { margin:6px 0 0; opacity:.8; font-size:13px; }
.layout { display:flex; max-width:1200px; margin:0 auto; gap:32px; padding:24px 32px 64px; }
nav { flex:0 0 240px; position:sticky; top:16px; align-self:flex-start; max-height:calc(100vh - 32px);
      overflow:auto; background:#fff; border:1px solid var(--line); border-radius:10px; padding:16px; }
nav b { display:block; font-size:12px; text-transform:uppercase; letter-spacing:.06em; color:var(--muted);
        margin-bottom:8px; }
nav a { display:block; color:var(--text); text-decoration:none; padding:5px 8px; border-radius:6px; font-size:14px; }
nav a:hover { background:var(--bg); color:var(--accent); }
main { flex:1; min-width:0; background:#fff; border:1px solid var(--line); border-radius:10px; padding:8px 36px 36px; }
h2 { color:var(--brand); font-size:21px; margin:36px 0 12px; padding-top:12px; border-top:1px solid var(--line);
     scroll-margin-top:16px; }
main > h2:first-of-type { border-top:none; }
h3 { font-size:17px; margin:24px 0 8px; scroll-margin-top:16px; }
a { color:var(--accent); }
code { background:#f2f4f7; border:1px solid var(--line); border-radius:4px; padding:1px 5px; font-size:13px;
       font-family:Consolas, "Cascadia Mono", monospace; }
.table-wrap { overflow-x:auto; margin:12px 0 20px; }
table { width:100%; border-collapse:collapse; font-size:14px; }
th { background:var(--brand); color:#fff; text-align:left; font-weight:600; }
th, td { padding:9px 12px; border:1px solid var(--line); vertical-align:top; }
tbody tr:nth-child(even) { background:#fafbfc; }
blockquote { margin:16px 0; padding:12px 16px; background:#fff8e6; border-left:4px solid #f5a524; border-radius:6px; }
blockquote p { margin:0; }
hr { display:none; }
.back { display:inline-block; margin-top:28px; font-size:13px; }
@media (max-width: 860px) {
  .layout { flex-direction:column; padding:16px; }
  nav { position:static; max-height:none; width:100%; }
  main { padding:4px 18px 24px; }
}
@media print {
  body { background:#fff; }
  header { background:#fff; color:var(--brand); border-bottom:2px solid var(--brand); padding:0 0 12px; }
  nav, .back { display:none; }
  .layout { display:block; padding:0; }
  main { border:none; padding:0; }
  h2 { break-after:avoid; }
  table, blockquote { break-inside:avoid; }
  .table-wrap { overflow:visible; }
  th { background:#e8edf5 !important; color:#000; }
}
"""


def build() -> Path:
    text = SOURCE.read_text(encoding="utf-8")
    title_match = re.match(r"#\s+(.+)", text)
    title = title_match.group(1).strip() if title_match else "Client Guide"
    body_md = text[title_match.end():] if title_match else text
    md = markdown.Markdown(extensions=["tables", "toc", "sane_lists"],
                           extension_configs={"toc": {"toc_depth": "2"}})
    body = md.convert(body_md).replace("<table>", '<div class="table-wrap"><table>').replace("</table>",
                                                                                            "</table></div>")
    links = "".join(f'<a href="#{t["id"]}">{html.escape(t["name"])}</a>' for t in md.toc_tokens)
    page = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(title)}</title>
<style>{CSS}</style>
</head>
<body>
<header id="top"><h1>{html.escape(title)}</h1><p>Last updated {date.today():%d %B %Y}</p></header>
<div class="layout">
<nav aria-label="Contents"><b>Contents</b>{links}</nav>
<main>
{body}
<a class="back" href="#top">&uarr; Back to top</a>
</main>
</div>
</body>
</html>
"""
    TARGET.write_text(page, encoding="utf-8")
    return TARGET


if __name__ == "__main__":
    if not SOURCE.exists():
        sys.exit(f"Guide not found: {SOURCE}")
    print(f"Written: {build()}")
