"""Tests for multi-client management."""
import pytest
from datetime import date, timedelta
from pathlib import Path

from immigration_tracker.db import Database, Client, ClientUser
from immigration_tracker.client_manager import ClientManager, ClientDashboard
from immigration_tracker import rules as R


TODAY = date(2026, 11, 16)


def test_add_client(tmp_path):
    """Test adding a new client."""
    db = Database(tmp_path / "test.db")
    
    # Add a client
    client_id = db.add_client("Acme Corp", "Oil & Gas")
    assert client_id > 0
    
    # Verify client was added
    clients = db.clients()
    assert len(clients) == 1
    assert clients[0].name == "Acme Corp"
    assert clients[0].industry == "Oil & Gas"
    assert clients[0].status == "active"


def test_client_users(tmp_path):
    """Test adding and managing client users."""
    db = Database(tmp_path / "test.db")
    
    # Add a client
    client_id = db.add_client("Test Corp", "Energy")
    
    # Add users with different roles
    owner_id = db.add_client_user(client_id, "owner@example.com", "John Doe", "Owner")
    manager_id = db.add_client_user(client_id, "manager@example.com", "Jane Smith", "Manager")
    partner_id = db.add_client_user(client_id, "partner@example.com", "Bob Johnson", "Partner")
    
    # Retrieve users
    users = db.client_users(client_id)
    assert len(users) == 3
    
    # Verify roles
    owner = next(u for u in users if u.role == "Owner")
    assert owner.email == "owner@example.com"
    
    managers = [u for u in users if u.role == "Manager"]
    assert len(managers) == 1
    assert managers[0].email == "manager@example.com"


def test_archive_client(tmp_path):
    """Test archiving a client."""
    db = Database(tmp_path / "test.db")
    
    # Add and archive a client
    client_id = db.add_client("Archive Me", "Test")
    db.archive_client(client_id)
    
    # Active clients should be empty
    active_clients = db.clients(active_only=True)
    assert len(active_clients) == 0
    
    # All clients should include the archived one
    all_clients = db.clients(active_only=False)
    archived = next(c for c in all_clients if c.id == client_id)
    assert archived.status == "archived"
    assert archived.archived_at is not None


def test_client_settings(tmp_path):
    """Test client-specific reminder settings."""
    db = Database(tmp_path / "test.db")
    
    client_id = db.add_client("Settings Test", "Test")
    
    # Set custom escalation days
    settings = {
        "escalate_owner_days": 2,
        "escalate_manager_days": 5,
        "escalate_partner_days": 10,
        "notify_enabled": 1,
        "notify_thresholds": "14,7,3,1",
    }
    db.set_client_settings(client_id, settings)
    
    # Retrieve and verify
    retrieved = db.client_settings(client_id)
    assert retrieved["escalate_owner_days"] == 2
    assert retrieved["escalate_manager_days"] == 5
    assert retrieved["escalate_partner_days"] == 10
    assert retrieved["notify_thresholds"] == "14,7,3,1"


def test_client_manager_dashboard(tmp_path):
    """Test building a client dashboard."""
    db = Database(tmp_path / "test.db")
    
    # Set up a client
    client_id = db.add_client("Dashboard Test", "Energy")
    db.add_client_user(client_id, "owner@example.com", "Owner", "Owner")
    db.add_client_user(client_id, "manager@example.com", "Manager", "Manager")
    
    # Create manager and get dashboard
    mgr = ClientManager(db, today=TODAY)
    dashboard = mgr.get_client_dashboard(client_id)
    
    assert dashboard.client_id == client_id
    assert dashboard.client_name == "Dashboard Test"
    assert len(dashboard.users) == 2
    assert dashboard.owner is not None
    assert len(dashboard.managers) == 1
    assert len(dashboard.partners) == 0


def test_reminder_recipient_routing(tmp_path):
    """Test escalation stage recipient routing."""
    db = Database(tmp_path / "test.db")
    
    client_id = db.add_client("Escalation Test", "Energy")
    db.add_client_user(client_id, "owner@example.com", "Owner", "Owner")
    db.add_client_user(client_id, "manager@example.com", "Manager", "Manager")
    db.add_client_user(client_id, "partner@example.com", "Partner", "Partner")
    
    mgr = ClientManager(db)
    
    # Stage 0: Owner only
    stage0 = mgr.get_reminder_recipients(client_id, escalation_stage=0)
    assert stage0["to"] == ["owner@example.com"]
    assert stage0["cc"] == []
    
    # Stage 1: Manager, CC owner
    stage1 = mgr.get_reminder_recipients(client_id, escalation_stage=1)
    assert stage1["to"] == ["manager@example.com"]
    assert "owner@example.com" in stage1["cc"]
    
    # Stage 2: Partner, CC owner and managers
    stage2 = mgr.get_reminder_recipients(client_id, escalation_stage=2)
    assert stage2["to"] == ["partner@example.com"]
    assert "owner@example.com" in stage2["cc"]
    assert "manager@example.com" in stage2["cc"]


def test_multiple_clients_isolation(tmp_path):
    """Test that clients are properly isolated."""
    db = Database(tmp_path / "test.db")
    
    # Create two clients
    client1_id = db.add_client("Client 1", "Energy")
    client2_id = db.add_client("Client 2", "Finance")
    
    # Add different users to each
    db.add_client_user(client1_id, "user1@example.com", "User 1", "Owner")
    db.add_client_user(client2_id, "user2@example.com", "User 2", "Owner")
    
    # Verify isolation
    users1 = db.client_users(client1_id)
    users2 = db.client_users(client2_id)
    
    assert len(users1) == 1
    assert len(users2) == 1
    assert users1[0].email == "user1@example.com"
    assert users2[0].email == "user2@example.com"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])


# --- every record belongs to a client ------------------------------------------------

def _eq(title, client_id, cerpac_days=3):
    from immigration_tracker.db import EQPosition
    return EQPosition(None, 1, title, date(2024, 1, 1), date(2024, 1, 1), "Expat 1",
                      cerpac_expiry=TODAY + timedelta(days=cerpac_days), client_id=client_id)


def test_records_reminders_and_teams_are_isolated_per_client(tmp_path, monkeypatch):
    from immigration_tracker import notifications as N
    from immigration_tracker.services import TrackerService
    db = Database(tmp_path / "t.db")
    a, b = db.add_client("Acme"), db.add_client("Bravo")
    db.save_eq(_eq("ENGINEER", a))
    db.save_eq(_eq("ENGINEER", b))  # same title at another client must not share reminders
    db.add_client_user(a, "owner@acme.com", "", "Owner")
    db.add_client_user(b, "owner@bravo.com", "", "Owner")
    assert [p.rec.title for p in TrackerService(db, TODAY, a).eq_rows] == ["ENGINEER"]
    assert len(TrackerService(db, TODAY).eq_rows) == 2  # all clients
    db.set_setting("notify_kinds", R.EV_CERPAC_EXPIRY)
    mails = []
    monkeypatch.setattr(N, "send_email", lambda db_, to, s, h, t, cc=None: mails.append((to, s)))
    # The screen shows Acme only, but the run covers every client.
    res = N.run_alerts(db, TrackerService(db, TODAY, a), require_enabled=False)
    assert res.sent == 2
    assert sorted((to[0], s.split(":")[0]) for to, s in mails) == [
        ("owner@acme.com", "Immigration Tracker · Acme"), ("owner@bravo.com", "Immigration Tracker · Bravo")]
    assert {r["client_id"] for r in db.sent_alerts()} == {a, b}

    db.archive_client(b)
    assert len(TrackerService(db, TODAY).eq_rows) == 1  # archived clients drop out of every view


def test_upgrade_moves_existing_data_into_default_client_without_resending(tmp_path, monkeypatch):
    import sqlite3
    from immigration_tracker import notifications as N
    from immigration_tracker.db import DEFAULT_CLIENT
    from immigration_tracker.services import TrackerService
    path = tmp_path / "old.db"
    db = Database(path)
    db.save_eq(_eq("ENGINEER", None))
    db.add_recipient("ops@example.com", "Ops", "Manager")
    db.set_setting("notify_kinds", R.EV_CERPAC_EXPIRY)
    monkeypatch.setattr(N, "send_email", lambda *a, **k: None)
    db.add_client_user(db.default_client_id(), "x@example.com", "", "Owner")
    assert N.run_alerts(db, TrackerService(db, TODAY), require_enabled=False).sent == 1
    key = N.matter_key(TrackerService(db, TODAY).events[0])
    db.set_matter_status(key, "In progress")
    # Make it look like a v6 database: no clients, keys without the client prefix.
    c = db.conn
    with c:
        for t in ("eq_positions", "quotas", "activity_log", "sent_alerts"):
            c.execute(f"UPDATE {t} SET client_id = NULL")
        c.execute("DELETE FROM client_users")
        c.execute("DELETE FROM clients")
        c.execute("UPDATE sent_alerts SET event_key = substr(event_key, instr(event_key, '|') + 1)")
        c.execute("UPDATE matter_status SET matter = substr(matter, instr(matter, '|') + 1)")
        c.execute("PRAGMA user_version = 6")
    c.close()

    db = Database(path)
    clients = db.clients()
    assert [cl.name for cl in clients] == [DEFAULT_CLIENT]
    cid = clients[0].id
    assert [p.client_id for p in db.eq_positions()] == [cid]
    assert [(u.email, u.role) for u in db.client_users(cid)] == [("ops@example.com", "Manager")]
    svc = TrackerService(db, TODAY)
    assert N.pending_alerts(db, svc) == []  # already sent before the upgrade: not sent again
    assert db.matter_statuses() == {N.matter_key(svc.events[0]): "In progress"}
    assert sqlite3.connect(path).execute("PRAGMA user_version").fetchone()[0] == 7
