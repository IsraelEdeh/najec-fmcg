﻿from datetime import date
from pathlib import Path

import openpyxl
import pytest

from immigration_tracker.db import Database, EQPosition, Quota
from immigration_tracker.excel_io import ImportFailed, export_workbook, import_workbook

WORKBOOK = Path(__file__).resolve().parents[2] / "Expatriate Quota & CERPAC Tracker.xlsx"


def _save(tmp_path, build) -> str:
    wb = openpyxl.Workbook()
    build(wb.active)
    path = tmp_path / "book.xlsx"
    wb.save(path)
    return str(path)


def test_unrelated_workbook_is_rejected_cleanly(tmp_path):
    path = _save(tmp_path, lambda ws: ws.append(["Name", "Amount"]))
    with pytest.raises(ImportFailed, match="EQ POSITION TITLE"):
        import_workbook(path)


def test_non_excel_file_is_rejected_cleanly(tmp_path):
    bad = tmp_path / "fake.xlsx"
    bad.write_text("not a workbook")
    with pytest.raises(ImportFailed, match="can't be read"):
        import_workbook(str(bad))


def test_missing_required_column_is_reported(tmp_path):
    path = _save(tmp_path, lambda ws: ws.append(["S/N", "EQ POSITION TITLE", "FIRST GRANT"]))
    with pytest.raises(ImportFailed, match="MOST RECENT FMI APPROVAL"):
        import_workbook(path)


def test_headers_found_anywhere_and_messy_values_tolerated(tmp_path):
    def build(ws):
        ws.title = "Renamed sheet"
        ws.append([])
        ws.append(["S/N", "EQ  Position Title", "First Grant", "Most recent FMI approval", "Expat", "CERPAC Expiry"])
        ws.append(["1", "ENGINEER", "12/12/2024", date(2025, 1, 5), "Jane", "TBD"])
        ws.append([2.0, "ADVISOR", 45658, "not a date", None, None])
        ws.append([None, None, None, None, None, None])
    rep = import_workbook(_save(tmp_path, build))
    a, b = rep.positions
    assert (a.sn, a.first_grant, a.fmi_approval, a.cerpac_expiry) == (1, date(2024, 12, 12), date(2025, 1, 5), None)
    assert (b.sn, b.first_grant, b.fmi_approval) == (2, date(2025, 1, 1), None)
    assert any("ADVISOR" in w for w in rep.warnings)


def test_failed_import_leaves_data_untouched_and_reimport_replaces(tmp_path):
    db = Database(tmp_path / "t.db")
    db.save_eq(EQPosition(None, 1, "KEEP ME", date(2024, 1, 1), date(2024, 1, 1)))
    with pytest.raises(ImportFailed):
        import_workbook(_save(tmp_path, lambda ws: ws.append(["junk"])))
    assert [p.title for p in db.eq_positions()] == ["KEEP ME"]

    db.backup("before-import")
    first = import_workbook(_save(tmp_path, lambda ws: (
        ws.append(["S/N", "EQ POSITION TITLE", "FIRST GRANT", "MOST RECENT FMI APPROVAL"]),
        ws.append([1, "NEW ONE", date(2024, 1, 1), date(2025, 1, 1)]))))
    db.replace_all(first.quotas, first.positions)
    db.replace_all(first.quotas, first.positions)  # importing again must not duplicate or fail
    assert [p.title for p in db.eq_positions()] == ["NEW ONE"]

    db.restore(db.backups()[0])
    assert [p.title for p in db.eq_positions()] == ["KEEP ME"]


@pytest.mark.skipif(not WORKBOOK.exists(), reason="source workbook not present")
def test_original_and_exported_workbooks_reimport(tmp_path):
    rep = import_workbook(str(WORKBOOK))
    out = tmp_path / "export.xlsx"
    export_workbook(str(out), rep.quotas, rep.positions)
    again = import_workbook(str(out))
    assert (len(again.positions), len(again.quotas)) == (len(rep.positions), len(rep.quotas))
    assert [q.category for q in again.quotas] == [q.category for q in rep.quotas]


def test_damaged_database_is_set_aside(tmp_path):
    path = tmp_path / "tracker.db"
    path.write_bytes(b"this is not sqlite" * 100)
    db = Database(path)
    assert db.recovered_from is not None and db.recovered_from.exists()
    assert db.eq_positions() == []


def _eq_book(tmp_path, rows):
    return import_workbook(_save(tmp_path, lambda ws: (
        ws.append(["S/N", "EQ POSITION TITLE", "FIRST GRANT", "MOST RECENT FMI APPROVAL", "EXPAT", "CERPAC EXPIRY"]),
        [ws.append(r) for r in rows])))


def _import(db, rep, remove_missing=False):
    from immigration_tracker.reimport import apply_import, plan_import
    plan = plan_import(db.quotas(), db.eq_positions(), rep.quotas, rep.positions, rep.has_quotas, rep.has_eq)
    return apply_import(db, plan, remove_missing, "book.xlsx")


def test_second_import_updates_in_place_and_keeps_app_data(tmp_path):
    db = Database(tmp_path / "t.db")
    db.save_quota(Quota(None, 1, "QUOTA ONLY IN APP", date(2024, 1, 1), date(2026, 1, 1)))
    _import(db, _eq_book(tmp_path, [[1, "ENGINEER", date(2024, 1, 1), date(2025, 1, 1), "Jane", date(2026, 5, 1)],
                                     [2, "ADVISOR", date(2024, 1, 1), date(2025, 1, 1), None, None]]))
    eng = next(p for p in db.eq_positions() if p.title == "ENGINEER")
    eng.notes = "added in the app"
    db.save_eq(eng)
    eng_id = eng.id
    db.save_eq(EQPosition(None, 9, "ADDED IN APP", date(2024, 1, 1), date(2025, 1, 1)))

    # Second file: ENGINEER renumbered with a new FMI date and a blank CERPAC cell, ADVISOR unchanged, one new row.
    counts = _import(db, _eq_book(tmp_path, [[5, "ENGINEER", date(2024, 1, 1), date(2026, 1, 1), "Jane", None],
                                             [2, "ADVISOR", date(2024, 1, 1), date(2025, 1, 1), None, None],
                                             [3, "MANAGER", date(2024, 1, 1), date(2025, 1, 1), None, None]]))
    assert (counts["New"], counts["Updated"], counts["Unchanged"], counts["Kept"]) == (1, 1, 1, 1)
    by_title = {p.title: p for p in db.eq_positions()}
    assert sorted(by_title) == ["ADDED IN APP", "ADVISOR", "ENGINEER", "MANAGER"]
    eng = by_title["ENGINEER"]
    assert (eng.id, eng.sn, eng.fmi_approval, eng.notes) == (eng_id, 5, date(2026, 1, 1), "added in the app")
    assert eng.cerpac_expiry == date(2026, 5, 1)  # a blank cell in the file doesn't erase a date
    assert [q.title for q in db.quotas()] == ["QUOTA ONLY IN APP"]  # no quota table in the file: untouched
    assert any(r["action"] == "Updated by import" for r in db.activity_logs())

    _import(db, _eq_book(tmp_path, [[2, "ADVISOR", date(2024, 1, 1), date(2025, 1, 1), None, None]]),
            remove_missing=True)
    assert [p.title for p in db.eq_positions()] == ["ADVISOR"]
    assert [q.title for q in db.quotas()] == ["QUOTA ONLY IN APP"]
