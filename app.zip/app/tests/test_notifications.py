from datetime import date, timedelta

from immigration_tracker import notifications as N
from immigration_tracker import rules as R
from immigration_tracker.db import SCHEMA_VERSION, Database, EQPosition
from immigration_tracker.services import TrackerService

TODAY = date(2026, 11, 9)
KINDS = {R.EV_EXPIRY, R.EV_CERPAC_EXPIRY}


def _event(days: int, kind: str = R.EV_CERPAC_EXPIRY, rid: int = 1) -> R.Event:
    return R.Event(TODAY + timedelta(days=days), kind, "ENGINEER", "Expat 1", "CERPAC", rid)


def _thresholds_hit(days: int, sent=frozenset()) -> list[int]:
    return [a.threshold for a in N.due_alerts([_event(days)], TODAY, [7, 3, 1], KINDS, set(sent))]


def test_thresholds_map_to_tightest_window():
    assert _thresholds_hit(8) == []
    assert _thresholds_hit(7) == [7]
    assert _thresholds_hit(5) == [7]
    assert _thresholds_hit(3) == [3]
    assert _thresholds_hit(1) == [1]
    assert _thresholds_hit(0) == [1]
    assert _thresholds_hit(-1) == []


def test_already_sent_is_not_repeated_and_missed_runs_catch_up():
    key = N.event_key(_event(5))
    assert _thresholds_hit(5, {(key, 7)}) == []
    # Run missed between day 7 and day 2: only the 3-day reminder goes out, not a stale 7-day one.
    assert _thresholds_hit(2, {(key, 7)}) == [3]


def test_unselected_kinds_are_ignored():
    assert N.due_alerts([_event(3, R.EV_QUOTA_EXPIRY)], TODAY, [7, 3, 1], KINDS, set()) == []


def test_parse_thresholds_and_email_validation():
    assert N.parse_thresholds("7, 3,1") == [1, 3, 7]
    assert N.parse_thresholds("abc") == [7, 3, 1]
    assert N.valid_email("a.b@deloitte.com")
    assert not N.valid_email("not-an-email")
    assert not N.valid_email("x@y.com; evil@z.com")


def test_email_escapes_html():
    a = N.DueAlert(R.Event(TODAY, R.EV_EXPIRY, "<script>", "Bob & Co", "EQ", 1), 1, 0)
    subject, body_html, _ = N.build_email([a], TODAY)
    assert "<script>" not in body_html and "&lt;script&gt;" in body_html
    assert "1 EQ notification" in subject


def test_run_alerts_sends_once_and_releases_on_failure(tmp_path, monkeypatch):
    db = Database(tmp_path / "t.db")
    db.save_eq(EQPosition(None, 1, "ENGINEER", date(2024, 1, 1), date(2024, 1, 1), "Expat 1",
                          cerpac_expiry=TODAY + timedelta(days=3)))
    db.add_client_user(db.default_client_id(), "ops@example.com", "", "Owner")
    db.set_setting("notify_enabled", "1")
    db.set_setting("notify_kinds", R.EV_CERPAC_EXPIRY)
    svc = TrackerService(db, today=TODAY)
    sent = []

    def fail(*a):
        raise N.DeliveryError("offline")

    monkeypatch.setattr(N, "send_email", fail)
    assert N.run_alerts(db, svc).error == "offline"
    assert db.sent_alert_keys() == set()

    monkeypatch.setattr(N, "send_email", lambda db_, to, s, h, t, cc=None: sent.append((to, s)))
    res = N.run_alerts(db, svc)
    assert res.sent == 1 and sent[0][0] == ["ops@example.com"]
    assert N.run_alerts(db, svc).sent == 0
    assert len(sent) == 1


def _notice(kind: str, when_days: int, expiry_days: int, source: str = "CERPAC") -> R.Event:
    return R.Event(TODAY + timedelta(days=when_days), kind, "ENGINEER", "Expat 1", source, 1,
                   TODAY + timedelta(days=expiry_days))


NOTICES = set(R.NOTICE_KINDS)


def test_notice_sent_once_from_its_date_until_expiry():
    e = _notice(R.EV_EQ_NOTIFY, 0, 213, "EQ")
    due = N.due_alerts([e], TODAY, [7, 3, 1], NOTICES, set())
    assert [(a.threshold, a.days_left, a.is_notice) for a in due] == [(0, 213, True)]
    # Missed run: notice date passed but EQ not yet expired -> still sent (catch-up).
    assert N.due_alerts([_notice(R.EV_EQ_NOTIFY, -30, 183, "EQ")], TODAY, [7], NOTICES, set())
    assert N.due_alerts([_notice(R.EV_EQ_NOTIFY, 1, 214, "EQ")], TODAY, [7], NOTICES, set()) == []
    assert N.due_alerts([_notice(R.EV_EQ_NOTIFY, -300, -1, "EQ")], TODAY, [7], NOTICES, set()) == []
    assert N.due_alerts([e], TODAY, [7], NOTICES, {(N.event_key(e), 0)}) == []


def test_cerpac_one_month_notice_supersedes_four_month():
    four, one = _notice(R.EV_CERPAC_NOTIFY, -60, 20), _notice(R.EV_CERPAC_FINAL_NOTIFY, -10, 20)
    due = N.due_alerts([four, one], TODAY, [7], NOTICES, set())
    assert [a.event.kind for a in due] == [R.EV_CERPAC_FINAL_NOTIFY]
    # Only the 4-month notice reached so far.
    due = N.due_alerts([_notice(R.EV_CERPAC_NOTIFY, -5, 115), _notice(R.EV_CERPAC_FINAL_NOTIFY, 85, 115)],
                       TODAY, [7], NOTICES, set())
    assert [a.event.kind for a in due] == [R.EV_CERPAC_NOTIFY]


def test_v2_settings_are_migrated(tmp_path):
    import sqlite3
    path = tmp_path / "old.db"
    db = Database(path)
    db.set_setting("notify_kinds", "EQ expiry,Renewal lead time,System blackout")
    db.conn.execute("PRAGMA user_version = 2")
    db.conn.close()
    kinds = Database(path).get_setting("notify_kinds").split(",")
    assert kinds[:3] == [R.EV_EXPIRY, R.EV_EQ_NOTIFY, R.EV_BLACKOUT]
    assert R.EV_CERPAC_NOTIFY in kinds and R.EV_CERPAC_FINAL_NOTIFY in kinds
    assert sqlite3.connect(path).execute("PRAGMA user_version").fetchone()[0] == SCHEMA_VERSION


DAYS = {1: 3, 2: 7, 3: 14}


def _stages(waited: int, sent_stages=(), status=None, since=None) -> list[int]:
    e = _notice(R.EV_CERPAC_NOTIFY, -waited, 100)
    first = (TODAY - timedelta(days=waited)).isoformat() + "T08:00:00"
    sent = [(N.event_key(e), N.NOTICE_THRESHOLD, first)]
    sent += [(N.ESC_PREFIX + N.matter_key(e), -s, TODAY.isoformat()) for s in sent_stages]
    statuses = {N.matter_key(e): status} if status else {}
    return [x.stage for x in N.due_escalations([e], sent, statuses, TODAY, DAYS, since)]


def test_escalation_stages_follow_days_and_never_repeat():
    assert _stages(2) == []
    assert _stages(3) == [1]
    assert _stages(7, sent_stages=[1]) == [2]
    assert _stages(14, sent_stages=[1, 2]) == [3]
    assert _stages(30, sent_stages=[1, 2, 3]) == []
    assert _stages(15) == [3]  # PC was off: only the highest stage reached goes out
    assert _stages(8, sent_stages=[3]) == []


def test_in_progress_or_done_stops_escalation_and_done_stops_reminders():
    assert _stages(14, status="In progress") == []
    assert _stages(14, status="Done") == []
    e = _notice(R.EV_EQ_NOTIFY, 0, 213, "EQ")
    assert N.due_alerts([e], TODAY, [7, 3, 1], NOTICES, set(), {N.matter_key(e)}) == []


def test_old_emails_count_from_upgrade_date():
    assert _stages(60, since=TODAY - timedelta(days=4)) == [1]


def test_run_alerts_routes_to_owner_then_manager_then_partner(tmp_path, monkeypatch):
    db = Database(tmp_path / "t.db")
    db.save_eq(EQPosition(None, 1, "ENGINEER", date(2024, 1, 1), date(2024, 1, 1), "Expat 1",
                          cerpac_expiry=TODAY + timedelta(days=100)))
    db.add_client_user(db.default_client_id(), "owner@example.com", "", "Owner")
    db.add_client_user(db.default_client_id(), "manager@example.com", "", "Manager")
    db.set_setting("notify_enabled", "1")
    db.set_setting("notify_kinds", R.EV_CERPAC_NOTIFY)
    db.set_setting("escalate_since", "")
    mails = []
    monkeypatch.setattr(N, "send_email", lambda db_, to, s, h, t, cc=None: mails.append((to, cc or [], s)))

    def run(day):
        return N.run_alerts(db, TrackerService(db, today=TODAY + timedelta(days=day)))

    run(0)
    assert mails[-1][:2] == (["owner@example.com"], [])
    run(3)
    assert mails[-1][:2] == (["owner@example.com"], []) and "still not started" in mails[-1][2]
    run(7)
    assert mails[-1][:2] == (["manager@example.com"], ["owner@example.com"]) and "ESCALATION" in mails[-1][2]
    res = run(14)  # no partner set up yet: warned, and kept pending
    assert "no active Partner" in res.summary() and len(mails) == 3
    db.add_client_user(db.default_client_id(), "partner@example.com", "", "Partner")
    run(15)
    assert mails[-1][:2] == (["partner@example.com"], ["owner@example.com", "manager@example.com"])
    run(16)
    assert len(mails) == 4

    # A new expiry cycle where someone marks the item In progress: no escalation.
    db.set_matter_status(N.matter_key(TrackerService(db, today=TODAY).events[0]), "In progress")
    assert N.pending_escalations(db, TrackerService(db, today=TODAY + timedelta(days=30))) == []
    assert any(r["action"] == "Status changed" for r in db.activity_logs())
