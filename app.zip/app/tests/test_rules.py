from datetime import date, datetime
from pathlib import Path

import openpyxl
import pytest

from immigration_tracker import rules as R
from immigration_tracker.db import Database
from immigration_tracker.excel_io import export_workbook, import_workbook
from immigration_tracker.services import TrackerService

WORKBOOK = Path(__file__).resolve().parents[2] / "Expatriate Quota & CERPAC Tracker.xlsx"
# Date on which Excel last recalculated the cached values in the workbook.
CACHE_TODAY = date(2026, 10, 15)


def test_excel_date_rolls_over_like_excel():
    assert R.add_months(date(2027, 10, 30), -8) == date(2027, 3, 2)
    assert R.add_months(date(2027, 3, 31), -1) == date(2027, 3, 3)
    assert R.add_years(date(2024, 2, 29), 2) == date(2026, 3, 1)


def test_edate_clamps():
    assert R.edate(date(2026, 8, 31), 6) == date(2027, 2, 28)
    assert R.edate(date(2013, 3, 8), 72) == date(2019, 3, 8)


def test_datedif_months():
    assert R.datedif_months(date(2026, 1, 31), date(2026, 2, 28)) == 0
    assert R.datedif_months(date(2026, 10, 15), date(2027, 9, 11)) == 10
    assert R.datedif_months(date(2027, 1, 1), date(2026, 1, 1)) is None


def test_row_sn5_matches_spec():
    c = R.compute_eq(date(2025, 10, 30), date(2025, 10, 30), "Expat 5", date(2027, 6, 28), CACHE_TODAY)
    assert c.expiry == date(2027, 10, 30)
    assert c.validity == date(2029, 10, 30)
    assert c.renewable == R.RENEWABLE
    assert c.blackout_date == date(2027, 4, 30)
    assert c.eq_notification == date(2027, 3, 30)
    assert c.lead_to_blackout == date(2027, 3, 2)
    assert c.cerpac_notification == date(2027, 2, 28)


def test_blank_inputs_do_not_crash():
    c = R.compute_eq(None, None, "", None, CACHE_TODAY)
    assert c.expiry is None and c.cerpac_notification is None and c.vacant


def test_status_progression():
    fg, fmi = date(2025, 1, 1), date(2025, 1, 1)  # expiry 2027-01-01
    assert R.compute_eq(fg, fmi, "x", None, date(2026, 4, 1)).status == R.ST_OK
    assert R.compute_eq(fg, fmi, "x", None, date(2026, 5, 2)).status == R.ST_HEADS_UP
    assert R.compute_eq(fg, fmi, "x", None, date(2026, 6, 2)).status == R.ST_NOTIFY
    assert R.compute_eq(fg, fmi, "x", None, date(2026, 7, 2)).status == R.ST_BLACKOUT
    assert R.compute_eq(fg, fmi, "x", None, date(2027, 1, 2)).status == R.ST_EXPIRED


def _d(v):
    return v.date() if isinstance(v, datetime) else v


@pytest.mark.skipif(not WORKBOOK.exists(), reason="source workbook not present")
def test_matches_excel_cached_values():
    ws = openpyxl.load_workbook(WORKBOOK, data_only=True)["EQ & CERPAC Tracker"]
    checked = 0
    for r in range(8, ws.max_row + 1):
        if not ws[f"B{r}"].value or not isinstance(ws[f"D{r}"].value, datetime):
            continue
        c = R.compute_eq(_d(ws[f"C{r}"].value), _d(ws[f"D{r}"].value), ws[f"N{r}"].value,
                         _d(ws[f"O{r}"].value) if isinstance(ws[f"O{r}"].value, datetime) else None, CACHE_TODAY)
        assert c.expiry == _d(ws[f"E{r}"].value), r
        if isinstance(ws[f"F{r}"].value, datetime):  # 'TBD' for pending NCDMB approvals
            assert c.validity_ncdmb == _d(ws[f"F{r}"].value), r
        assert c.validity == _d(ws[f"G{r}"].value), r
        assert c.renewable == ws[f"H{r}"].value, r
        assert c.blackout == ws[f"I{r}"].value, r
        assert c.blackout_date == _d(ws[f"J{r}"].value), r
        if isinstance(ws[f"K{r}"].value, int):
            assert c.shelf_life_months == ws[f"K{r}"].value, r
        assert c.eq_notification == _d(ws[f"L{r}"].value), r
        assert c.lead_to_blackout == _d(ws[f"M{r}"].value), r
        if isinstance(ws[f"P{r}"].value, datetime):
            assert c.cerpac_notification == _d(ws[f"P{r}"].value), r
        checked += 1
    assert checked >= 30

    q = openpyxl.load_workbook(WORKBOOK, data_only=True)["EEPNL QUOTAS"]
    for r in range(4, q.max_row + 1):
        if isinstance(q[f"D{r}"].value, datetime) and isinstance(q[f"F{r}"].value, datetime):
            qc = R.compute_quota(_d(q[f"D{r}"].value), _d(q[f"E{r}"].value), None, q[f"G{r}"].value, CACHE_TODAY,
                                  lifespan_years=6)  # workbook column F used first grant + 6 years
            if r not in (12, 13):  # rows hard-coded in Excel instead of EDATE
                assert qc.non_renewable_date == _d(q[f"F{r}"].value), r


@pytest.mark.skipif(not WORKBOOK.exists(), reason="source workbook not present")
def test_import_roundtrip(tmp_path):
    rep = import_workbook(str(WORKBOOK))
    assert len(rep.positions) >= 30 and len(rep.quotas) >= 40
    db = Database(tmp_path / "t.db")
    db.replace_all(rep.quotas, rep.positions)
    svc = TrackerService(db, today=CACHE_TODAY)
    assert len(svc.eq_rows) == len(rep.positions)
    assert any(r.quota for r in svc.eq_rows)
    hold = [q for q in db.quotas() if q.movement == "Hold / Moving In"]
    assert hold and all(not q.current_expat for q in hold)
    out = tmp_path / "export.xlsx"
    export_workbook(str(out), db.quotas(), db.eq_positions())
    again = import_workbook(str(out))
    assert len(again.positions) == len(rep.positions)

def test_meeting_example_eq_dates():
    # FMI approval 12 Dec 2026 -> EQ expiry 12 Dec 2028; notice 7 months before, blackout 6 months before.
    c = R.compute_eq(date(2024, 12, 12), date(2026, 12, 12), "x", None, date(2026, 12, 13))
    assert c.expiry == date(2028, 12, 12)
    assert c.eq_notification == date(2028, 5, 12)
    assert c.blackout_date == date(2028, 6, 12)
    assert c.status == R.ST_OK
    assert c.lifecycle == R.LC_FINAL_TERM  # expiry reaches first grant + 4 years


def test_cerpac_notices_at_4_and_1_month():
    exp = date(2027, 3, 27)
    c = R.compute_eq(None, None, "x", exp, date(2026, 11, 26))
    assert (c.cerpac_notification, c.cerpac_final_notification) == (date(2026, 11, 27), date(2027, 2, 27))
    assert c.cerpac_status == R.CERPAC_VALID
    assert R.cerpac_status(exp, date(2026, 11, 27)) == R.CERPAC_NOTIFY
    assert R.cerpac_status(exp, date(2027, 2, 27)) == R.CERPAC_FINAL_NOTIFY
    assert R.cerpac_status(exp, exp) == R.CERPAC_FINAL_NOTIFY
    assert R.cerpac_status(exp, date(2027, 3, 28)) == R.CERPAC_EXPIRED


def test_quota_lifecycle_separates_final_term_from_expired():
    fg, today = date(2024, 1, 1), date(2026, 6, 1)  # lifespan (4 yrs) ends 2028-01-01
    assert R.compute_quota(fg, date(2027, 6, 1), None, "x", today).lifecycle == R.LC_RENEWABLE
    active_final = R.compute_quota(fg, date(2028, 1, 1), None, "x", today)
    assert active_final.lifecycle == R.LC_FINAL_TERM and active_final.status != R.ST_EXPIRED
    assert R.compute_quota(fg, date(2026, 1, 1), None, "x", today).lifecycle == R.LC_EXPIRED_RENEWABLE
    # Expired after the lifespan has run out: cannot be renewed.
    assert R.compute_quota(fg, date(2026, 1, 1), None, "x", date(2028, 2, 1)).lifecycle == R.LC_EXPIRED_FINAL
    # A non-renewable override wins over the computed lifespan.
    assert R.compute_quota(fg, date(2027, 6, 1), date(2027, 1, 1), "x", today).lifecycle == R.LC_FINAL_TERM


def test_quota_status_uses_7_month_notice():
    exp = date(2027, 7, 1)
    assert R.compute_quota(date(2025, 7, 1), exp, None, "x", date(2026, 11, 30)).status == R.ST_OK
    assert R.compute_quota(date(2025, 7, 1), exp, None, "x", date(2026, 12, 1)).status == R.ST_NOTIFY
    assert R.compute_quota(date(2025, 7, 1), exp, None, "x", date(2027, 1, 2)).status == R.ST_BLACKOUT


def test_dashboard_separates_expired_eqs_and_cerpacs(tmp_path):
    from immigration_tracker.db import EQPosition, Quota
    db = Database(tmp_path / "t.db")
    today = date(2026, 11, 16)
    db.save_eq(EQPosition(None, 1, "A", date(2016, 10, 10), date(2024, 10, 9), "x", date(2027, 5, 2)))  # EQ expired
    db.save_eq(EQPosition(None, 2, "B", date(2024, 12, 12), date(2026, 12, 12), "y", date(2026, 10, 1)))  # CERPAC expired
    db.save_quota(Quota(None, 1, "Q", date(2024, 1, 1), date(2028, 1, 1)))  # active, final term: not expired
    tiles = {t.key: t.count for t in TrackerService(db, today=today).tiles()}
    assert tiles["eq_expired"] == 1 and tiles["cerpac_expired"] == 1
    assert tiles["q_expired"] == 0 and tiles["q_final"] == 1
    sources = {(a.source, a.position) for a in TrackerService(db, today=today).action_items()}
    assert sources == {("EQ", "A"), ("CERPAC", "B")}


def test_lifespan_setting_changes_non_renewable_date(tmp_path):
    from immigration_tracker.db import Quota
    db = Database(tmp_path / "t.db")
    db.save_quota(Quota(None, 1, "Q", date(2024, 12, 12), date(2026, 12, 11)))
    assert TrackerService(db, today=CACHE_TODAY).quota_rows[0].calc.non_renewable_date == date(2028, 12, 12)
    db.set_setting("quota_lifespan_years", "6")
    assert TrackerService(db, today=CACHE_TODAY).quota_rows[0].calc.non_renewable_date == date(2030, 12, 12)
