import os
from datetime import date

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
QtWidgets = pytest.importorskip("PySide6.QtWidgets")

from immigration_tracker import rules as R  # noqa: E402
from immigration_tracker.db import Database, EQPosition, Quota  # noqa: E402
from immigration_tracker.services import TrackerService  # noqa: E402

TODAY = date(2026, 11, 16)


@pytest.fixture(scope="module")
def app():
    return QtWidgets.QApplication.instance() or QtWidgets.QApplication([])


def test_dashboard_tiles_open_matching_filtered_lists(app, tmp_path):
    from immigration_tracker.ui.main_window import MainWindow
    db = Database(tmp_path / "t.db")
    db.save_eq(EQPosition(None, 1, "ALPHA", date(2016, 10, 10), date(2024, 10, 9), "x", date(2027, 5, 2)))
    db.save_eq(EQPosition(None, 2, "BRAVO", date(2024, 12, 12), date(2026, 12, 12), "y", date(2026, 12, 1)))
    db.save_eq(EQPosition(None, 3, "CHARLIE", date(2025, 6, 1), date(2025, 6, 1), "z", None))
    db.save_quota(Quota(None, 1, "Q1", date(2024, 1, 1), date(2028, 1, 1)))
    db.save_quota(Quota(None, 2, "Q2", date(2013, 1, 1), date(2025, 1, 1)))
    w = MainWindow(TrackerService(db, today=TODAY))
    dash = w.pages["dashboard"]
    tiles = w.svc.tiles()
    assert {t.key: t.count for t in tiles}["eq_expired"] == 1
    for t in tiles:
        dash._open_tile(t.key)
        assert w.stack.currentWidget().table.proxy.rowCount() == t.count, t.key
    # Opening an action item lands on its page, searched to that position.
    dash.navigate.emit("eq", {"search": "BRAVO"})
    assert w.search.text() == "BRAVO" and w.stack.currentWidget() is w.pages["eq"]
    assert w.pages["eq"].table.proxy.rowCount() == 1
    w.close()


def test_dashboard_type_slicer_filters_report(app, tmp_path):
    from immigration_tracker.ui.main_window import MainWindow
    db = Database(tmp_path / "t.db")
    db.save_eq(EQPosition(None, 1, "ALPHA", date(2016, 10, 10), date(2024, 10, 9), "x", date(2027, 5, 2)))
    db.save_quota(Quota(None, 2, "Q2", date(2013, 1, 1), date(2025, 1, 1)))
    w = MainWindow(TrackerService(db, today=TODAY))
    dash = w.pages["dashboard"]
    items = w.svc.action_items()
    for src in ("", R.SRC_EQ, R.SRC_QUOTA):
        dash.set_type(src)
        expected = sum(1 for a in items if not src or a.source == src)
        assert dash.actions_table.proxy.rowCount() == expected
        assert dash.metrics["actions"].value.text() == str(expected)
    assert dash.quota_card.isHidden() is False and dash.pie_card.isHidden() is True
    w.close()


def test_bulk_fmi_update_recalculates_eq_expiry(tmp_path):
    db = Database(tmp_path / "t.db")
    ids = [db.save_eq(EQPosition(None, i, f"P{i}", date(2024, 12, 12), date(2024, 12, 12), "x")) for i in (1, 2)]
    db.set_fmi_approval(ids, date(2026, 12, 12))
    rows = TrackerService(db, today=TODAY).eq_rows
    assert [r.calc.expiry for r in rows] == [date(2028, 12, 12)] * 2
    assert rows[0].calc.status == R.ST_OK


def test_clients_tab_dropdown_only_when_multiple_and_member_form(app, tmp_path):
    from immigration_tracker.ui.dialogs import TeamMemberDialog
    from immigration_tracker.ui.main_window import MainWindow
    db = Database(tmp_path / "t.db")
    w = MainWindow(TrackerService(db, today=TODAY))
    data = w.pages["data"]
    assert data.client_picker.isHidden() and not data.clients_empty.isHidden()

    a = db.add_client("Acme", "Mining & metals")
    data._reload_clients()
    assert data.client_picker.isHidden() and not data.client_single.isHidden()
    assert data.client_warning.text().startswith("No active Owner")

    b = db.add_client("Bravo")
    data._reload_clients(select_id=b)
    assert not data.client_picker.isHidden() and data.client_picker.count() == 2
    assert data.client_picker.currentData() == b

    db.add_client_user(a, "owner@acme.com", "Ola", "Owner")
    clients = db.clients()
    dlg = TeamMemberDialog(clients, a, emails_for=lambda cid: {u.email for u in db.client_users(cid)})
    assert dlg.client.parent() is not None and dlg.client_id == a  # client dropdown shown, preselected
    dlg.email.setText("not-an-email")
    assert "valid email" in dlg.validate()
    dlg.email.setText("OWNER@acme.com")
    assert "already a team member" in dlg.validate()
    dlg.client.setCurrentIndex(dlg.client.findData(b))
    assert dlg.validate() is None and dlg.client_id == b

    single = TeamMemberDialog(clients[:1], None)
    assert single.client_id == clients[0].id
    w.close()


def test_sidebar_client_switch_scopes_every_page(app, tmp_path):
    from immigration_tracker.ui.main_window import ALL_CLIENTS, MainWindow
    db = Database(tmp_path / "t.db")
    a, b = db.add_client("Acme"), db.add_client("Bravo")
    db.save_eq(EQPosition(None, 1, "ALPHA", date(2016, 10, 10), date(2024, 10, 9), "x", client_id=a))
    db.save_eq(EQPosition(None, 1, "BRAVO ONE", date(2024, 12, 12), date(2026, 12, 12), "y", client_id=b))
    db.save_eq(EQPosition(None, 2, "BRAVO TWO", date(2024, 12, 12), date(2026, 12, 12), "z", client_id=b))
    w = MainWindow(TrackerService(db, today=TODAY))
    eq = w.pages["eq"]
    assert w.client_switch.findData(ALL_CLIENTS) >= 0
    w.set_client(b)
    assert eq.table.proxy.rowCount() == 2 and eq.table.isColumnHidden(0)
    assert db.get_setting("current_client") == str(b)
    w.client_switch.setCurrentIndex(w.client_switch.findData(ALL_CLIENTS))
    assert w.svc.client_id is None and eq.table.proxy.rowCount() == 3 and not eq.table.isColumnHidden(0)
    assert w.pages["dashboard"].metrics["records"].value.text() == "3"
    # Choosing a client on the Clients tab switches the whole app.
    w.pages["data"].client_chosen.emit(a)
    assert w.svc.client_id == a and eq.table.proxy.rowCount() == 1
    w.close()
